"""Register the Tajawal Arabic font in pubspec.yaml if the TTFs were downloaded."""
import os, sys
W = {"Regular": 400, "Medium": 500, "Bold": 700, "ExtraBold": 800}
d = "assets/fonts"
ok = True
for w in W:
    f = f"{d}/Tajawal-{w}.ttf"
    if not os.path.isfile(f) or os.path.getsize(f) < 20000:
        ok = False; break
    if open(f, "rb").read(4) not in (b"\x00\x01\x00\x00", b"true", b"OTTO"):
        ok = False; break
if not ok:
    print("fonts missing/invalid; using default font"); sys.exit(0)
s = open("pubspec.yaml").read()
if "AppArabic" in s:
    sys.exit(0)
block = "  uses-material-design: true\n  fonts:\n    - family: AppArabic\n      fonts:\n"
block += "        - asset: assets/fonts/Tajawal-Regular.ttf\n"
for w, n in W.items():
    if n != 400:
        block += f"        - asset: assets/fonts/Tajawal-{w}.ttf\n          weight: {n}\n"
s = s.replace("  uses-material-design: true\n", block, 1)
open("pubspec.yaml", "w").write(s)
print("fonts registered")
