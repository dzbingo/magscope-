"""Generates the Sniper-Dz launcher icon: a scope reticle with magnetic field arcs.

Run from the project root:  python3 tool/make_icon.py
Writes assets/icon/icon.png and assets/icon/icon_fg.png
"""
import math
import os

from PIL import Image, ImageDraw, ImageFilter


def disable_lint():
    """Android lint crashes on some plugins (camera) with the CI's JDK. Lint is
    only a code check, so switch it off for the build with a Gradle init script.
    This runs here because this script is already part of the workflow."""
    home = os.environ.get("GRADLE_USER_HOME") or os.path.join(os.path.expanduser("~"), ".gradle")
    d = os.path.join(home, "init.d")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "nolint.gradle"), "w") as f:
        f.write(
            "allprojects {\n"
            "  tasks.configureEach { t ->\n"
            "    if (t.name.startsWith('lint')) { t.enabled = false }\n"
            "  }\n"
            "}\n"
        )
    print("lint disabled via", d)


disable_lint()

S = 2048  # drawn at 2x, then downscaled for smooth edges
OUT = 1024
BG1 = (8, 7, 5)
BG2 = (46, 36, 16)
AMBER = (226, 180, 82, 255)
AMBER_SOFT = (226, 180, 82, 70)
VIOLET = (255, 224, 138, 255)
WHITE = (232, 236, 242, 255)


def background():
    img = Image.new("RGBA", (S, S), BG1 + (255,))
    px = img.load()
    cx = cy = S / 2
    maxd = math.hypot(cx, cy)
    for y in range(0, S, 2):
        for x in range(0, S, 2):
            d = math.hypot(x - cx, y - cy) / maxd
            t = max(0.0, 1.0 - d * 1.5)
            c = tuple(int(BG1[i] + (BG2[i] - BG1[i]) * t) for i in range(3)) + (255,)
            px[x, y] = c
            if x + 1 < S:
                px[x + 1, y] = c
            if y + 1 < S:
                px[x, y + 1] = c
                if x + 1 < S:
                    px[x + 1, y + 1] = c
    return img


def mark(scale):
    """Transparent layer with the reticle drawn around the canvas centre."""
    layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx = cy = S / 2
    k = scale * 2  # canvas is 2x

    def ring(r, w, col):
        d.ellipse([cx - r * k, cy - r * k, cx + r * k, cy + r * k],
                  outline=col, width=max(1, int(w * k)))

    # outer scope ring + thin inner ring
    ring(380, 34, AMBER)
    ring(300, 8, VIOLET)

    # magnetic field arcs inside the scope (dipole look)
    for rx, ry, col in ((95, 60, AMBER), (160, 105, VIOLET), (225, 150, AMBER)):
        w = int(14 * k)
        d.arc([cx - rx * k - 60 * k, cy - ry * k, cx + rx * k - 60 * k, cy + ry * k],
              start=105, end=255, fill=col, width=w)
        d.arc([cx - rx * k + 60 * k, cy - ry * k, cx + rx * k + 60 * k, cy + ry * k],
              start=-75, end=75, fill=col, width=w)

    # crosshair with a gap around the centre
    gap, long_ = 70, 440
    for ang in (0, 90, 180, 270):
        a = math.radians(ang)
        x1, y1 = cx + math.cos(a) * gap * k, cy + math.sin(a) * gap * k
        x2, y2 = cx + math.cos(a) * long_ * k, cy + math.sin(a) * long_ * k
        d.line([x1, y1, x2, y2], fill=WHITE, width=int(12 * k))

    # centre dot
    r = 26
    d.ellipse([cx - r * k, cy - r * k, cx + r * k, cy + r * k], fill=AMBER)

    # soft glow behind everything
    glow = layer.filter(ImageFilter.GaussianBlur(28 * k))
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out = Image.alpha_composite(out, glow)
    out = Image.alpha_composite(out, layer)
    return out


def main():
    os.makedirs("assets/icon", exist_ok=True)

    full = Image.alpha_composite(background(), mark(1.0))
    full.resize((OUT, OUT), Image.LANCZOS).save("assets/icon/icon.png")

    # Adaptive icon foreground: transparent, mark kept in the safe zone.
    fg = mark(0.74)
    fg.resize((OUT, OUT), Image.LANCZOS).save("assets/icon/icon_fg.png")

    # 512 x 512 store/launcher icon
    full.resize((512, 512), Image.LANCZOS).save("assets/icon/icon_512.png")


if __name__ == "__main__":
    main()
