"""Generates MagScope's original launcher icon (magnetic field lines around a core).

Run from the project root:  python3 tool/make_icon.py
Writes assets/icon/icon.png and assets/icon/icon_fg.png
"""
import math
import os

from PIL import Image, ImageDraw

SIZE = 1024
BG = (14, 17, 22, 255)
AMBER = (255, 164, 58, 255)
VIOLET = (139, 124, 255, 255)


def draw_mark(draw, cx, cy, scale):
    # Field lines: nested ellipses left and right of the core, like a dipole.
    for i, (rx, ry) in enumerate([(150, 90), (250, 170), (350, 250)]):
        color = AMBER if i % 2 == 0 else VIOLET
        w = int(26 * scale)
        rx, ry = rx * scale, ry * scale
        draw.arc([cx - rx - 120 * scale, cy - ry, cx + rx - 120 * scale, cy + ry],
                 start=100, end=260, fill=color, width=w)
        draw.arc([cx - rx + 120 * scale, cy - ry, cx + rx + 120 * scale, cy + ry],
                 start=-80, end=80, fill=color, width=w)
    r = 70 * scale
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=AMBER)
    r2 = 30 * scale
    draw.ellipse([cx - r2, cy - r2, cx + r2, cy + r2], fill=BG)


def main():
    os.makedirs("assets/icon", exist_ok=True)

    full = Image.new("RGBA", (SIZE, SIZE), BG)
    draw_mark(ImageDraw.Draw(full), SIZE / 2, SIZE / 2, 1.0)
    full.save("assets/icon/icon.png")

    # Adaptive icon foreground: transparent, mark kept inside the safe zone.
    fg = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw_mark(ImageDraw.Draw(fg), SIZE / 2, SIZE / 2, 0.62)
    fg.save("assets/icon/icon_fg.png")


if __name__ == "__main__":
    main()
