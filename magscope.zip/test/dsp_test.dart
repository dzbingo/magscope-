import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:magscope/anomaly.dart';
import 'package:magscope/dsp.dart';

/// Total-field anomaly of a small induced magnetic body (point dipole) at
/// depth [z] metres, field inclination [inclDeg], sampled on an n x n grid.
List<double> dipoleGrid(double z, double inclDeg, double cell, int n) {
  final inc = inclDeg * math.pi / 180;
  final fy = math.cos(inc), fz = -math.sin(inc);
  final out = List<double>.filled(n * n, 0);
  for (int y = 0; y < n; y++) {
    for (int x = 0; x < n; x++) {
      final gx = (x - n ~/ 2) * cell, gy = (y - n ~/ 2) * cell;
      final r = math.sqrt(gx * gx + gy * gy + z * z);
      final c = (gy * fy + z * fz) / r;
      out[y * n + x] = 780 + 40 * (3 * c * c - 1) / (r * r * r);
    }
  }
  return out;
}

void main() {
  test('despikeFilter removes a single spike but keeps a real broad peak', () {
    final rnd = math.Random(3);
    final clean = <double>[
      for (int i = 0; i < 80; i++)
        780 + 20 * math.exp(-math.pow((i - 55) / 6.0, 2)) + 0.2 * math.sin(i)
    ];
    final x = <double>[for (final c in clean) c + (rnd.nextDouble() - 0.5) * 0.2];
    x[30] += 60;
    final o = despikeFilter(x, 7, 4.0);
    expect((o[30] - clean[30]).abs(), lessThan(1.0));
    final peakBefore = x.sublist(40).reduce(math.max);
    final peakAfter = o.sublist(40).reduce(math.max);
    expect(peakAfter, greaterThan(peakBefore - 1.0));
  });

  test('estimateDepth on a simulated compact body is within 30%', () {
    for (final incl in <double>[90, 55]) {
      for (final c in <List<double>>[
        <double>[0.5, 0.3],
        <double>[1.0, 0.5],
        <double>[1.5, 0.5],
        <double>[2.0, 0.4],
      ]) {
        final z = c[0], cell = c[1];
        final g = dipoleGrid(z, incl, cell, 41);
        final med = medianOf(g);
        int best = 0;
        for (int i = 0; i < g.length; i++) {
          if ((g[i] - med).abs() > (g[best] - med).abs()) best = i;
        }
        final d = estimateDepth(g, 41, 41, best % 41, best ~/ 41, cell);
        expect(d, isNotNull, reason: 'incl $incl z $z');
        expect(d!.depthM, inInclusiveRange(z * 0.7, z * 1.3),
            reason: 'incl $incl z $z cell $cell -> ${d.depthM}');
      }
    }
  });

  test('Detect.find returns both a metal and a void', () {
    const n = 24;
    final rnd = math.Random(5);
    final g = List<double>.filled(n * n, 0);
    for (int y = 0; y < n; y++) {
      for (int x = 0; x < n; x++) {
        double v = 780 + (rnd.nextDouble() - 0.5) * 0.6;
        v += 30 * math.exp(-(math.pow(x - 6, 2) + math.pow(y - 6, 2)) / 6);
        v -= 30 * math.exp(-(math.pow(x - 17, 2) + math.pow(y - 16, 2)) / 6);
        g[y * n + x] = v;
      }
    }
    final hits = Detect.find(g, n, n, 3.0);
    expect(hits.any((h) => h.deviation > 0 && (h.x - 6).abs() <= 1 && (h.y - 6).abs() <= 1),
        isTrue);
    expect(hits.any((h) => h.deviation < 0 && (h.x - 17).abs() <= 1 && (h.y - 16).abs() <= 1),
        isTrue);
  });

  test('destripeGrid reduces stripes and keeps a large target', () {
    const cols = 14, rows = 14;
    final rnd = math.Random(1);
    final off = <double>[for (int x = 0; x < cols; x++) (rnd.nextDouble() - 0.5) * 6];
    List<double> make(bool blob) => <double>[
          for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++)
              780 +
                  off[x] +
                  (blob && x >= 1 && x <= 6 && y >= 1 && y <= 7 ? 40 : 0)
        ];
    double colSpread(List<double> g) {
      final m = <double>[
        for (int x = 0; x < cols; x++)
          meanOf(<double>[for (int y = 0; y < rows; y++) g[y * cols + x]])
      ];
      return stdOf(m);
    }

    final stripes = make(false);
    expect(colSpread(destripeGrid(stripes, cols, rows)), lessThan(colSpread(stripes)));
    final withBlob = destripeGrid(make(true), cols, rows);
    expect(withBlob[4 * cols + 3] - 780, greaterThan(30));
  });

  test('preCheckVerdict: steady, spikes, drift, too few', () {
    expect(preCheckVerdict(<double>[1, 2, 3]), 'pre_nodata');
    expect(preCheckVerdict(List<double>.filled(30, 128)), 'pre_ok');
    expect(
        preCheckVerdict(<double>[for (int i = 0; i < 30; i++) 128.0 + (i % 3 - 1)]),
        'pre_ok');
    final one = List<double>.filled(30, 128);
    one[5] = 20;
    expect(preCheckVerdict(one), 'pre_ok'); // a single jump is not "repeated"
    final two = List<double>.filled(30, 128);
    two[5] = 20;
    two[17] = 250;
    expect(preCheckVerdict(two), 'pre_spikes');
    expect(preCheckVerdict(<double>[for (int i = 0; i < 30; i++) 100 + i * 0.7]),
        'pre_drift');
  });
}
