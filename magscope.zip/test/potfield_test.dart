import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:magscope/potfield.dart';

/// Induced point dipole (total field), unit moment, depth [z] below the
/// sensor, grid rows running south.
List<double> dipoleGrid(int cols, int rows, double cell, double e0, double n0,
    double z, double incDeg, double decDeg) {
  final ir = incDeg * math.pi / 180, dr = decDeg * math.pi / 180;
  final fN = math.cos(ir) * math.cos(dr),
      fE = math.cos(ir) * math.sin(dr),
      fD = math.sin(ir);
  final out = List<double>.filled(cols * rows, 0.0);
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      final rE = (x - cols / 2 + 0.5) * cell - e0;
      final rN = -(y - rows / 2 + 0.5) * cell - n0;
      final rD = -z;
      final r2 = rE * rE + rN * rN + rD * rD;
      final fr = fN * rN + fE * rE + fD * rD;
      out[y * cols + x] = (3 * fr * fr / r2 - 1) / (r2 * math.sqrt(r2));
    }
  }
  return out;
}

double relErr(List<double> a, List<double> b) {
  double n = 0, d = 0;
  for (int i = 0; i < a.length; i++) {
    n += (a[i] - b[i]) * (a[i] - b[i]);
    d += b[i] * b[i];
  }
  return math.sqrt(n / d);
}

int argMax(List<double> v) {
  int k = 0;
  for (int i = 1; i < v.length; i++) {
    if (v[i] > v[k]) k = i;
  }
  return k;
}

void main() {
  test('upward continuation matches a dipole seen from higher up', () {
    final g = dipoleGrid(20, 20, 0.3, 0.1, -0.1, 0.6, 90, 0);
    final ref = dipoleGrid(20, 20, 0.3, 0.1, -0.1, 0.9, 90, 0);
    final up = upwardContinue(g, 20, 20, 0.3, 0.3);
    expect(relErr(up, ref), lessThan(0.1));
  });

  test('reduction to the pole puts one peak over the source', () {
    final g = dipoleGrid(20, 20, 0.3, 0.2, -0.1, 0.6, 55, 0);
    final ref = dipoleGrid(20, 20, 0.3, 0.2, -0.1, 0.6, 90, 0);
    final out = reduceToPole(g, 20, 20, 0.3, 55, 0);
    expect(relErr(out, ref), lessThan(0.2));
    expect(argMax(out), argMax(ref));
  });

  test('tools are refused on small grids and low inclinations', () {
    final g = List<double>.generate(36, (int i) => i.toDouble());
    expect(identical(upwardContinue(g, 6, 6, 0.3, 0.5), g), isTrue);
    final big = dipoleGrid(12, 12, 0.3, 0, 0, 0.6, 10, 0);
    expect(identical(reduceToPole(big, 12, 12, 0.3, 10, 0), big), isTrue);
  });

  test('dipole fit finds the depth of a clear synthetic target', () {
    const n = 15;
    final g = dipoleGrid(n, n, 0.3, 0.1, -0.05, 0.6, 55, 0);
    double mx = 0;
    for (final v in g) {
      mx = math.max(mx, v.abs());
    }
    final rnd = math.Random(3);
    final data = <double>[
      for (final v in g)
        v / mx * 30 + (rnd.nextDouble() + rnd.nextDouble() - 1) * 0.8
    ];
    final f = inverseFit(data, n, n, n ~/ 2, n ~/ 2, 0.3,
        incDeg: 55, decDeg: 0);
    expect(f.ok, isTrue, reason: f.reason);
    expect((f.depthM - 0.6).abs(), lessThan(0.12));
    expect(f.snr, greaterThan(8));
  });

  test('dipole fit refuses pure noise', () {
    const n = 15;
    final rnd = math.Random(5);
    final data = <double>[
      for (int i = 0; i < n * n; i++)
        (rnd.nextDouble() + rnd.nextDouble() - 1) * 0.8
    ];
    final f = inverseFit(data, n, n, 7, 7, 0.3, incDeg: 55, decDeg: 0);
    expect(f.ok, isFalse);
  });
}
