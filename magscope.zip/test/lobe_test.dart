import 'package:flutter_test/flutter_test.dart';
import 'package:magscope/anomaly.dart';

void main() {
  test('a low next to a strong metal peak is listed as a lobe, not a void', () {
    const cols = 12, rows = 12;
    final g = List<double>.filled(cols * rows, 100.0);
    // small deterministic ripple so the noise estimate is not zero
    for (int i = 0; i < g.length; i++) {
      g[i] += (i % 3 - 1) * 0.1;
    }
    g[6 * cols + 6] += 20; // metal peak
    g[8 * cols + 6] -= 8; // low two cells away
    final kept = Detect.find(g, cols, rows, 2.5);
    final lobes = Detect.lobes(g, cols, rows, 2.5);
    expect(kept.any((a) => a.deviation > 0), isTrue);
    expect(kept.any((a) => a.deviation < 0), isFalse);
    expect(lobes.length, 1);
    expect(lobes.first.x, 6);
    expect(lobes.first.y, 8);
  });

  test('a low far from any metal stays a void and is not a lobe', () {
    const cols = 12, rows = 12;
    final g = List<double>.filled(cols * rows, 100.0);
    for (int i = 0; i < g.length; i++) {
      g[i] += (i % 3 - 1) * 0.1;
    }
    g[2 * cols + 2] -= 8;
    expect(Detect.find(g, cols, rows, 2.5).any((a) => a.deviation < 0), isTrue);
    expect(Detect.lobes(g, cols, rows, 2.5), isEmpty);
  });
}
