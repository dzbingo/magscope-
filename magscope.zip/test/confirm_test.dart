import 'package:flutter_test/flutter_test.dart';
import 'package:magscope/confirm.dart';
import 'package:magscope/dsp.dart';

void main() {
  const first = ConfirmTarget(
      x: 10, y: 10, metal: true, depthM: 1.0, cols: 30, rows: 30,
      cellCm: 30, firstPerp: false);

  ConfirmResult run(List<CellAnomaly> hits, {bool perp = true, int cols = 30}) =>
      judgeConfirmation(
        first: first,
        second: hits,
        depthOf: (CellAnomaly h) => 1.2,
        cols: cols,
        rows: 30,
        cellCm: 30,
        secondPerp: perp,
      );

  test('same kind close by is confirmed', () {
    final r = run(<CellAnomaly>[const CellAnomaly(11, 10, 5)]);
    expect(r.verdict, ConfirmVerdict.confirmed);
    expect(r.depthRatio, closeTo(1.2, 1e-9));
  });
  test('nothing near is not confirmed', () {
    expect(run(<CellAnomaly>[const CellAnomaly(25, 25, 5)]).verdict,
        ConfirmVerdict.notConfirmed);
  });
  test('opposite sign near is a conflict', () {
    expect(run(<CellAnomaly>[const CellAnomaly(10, 11, -5)]).verdict,
        ConfirmVerdict.conflict);
  });
  test('same walking direction and different grid are refused', () {
    expect(run(<CellAnomaly>[], perp: false).verdict,
        ConfirmVerdict.sameDirection);
    expect(run(<CellAnomaly>[], cols: 20).verdict,
        ConfirmVerdict.differentGrid);
  });
}
