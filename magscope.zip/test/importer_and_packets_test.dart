import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:magscope/exporters.dart';
import 'package:magscope/importer.dart';
import 'package:magscope/models.dart';
import 'package:magscope/sources.dart';
import 'package:magscope/v3d_export.dart';

void main() {
  test('pwr-3d Surfer grid is turned back (anti-transpose)', () {
    final bytes = File('test/fixtures/pwr3d_6x6.grd').readAsBytesSync();
    final s = ScanImporter.parse(Uint8List.fromList(bytes), 'pwr');
    expect(s, isNotNull);
    expect(s!.cols, 6);
    expect(s.rows, 6);
    final lines = utf8.decode(bytes).trim().split(RegExp(r'\r?\n'));
    final f = <List<double>>[
      for (final l in lines.skip(5))
        l.trim().split(RegExp(r'\s+')).map(double.parse).toList()
    ];
    for (int i = 0; i < 6; i++) {
      for (int j = 0; j < 6; j++) {
        expect(s.cells[i * 6 + j], f[5 - j][5 - i], reason: 'cell $i,$j');
      }
    }
  });

  test('MagnoLite JSON is imported as is', () {
    final bytes = File('test/fixtures/magnolite_5x5.json').readAsBytesSync();
    final s = ScanImporter.parse(Uint8List.fromList(bytes), 'mg');
    expect(s, isNotNull);
    expect(s!.cols, 5);
    expect(s.rows, 5);
    expect(s.cells[0], 793.0);
    expect(s.cells[4], 734.0);
    expect(s.cells[24], 729.0);
  });

  test('ESRI grid: first file row is the north (top) row', () {
    const txt = 'ncols 3\nnrows 2\nxllcorner 0\nyllcorner 0\ncellsize 1\n'
        'NODATA_value -9999\n1 2 3\n4 5 6\n';
    final s = ScanImporter.parse(Uint8List.fromList(utf8.encode(txt)), 'esri');
    expect(s, isNotNull);
    expect(s!.cells.sublist(0, 3), <double>[1, 2, 3]);
  });

  test('our own Surfer and ESRI exports import back unchanged (5 x 4 grid)', () {
    const cols = 5, rows = 4;
    final cells = <double>[
      for (int y = 0; y < rows; y++)
        for (int x = 0; x < cols; x++) 700.0 + y * 10 + x
    ];
    final s = ScanSession(
      id: '1',
      name: 'rt',
      createdAt: DateTime(2026, 1, 1),
      source: 'sim',
      raw: <double>[],
      cols: cols,
      rows: rows,
      cells: cells,
    );
    for (final f in <ExportFormat>[ExportFormat.surfer, ExportFormat.esri]) {
      final text = Exporter.build(s, f, 1.0);
      final back =
          ScanImporter.parse(Uint8List.fromList(utf8.encode(text)), 'rt');
      expect(back, isNotNull, reason: '$f');
      expect(back!.cols, cols, reason: '$f');
      expect(back.rows, rows, reason: '$f');
      for (int i = 0; i < cells.length; i++) {
        expect(back.cells[i], closeTo(cells[i], 1e-3), reason: '$f cell $i');
      }
    }
  });

  test('packets: ASCII, int16 and float32, also with missing bytes', () {
    expect(parsePacket(utf8.encode('12.5\n13.0\n'), PacketFormat.ascii, 1, 1),
        <double>[12.5, 13.0]);
    final i16 = ByteData(4)..setInt16(0, 250, Endian.little)..setInt16(2, -40, Endian.little);
    final v16 = parsePacket(i16.buffer.asUint8List(), PacketFormat.int16le, 0.1, 1);
    expect(v16.length, 2);
    expect(v16[0], closeTo(25.0, 1e-9));
    expect(v16[1], closeTo(-4.0, 1e-9));
    final f32 = ByteData(4)..setFloat32(0, 48.5, Endian.little);
    expect(parsePacket(f32.buffer.asUint8List(), PacketFormat.float32le, 1, 1),
        <double>[48.5]);
    // a truncated packet must not crash and must not invent values
    final cut = f32.buffer.asUint8List().sublist(0, 3);
    expect(() => parsePacket(cut, PacketFormat.float32le, 1, 1), returnsNormally);
    expect(parsePacket(cut, PacketFormat.float32le, 1, 1), isEmpty);
    expect(() => parsePacket(<int>[], PacketFormat.auto, 1, 1), returnsNormally);
  });

  test('OKM .v3d: complete grids are read, y = 0 is the bottom row', () {
    final a = ScanImporter.parse(
        Uint8List.fromList(File('test/fixtures/okm_10x10.v3d').readAsBytesSync()),
        'okm');
    expect(a, isNotNull);
    expect(a!.cols, 10);
    expect(a.rows, 10);
    // record (x=0, y=0) has value 512, record (x=0, y=2) has 513
    expect(a.cells[9 * 10 + 0], 512.0);
    expect(a.cells[7 * 10 + 0], 513.0);
    final b = ScanImporter.parse(
        Uint8List.fromList(File('test/fixtures/okm_13x19.v3d').readAsBytesSync()),
        'okm');
    expect(b, isNotNull);
    expect(b!.cols, 13);
    expect(b.rows, 19);
    expect(b.cells[18 * 13 + 0], 510.0);
    expect(b.cells.where((e) => e.isNaN).length, 0);
  });

  test('v3d export is read back by the importer unchanged', () {
    final src = ScanImporter.parse(
        Uint8List.fromList(File('test/fixtures/okm_13x19.v3d').readAsBytesSync()),
        'okm')!;
    final bytes = V3dExport.build(src, now: DateTime.utc(2026, 11, 26));
    expect(bytes.length, 479 + 36 * 13 * 19);
    expect(bytes[175], 19);
    final back = ScanImporter.parse(bytes, 'back');
    expect(back, isNotNull);
    expect(back!.cols, 13);
    expect(back.rows, 19);
    for (int i = 0; i < src.cells.length; i++) {
      expect(back.cells[i], src.cells[i], reason: 'cell $i');
    }
  });

  test('OKM .v3d: unfinished scan tail is blank, odd headers are accepted', () {
    final a = ScanImporter.parse(
        Uint8List.fromList(
            File('test/fixtures/okm_cave_5x6.v3d').readAsBytesSync()),
        'cave');
    expect(a, isNotNull);
    expect(a!.cols, 5);
    expect(a.rows, 6);
    expect(a.cells.where((e) => e.isNaN).length, 5);
    final b = ScanImporter.parse(
        Uint8List.fromList(
            File('test/fixtures/okm_7x7_hdr493.v3d').readAsBytesSync()),
        'h493');
    expect(b, isNotNull);
    expect(b!.cols, 7);
    expect(b.rows, 7);
    expect(b.cells.where((e) => e.isNaN).length, 6);
  });
}
