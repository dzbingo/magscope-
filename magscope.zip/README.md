# Sniper-Dz (القناص)

Magnetic-field scanner for Android: live chart, heat map, pseudo-3D view,
standard signal filters, saved sessions, Arabic / English / French.
Data source: built-in simulator, or a Bluetooth LE device (configure in Settings).

Build: see the GitHub Actions workflow (builds app-release.apk automatically),
or run `flutter create --platforms=android .`, copy
`android_overrides/AndroidManifest.xml` over `android/app/src/main/AndroidManifest.xml`,
then `flutter build apk --release`.
