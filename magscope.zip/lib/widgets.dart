import 'dart:math' as math;
import 'anomaly.dart';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'dsp.dart';
import 'state.dart';
import 'theme.dart';

String stamp(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)}_${two(d.hour)}-${two(d.minute)}';
}

/// Selected heat-map palette (index into [kPalettes]). Set by AppState.
int kPalette = 0;

const List<List<Color>> kPalettes = <List<Color>>[
  // 0: jet (dark blue -> cyan -> green -> yellow -> orange -> red -> dark red)
  <Color>[
    Color(0xFF0A1A8C),
    Color(0xFF0072FF),
    Color(0xFF00E5FF),
    Color(0xFF3DDC3D),
    Color(0xFFD9F000),
    Color(0xFFFFE600),
    Color(0xFFFF8C00),
    Color(0xFFE01010),
    Color(0xFF7A0010),
  ],
  // 1: rainbow
  <Color>[
    Color(0xFF0000FF),
    Color(0xFF00FFFF),
    Color(0xFF00FF00),
    Color(0xFFFFFF00),
    Color(0xFFFF0000),
  ],
  // 2: high contrast (blue -> white -> red)
  <Color>[
    Color(0xFF00008F),
    Color(0xFF0080FF),
    Color(0xFFFFFFFF),
    Color(0xFFFF8000),
    Color(0xFFA00000),
  ],
  // 3: iron
  <Color>[
    Color(0xFF0F0F19),
    Color(0xFF4B2882),
    Color(0xFFB43232),
    Color(0xFFF0A028),
    Color(0xFFFFFFDC),
  ],
];

/// Colour ramp for the heat map, using the currently selected palette.
Color heatColor(double t) {
  final stops = kPalettes[kPalette.clamp(0, kPalettes.length - 1).toInt()];
  final x = t.isNaN ? 0.0 : t.clamp(0.0, 1.0).toDouble();
  final scaled = x * (stops.length - 1);
  final i = math.min(scaled.floor(), stops.length - 2);
  final f = scaled - i;
  return Color.lerp(stops[i], stops[i + 1], f) ?? stops[i];
}

/// Darkens (f < 1) or lightens (f > 1) a colour.
Color shade(Color c, double f) {
  if (f < 1) {
    return Color.lerp(Colors.black, c, f.clamp(0.0, 1.0).toDouble()) ?? c;
  }
  return Color.lerp(c, Colors.white, ((f - 1) * 0.8).clamp(0.0, 1.0).toDouble()) ??
      c;
}

// ---------------------------------------------------------------------------
// Basic building blocks
// ---------------------------------------------------------------------------

/// Put above settings panels that float over a picture: the panels inside
/// then become see-through so the picture stays visible while you change a
/// setting.
class PanelGlass extends InheritedWidget {
  const PanelGlass({super.key, required super.child});

  @override
  bool updateShouldNotify(PanelGlass old) => false;
}

class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.glow,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? glow;

  @override
  Widget build(BuildContext context) {
    final g = glow;
    if (context.getInheritedWidgetOfExactType<PanelGlass>() != null) {
      return Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
          color: Pal.bg.withAlpha(70),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Pal.outline.withAlpha(170)),
        ),
        child: child,
      );
    }
    if (Pal.neon) {
      final c1 = g ?? Pal.amber;
      final c2 = g ?? Pal.violet;
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(1.6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[c1.withAlpha(230), c2.withAlpha(200)],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(color: c1.withAlpha(70), blurRadius: 18, spreadRadius: 0),
            BoxShadow(color: c2.withAlpha(45), blurRadius: 26),
          ],
        ),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.4),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Pal.surface2, Pal.surface],
            ),
          ),
          child: child,
        ),
      );
    }
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF1C232E), Color(0xFF141922)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: g == null ? Pal.outline : g.withAlpha(170)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: g == null ? const Color(0x59000000) : g.withAlpha(60),
            blurRadius: g == null ? 14 : 22,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style:  TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: Pal.text,
        ),
      ),
    );
  }
}

/// Numbers and units must never be mirrored in right-to-left languages.
class Num extends StatelessWidget {
  const Num(this.text, {super.key, this.style});
  final String text;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return Text(text, style: style, textDirection: TextDirection.ltr);
  }
}

class HeatLegend extends StatelessWidget {
  const HeatLegend({super.key, required this.lo, required this.hi});
  final double lo;
  final double hi;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        children: <Widget>[
          Container(
            height: 10,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              gradient: LinearGradient(
                colors: <Color>[
                  heatColor(0),
                  heatColor(0.25),
                  heatColor(0.5),
                  heatColor(0.75),
                  heatColor(1),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(lo.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
              Text(hi.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

void _label(Canvas canvas, String text, Offset at,
    {Color? color, double size = 10}) {
  final tp = TextPainter(
    text: TextSpan(
        text: text, style: TextStyle(color: color ?? Pal.muted, fontSize: size)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, at);
}

// ---------------------------------------------------------------------------
// Brand mark (same design as the launcher icon)
// ---------------------------------------------------------------------------

class AppMark extends StatelessWidget {
  const AppMark({super.key, this.size = 30});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _MarkPainter()),
    );
  }
}

class _MarkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.6, r * 0.14)
      ..color = Pal.amber;
    canvas.drawCircle(c, r * 0.8, ring);
    canvas.drawCircle(
      c,
      r * 0.58,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.0, r * 0.04)
        ..color = Pal.violet,
    );
    final cross = Paint()
      ..strokeWidth = math.max(1.2, r * 0.07)
      ..strokeCap = StrokeCap.round
      ..color = Pal.text;
    for (int i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final dx = math.cos(a);
      final dy = math.sin(a);
      canvas.drawLine(
        c + Offset(dx, dy) * (r * 0.16),
        c + Offset(dx, dy) * (r * 0.95),
        cross,
      );
    }
    canvas.drawCircle(c, r * 0.1, Paint()..color = Pal.amber);
  }

  @override
  bool shouldRepaint(covariant _MarkPainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Deviation gauge
// ---------------------------------------------------------------------------

/// Arc gauge. [frac] is -1..1: how far the reading is from the reference,
/// as a fraction of twice the detection threshold.
class GaugePainter extends CustomPainter {
  GaugePainter({required this.frac, required this.color});

  final double frac;
  final Color color;

  static const double _start = math.pi * 0.8;
  static const double _sweep = math.pi * 1.4;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.62);
    final radius = math.min(size.width / 2 - 14, size.height * 0.62 - 12);
    final rect = Rect.fromCircle(center: center, radius: radius);

    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = Pal.surface2;
    canvas.drawArc(rect, _start, _sweep, false, track);

    final tick = Paint()
      ..color = Pal.outline
      ..strokeWidth = 2;
    for (int i = 0; i <= 14; i++) {
      final a = _start + _sweep * i / 14;
      final r1 = radius - 16;
      final r2 = radius - (i % 7 == 0 ? 28 : 23);
      canvas.drawLine(
        center + Offset(math.cos(a) * r1, math.sin(a) * r1),
        center + Offset(math.cos(a) * r2, math.sin(a) * r2),
        tick,
      );
    }

    final f = frac.isNaN ? 0.0 : frac.clamp(-1.0, 1.0).toDouble();
    final mid = _start + _sweep / 2;
    if (f.abs() > 0.005) {
      final vp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14
        ..strokeCap = StrokeCap.round
        ..color = color;
      canvas.drawArc(rect, mid, _sweep / 2 * f, false, vp);
    }
    final a = mid + _sweep / 2 * f;
    final tip = center + Offset(math.cos(a) * radius, math.sin(a) * radius);
    canvas.drawCircle(tip, 12, Paint()..color = color.withAlpha(70));
    canvas.drawCircle(tip, 7.5, Paint()..color = Colors.white);
    canvas.drawCircle(tip, 4, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant GaugePainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Live chart
// ---------------------------------------------------------------------------

Path _smoothPath(List<Offset> p) {
  final path = Path()..moveTo(p[0].dx, p[0].dy);
  for (int i = 1; i < p.length - 1; i++) {
    final mid = Offset((p[i].dx + p[i + 1].dx) / 2, (p[i].dy + p[i + 1].dy) / 2);
    path.quadraticBezierTo(p[i].dx, p[i].dy, mid.dx, mid.dy);
  }
  path.lineTo(p.last.dx, p.last.dy);
  return path;
}

/// Smooth live chart: raw signal (dim), filtered signal with gradient fill,
/// optional reference line and a touch cursor with a value bubble.
class LinePainter extends CustomPainter {
  LinePainter({
    required this.raw,
    required this.filtered,
    this.cursor,
    this.baseline,
  });

  final List<double> raw;
  final List<double> filtered;
  final double? cursor;
  final double? baseline;

  static const double padL = 44;
  static const double padR = 8;
  static const double padT = 10;
  static const double padB = 8;

  @override
  void paint(Canvas canvas, Size size) {
    final plot = Rect.fromLTWH(
        padL, padT, size.width - padL - padR, size.height - padT - padB);

    double lo = double.infinity;
    double hi = -double.infinity;
    for (final v in raw) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    for (final v in filtered) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    final hasData = lo.isFinite && hi.isFinite;
    if (!hasData) {
      lo = 0;
      hi = 1;
    }
    if (hi - lo < 0.5) {
      final c = (hi + lo) / 2;
      lo = c - 0.25;
      hi = c + 0.25;
    }
    final pad = (hi - lo) * 0.12;
    lo -= pad;
    hi += pad;
    final range = hi - lo;

    final gridPaint = Paint()
      ..color = Pal.outline.withAlpha(150)
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final y = plot.top + plot.height * i / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
      if (hasData) {
        final v = hi - range * i / 4;
        _label(canvas, v.toStringAsFixed(1), Offset(0, y - 6));
      }
    }
    for (int i = 1; i < 6; i++) {
      final x = plot.left + plot.width * i / 6;
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom),
          Paint()..color = Pal.outline.withAlpha(60));
    }

    Offset pt(int i, double v, int n) => Offset(
          plot.left + plot.width * i / (n - 1),
          plot.bottom - plot.height * (v - lo) / range,
        );

    canvas.save();
    canvas.clipRect(plot.inflate(3));

    if (raw.length > 1) {
      final pts = <Offset>[
        for (int i = 0; i < raw.length; i++) pt(i, raw[i], raw.length),
      ];
      final path = Path()..moveTo(pts[0].dx, pts[0].dy);
      for (int i = 1; i < pts.length; i++) {
        path.lineTo(pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = Pal.muted.withAlpha(90)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
    }

    final b = baseline;
    if (b != null && b > lo && b < hi) {
      final y = plot.bottom - plot.height * (b - lo) / range;
      final dp = Paint()
        ..color = Pal.violet.withAlpha(190)
        ..strokeWidth = 1.3;
      double x = plot.left;
      while (x < plot.right) {
        canvas.drawLine(
            Offset(x, y), Offset(math.min(x + 6, plot.right), y), dp);
        x += 11;
      }
    }

    if (filtered.length > 1) {
      final n = filtered.length;
      final pts = <Offset>[
        for (int i = 0; i < n; i++) pt(i, filtered[i], n),
      ];
      final line = _smoothPath(pts);
      final fill = Path.from(line)
        ..lineTo(pts.last.dx, plot.bottom)
        ..lineTo(pts.first.dx, plot.bottom)
        ..close();
      canvas.drawPath(
        fill,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[Color(0x66FFA43A), Color(0x00FFA43A)],
          ).createShader(plot),
      );
      canvas.drawPath(
        line,
        Paint()
          ..color = Pal.amber
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );
      final last = pts.last;
      canvas.drawCircle(last, 10, Paint()..color = Pal.amber.withAlpha(50));
      canvas.drawCircle(last, 5.5, Paint()..color = Pal.amber);
      canvas.drawCircle(last, 2.5, Paint()..color = Colors.white);
    }
    canvas.restore();

    final cur = cursor;
    if (cur != null && filtered.length > 1) {
      final n = filtered.length;
      final i = (cur * (n - 1)).round().clamp(0, n - 1).toInt();
      final p = pt(i, filtered[i], n);
      canvas.drawLine(
        Offset(p.dx, plot.top),
        Offset(p.dx, plot.bottom),
        Paint()
          ..color = Colors.white.withAlpha(90)
          ..strokeWidth = 1,
      );
      canvas.drawCircle(p, 5, Paint()..color = Colors.white);
      final tp = TextPainter(
        text: TextSpan(
          text: filtered[i].toStringAsFixed(2),
          style: const TextStyle(
              color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      final bw = tp.width + 14;
      final bh = tp.height + 8;
      double bx = p.dx - bw / 2;
      if (bx < plot.left) bx = plot.left;
      if (bx + bw > plot.right) bx = plot.right - bw;
      final by = math.max(plot.top, p.dy - bh - 10);
      final rr = RRect.fromRectAndRadius(
          Rect.fromLTWH(bx, by, bw, bh), const Radius.circular(8));
      canvas.drawRRect(rr, Paint()..color = Pal.surface2);
      canvas.drawRRect(
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = Pal.amber,
      );
      tp.paint(canvas, Offset(bx + 7, by + 4));
    }
  }

  @override
  bool shouldRepaint(covariant LinePainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Heat map (smoothly interpolated)
// ---------------------------------------------------------------------------

/// Interpolation used when drawing the field: 0 = smooth (linear),
/// 1 = extra smooth (cosine), 2 = blocks (no interpolation).
class HeatInterp {
  static int mode = 0;
  static double w(double t) {
    if (mode == 1) return (1 - math.cos(t * math.pi)) / 2;
    if (mode == 2) return t < 0.5 ? 0.0 : 1.0;
    return t;
  }
}

class HeatPainter extends CustomPainter {
  HeatPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    this.cursorX = -1,
    this.cursorY = -1,
    this.selX = -1,
    this.selY = -1,
    this.anomalies = const <CellAnomaly>[],
    this.labels,
    this.coverage,
  });

  /// Optional coverage codes per cell (see AppState.coverageMap).
  final List<int>? coverage;

  /// Optional text per cell (row-major), drawn centred in the square.
  final List<String?>? labels;
  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;
  final int cursorX;
  final int cursorY;
  final int selX;
  final int selY;
  final List<CellAnomaly> anomalies;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols <= 0 || rows <= 0) return;
    final cell = math.min(size.width / cols, size.height / rows);
    final ox = (size.width - cell * cols) / 2;
    final oy = (size.height - cell * rows) / 2;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(ox, oy, cell * cols, cell * rows),
        const Radius.circular(10),
      ),
      Paint()..color = Pal.surface2,
    );

    final sub = HeatInterp.mode == 2
        ? 1
        : (240 / math.max(cols, rows)).floor().clamp(2, 10).toInt();
    final sc = cell / sub;
    final paint = Paint()..style = PaintingStyle.fill;
    for (int sy = 0; sy < rows * sub; sy++) {
      final cyc = (sy + 0.5) / sub - 0.5;
      final y0 = cyc.floor();
      final ty = HeatInterp.w(cyc - y0);
      final cellY = sy ~/ sub;
      for (int sx = 0; sx < cols * sub; sx++) {
        final cellX = sx ~/ sub;
        if (cells[cellY * cols + cellX].isNaN) continue;
        final cxc = (sx + 0.5) / sub - 0.5;
        final x0 = cxc.floor();
        final tx = HeatInterp.w(cxc - x0);
        double sum = 0;
        double ws = 0;
        for (int dy = 0; dy <= 1; dy++) {
          for (int dx = 0; dx <= 1; dx++) {
            final gx = x0 + dx;
            final gy = y0 + dy;
            if (gx < 0 || gy < 0 || gx >= cols || gy >= rows) continue;
            final v = cells[gy * cols + gx];
            if (v.isNaN) continue;
            final w = (dx == 0 ? 1 - tx : tx) * (dy == 0 ? 1 - ty : ty);
            sum += v * w;
            ws += w;
          }
        }
        if (ws <= 0) continue;
        paint.color = heatColor((sum / ws - lo) / span);
        canvas.drawRect(
          Rect.fromLTWH(ox + sx * sc, oy + sy * sc, sc + 0.7, sc + 0.7),
          paint,
        );
      }
    }

    if (cell > 12) {
      final gp = Paint()
        ..color = Pal.bg.withAlpha(45)
        ..strokeWidth = 0.6;
      for (int x = 1; x < cols; x++) {
        canvas.drawLine(Offset(ox + x * cell, oy),
            Offset(ox + x * cell, oy + rows * cell), gp);
      }
      for (int y = 1; y < rows; y++) {
        canvas.drawLine(Offset(ox, oy + y * cell),
            Offset(ox + cols * cell, oy + y * cell), gp);
      }
    }

    final cov = coverage;
    if (cov != null && cov.length >= cols * rows) {
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          final k = cov[y * cols + x];
          if (k == 0) continue;
          final col = k == 3
              ? const Color(0xFFE53935)
              : (k == 2 ? Pal.violet : Pal.amber);
          final r = Rect.fromLTWH(ox + x * cell, oy + y * cell, cell, cell);
          canvas.drawRect(r, Paint()..color = col.withAlpha(k == 3 ? 150 : 110));
          canvas.drawRect(
              r.deflate(1),
              Paint()
                ..style = PaintingStyle.stroke
                ..strokeWidth = 2
                ..color = col);
        }
      }
    }

    final lab = labels;
    if (lab != null && lab.length >= cols * rows) {
      final fs = math.min(cell * 0.30, 14.0);
      if (fs >= 6) {
        for (int y = 0; y < rows; y++) {
          for (int x = 0; x < cols; x++) {
            final txt = lab[y * cols + x];
            if (txt == null || txt.isEmpty) continue;
            final v = cells[y * cols + x];
            final bright = v.isNaN
                ? false
                : heatColor((v - lo) / (hi - lo <= 0 ? 1.0 : hi - lo))
                        .computeLuminance() >
                    0.45;
            final tp = TextPainter(
              text: TextSpan(
                text: txt,
                style: TextStyle(
                  fontSize: fs,
                  fontWeight: FontWeight.w700,
                  color: bright ? Colors.black : Colors.white,
                ),
              ),
              textDirection: TextDirection.ltr,
            )..layout(maxWidth: cell);
            tp.paint(
              canvas,
              Offset(ox + (x + 0.5) * cell - tp.width / 2,
                  oy + (y + 0.5) * cell - tp.height / 2),
            );
          }
        }
      }
    }

    for (final a in anomalies) {
      final c = Offset(ox + (a.x + 0.5) * cell, oy + (a.y + 0.5) * cell);
      final col = a.deviation >= 0 ? Colors.white : Pal.violet;
      canvas.drawCircle(
        c,
        cell * 0.85,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = col.withAlpha(220),
      );
      canvas.drawCircle(c, 2.5, Paint()..color = col);
    }

    void outline(int x, int y, Color color, double w) {
      canvas.drawRect(
        Rect.fromLTWH(ox + x * cell, oy + y * cell, cell, cell),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = w
          ..color = color,
      );
    }

    if (cursorX >= 0 && cursorY >= 0) outline(cursorX, cursorY, Colors.white, 2);
    if (selX >= 0 && selY >= 0) outline(selX, selY, Pal.good, 2.5);
  }

  @override
  bool shouldRepaint(covariant HeatPainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// 3D surface (isometric, shaded)
// ---------------------------------------------------------------------------

class _Quad {
  _Quad(this.path, this.depth, this.color, [this.h = 0]);
  final Path path;
  final double depth;
  final Color color;
  final double h;
}

/// A target marker hanging below the ground plane in the 3D view.
class DepthPin {
  const DepthPin(this.x, this.y, this.depthM, this.metal);
  final int x;
  final int y;
  final double depthM;
  final bool metal;
}

class IsoPainter extends CustomPainter {
  IsoPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    this.cutLo,
    required this.angle,
    required this.heightScale,
    this.pitch = 0.9,
    this.groundImage,
    this.groundOpacity = 0.6,
    this.showGround = true,
    this.pins = const <DepthPin>[],
    this.solid = false,
    this.block = false,
    this.cellM = 0.5,
    this.groundLabel = '',
    this.under = false,
  });

  /// Anomalies hang below a flat ground level (|deviation| downwards, colour
  /// still shows high = metal / low = void).
  final bool under;

  final ui.Image? groundImage;
  final double groundOpacity;
  final bool showGround;
  final List<DepthPin> pins;
  final bool solid;

  /// Draw the layered soil block under the map.
  final bool block;
  final double cellM;
  final String groundLabel;

  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;

  /// When the saturation buttons raised the low end of the colour scale, the
  /// cells below it are flattened in the underground relief too (null = off).
  final double? cutLo;

  /// Rotation around the vertical axis (radians, any value).
  final double angle;
  final double heightScale;

  /// Viewing elevation in radians, any value: 0 = from the side, pi/2 = from
  /// straight above, negative = from below, beyond pi/2 = upside down.
  final double pitch;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols < 2 || rows < 2) return;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);

    final valid = cells.where((e) => !e.isNaN).toList();
    final fillV = valid.isEmpty ? lo : medianOf(valid);
    // colour position of a cell (0..1 over the shown range)
    double cn(int x, int y) {
      final v = cells[y * cols + x];
      return (((v.isNaN ? fillV : v) - lo) / span).clamp(0.0, 1.0).toDouble();
    }

    // underground mode: distance below ground = size of the deviation from the
    // regional trend, whatever its sign
    final res = under ? Detect.residual(cells, cols, rows) : const <double>[];
    double maxAbs = 1e-9;
    if (under) {
      for (final e in res) {
        if (!e.isNaN && e.abs() > maxAbs) maxAbs = e.abs();
      }
    }
    double hv(int x, int y) {
      if (!under) return cn(x, y);
      final r = res[y * cols + x];
      if (r.isNaN) return 0.0;
      double vis = 1.0;
      final cl = cutLo;
      if (cl != null) {
        final v = cells[y * cols + x];
        final w = 0.06 * span;
        if (!v.isNaN) vis = ((v - (cl - w)) / w).clamp(0.0, 1.0).toDouble();
      }
      return -(r.abs() / maxAbs) * vis;
    }

    final gh = under
        ? 0.0
        : (valid.isEmpty
            ? 0.0
            : ((medianOf(valid) - lo) / span).clamp(0.0, 1.0).toDouble());

    // finer mesh for a smooth surface (cosine blending, or steps in "blocks")
    double w3(double t) {
      if (HeatInterp.mode == 2) return t < 0.5 ? 0.0 : 1.0;
      return (1 - math.cos(t * math.pi)) / 2;
    }

    final up = solid ? 1 : (60 / math.max(cols, rows)).floor().clamp(2, 8).toInt();
    final nx = (cols - 1) * up + 1;
    final ny = (rows - 1) * up + 1;

    final hh = List<double>.filled(solid ? 0 : nx * ny, 0);
    final cc = List<double>.filled(solid ? 0 : nx * ny, 0);
    if (!solid) {
      for (int j = 0; j < ny; j++) {
        final gy = j / up;
        final y0 = math.min(gy.floor(), rows - 2);
        final ty = w3(gy - y0);
        for (int i = 0; i < nx; i++) {
          final gx = i / up;
          final x0 = math.min(gx.floor(), cols - 2);
          final tx = w3(gx - x0);
          double mix(double Function(int, int) f) =>
              f(x0, y0) * (1 - tx) * (1 - ty) +
              f(x0 + 1, y0) * tx * (1 - ty) +
              f(x0, y0 + 1) * (1 - tx) * ty +
              f(x0 + 1, y0 + 1) * tx * ty;
          hh[j * nx + i] = mix(hv);
          cc[j * nx + i] = mix(cn);
        }
      }
    }

    // ---- free orthographic camera -----------------------------------------
    const hs = 5.0; // height of a full-scale column, in cell units
    final diag = math.sqrt((cols * cols + rows * rows).toDouble());
    final unit = math.min(size.width / (diag + 2), size.height / (diag + 4)) * 0.95;
    final cx = (cols - 1) / 2;
    final cy = (rows - 1) / 2;
    final ca = math.cos(angle);
    final sa = math.sin(angle);
    final sp = math.sin(pitch);
    final cp = math.cos(pitch);
    final origin = under
        ? Offset(size.width / 2, size.height / 2 - 0.3 * hs * heightScale * cp * unit)
        : Offset(size.width / 2, size.height / 2 + 0.3 * hs * cp * unit);

    Offset project(double gx, double gy, double h) {
      final dx = gx - cx;
      final dy = gy - cy;
      final rx = dx * ca - dy * sa;
      final ry = dx * sa + dy * ca;
      return origin + Offset(rx * unit, (ry * sp - h * heightScale * hs * cp) * unit);
    }

    /// Larger = nearer to the camera.
    double camDepth(double gx, double gy, double h) {
      final dx = gx - cx;
      final dy = gy - cy;
      final ry = dx * sa + dy * ca;
      return ry * cp + h * heightScale * hs * sp;
    }

    final fromAbove = sp >= 0;

    void drawFloor() {
      final p0 = project(-0.5, -0.5, 0);
      final p1 = project(cols - 0.5, -0.5, 0);
      final p2 = project(cols - 0.5, rows - 0.5, 0);
      final p3 = project(-0.5, rows - 0.5, 0);
      final floor = Path()
        ..moveTo(p0.dx, p0.dy)
        ..lineTo(p1.dx, p1.dy)
        ..lineTo(p2.dx, p2.dy)
        ..lineTo(p3.dx, p3.dy)
        ..close();
      canvas.drawPath(
          floor, Paint()..color = Pal.surface2.withAlpha(fromAbove ? 150 : 110));
      final gridPaint = Paint()
        ..color = Pal.outline.withAlpha(140)
        ..strokeWidth = 0.7;
      final stepG = cols > 20 || rows > 20 ? 2 : 1;
      for (int x = 0; x <= cols; x += stepG) {
        canvas.drawLine(project(x - 0.5, -0.5, 0),
            project(x - 0.5, rows - 0.5, 0), gridPaint);
      }
      for (int y = 0; y <= rows; y += stepG) {
        canvas.drawLine(project(-0.5, y - 0.5, 0),
            project(cols - 0.5, y - 0.5, 0), gridPaint);
      }
      canvas.drawPath(
        floor,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = Pal.outline,
      );
    }

    if (fromAbove) drawFloor();

    // ---- soil block: layered side walls under the map (seen from above) ---
    if (block && sp > 0.0001) {
      const layers = <double>[0.0, -0.12, -0.26, -0.40, -0.52];
      const soilCols = <Color>[
        Color(0xFF2A150C),
        Color(0xFF45261A),
        Color(0xFF58391F),
        Color(0xFF262421),
      ];
      // side: outward normal, edge cell count, cell position, height lookup
      for (int sd = 0; sd < 4; sd++) {
        final nxg = sd == 0 ? 0.0 : sd == 1 ? 1.0 : sd == 2 ? 0.0 : -1.0;
        final nyg = sd == 0 ? -1.0 : sd == 1 ? 0.0 : sd == 2 ? 1.0 : 0.0;
        final nrx = nxg * ca - nyg * sa;
        final nry = nxg * sa + nyg * ca;
        if (nry * cp <= 0.0001) continue;
        final lum = (0.72 + 0.28 * (nrx * -0.64 + nry * -0.77)).clamp(0.4, 1.0).toDouble();
        final n = (sd == 0 || sd == 2) ? cols : rows;
        for (int i = 0; i < n; i++) {
          double gx0, gy0, gx1, gy1, top;
          if (sd == 0) {
            gx0 = i - 0.5; gx1 = i + 0.5; gy0 = gy1 = -0.5; top = hv(i, 0);
          } else if (sd == 2) {
            gx0 = i - 0.5; gx1 = i + 0.5; gy0 = gy1 = rows - 0.5; top = hv(i, rows - 1);
          } else if (sd == 3) {
            gy0 = i - 0.5; gy1 = i + 0.5; gx0 = gx1 = -0.5; top = hv(0, i);
          } else {
            gy0 = i - 0.5; gy1 = i + 0.5; gx0 = gx1 = cols - 0.5; top = hv(cols - 1, i);
          }
          for (int k = 0; k < 4; k++) {
            final hTop = k == 0 ? top : layers[k];
            final hBot = layers[k + 1];
            canvas.drawPath(
              Path()
                ..moveTo(project(gx0, gy0, hTop).dx, project(gx0, gy0, hTop).dy)
                ..lineTo(project(gx1, gy1, hTop).dx, project(gx1, gy1, hTop).dy)
                ..lineTo(project(gx1, gy1, hBot).dx, project(gx1, gy1, hBot).dy)
                ..lineTo(project(gx0, gy0, hBot).dx, project(gx0, gy0, hBot).dy)
                ..close(),
              Paint()..color = shade(soilCols[k], lum),
            );
          }
        }
      }
    }

    // ---- surface (smooth) or solid columns ------------------------------
    final quads = <_Quad>[];
    if (solid) {
      const gap = 0.035;
      const light = <double>[-0.64, -0.77];
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          final v = cells[y * cols + x];
          if (v.isNaN) continue;
          final h = hv(x, y);
          final base = heatColor(cn(x, y));
          final depth = camDepth(x.toDouble(), y.toDouble(), h * 0.5);
          final x0 = x - 0.5 + gap;
          final x1 = x + 0.5 - gap;
          final y0 = y - 0.5 + gap;
          final y1 = y + 0.5 - gap;
          Path quadOf(Offset a, Offset b, Offset c, Offset d) => Path()
            ..moveTo(a.dx, a.dy)
            ..lineTo(b.dx, b.dy)
            ..lineTo(c.dx, c.dy)
            ..lineTo(d.dx, d.dy)
            ..close();
          // side faces: outward normal in grid space, corner pairs
          final sides = <List<double>>[
            <double>[0, -1, x0, y0, x1, y0],
            <double>[1, 0, x1, y0, x1, y1],
            <double>[0, 1, x1, y1, x0, y1],
            <double>[-1, 0, x0, y1, x0, y0],
          ];
          for (final sd in sides) {
            final nrx = sd[0] * ca - sd[1] * sa;
            final nry = sd[0] * sa + sd[1] * ca;
            if (nry * cp <= 0.0001) continue; // faces away from the camera
            final lum = 0.66 + 0.30 * (nrx * light[0] + nry * light[1]);
            quads.add(_Quad(
              quadOf(project(sd[2], sd[3], 0), project(sd[4], sd[5], 0),
                  project(sd[4], sd[5], h), project(sd[2], sd[3], h)),
              depth - 0.002,
              shade(base, lum.clamp(0.35, 1.0).toDouble()),
              h,
            ));
          }
          if (sp > 0.0001) {
            quads.add(_Quad(
              quadOf(project(x0, y0, h), project(x1, y0, h),
                  project(x1, y1, h), project(x0, y1, h)),
              depth,
              shade(base, 1.1),
              h,
            ));
          } else if (sp < -0.0001) {
            quads.add(_Quad(
              quadOf(project(x0, y0, 0), project(x1, y0, 0),
                  project(x1, y1, 0), project(x0, y1, 0)),
              depth,
              shade(base, 0.45),
              h,
            ));
          }
        }
      }
    } else {
      for (int j = 0; j < ny - 1; j++) {
        for (int i = 0; i < nx - 1; i++) {
          final h00 = hh[j * nx + i];
          final h10 = hh[j * nx + i + 1];
          final h01 = hh[(j + 1) * nx + i];
          final h11 = hh[(j + 1) * nx + i + 1];
          final x = i.toDouble() / up;
          final y = j.toDouble() / up;
          final x1 = (i + 1).toDouble() / up;
          final y1 = (j + 1).toDouble() / up;
          final p00 = project(x, y, h00);
          final p10 = project(x1, y, h10);
          final p11 = project(x1, y1, h11);
          final p01 = project(x, y1, h01);
          final path = Path()
            ..moveTo(p00.dx, p00.dy)
            ..lineTo(p10.dx, p10.dy)
            ..lineTo(p11.dx, p11.dy)
            ..lineTo(p01.dx, p01.dy)
            ..close();

          final srcX = math.min(((i + 0.5) / up).floor(), cols - 1);
          final srcY = math.min(((j + 0.5) / up).floor(), rows - 1);
          final empty = cells[srcY * cols + srcX].isNaN;

          final avg = (h00 + h10 + h01 + h11) / 4;
          final cAvg = (cc[j * nx + i] +
                  cc[j * nx + i + 1] +
                  cc[(j + 1) * nx + i] +
                  cc[(j + 1) * nx + i + 1]) /
              4;
          final dxs = (h10 + h11 - h00 - h01) / 2;
          final dys = (h01 + h11 - h00 - h10) / 2;
          final light = (-(dxs + dys) * up * 3.0).clamp(-0.4, 0.4).toDouble();

          final base = empty
              ? Pal.surface2.withAlpha(190)
              : shade(heatColor(cAvg), 1.0 + light);
          final depth =
              camDepth(x + 0.5 / up, y + 0.5 / up, avg);
          quads.add(_Quad(path, depth, base, avg));
        }
      }
    }
    quads.sort((a, b) => a.depth.compareTo(b.depth));

    final fill = Paint()..style = PaintingStyle.fill;
    final seam = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    void drawQuad(_Quad q) {
      fill.color = q.color;
      seam.color = q.color;
      canvas.drawPath(q.path, fill);
      canvas.drawPath(q.path, seam);
    }

    // The ground sheet separates what lies below the ground level from what
    // rises above it; from underneath the order is reversed.
    if (showGround) {
      final firstBelow = fromAbove;
      for (final q in quads) {
        if ((q.h <= gh) == firstBelow) drawQuad(q);
      }
      _drawGround(canvas, project, gh);
      for (final q in quads) {
        if ((q.h <= gh) != firstBelow) drawQuad(q);
      }
    } else {
      for (final q in quads) {
        drawQuad(q);
      }
    }

    if (!fromAbove) drawFloor();

    // north marker, so the orientation stays clear while rotating
    final north = project(cx, -1.6, 0);
    _label(canvas, 'N', north + const Offset(-4, -7), color: Pal.amber, size: 13);

    // depth pins: targets hanging below the ground sheet
    if (showGround) {
      for (final pin in pins) {
        final o = project(pin.x.toDouble(), pin.y.toDouble(), gh);
        final dCells = (pin.depthM / (cellM <= 0 ? 0.5 : cellM))
            .clamp(0.3, 25.0)
            .toDouble();
        final end = project(pin.x.toDouble(), pin.y.toDouble(),
            gh - dCells / (hs * heightScale));
        final c = pin.metal ? Pal.amber : Pal.violet;
        final line = Paint()
          ..color = c
          ..strokeWidth = 1.6;
        const dashes = 8;
        for (int k = 0; k < dashes; k++) {
          final f0 = k / dashes;
          final f1 = (k + 0.5) / dashes;
          canvas.drawLine(Offset.lerp(o, end, f0)!, Offset.lerp(o, end, f1)!, line);
        }
        canvas.drawCircle(o, 3, Paint()..color = Colors.white);
        final dia = Path()
          ..moveTo(end.dx, end.dy - 6)
          ..lineTo(end.dx + 6, end.dy)
          ..lineTo(end.dx, end.dy + 6)
          ..lineTo(end.dx - 6, end.dy)
          ..close();
        canvas.drawPath(dia, Paint()..color = c);
        canvas.drawPath(
            dia,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.2
              ..color = Colors.white);
        _label(canvas, '~${pin.depthM.toStringAsFixed(1)} m',
            end + const Offset(9, -7),
            color: Colors.white, size: 11);
      }
    }

    // peak marker (largest deviation when underground, highest value otherwise)
    if (valid.isNotEmpty) {
      int bx = 0;
      int by = 0;
      double bs = -double.infinity;
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          final v = cells[y * cols + x];
          if (v.isNaN) continue;
          final sc = under ? res[y * cols + x].abs() : v;
          if (sc > bs) {
            bs = sc;
            bx = x;
            by = y;
          }
        }
      }
      final bv = cells[by * cols + bx];
      final hp = hv(bx, by);
      final tip = project(bx.toDouble(), by.toDouble(), hp);
      final top = project(bx.toDouble(), by.toDouble(), under ? 0.0 : hp + 0.3);
      canvas.drawLine(
          tip, top, Paint()..color = Colors.white..strokeWidth = 1.2);
      canvas.drawCircle(top, 4, Paint()..color = Colors.white);
      _label(canvas, bv.toStringAsFixed(2), top + const Offset(6, -14),
          color: Colors.white, size: 11);
    }
  }

  void _drawGround(Canvas canvas, Offset Function(double, double, double) project,
      double gh) {
    final q0 = project(-0.5, -0.5, gh);
    final q1 = project(cols - 0.5, -0.5, gh);
    final q2 = project(cols - 0.5, rows - 0.5, gh);
    final q3 = project(-0.5, rows - 0.5, gh);
    final sheet = Path()
      ..moveTo(q0.dx, q0.dy)
      ..lineTo(q1.dx, q1.dy)
      ..lineTo(q2.dx, q2.dy)
      ..lineTo(q3.dx, q3.dy)
      ..close();
    final img = groundImage;
    if (img != null) {
      final w = img.width.toDouble();
      final h = img.height.toDouble();
      final verts = ui.Vertices(
        ui.VertexMode.triangles,
        <Offset>[q0, q1, q2, q0, q2, q3],
        textureCoordinates: <Offset>[
          const Offset(0, 0),
          Offset(w, 0),
          Offset(w, h),
          const Offset(0, 0),
          Offset(w, h),
          Offset(0, h),
        ],
      );
      final a = (groundOpacity.clamp(0.0, 1.0) * 255).round();
      canvas.saveLayer(
          sheet.getBounds().inflate(2), Paint()..color = Color.fromARGB(a, 255, 255, 255));
      canvas.drawVertices(
        verts,
        BlendMode.srcOver,
        Paint()
          ..shader = ImageShader(img, TileMode.clamp, TileMode.clamp,
              Matrix4.identity().storage),
      );
      canvas.restore();
    } else {
      canvas.drawPath(sheet, Paint()..color = Pal.good.withAlpha(38));
    }
    canvas.drawPath(
      sheet,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = Pal.good.withAlpha(190),
    );
    if (groundLabel.isNotEmpty) {
      _label(canvas, groundLabel, q3 + const Offset(4, 4),
          color: Pal.good, size: 11);
    }
  }

  @override
  bool shouldRepaint(covariant IsoPainter oldDelegate) => true;
}


/// Asks "save this scan?" (yes / no) and, on yes, saves it once. Returns true
/// when a file was written (or the scan was already saved).
Future<bool> askAndSaveScan(
    BuildContext context, AppState s, String prefix) async {
  if (!s.hasData) return false;
  if (s.currentSaved) return true;
  final ok = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext c) => AlertDialog(
      title: Text(s.t('save_ask_title')),
      content: Text(s.t('save_ask_body')),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(c, false),
          child: Text(s.t('no')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(c, true),
          child: Text(s.t('yes')),
        ),
      ],
    ),
  );
  if (ok != true) return false;
  await s.saveCurrent('${prefix}_${stamp(DateTime.now())}');
  if (context.mounted) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }
  return true;
}

/// Start side (left / right) and path style (parallel / zig-zag) pickers,
/// shared by the map scan and the AI-vision scan setup.
class ScanPathPicker extends StatelessWidget {
  const ScanPathPicker({super.key});

  // Arrows must never be mirrored by the RTL layout, so force LTR.
  Widget _arrow(IconData i) => Directionality(
        textDirection: TextDirection.ltr,
        child: Icon(i, size: 18),
      );

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SegmentedButton<bool>(
          segments: <ButtonSegment<bool>>[
            ButtonSegment<bool>(
                value: false,
                icon: _arrow(Icons.arrow_forward),
                label: Text(s.t('dir_ltr'))),
            ButtonSegment<bool>(
                value: true,
                icon: _arrow(Icons.arrow_back),
                label: Text(s.t('dir_rtl'))),
          ],
          selected: <bool>{s.rtl},
          onSelectionChanged:
              s.scanning ? null : (Set<bool> v) => s.setRtl(v.first),
        ),
        const SizedBox(height: 8),
        Text(s.t('path_mode_hint'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
        const SizedBox(height: 6),
        SegmentedButton<bool>(
          segments: <ButtonSegment<bool>>[
            ButtonSegment<bool>(
                value: false,
                icon: const Icon(Icons.north, size: 18),
                label: Text(s.t('path_parallel'))),
            ButtonSegment<bool>(
                value: true,
                icon: const Icon(Icons.swap_vert, size: 18),
                label: Text(s.t('path_zigzag'))),
          ],
          selected: <bool>{s.zigzagScan},
          onSelectionChanged:
              s.scanning ? null : (Set<bool> v) => s.setZigzag(v.first),
        ),
        const SizedBox(height: 6),
        Text(s.t('path_mode_note'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
      ],
    );
  }
}

/// Device calibration + stability check in one: the device is held still for
/// ten seconds, the real noise is measured and the readings are judged
/// steady or not. Devices that send only when a button is pressed are
/// covered: three or more presses in the window are enough.
class CalibrationPanel extends StatelessWidget {
  const CalibrationPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final connected = s.conn == ConnState.connected;
    final steady = s.calVerdict == 'pre_ok';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(s.t('cal_title'),
            style: TextStyle(
                color: Pal.violet, fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        Text(s.t('cal_hint'), style: TextStyle(color: Pal.muted, fontSize: 11)),
        if (connected && s.rawScale != null) ...<Widget>[
          const SizedBox(height: 6),
          Text(
            s.t('unit_note').replaceAll('{v}', s.rawScale!.toStringAsFixed(s.rawScale! < 10 ? 2 : 0)),
            style: TextStyle(color: Pal.amber, fontSize: 11),
          ),
        ],
        const SizedBox(height: 6),
        if (s.calibrating) ...<Widget>[
          LinearProgressIndicator(value: 1 - s.calLeft / 10.0),
          const SizedBox(height: 4),
          Text('${s.t('cal_running')}  ${s.calLeft}',
              style: TextStyle(color: Pal.amber)),
        ] else ...<Widget>[
          Text(
            s.calSigma == null
                ? s.t('cal_none')
                : '${s.t('cal_done')}: ${s.calSigma!.toStringAsFixed(3)}'
                    '   (${s.calN} ${s.t('cal_readings')}, Δ ${s.calSpread.toStringAsFixed(2)})',
            style: TextStyle(
                color: s.calSigma == null ? Pal.muted : Pal.good, fontSize: 12),
          ),
          if (s.calVerdict.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(s.t(s.calVerdict),
                  style: TextStyle(
                      color: steady ? Pal.good : Pal.amber,
                      fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: (!connected || s.scanning)
                      ? null
                      : () async {
                          final ok = await s.calibrateNoise();
                          if (!context.mounted || ok) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(s.t('cal_failed'))));
                        },
                  icon: const Icon(Icons.tune),
                  label: Text(s.t('cal_start')),
                ),
              ),
              if (s.calSigma != null)
                TextButton(
                    onPressed: s.clearCalibration,
                    child: Text(s.t('cal_reset'))),
            ],
          ),
          if (!connected)
            Text(s.t('cal_connect'),
                style: TextStyle(color: Pal.amber, fontSize: 11)),
        ],
      ],
    );
  }
}
