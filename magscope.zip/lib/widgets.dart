import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'dsp.dart';
import 'theme.dart';

String stamp(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)}_${two(d.hour)}-${two(d.minute)}';
}

/// Selected heat-map palette (index into [kPalettes]). Set by AppState.
int kPalette = 0;

const List<List<Color>> kPalettes = <List<Color>>[
  // 0: thermal (indigo -> magenta -> orange -> yellow)
  <Color>[
    Color(0xFF1B1464),
    Color(0xFF6A1B9A),
    Color(0xFFD81B60),
    Color(0xFFFF8F00),
    Color(0xFFFFF176),
  ],
  // 1: rainbow
  <Color>[
    Color(0xFF0000FF),
    Color(0xFF00FFFF),
    Color(0xFF00FF00),
    Color(0xFFFFFF00),
    Color(0xFFFF0000),
  ],
  // 2: high contrast (blue -> white -> red)
  <Color>[
    Color(0xFF00008F),
    Color(0xFF0080FF),
    Color(0xFFFFFFFF),
    Color(0xFFFF8000),
    Color(0xFFA00000),
  ],
  // 3: iron
  <Color>[
    Color(0xFF0F0F19),
    Color(0xFF4B2882),
    Color(0xFFB43232),
    Color(0xFFF0A028),
    Color(0xFFFFFFDC),
  ],
];

/// Colour ramp for the heat map, using the currently selected palette.
Color heatColor(double t) {
  final stops = kPalettes[kPalette.clamp(0, kPalettes.length - 1).toInt()];
  final x = t.isNaN ? 0.0 : t.clamp(0.0, 1.0).toDouble();
  final scaled = x * (stops.length - 1);
  final i = math.min(scaled.floor(), stops.length - 2);
  final f = scaled - i;
  return Color.lerp(stops[i], stops[i + 1], f) ?? stops[i];
}

/// Darkens (f < 1) or lightens (f > 1) a colour.
Color shade(Color c, double f) {
  if (f < 1) {
    return Color.lerp(Colors.black, c, f.clamp(0.0, 1.0).toDouble()) ?? c;
  }
  return Color.lerp(c, Colors.white, ((f - 1) * 0.8).clamp(0.0, 1.0).toDouble()) ??
      c;
}

// ---------------------------------------------------------------------------
// Basic building blocks
// ---------------------------------------------------------------------------

class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.glow,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? glow;

  @override
  Widget build(BuildContext context) {
    final g = glow;
    if (Pal.neon) {
      final c1 = g ?? Pal.amber;
      final c2 = g ?? Pal.violet;
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(1.6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[c1.withAlpha(230), c2.withAlpha(200)],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(color: c1.withAlpha(70), blurRadius: 18, spreadRadius: 0),
            BoxShadow(color: c2.withAlpha(45), blurRadius: 26),
          ],
        ),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.4),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Pal.surface2, Pal.surface],
            ),
          ),
          child: child,
        ),
      );
    }
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF1C232E), Color(0xFF141922)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: g == null ? Pal.outline : g.withAlpha(170)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: g == null ? const Color(0x59000000) : g.withAlpha(60),
            blurRadius: g == null ? 14 : 22,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style:  TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: Pal.text,
        ),
      ),
    );
  }
}

/// Numbers and units must never be mirrored in right-to-left languages.
class Num extends StatelessWidget {
  const Num(this.text, {super.key, this.style});
  final String text;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return Text(text, style: style, textDirection: TextDirection.ltr);
  }
}

class HeatLegend extends StatelessWidget {
  const HeatLegend({super.key, required this.lo, required this.hi});
  final double lo;
  final double hi;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        children: <Widget>[
          Container(
            height: 10,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              gradient: LinearGradient(
                colors: <Color>[
                  heatColor(0),
                  heatColor(0.25),
                  heatColor(0.5),
                  heatColor(0.75),
                  heatColor(1),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(lo.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
              Text(hi.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

void _label(Canvas canvas, String text, Offset at,
    {Color? color, double size = 10}) {
  final tp = TextPainter(
    text: TextSpan(
        text: text, style: TextStyle(color: color ?? Pal.muted, fontSize: size)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, at);
}

// ---------------------------------------------------------------------------
// Brand mark (same design as the launcher icon)
// ---------------------------------------------------------------------------

class AppMark extends StatelessWidget {
  const AppMark({super.key, this.size = 30});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _MarkPainter()),
    );
  }
}

class _MarkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.6, r * 0.14)
      ..color = Pal.amber;
    canvas.drawCircle(c, r * 0.8, ring);
    canvas.drawCircle(
      c,
      r * 0.58,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.0, r * 0.04)
        ..color = Pal.violet,
    );
    final cross = Paint()
      ..strokeWidth = math.max(1.2, r * 0.07)
      ..strokeCap = StrokeCap.round
      ..color = Pal.text;
    for (int i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final dx = math.cos(a);
      final dy = math.sin(a);
      canvas.drawLine(
        c + Offset(dx, dy) * (r * 0.16),
        c + Offset(dx, dy) * (r * 0.95),
        cross,
      );
    }
    canvas.drawCircle(c, r * 0.1, Paint()..color = Pal.amber);
  }

  @override
  bool shouldRepaint(covariant _MarkPainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Deviation gauge
// ---------------------------------------------------------------------------

/// Arc gauge. [frac] is -1..1: how far the reading is from the reference,
/// as a fraction of twice the detection threshold.
class GaugePainter extends CustomPainter {
  GaugePainter({required this.frac, required this.color});

  final double frac;
  final Color color;

  static const double _start = math.pi * 0.8;
  static const double _sweep = math.pi * 1.4;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.62);
    final radius = math.min(size.width / 2 - 14, size.height * 0.62 - 12);
    final rect = Rect.fromCircle(center: center, radius: radius);

    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = Pal.surface2;
    canvas.drawArc(rect, _start, _sweep, false, track);

    final tick = Paint()
      ..color = Pal.outline
      ..strokeWidth = 2;
    for (int i = 0; i <= 14; i++) {
      final a = _start + _sweep * i / 14;
      final r1 = radius - 16;
      final r2 = radius - (i % 7 == 0 ? 28 : 23);
      canvas.drawLine(
        center + Offset(math.cos(a) * r1, math.sin(a) * r1),
        center + Offset(math.cos(a) * r2, math.sin(a) * r2),
        tick,
      );
    }

    final f = frac.isNaN ? 0.0 : frac.clamp(-1.0, 1.0).toDouble();
    final mid = _start + _sweep / 2;
    if (f.abs() > 0.005) {
      final vp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14
        ..strokeCap = StrokeCap.round
        ..color = color;
      canvas.drawArc(rect, mid, _sweep / 2 * f, false, vp);
    }
    final a = mid + _sweep / 2 * f;
    final tip = center + Offset(math.cos(a) * radius, math.sin(a) * radius);
    canvas.drawCircle(tip, 12, Paint()..color = color.withAlpha(70));
    canvas.drawCircle(tip, 7.5, Paint()..color = Colors.white);
    canvas.drawCircle(tip, 4, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant GaugePainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Live chart
// ---------------------------------------------------------------------------

Path _smoothPath(List<Offset> p) {
  final path = Path()..moveTo(p[0].dx, p[0].dy);
  for (int i = 1; i < p.length - 1; i++) {
    final mid = Offset((p[i].dx + p[i + 1].dx) / 2, (p[i].dy + p[i + 1].dy) / 2);
    path.quadraticBezierTo(p[i].dx, p[i].dy, mid.dx, mid.dy);
  }
  path.lineTo(p.last.dx, p.last.dy);
  return path;
}

/// Smooth live chart: raw signal (dim), filtered signal with gradient fill,
/// optional reference line and a touch cursor with a value bubble.
class LinePainter extends CustomPainter {
  LinePainter({
    required this.raw,
    required this.filtered,
    this.cursor,
    this.baseline,
  });

  final List<double> raw;
  final List<double> filtered;
  final double? cursor;
  final double? baseline;

  static const double padL = 44;
  static const double padR = 8;
  static const double padT = 10;
  static const double padB = 8;

  @override
  void paint(Canvas canvas, Size size) {
    final plot = Rect.fromLTWH(
        padL, padT, size.width - padL - padR, size.height - padT - padB);

    double lo = double.infinity;
    double hi = -double.infinity;
    for (final v in raw) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    for (final v in filtered) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    final hasData = lo.isFinite && hi.isFinite;
    if (!hasData) {
      lo = 0;
      hi = 1;
    }
    if (hi - lo < 0.5) {
      final c = (hi + lo) / 2;
      lo = c - 0.25;
      hi = c + 0.25;
    }
    final pad = (hi - lo) * 0.12;
    lo -= pad;
    hi += pad;
    final range = hi - lo;

    final gridPaint = Paint()
      ..color = Pal.outline.withAlpha(150)
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final y = plot.top + plot.height * i / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
      if (hasData) {
        final v = hi - range * i / 4;
        _label(canvas, v.toStringAsFixed(1), Offset(0, y - 6));
      }
    }
    for (int i = 1; i < 6; i++) {
      final x = plot.left + plot.width * i / 6;
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom),
          Paint()..color = Pal.outline.withAlpha(60));
    }

    Offset pt(int i, double v, int n) => Offset(
          plot.left + plot.width * i / (n - 1),
          plot.bottom - plot.height * (v - lo) / range,
        );

    canvas.save();
    canvas.clipRect(plot.inflate(3));

    if (raw.length > 1) {
      final pts = <Offset>[
        for (int i = 0; i < raw.length; i++) pt(i, raw[i], raw.length),
      ];
      final path = Path()..moveTo(pts[0].dx, pts[0].dy);
      for (int i = 1; i < pts.length; i++) {
        path.lineTo(pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = Pal.muted.withAlpha(90)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1,
      );
    }

    final b = baseline;
    if (b != null && b > lo && b < hi) {
      final y = plot.bottom - plot.height * (b - lo) / range;
      final dp = Paint()
        ..color = Pal.violet.withAlpha(190)
        ..strokeWidth = 1.3;
      double x = plot.left;
      while (x < plot.right) {
        canvas.drawLine(
            Offset(x, y), Offset(math.min(x + 6, plot.right), y), dp);
        x += 11;
      }
    }

    if (filtered.length > 1) {
      final n = filtered.length;
      final pts = <Offset>[
        for (int i = 0; i < n; i++) pt(i, filtered[i], n),
      ];
      final line = _smoothPath(pts);
      final fill = Path.from(line)
        ..lineTo(pts.last.dx, plot.bottom)
        ..lineTo(pts.first.dx, plot.bottom)
        ..close();
      canvas.drawPath(
        fill,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[Color(0x66FFA43A), Color(0x00FFA43A)],
          ).createShader(plot),
      );
      canvas.drawPath(
        line,
        Paint()
          ..color = Pal.amber
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );
      final last = pts.last;
      canvas.drawCircle(last, 10, Paint()..color = Pal.amber.withAlpha(50));
      canvas.drawCircle(last, 5.5, Paint()..color = Pal.amber);
      canvas.drawCircle(last, 2.5, Paint()..color = Colors.white);
    }
    canvas.restore();

    final cur = cursor;
    if (cur != null && filtered.length > 1) {
      final n = filtered.length;
      final i = (cur * (n - 1)).round().clamp(0, n - 1).toInt();
      final p = pt(i, filtered[i], n);
      canvas.drawLine(
        Offset(p.dx, plot.top),
        Offset(p.dx, plot.bottom),
        Paint()
          ..color = Colors.white.withAlpha(90)
          ..strokeWidth = 1,
      );
      canvas.drawCircle(p, 5, Paint()..color = Colors.white);
      final tp = TextPainter(
        text: TextSpan(
          text: filtered[i].toStringAsFixed(2),
          style: const TextStyle(
              color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      final bw = tp.width + 14;
      final bh = tp.height + 8;
      double bx = p.dx - bw / 2;
      if (bx < plot.left) bx = plot.left;
      if (bx + bw > plot.right) bx = plot.right - bw;
      final by = math.max(plot.top, p.dy - bh - 10);
      final rr = RRect.fromRectAndRadius(
          Rect.fromLTWH(bx, by, bw, bh), const Radius.circular(8));
      canvas.drawRRect(rr, Paint()..color = Pal.surface2);
      canvas.drawRRect(
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = Pal.amber,
      );
      tp.paint(canvas, Offset(bx + 7, by + 4));
    }
  }

  @override
  bool shouldRepaint(covariant LinePainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// Heat map (smoothly interpolated)
// ---------------------------------------------------------------------------

class HeatPainter extends CustomPainter {
  HeatPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    this.cursorX = -1,
    this.cursorY = -1,
    this.selX = -1,
    this.selY = -1,
    this.anomalies = const <CellAnomaly>[],
  });

  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;
  final int cursorX;
  final int cursorY;
  final int selX;
  final int selY;
  final List<CellAnomaly> anomalies;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols <= 0 || rows <= 0) return;
    final cell = math.min(size.width / cols, size.height / rows);
    final ox = (size.width - cell * cols) / 2;
    final oy = (size.height - cell * rows) / 2;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(ox, oy, cell * cols, cell * rows),
        const Radius.circular(10),
      ),
      Paint()..color = Pal.surface2,
    );

    const sub = 4;
    final sc = cell / sub;
    final paint = Paint()..style = PaintingStyle.fill;
    for (int sy = 0; sy < rows * sub; sy++) {
      final cyc = (sy + 0.5) / sub - 0.5;
      final y0 = cyc.floor();
      final ty = cyc - y0;
      final cellY = sy ~/ sub;
      for (int sx = 0; sx < cols * sub; sx++) {
        final cellX = sx ~/ sub;
        if (cells[cellY * cols + cellX].isNaN) continue;
        final cxc = (sx + 0.5) / sub - 0.5;
        final x0 = cxc.floor();
        final tx = cxc - x0;
        double sum = 0;
        double ws = 0;
        for (int dy = 0; dy <= 1; dy++) {
          for (int dx = 0; dx <= 1; dx++) {
            final gx = x0 + dx;
            final gy = y0 + dy;
            if (gx < 0 || gy < 0 || gx >= cols || gy >= rows) continue;
            final v = cells[gy * cols + gx];
            if (v.isNaN) continue;
            final w = (dx == 0 ? 1 - tx : tx) * (dy == 0 ? 1 - ty : ty);
            sum += v * w;
            ws += w;
          }
        }
        if (ws <= 0) continue;
        paint.color = heatColor((sum / ws - lo) / span);
        canvas.drawRect(
          Rect.fromLTWH(ox + sx * sc, oy + sy * sc, sc + 0.7, sc + 0.7),
          paint,
        );
      }
    }

    if (cell > 12) {
      final gp = Paint()
        ..color = Pal.bg.withAlpha(45)
        ..strokeWidth = 0.6;
      for (int x = 1; x < cols; x++) {
        canvas.drawLine(Offset(ox + x * cell, oy),
            Offset(ox + x * cell, oy + rows * cell), gp);
      }
      for (int y = 1; y < rows; y++) {
        canvas.drawLine(Offset(ox, oy + y * cell),
            Offset(ox + cols * cell, oy + y * cell), gp);
      }
    }

    for (final a in anomalies) {
      final c = Offset(ox + (a.x + 0.5) * cell, oy + (a.y + 0.5) * cell);
      final col = a.deviation >= 0 ? Colors.white : Pal.violet;
      canvas.drawCircle(
        c,
        cell * 0.85,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = col.withAlpha(220),
      );
      canvas.drawCircle(c, 2.5, Paint()..color = col);
    }

    void outline(int x, int y, Color color, double w) {
      canvas.drawRect(
        Rect.fromLTWH(ox + x * cell, oy + y * cell, cell, cell),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = w
          ..color = color,
      );
    }

    if (cursorX >= 0 && cursorY >= 0) outline(cursorX, cursorY, Colors.white, 2);
    if (selX >= 0 && selY >= 0) outline(selX, selY, Pal.good, 2.5);
  }

  @override
  bool shouldRepaint(covariant HeatPainter oldDelegate) => true;
}

// ---------------------------------------------------------------------------
// 3D surface (isometric, shaded)
// ---------------------------------------------------------------------------

class _Quad {
  _Quad(this.path, this.depth, this.color, [this.h = 0]);
  final Path path;
  final double depth;
  final Color color;
  final double h;
}

/// A target marker hanging below the ground plane in the 3D view.
class DepthPin {
  const DepthPin(this.x, this.y, this.depthM, this.metal);
  final int x;
  final int y;
  final double depthM;
  final bool metal;
}

class IsoPainter extends CustomPainter {
  IsoPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    required this.angle,
    required this.heightScale,
    this.tilt = 0.5,
    this.groundImage,
    this.groundOpacity = 0.6,
    this.showGround = true,
    this.pins = const <DepthPin>[],
    this.solid = false,
    this.cellM = 0.5,
    this.groundLabel = '',
  });

  final ui.Image? groundImage;
  final double groundOpacity;
  final bool showGround;
  final List<DepthPin> pins;
  final bool solid;
  final double cellM;
  final String groundLabel;

  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;
  final double angle;
  final double heightScale;
  final double tilt;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols < 2 || rows < 2) return;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);

    final valid = cells.where((e) => !e.isNaN).toList();
    final fillV = valid.isEmpty ? lo : medianOf(valid);
    double hv(int x, int y) {
      final v = cells[y * cols + x];
      return (((v.isNaN ? fillV : v) - lo) / span).clamp(0.0, 1.0).toDouble();
    }

    final gh = valid.isEmpty
        ? 0.0
        : ((medianOf(valid) - lo) / span).clamp(0.0, 1.0).toDouble();

    final up = (cols * rows <= 600) ? 2 : 1;
    final nx = (cols - 1) * up + 1;
    final ny = (rows - 1) * up + 1;

    final hh = List<double>.filled(nx * ny, 0);
    for (int j = 0; j < ny; j++) {
      final gy = j / up;
      final y0 = math.min(gy.floor(), rows - 2);
      final ty = gy - y0;
      for (int i = 0; i < nx; i++) {
        final gx = i / up;
        final x0 = math.min(gx.floor(), cols - 2);
        final tx = gx - x0;
        hh[j * nx + i] = hv(x0, y0) * (1 - tx) * (1 - ty) +
            hv(x0 + 1, y0) * tx * (1 - ty) +
            hv(x0, y0 + 1) * (1 - tx) * ty +
            hv(x0 + 1, y0 + 1) * tx * ty;
      }
    }

    final unit = math.min(size.width / ((cols + rows) * 0.8),
        size.height / ((cols + rows) * tilt + 7));
    final origin = Offset(size.width / 2, size.height * 0.64);
    final cx = (cols - 1) / 2;
    final cy = (rows - 1) / 2;
    final ca = math.cos(angle);
    final sa = math.sin(angle);

    Offset project(double gx, double gy, double h) {
      final dx = gx - cx;
      final dy = gy - cy;
      final rx = dx * ca - dy * sa;
      final ry = dx * sa + dy * ca;
      final sx = (rx - ry) * 0.866 * unit;
      final sy = (rx + ry) * tilt * unit - h * heightScale * 6 * unit;
      return origin + Offset(sx, sy);
    }

    // floor plate and grid
    final floor = Path()
      ..moveTo(project(0, 0, 0).dx, project(0, 0, 0).dy)
      ..lineTo(project(cols - 1.0, 0, 0).dx, project(cols - 1.0, 0, 0).dy)
      ..lineTo(project(cols - 1.0, rows - 1.0, 0).dx,
          project(cols - 1.0, rows - 1.0, 0).dy)
      ..lineTo(project(0, rows - 1.0, 0).dx, project(0, rows - 1.0, 0).dy)
      ..close();
    canvas.drawPath(floor, Paint()..color = Pal.surface2.withAlpha(150));
    final gridPaint = Paint()
      ..color = Pal.outline.withAlpha(140)
      ..strokeWidth = 0.7;
    final stepG = cols > 20 || rows > 20 ? 2 : 1;
    for (int x = 0; x < cols; x += stepG) {
      canvas.drawLine(
          project(x.toDouble(), 0, 0), project(x.toDouble(), rows - 1.0, 0), gridPaint);
    }
    for (int y = 0; y < rows; y += stepG) {
      canvas.drawLine(
          project(0, y.toDouble(), 0), project(cols - 1.0, y.toDouble(), 0), gridPaint);
    }
    canvas.drawPath(
      floor,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = Pal.outline,
    );

    // ---- surface (smooth) or solid columns ------------------------------
    final quads = <_Quad>[];
    if (solid) {
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          final v = cells[y * cols + x];
          if (v.isNaN) continue;
          final h = hv(x, y);
          final base = heatColor(h);
          final mx = x - cx;
          final my = y - cy;
          final depth = (mx * ca - my * sa) + (mx * sa + my * ca);
          // four side faces + top, drawn as one group per column
          final x0 = x - 0.5;
          final x1 = x + 0.5;
          final y0 = y - 0.5;
          final y1 = y + 0.5;
          final path = Path();
          final faces = <List<Offset>>[
            <Offset>[project(x0, y0, 0), project(x1, y0, 0), project(x1, y0, h), project(x0, y0, h)],
            <Offset>[project(x1, y0, 0), project(x1, y1, 0), project(x1, y1, h), project(x1, y0, h)],
            <Offset>[project(x1, y1, 0), project(x0, y1, 0), project(x0, y1, h), project(x1, y1, h)],
            <Offset>[project(x0, y1, 0), project(x0, y0, 0), project(x0, y0, h), project(x0, y1, h)],
          ];
          final top = <Offset>[
            project(x0, y0, h), project(x1, y0, h), project(x1, y1, h), project(x0, y1, h)
          ];
          // shaded sides first, bright top last
          for (int f = 0; f < 4; f++) {
            final fp = faces[f];
            final pth = Path()
              ..moveTo(fp[0].dx, fp[0].dy)
              ..lineTo(fp[1].dx, fp[1].dy)
              ..lineTo(fp[2].dx, fp[2].dy)
              ..lineTo(fp[3].dx, fp[3].dy)
              ..close();
            final fc = (f.isEven ? 0.62 : 0.42);
            final mid = Offset((fp[0].dx + fp[1].dx) / 2, (fp[0].dy + fp[1].dy) / 2);
            // only faces pointing towards the viewer (lower on screen than the column centre)
            final cen = project(x.toDouble(), y.toDouble(), 0);
            if (mid.dy >= cen.dy - 0.01) {
              quads.add(_Quad(pth, depth - 0.001, shade(base, fc), h));
            }
          }
          path
            ..moveTo(top[0].dx, top[0].dy)
            ..lineTo(top[1].dx, top[1].dy)
            ..lineTo(top[2].dx, top[2].dy)
            ..lineTo(top[3].dx, top[3].dy)
            ..close();
          quads.add(_Quad(path, depth, shade(base, 1.08), h));
        }
      }
    } else {
      for (int j = 0; j < ny - 1; j++) {
        for (int i = 0; i < nx - 1; i++) {
          final h00 = hh[j * nx + i];
          final h10 = hh[j * nx + i + 1];
          final h01 = hh[(j + 1) * nx + i];
          final h11 = hh[(j + 1) * nx + i + 1];
          final x = i.toDouble() / up;
          final y = j.toDouble() / up;
          final x1 = (i + 1).toDouble() / up;
          final y1 = (j + 1).toDouble() / up;
          final p00 = project(x, y, h00);
          final p10 = project(x1, y, h10);
          final p11 = project(x1, y1, h11);
          final p01 = project(x, y1, h01);
          final path = Path()
            ..moveTo(p00.dx, p00.dy)
            ..lineTo(p10.dx, p10.dy)
            ..lineTo(p11.dx, p11.dy)
            ..lineTo(p01.dx, p01.dy)
            ..close();

          final srcX = math.min(((i + 0.5) / up).floor(), cols - 1);
          final srcY = math.min(((j + 0.5) / up).floor(), rows - 1);
          final empty = cells[srcY * cols + srcX].isNaN;

          final avg = (h00 + h10 + h01 + h11) / 4;
          final dxs = (h10 + h11 - h00 - h01) / 2;
          final dys = (h01 + h11 - h00 - h10) / 2;
          final light = (-(dxs + dys) * up * 3.0).clamp(-0.4, 0.4).toDouble();

          final base = empty
              ? Pal.surface2.withAlpha(190)
              : shade(heatColor(avg), 1.0 + light);
          final mx = x + 0.5 / up - cx;
          final my = y + 0.5 / up - cy;
          final depth = (mx * ca - my * sa) + (mx * sa + my * ca);
          quads.add(_Quad(path, depth, base, avg));
        }
      }
    }
    quads.sort((a, b) => a.depth.compareTo(b.depth));

    final fill = Paint()..style = PaintingStyle.fill;
    final seam = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    void drawQuad(_Quad q) {
      fill.color = q.color;
      seam.color = q.color;
      canvas.drawPath(q.path, fill);
      canvas.drawPath(q.path, seam);
    }

    // Parts of the surface below the ground level are drawn first, then the
    // ground sheet, then the parts that rise above it.
    if (showGround) {
      for (final q in quads) {
        if (q.h <= gh) drawQuad(q);
      }
      _drawGround(canvas, project, gh);
      for (final q in quads) {
        if (q.h > gh) drawQuad(q);
      }
    } else {
      for (final q in quads) {
        drawQuad(q);
      }
    }

    // depth pins: targets hanging below the ground sheet
    if (showGround) {
      for (final pin in pins) {
        final o = project(pin.x.toDouble(), pin.y.toDouble(), gh);
        final dPx = (pin.depthM / (cellM <= 0 ? 0.5 : cellM) * unit)
            .clamp(8.0, 150.0)
            .toDouble();
        final end = o + Offset(0, dPx);
        final c = pin.metal ? Pal.amber : Pal.violet;
        final line = Paint()
          ..color = c
          ..strokeWidth = 1.6;
        const seg = 5.0;
        for (double yy = 0; yy < dPx; yy += seg * 2) {
          canvas.drawLine(o + Offset(0, yy),
              o + Offset(0, math.min(yy + seg, dPx)), line);
        }
        canvas.drawCircle(o, 3, Paint()..color = Colors.white);
        final dia = Path()
          ..moveTo(end.dx, end.dy - 6)
          ..lineTo(end.dx + 6, end.dy)
          ..lineTo(end.dx, end.dy + 6)
          ..lineTo(end.dx - 6, end.dy)
          ..close();
        canvas.drawPath(dia, Paint()..color = c);
        canvas.drawPath(
            dia,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.2
              ..color = Colors.white);
        _label(canvas, '~${pin.depthM.toStringAsFixed(1)} m',
            end + const Offset(9, -7),
            color: Colors.white, size: 11);
      }
    }

    // peak marker
    if (valid.isNotEmpty) {
      int bx = 0;
      int by = 0;
      double bv = -double.infinity;
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          final v = cells[y * cols + x];
          if (!v.isNaN && v > bv) {
            bv = v;
            bx = x;
            by = y;
          }
        }
      }
      final tip = project(bx.toDouble(), by.toDouble(), hv(bx, by));
      canvas.drawLine(
          tip, tip + const Offset(0, -26), Paint()..color = Colors.white..strokeWidth = 1.2);
      canvas.drawCircle(tip + const Offset(0, -26), 4, Paint()..color = Colors.white);
      _label(canvas, bv.toStringAsFixed(2), tip + const Offset(6, -42),
          color: Colors.white, size: 11);
    }
  }

  void _drawGround(Canvas canvas, Offset Function(double, double, double) project,
      double gh) {
    final q0 = project(-0.5, -0.5, gh);
    final q1 = project(cols - 0.5, -0.5, gh);
    final q2 = project(cols - 0.5, rows - 0.5, gh);
    final q3 = project(-0.5, rows - 0.5, gh);
    final sheet = Path()
      ..moveTo(q0.dx, q0.dy)
      ..lineTo(q1.dx, q1.dy)
      ..lineTo(q2.dx, q2.dy)
      ..lineTo(q3.dx, q3.dy)
      ..close();
    final img = groundImage;
    if (img != null) {
      final w = img.width.toDouble();
      final h = img.height.toDouble();
      final verts = ui.Vertices(
        ui.VertexMode.triangles,
        <Offset>[q0, q1, q2, q0, q2, q3],
        textureCoordinates: <Offset>[
          const Offset(0, 0),
          Offset(w, 0),
          Offset(w, h),
          const Offset(0, 0),
          Offset(w, h),
          Offset(0, h),
        ],
      );
      final a = (groundOpacity.clamp(0.0, 1.0) * 255).round();
      canvas.saveLayer(
          sheet.getBounds().inflate(2), Paint()..color = Color.fromARGB(a, 255, 255, 255));
      canvas.drawVertices(
        verts,
        BlendMode.srcOver,
        Paint()
          ..shader = ImageShader(img, TileMode.clamp, TileMode.clamp,
              Matrix4.identity().storage),
      );
      canvas.restore();
    } else {
      canvas.drawPath(sheet, Paint()..color = Pal.good.withAlpha(38));
    }
    canvas.drawPath(
      sheet,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = Pal.good.withAlpha(190),
    );
    if (groundLabel.isNotEmpty) {
      _label(canvas, groundLabel, q3 + const Offset(4, 4),
          color: Pal.good, size: 11);
    }
  }

  @override
  bool shouldRepaint(covariant IsoPainter oldDelegate) => true;
}
