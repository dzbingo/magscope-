import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'theme.dart';

String stamp(DateTime d) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)}_${two(d.hour)}-${two(d.minute)}';
}

/// Colour ramp for the heat map: indigo -> purple -> magenta -> orange -> yellow.
Color heatColor(double t) {
  const stops = <Color>[
    Color(0xFF1B1464),
    Color(0xFF6A1B9A),
    Color(0xFFD81B60),
    Color(0xFFFF8F00),
    Color(0xFFFFF176),
  ];
  final x = t.isNaN ? 0.0 : t.clamp(0.0, 1.0).toDouble();
  final scaled = x * (stops.length - 1);
  final i = math.min(scaled.floor(), stops.length - 2);
  final f = scaled - i;
  return Color.lerp(stops[i], stops[i + 1], f) ?? stops[i];
}

class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: Pal.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Pal.outline),
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: Pal.text,
        ),
      ),
    );
  }
}

class HeatLegend extends StatelessWidget {
  const HeatLegend({super.key, required this.lo, required this.hi});
  final double lo;
  final double hi;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          height: 10,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            gradient: LinearGradient(
              colors: <Color>[
                heatColor(0),
                heatColor(0.25),
                heatColor(0.5),
                heatColor(0.75),
                heatColor(1),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Text(lo.toStringAsFixed(2),
                style: const TextStyle(color: Pal.muted, fontSize: 11)),
            Text(hi.toStringAsFixed(2),
                style: const TextStyle(color: Pal.muted, fontSize: 11)),
          ],
        ),
      ],
    );
  }
}

void _label(Canvas canvas, String text, Offset at,
    {Color color = Pal.muted, double size = 10}) {
  final tp = TextPainter(
    text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, at);
}

/// Scrolling line chart: raw signal (dim) and filtered signal (bright).
class LinePainter extends CustomPainter {
  LinePainter({required this.raw, required this.filtered});

  final List<double> raw;
  final List<double> filtered;

  @override
  void paint(Canvas canvas, Size size) {
    const padL = 44.0;
    const padR = 6.0;
    const padT = 6.0;
    const padB = 6.0;
    final plot = Rect.fromLTWH(
        padL, padT, size.width - padL - padR, size.height - padT - padB);

    double lo = double.infinity;
    double hi = -double.infinity;
    for (final v in raw) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    for (final v in filtered) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    final hasData = lo.isFinite && hi.isFinite;
    if (!hasData) {
      lo = 0;
      hi = 1;
    }
    if (hi - lo < 0.5) {
      final c = (hi + lo) / 2;
      lo = c - 0.25;
      hi = c + 0.25;
    }
    final pad = (hi - lo) * 0.1;
    lo -= pad;
    hi += pad;

    final gridPaint = Paint()
      ..color = Pal.outline
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final y = plot.top + plot.height * i / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
      if (hasData) {
        final v = hi - (hi - lo) * i / 4;
        _label(canvas, v.toStringAsFixed(1), Offset(0, y - 6));
      }
    }

    void drawSeries(List<double> s, Paint p) {
      if (s.length < 2) return;
      final path = Path();
      for (int i = 0; i < s.length; i++) {
        final x = plot.left + plot.width * i / (s.length - 1);
        final y = plot.bottom - plot.height * (s[i] - lo) / (hi - lo);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(path, p);
    }

    canvas.save();
    canvas.clipRect(plot.inflate(2));
    drawSeries(
      raw,
      Paint()
        ..color = Pal.muted.withAlpha(110)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
    drawSeries(
      filtered,
      Paint()
        ..color = Pal.amber
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeJoin = StrokeJoin.round,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant LinePainter oldDelegate) => true;
}

/// Flat heat map of the scanned grid. Empty cells are dark.
class HeatPainter extends CustomPainter {
  HeatPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    this.cursorX = -1,
    this.cursorY = -1,
  });

  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;
  final int cursorX;
  final int cursorY;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols <= 0 || rows <= 0) return;
    final cell = math.min(size.width / cols, size.height / rows);
    final ox = (size.width - cell * cols) / 2;
    final oy = (size.height - cell * rows) / 2;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);
    final paint = Paint()..style = PaintingStyle.fill;
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final v = cells[y * cols + x];
        paint.color = v.isNaN ? Pal.surface2 : heatColor((v - lo) / span);
        final r = Rect.fromLTWH(ox + x * cell, oy + y * cell, cell, cell)
            .deflate(0.6);
        canvas.drawRRect(
            RRect.fromRectAndRadius(r, const Radius.circular(2)), paint);
      }
    }
    if (cursorX >= 0 && cursorY >= 0) {
      final r = Rect.fromLTWH(
          ox + cursorX * cell, oy + cursorY * cell, cell, cell);
      canvas.drawRect(
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white,
      );
    }
  }

  @override
  bool shouldRepaint(covariant HeatPainter oldDelegate) => true;
}

class _Quad {
  _Quad(this.path, this.depth, this.color);
  final Path path;
  final double depth;
  final Color color;
}

/// Pseudo-3D height map (isometric projection) of the scanned grid.
class IsoPainter extends CustomPainter {
  IsoPainter({
    required this.cells,
    required this.cols,
    required this.rows,
    required this.lo,
    required this.hi,
    required this.angle,
    required this.heightScale,
  });

  final List<double> cells;
  final int cols;
  final int rows;
  final double lo;
  final double hi;
  final double angle;
  final double heightScale;

  @override
  void paint(Canvas canvas, Size size) {
    if (cols < 2 || rows < 2) return;
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);
    double norm(int x, int y) {
      final v = cells[y * cols + x];
      if (v.isNaN) return 0.0;
      return ((v - lo) / span).clamp(0.0, 1.0).toDouble();
    }

    final unit = math.min(size.width / ((cols + rows) * 0.8),
        size.height / ((cols + rows) * 0.5 + 6));
    final origin = Offset(size.width / 2, size.height * 0.62);
    final cx = (cols - 1) / 2;
    final cy = (rows - 1) / 2;
    final ca = math.cos(angle);
    final sa = math.sin(angle);

    Offset project(double gx, double gy, double h) {
      final dx = gx - cx;
      final dy = gy - cy;
      final rx = dx * ca - dy * sa;
      final ry = dx * sa + dy * ca;
      final sx = (rx - ry) * 0.866 * unit;
      final sy = (rx + ry) * 0.5 * unit - h * heightScale * 6 * unit;
      return origin + Offset(sx, sy);
    }

    final quads = <_Quad>[];
    for (int y = 0; y < rows - 1; y++) {
      for (int x = 0; x < cols - 1; x++) {
        final h00 = norm(x, y);
        final h10 = norm(x + 1, y);
        final h11 = norm(x + 1, y + 1);
        final h01 = norm(x, y + 1);
        final avg = (h00 + h10 + h11 + h01) / 4;
        final allEmpty = cells[y * cols + x].isNaN &&
            cells[y * cols + x + 1].isNaN &&
            cells[(y + 1) * cols + x + 1].isNaN &&
            cells[(y + 1) * cols + x].isNaN;
        final path = Path()
          ..moveTo(project(x.toDouble(), y.toDouble(), h00).dx,
              project(x.toDouble(), y.toDouble(), h00).dy)
          ..lineTo(project(x + 1.0, y.toDouble(), h10).dx,
              project(x + 1.0, y.toDouble(), h10).dy)
          ..lineTo(project(x + 1.0, y + 1.0, h11).dx,
              project(x + 1.0, y + 1.0, h11).dy)
          ..lineTo(project(x.toDouble(), y + 1.0, h01).dx,
              project(x.toDouble(), y + 1.0, h01).dy)
          ..close();
        final mx = x + 0.5 - cx;
        final my = y + 0.5 - cy;
        final depth = (mx * ca - my * sa) + (mx * sa + my * ca);
        quads.add(_Quad(path, depth, allEmpty ? Pal.surface2 : heatColor(avg)));
      }
    }
    quads.sort((a, b) => a.depth.compareTo(b.depth));

    final fill = Paint()..style = PaintingStyle.fill;
    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6
      ..color = Pal.bg.withAlpha(160);
    for (final q in quads) {
      fill.color = q.color;
      canvas.drawPath(q.path, fill);
      canvas.drawPath(q.path, edge);
    }
  }

  @override
  bool shouldRepaint(covariant IsoPainter oldDelegate) => true;
}
