import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// Public folder "MagVision Pro" in the phone memory for scans and reports.
/// Falls back to the app's own external folder when the phone refuses it.
class AppFolders {
  static Future<Directory?> root() async {
    if (!Platform.isAndroid) return null;
    try {
      final d = Directory('/storage/emulated/0/MagVision Pro');
      if (!await d.exists()) await d.create(recursive: true);
      final t = File('${d.path}/.write_test');
      await t.writeAsString('1');
      await t.delete();
      return d;
    } catch (_) {}
    try {
      return await getExternalStorageDirectory();
    } catch (_) {
      return null;
    }
  }
}

/// Saves and loads scan sessions as JSON files inside the app's private folder.
class SessionStore {
  static Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/sessions');
    if (!await d.exists()) {
      await d.create(recursive: true);
    }
    return d;
  }

  static Future<List<ScanSession>> loadAll() async {
    final out = <ScanSession>[];
    try {
      final d = await _dir();
      await for (final e in d.list()) {
        if (e is File && e.path.endsWith('.json')) {
          try {
            final j = jsonDecode(await e.readAsString()) as Map<String, dynamic>;
            out.add(ScanSession.fromJson(j));
          } catch (_) {
            // skip unreadable file
          }
        }
      }
    } catch (_) {}
    // After a reinstall the private folder is empty but the public copies in
    // "MagVision Pro/Scans" survive: bring them back.
    try {
      final r = await AppFolders.root();
      if (r != null) {
        final sd = Directory('${r.path}/Scans');
        if (await sd.exists()) {
          final have = out.map((ScanSession e) => e.id).toSet();
          await for (final e in sd.list()) {
            if (e is File && e.path.endsWith('.json')) {
              try {
                final text = await e.readAsString();
                final sess =
                    ScanSession.fromJson(jsonDecode(text) as Map<String, dynamic>);
                if (have.contains(sess.id)) continue;
                have.add(sess.id);
                out.add(sess);
                final d = await _dir();
                await File('${d.path}/${sess.id}.json').writeAsString(text);
              } catch (_) {}
            }
          }
        }
      }
    } catch (_) {}
    out.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return out;
  }

  static Future<void> save(ScanSession s) async {
    final d = await _dir();
    final f = File('${d.path}/${s.id}.json');
    final text = jsonEncode(s.toJson());
    await f.writeAsString(text);
    // also keep a readable copy in the public MagVision Pro folder
    try {
      final r = await AppFolders.root();
      if (r != null) {
        final sd = Directory('${r.path}/Scans');
        if (!await sd.exists()) await sd.create(recursive: true);
        final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_\-\u0600-\u06FF ]'), '_');
        final target = '${sd.path}/${clean}_${s.id}.json';
        // a renamed scan must replace its old public copy, not sit beside it
        await for (final e in sd.list()) {
          if (e is File && e.path.endsWith('_${s.id}.json') && e.path != target) {
            try {
              await e.delete();
            } catch (_) {}
          }
        }
        await File(target).writeAsString(text);
      }
    } catch (_) {}
  }

  // ---- draft of the scan in progress (survives app kill / empty battery)
  static Future<File> _draftFile() async {
    final base = await getApplicationDocumentsDirectory();
    return File('${base.path}/draft_scan.json');
  }

  static Future<void> saveDraft(ScanSession s) async {
    final f = await _draftFile();
    await f.writeAsString(jsonEncode(s.toJson()));
  }

  static Future<ScanSession?> loadDraft() async {
    try {
      final f = await _draftFile();
      if (!await f.exists()) return null;
      final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      return ScanSession.fromJson(j);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clearDraft() async {
    try {
      final f = await _draftFile();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  static Future<void> delete(ScanSession s) async {
    final d = await _dir();
    final f = File('${d.path}/${s.id}.json');
    if (await f.exists()) {
      await f.delete();
    }
    // remove the public copy too, or it would come back after a restart
    try {
      final r = await AppFolders.root();
      if (r != null) {
        final sd = Directory('${r.path}/Scans');
        if (await sd.exists()) {
          await for (final e in sd.list()) {
            if (e is File && e.path.endsWith('_${s.id}.json')) await e.delete();
          }
        }
      }
    } catch (_) {}
  }

  /// Writes two CSV files (raw samples and the grid) and returns the folder.
  static Future<String> exportCsv(ScanSession s) async {
    Directory? ext;
    try {
      ext = await AppFolders.root();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final safe = '${s.id}_$clean';

    final raw = StringBuffer('index,value\n');
    for (int i = 0; i < s.raw.length; i++) {
      raw.writeln('$i,${s.raw[i]}');
    }
    await File('${base.path}/${safe}_raw.csv').writeAsString(raw.toString());

    final grid = StringBuffer();
    for (int y = 0; y < s.rows; y++) {
      final row = <String>[];
      for (int x = 0; x < s.cols; x++) {
        final v = s.cells[y * s.cols + x];
        row.add(v.isNaN ? '' : v.toStringAsFixed(3));
      }
      grid.writeln(row.join(','));
    }
    await File('${base.path}/${safe}_grid.csv').writeAsString(grid.toString());
    return base.path;
  }
}
