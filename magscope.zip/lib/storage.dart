import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// Saves and loads scan sessions as JSON files inside the app's private folder.
class SessionStore {
  static Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/sessions');
    if (!await d.exists()) {
      await d.create(recursive: true);
    }
    return d;
  }

  static Future<List<ScanSession>> loadAll() async {
    final out = <ScanSession>[];
    try {
      final d = await _dir();
      await for (final e in d.list()) {
        if (e is File && e.path.endsWith('.json')) {
          try {
            final j = jsonDecode(await e.readAsString()) as Map<String, dynamic>;
            out.add(ScanSession.fromJson(j));
          } catch (_) {
            // skip unreadable file
          }
        }
      }
    } catch (_) {}
    out.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return out;
  }

  static Future<void> save(ScanSession s) async {
    final d = await _dir();
    final f = File('${d.path}/${s.id}.json');
    await f.writeAsString(jsonEncode(s.toJson()));
  }

  static Future<void> delete(ScanSession s) async {
    final d = await _dir();
    final f = File('${d.path}/${s.id}.json');
    if (await f.exists()) {
      await f.delete();
    }
  }

  /// Writes two CSV files (raw samples and the grid) and returns the folder.
  static Future<String> exportCsv(ScanSession s) async {
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final safe = '${s.id}_$clean';

    final raw = StringBuffer('index,value\n');
    for (int i = 0; i < s.raw.length; i++) {
      raw.writeln('$i,${s.raw[i]}');
    }
    await File('${base.path}/${safe}_raw.csv').writeAsString(raw.toString());

    final grid = StringBuffer();
    for (int y = 0; y < s.rows; y++) {
      final row = <String>[];
      for (int x = 0; x < s.cols; x++) {
        final v = s.cells[y * s.cols + x];
        row.add(v.isNaN ? '' : v.toStringAsFixed(3));
      }
      grid.writeln(row.join(','));
    }
    await File('${base.path}/${safe}_grid.csv').writeAsString(grid.toString());
    return base.path;
  }
}
