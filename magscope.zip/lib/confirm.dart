import 'dart:math' as math;

import 'dsp.dart';

/// A suspect target noted from the first scan, kept so that a second scan of
/// the same grid, walked at right angles, can confirm or reject it.
class ConfirmTarget {
  const ConfirmTarget({
    required this.x,
    required this.y,
    required this.metal,
    required this.depthM,
    required this.cols,
    required this.rows,
    required this.cellCm,
    required this.firstPerp,
  });

  final int x;
  final int y;
  final bool metal;
  final double? depthM;
  final int cols;
  final int rows;
  final double cellCm;
  final bool firstPerp; // true when the first scan was already east-west
}

enum ConfirmVerdict { confirmed, notConfirmed, conflict, differentGrid, sameDirection }

class ConfirmResult {
  const ConfirmResult(this.verdict, {this.distM, this.depthRatio});
  final ConfirmVerdict verdict;
  final double? distM;
  final double? depthRatio;
}

/// Compares the remembered target with the targets found in the second scan.
/// Heuristic limits (not field-validated): same place = within 2 cells or
/// 0.6 m, whichever is larger; depth is "similar" within a factor 1.8.
ConfirmResult judgeConfirmation({
  required ConfirmTarget first,
  required List<CellAnomaly> second,
  required double? Function(CellAnomaly) depthOf,
  required int cols,
  required int rows,
  required double cellCm,
  required bool secondPerp,
}) {
  if (cols != first.cols || rows != first.rows || (cellCm - first.cellCm).abs() > 0.5) {
    return const ConfirmResult(ConfirmVerdict.differentGrid);
  }
  if (secondPerp == first.firstPerp) {
    return const ConfirmResult(ConfirmVerdict.sameDirection);
  }
  final tolCells = math.max(2.0, 60.0 / cellCm);
  CellAnomaly? best;
  double bestD = double.infinity;
  CellAnomaly? bestOpp;
  double bestOppD = double.infinity;
  for (final h in second) {
    final d = math.sqrt(math.pow(h.x - first.x, 2) + math.pow(h.y - first.y, 2)).toDouble();
    if (d > tolCells) continue;
    final isMetal = h.deviation >= 0;
    if (isMetal == first.metal) {
      if (d < bestD) {
        bestD = d;
        best = h;
      }
    } else if (d < bestOppD) {
      bestOppD = d;
      bestOpp = h;
    }
  }
  if (best != null) {
    double? ratio;
    final dd = depthOf(best);
    if (first.depthM != null && dd != null && dd > 0) {
      ratio = dd / first.depthM!;
    }
    return ConfirmResult(ConfirmVerdict.confirmed,
        distM: bestD * cellCm / 100.0, depthRatio: ratio);
  }
  if (bestOpp != null) {
    return ConfirmResult(ConfirmVerdict.conflict, distM: bestOppD * cellCm / 100.0);
  }
  return const ConfirmResult(ConfirmVerdict.notConfirmed);
}
