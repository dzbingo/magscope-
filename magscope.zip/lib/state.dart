import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dsp.dart';
import 'l10n.dart';
import 'models.dart';
import 'sources.dart';
import 'storage.dart';
import 'widgets.dart' show kPalette, kPalettes;

enum ConnState { idle, connecting, connected, error }

/// Makes [AppState] available to every widget.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    return scope!.notifier!;
  }
}

String tr(BuildContext context, String key) => AppScope.of(context).t(key);

class AppState extends ChangeNotifier {
  // ---- settings ----------------------------------------------------------
  Locale locale = const Locale('ar');
  bool useBle = false;
  FilterConfig filters = const FilterConfig();
  int cols = 16;
  int rows = 16;
  int samplesPerCell = 8;
  String serviceUuid = '';
  String charUuid = '';
  PacketFormat format = PacketFormat.ascii;
  double scale = 1.0;
  int axes = 1;
  String? deviceId;
  String deviceName = '';
  bool alerts = true;
  double minSpan = 2.0;
  int palette = 0;

  // ---- detector (live deviation from the reference level) ----------------
  double? baselineRef;
  double refValue = double.nan;
  double dev = 0;
  double sigma = 0.1;
  bool alarm = false;
  DateTime _lastBuzz = DateTime.fromMillisecondsSinceEpoch(0);

  // ---- runtime -----------------------------------------------------------
  ConnState conn = ConnState.idle;
  String? errorKey;
  bool scanning = false;
  final List<double> live = <double>[];
  List<double> allRaw = <double>[];
  List<double> cells = <double>[];
  int cellIdx = 0;
  int inCell = 0;
  double cellSum = 0;
  double lastValue = double.nan;
  List<ScanSession> sessions = <ScanSession>[];
  List<ScanResult> bleResults = <ScanResult>[];
  bool searching = false;

  SampleSource? _source;
  StreamSubscription<double>? _sub;
  StreamSubscription<List<ScanResult>>? _scanSub;
  Timer? _ticker;
  Timer? _rateTimer;
  bool _dirty = false;
  int _rateCount = 0;
  double sampleRate = 0;

  // ---- helpers -----------------------------------------------------------
  String t(String key) {
    final list = kStrings[key];
    if (list == null) return key;
    final code = locale.languageCode;
    final i = code == 'ar' ? 0 : (code == 'fr' ? 2 : 1);
    return list[i];
  }

  bool get hasData => allRaw.isNotEmpty;
  int get totalCells => cols * rows;

  List<double> get filteredLive => filters.apply(live);

  List<double> get displayCells => filters.gridSmooth
      ? smoothGrid(cells, cols, rows, filters.gridPasses)
      : cells;

  // ---- lifecycle ---------------------------------------------------------
  Future<void> init() async {
    await _loadPrefs();
    _resetCells();
    sessions = await SessionStore.loadAll();
    notifyListeners();
  }

  void _resetCells() {
    cells = List<double>.filled(cols * rows, double.nan);
    cellIdx = 0;
    inCell = 0;
    cellSum = 0;
  }

  Future<void> _loadPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      locale = Locale(p.getString('lang') ?? 'ar');
      useBle = p.getBool('useBle') ?? false;
      cols = p.getInt('cols') ?? 16;
      rows = p.getInt('rows') ?? 16;
      samplesPerCell = p.getInt('spc') ?? 8;
      serviceUuid = p.getString('svc') ?? '';
      charUuid = p.getString('chr') ?? '';
      final fi = p.getInt('format') ?? 0;
      format = PacketFormat
          .values[math.min(math.max(fi, 0), PacketFormat.values.length - 1)];
      scale = p.getDouble('scale') ?? 1.0;
      axes = p.getInt('axes') ?? 1;
      alerts = p.getBool('alerts') ?? true;
      deviceId = p.getString('devId');
      deviceName = p.getString('devName') ?? '';
      minSpan = p.getDouble('minSpan') ?? 2.0;
      palette = (p.getInt('palette') ?? 0).clamp(0, kPalettes.length - 1).toInt();
      kPalette = palette;
      final f = p.getString('filters');
      if (f != null) {
        filters = FilterConfig.fromJson(jsonDecode(f) as Map<String, dynamic>);
      }
    } catch (_) {}
  }

  Future<void> _savePrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('lang', locale.languageCode);
      await p.setBool('useBle', useBle);
      await p.setInt('cols', cols);
      await p.setInt('rows', rows);
      await p.setInt('spc', samplesPerCell);
      await p.setString('svc', serviceUuid);
      await p.setString('chr', charUuid);
      await p.setInt('format', format.index);
      await p.setDouble('scale', scale);
      await p.setInt('axes', axes);
      await p.setBool('alerts', alerts);
      if (deviceId != null) await p.setString('devId', deviceId!);
      await p.setString('devName', deviceName);
      await p.setDouble('minSpan', minSpan);
      await p.setInt('palette', palette);
      await p.setString('filters', jsonEncode(filters.toJson()));
    } catch (_) {}
  }

  // ---- settings setters --------------------------------------------------
  void setLocale(String code) {
    locale = Locale(code);
    notifyListeners();
    _savePrefs();
  }

  void setUseBle(bool v) {
    useBle = v;
    notifyListeners();
    _savePrefs();
  }

  void setFilters(FilterConfig f) {
    filters = f;
    notifyListeners();
    _savePrefs();
  }

  void setGrid(int c, int r) {
    if (scanning) return;
    cols = c;
    rows = r;
    clearData();
    _savePrefs();
  }

  void setPalette(int v) {
    palette = v;
    kPalette = v;
    notifyListeners();
    _savePrefs();
  }

  void setMinSpan(double v) {
    minSpan = v;
    notifyListeners();
    _savePrefs();
  }

  void setSamplesPerCell(int v) {
    samplesPerCell = v;
    notifyListeners();
    _savePrefs();
  }

  void setBleConfig({
    String? service,
    String? characteristic,
    PacketFormat? fmt,
    double? scaleFactor,
    int? axisCount,
  }) {
    if (service != null) serviceUuid = service;
    if (characteristic != null) charUuid = characteristic;
    if (fmt != null) format = fmt;
    if (scaleFactor != null) scale = scaleFactor;
    if (axisCount != null) axes = axisCount;
    notifyListeners();
    _savePrefs();
  }

  // ---- scan data ---------------------------------------------------------
  void clearData() {
    live.clear();
    allRaw = <double>[];
    lastValue = double.nan;
    dev = 0;
    alarm = false;
    refValue = double.nan;
    _resetCells();
    notifyListeners();
  }

  int get filledCells {
    int n = 0;
    for (final v in cells) {
      if (!v.isNaN) n++;
    }
    return n;
  }

  void setAlerts(bool v) {
    alerts = v;
    notifyListeners();
    _savePrefs();
  }

  /// Uses the current filtered level as the "ground" reference.
  void calibrate() {
    if (live.length < 10) return;
    final f = filteredLive;
    final tail = f.length > 40 ? f.sublist(f.length - 40) : f;
    baselineRef = medianOf(tail);
    _evaluate();
    notifyListeners();
  }

  void resetCalibration() {
    baselineRef = null;
    _evaluate();
    notifyListeners();
  }

  /// Compares the latest filtered reading with the reference level and
  /// decides whether it is an anomaly (and vibrates if alerts are on).
  void _evaluate() {
    if (live.length < 20) {
      dev = 0;
      alarm = false;
      return;
    }
    final tail = live.length > 150
        ? live.sublist(live.length - 150)
        : List<double>.from(live);
    final f = filters.apply(tail);
    if (f.isEmpty) return;
    final med = medianOf(f);
    final mad = medianOf(f.map((e) => (e - med).abs()).toList()) * 1.4826;
    sigma = math.max(mad, 0.05);
    final ref = baselineRef ?? med;
    refValue = ref;
    dev = f.last - ref;
    alarm = dev.abs() > filters.sensitivity * sigma;
    if (alarm && alerts && scanning) {
      final now = DateTime.now();
      if (now.difference(_lastBuzz).inMilliseconds > 700) {
        _lastBuzz = now;
        HapticFeedback.mediumImpact();
      }
    }
  }

  /// Snake path across the grid: even rows go left->right, odd rows back.
  List<int> _coord(int idx) {
    final row = idx ~/ cols;
    final c = idx % cols;
    final x = row.isEven ? c : cols - 1 - c;
    return <int>[x, row];
  }

  /// Grid coordinate (x, y) of the cell currently being filled, if scanning.
  List<int>? get cursor {
    if (!scanning || cellIdx >= totalCells) return null;
    return _coord(cellIdx);
  }

  Offset _mockPosition() {
    final c = _coord(math.min(cellIdx, totalCells - 1));
    final frac = samplesPerCell > 0 ? inCell / samplesPerCell : 0.0;
    final dir = c[1].isEven ? 1.0 : -1.0;
    final x = (c[0] + dir * frac) / cols * 16.0;
    final y = c[1] / rows * 16.0;
    return Offset(x, y);
  }

  void _onSample(double v) {
    if (!v.isFinite) return;
    lastValue = v;
    live.add(v);
    if (live.length > 1000) {
      live.removeRange(0, live.length - 1000);
    }
    if (allRaw.length < 300000) allRaw.add(v);
    _rateCount++;
    if (cellIdx < totalCells) {
      cellSum += v;
      inCell++;
      final p = _coord(cellIdx);
      cells[p[1] * cols + p[0]] = cellSum / inCell;
      if (inCell >= samplesPerCell) {
        cellIdx++;
        cellSum = 0;
        inCell = 0;
      }
    }
    _dirty = true;
  }

  void nextCell() {
    if (cellIdx < totalCells) {
      cellIdx++;
      cellSum = 0;
      inCell = 0;
      notifyListeners();
    }
  }

  Future<void> startScan() async {
    if (scanning) return;
    conn = ConnState.connecting;
    errorKey = null;
    notifyListeners();
    try {
      if (useBle) {
        if (deviceId == null) throw StateError('no_device');
        if (!await ensureBlePermissions()) throw StateError('perm');
        _source = BleSource(
          device: BluetoothDevice.fromId(deviceId!),
          serviceUuid: serviceUuid,
          charUuid: charUuid,
          format: format,
          scale: scale,
          axes: axes,
        );
      } else {
        _source = MockSource(_mockPosition);
      }
      _sub = _source!.samples.listen(
        _onSample,
        onError: (Object e) => _fail('disconnected'),
      );
      await _source!.start();
      scanning = true;
      conn = ConnState.connected;
      _ticker = Timer.periodic(const Duration(milliseconds: 80), (_) {
        if (_dirty) {
          _dirty = false;
          _evaluate();
          notifyListeners();
        }
      });
      _rateCount = 0;
      _rateTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        sampleRate = _rateCount.toDouble();
        _rateCount = 0;
        _dirty = true;
      });
    } catch (e) {
      await _teardown();
      scanning = false;
      conn = ConnState.error;
      errorKey = e is StateError ? e.message : 'conn_failed';
    }
    notifyListeners();
  }

  Future<void> _teardown() async {
    _ticker?.cancel();
    _ticker = null;
    _rateTimer?.cancel();
    _rateTimer = null;
    sampleRate = 0;
    await _sub?.cancel();
    _sub = null;
    try {
      await _source?.stop();
    } catch (_) {}
    _source?.dispose();
    _source = null;
  }

  void _fail(String key) {
    _teardown().then((_) {
      scanning = false;
      conn = ConnState.error;
      errorKey = key;
      notifyListeners();
    });
  }

  Future<void> stopScan() async {
    await _teardown();
    scanning = false;
    conn = ConnState.idle;
    errorKey = null;
    notifyListeners();
  }

  // ---- Bluetooth discovery -----------------------------------------------
  Future<bool> ensureBlePermissions() async {
    final res = await <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
    final scanOk = res[Permission.bluetoothScan]?.isGranted ?? false;
    final connOk = res[Permission.bluetoothConnect]?.isGranted ?? false;
    final locOk = res[Permission.locationWhenInUse]?.isGranted ?? false;
    return (scanOk && connOk) || locOk;
  }

  Future<void> searchDevices() async {
    if (searching) return;
    errorKey = null;
    if (!await ensureBlePermissions()) {
      errorKey = 'perm';
      notifyListeners();
      return;
    }
    bleResults = <ScanResult>[];
    searching = true;
    notifyListeners();
    await _scanSub?.cancel();
    _scanSub = FlutterBluePlus.scanResults.listen((List<ScanResult> r) {
      bleResults = r;
      notifyListeners();
    });
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));
      await FlutterBluePlus.isScanning.where((bool s) => s == false).first;
    } catch (_) {
      errorKey = 'conn_failed';
    }
    await _scanSub?.cancel();
    _scanSub = null;
    searching = false;
    notifyListeners();
  }

  String nameOf(ScanResult r) {
    final n = r.device.platformName;
    if (n.isNotEmpty) return n;
    return r.advertisementData.advName;
  }

  void selectDevice(ScanResult r) {
    deviceId = r.device.remoteId.str;
    deviceName = nameOf(r);
    notifyListeners();
    _savePrefs();
  }

  // ---- sessions ----------------------------------------------------------
  Future<ScanSession> saveCurrent(String name) async {
    final now = DateTime.now();
    final s = ScanSession(
      id: now.millisecondsSinceEpoch.toString(),
      name: name,
      createdAt: now,
      source: useBle ? 'ble' : 'sim',
      raw: List<double>.from(allRaw),
      cols: cols,
      rows: rows,
      cells: List<double>.from(cells),
    );
    await SessionStore.save(s);
    sessions.insert(0, s);
    notifyListeners();
    return s;
  }

  Future<void> loadSession(ScanSession s) async {
    if (scanning) await stopScan();
    cols = s.cols;
    rows = s.rows;
    cells = List<double>.from(s.cells);
    allRaw = List<double>.from(s.raw);
    live.clear();
    final from = math.max(0, allRaw.length - 1000);
    live.addAll(allRaw.sublist(from));
    lastValue = live.isEmpty ? double.nan : live.last;
    cellIdx = filledCells;
    inCell = 0;
    cellSum = 0;
    alarm = false;
    dev = 0;
    notifyListeners();
  }

  Future<void> deleteSession(ScanSession s) async {
    await SessionStore.delete(s);
    sessions.removeWhere((e) => e.id == s.id);
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _rateTimer?.cancel();
    _sub?.cancel();
    _scanSub?.cancel();
    super.dispose();
  }
}
