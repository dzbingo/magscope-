import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dsp.dart';
import 'geo.dart';
import 'l10n.dart';
import 'learning.dart';
import 'models.dart';
import 'satellite.dart';
import 'soil.dart';
import 'sources.dart';
import 'storage.dart';
import 'tone.dart';
import 'theme.dart';
import 'widgets.dart' show kPalette, kPalettes;

enum ConnState { idle, connecting, connected, error }

/// Makes [AppState] available to every widget.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    return scope!.notifier!;
  }
}

String tr(BuildContext context, String key) => AppScope.of(context).t(key);

class AppState extends ChangeNotifier {
  // ---- settings ----------------------------------------------------------
  Locale locale = const Locale('ar');
  bool get useBle => true; // the simulator was removed
  FilterConfig filters = const FilterConfig();
  int cols = 16;
  int rows = 16;
  int samplesPerCell = 1; // device send button = one reading = one cell
  String serviceUuid = '';
  String charUuid = '';
  PacketFormat format = PacketFormat.ascii;
  double scale = 1.0;
  int axes = 1;
  String? deviceId;
  String deviceName = '';
  bool alerts = true;
  double minSpan = 2.0;
  int palette = 0;
  int themeIdx = 7;
  bool rtl = false; // start every scan from the right
  bool zigzag = true; // false = parallel (all rows same direction)
  bool manualThr = false;
  double thrUT = 1.0; // manual threshold in uT
  double cellCm = 40; // cell size in centimetres (30..50)
  /// Last compass bearing (set by the compass screen), degrees from north.
  static double compassDeg = 0;

  /// Bearing the scan's "up" side points to, for the geographic overlay.
  double scanHeading = 0;
  void setScanHeading(double v) {
    scanHeading = ((v % 360) + 360) % 360;
    notifyListeners();
    _savePrefs();
  }

  int soilIdx = 0;
  bool homeList = false;
  int labelMode = 0; // 0 none, 1 values, 2 depth

  // ---- detector (live deviation from the reference level) ----------------
  double? baselineRef;
  double refValue = double.nan;
  double dev = 0;
  double sigma = 0.1;
  bool alarm = false;
  DateTime _lastBuzz = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime? _alarmSince;

  /// 0 = nothing, 1 = brief (may be a jolt / false reading), 2 = sustained.
  int get liveVerdict {
    final a = _alarmSince;
    if (!alarm || a == null) return 0;
    return DateTime.now().difference(a).inMilliseconds < 1500 ? 1 : 2;
  }

  // ---- runtime -----------------------------------------------------------
  ConnState conn = ConnState.idle;
  String? errorKey;
  String errorDetail = '';
  int packetCount = 0;
  String lastPacketHex = '';
  bool scanning = false;
  final List<double> live = <double>[];
  List<double> allRaw = <double>[];
  List<double> cells = <double>[];
  int cellIdx = 0;
  int inCell = 0;
  double cellSum = 0;
  double lastValue = double.nan;
  List<ScanSession> sessions = <ScanSession>[];
  List<ScanResult> bleResults = <ScanResult>[];
  bool searching = false;

  SampleSource? _source;
  StreamSubscription<double>? _sub;
  StreamSubscription<List<ScanResult>>? _scanSub;
  Timer? _ticker;
  Timer? _rateTimer;
  bool _dirty = false;
  int _rateCount = 0;
  double sampleRate = 0;

  // ---- helpers -----------------------------------------------------------
  String t(String key) {
    final list = kStrings[key];
    if (list == null) return key;
    final code = locale.languageCode;
    final i = code == 'ar' ? 0 : (code == 'fr' ? 2 : 1);
    return list[i];
  }

  bool get hasData => allRaw.isNotEmpty;
  int get totalCells => cols * rows;

  List<double> get filteredLive => filters.apply(live);

  /// Grid as shown on the map: smoothed, optionally destriped, and optionally
  /// transformed (0 = normal, 1 = high-pass, 2 = gradient).
  List<double> get displayCells {
    final src = _driftFixed(cells);
    var g = filters.gridSmooth
        ? smoothGrid(src, cols, rows, filters.gridPasses)
        : src;
    if (destripe) g = destripeGrid(g, cols, rows);
    if (gridView == 1) {
      g = highPassGrid(g, cols, rows);
    } else if (gridView == 2) {
      g = gradientGrid(g, cols, rows);
    } else if (gridView == 3) {
      g = analyticSignalGrid(g, cols, rows);
    } else if (gridView == 4) {
      final r = compareRef;
      if (r != null && r.cols == cols && r.rows == rows) {
        var b = filters.gridSmooth
            ? smoothGrid(r.cells, cols, rows, filters.gridPasses)
            : r.cells;
        if (destripe) b = destripeGrid(b, cols, rows);
        final out = List<double>.filled(g.length, double.nan);
        for (int i = 0; i < out.length; i++) {
          if (!g[i].isNaN && !b[i].isNaN) out[i] = g[i] - b[i];
        }
        g = out;
      }
    }
    return g;
  }

  // ---- scan comparison (difference of two scans of the same grid) ----------
  ScanSession? compareRef;

  void setCompare(ScanSession? s) {
    compareRef = s;
    if (s == null && gridView == 4) gridView = 0;
    notifyListeners();
  }

  // ---- drift correction with reference readings ---------------------------
  /// Each entry: [scan position (cells), reference reading].
  final List<List<double>> driftRefs = <List<double>>[];
  bool driftOn = false;

  /// Records the current reading as a reference taken at the present scan
  /// position (press it at the same fixed spot at the start and the end).
  void addReference() {
    if (!lastValue.isFinite) return;
    final double pos =
        cellIdx + (samplesPerCell <= 0 ? 0.0 : inCell / samplesPerCell);
    driftRefs.add(<double>[pos, lastValue]);
    if (driftRefs.length >= 2) driftOn = true;
    HapticFeedback.selectionClick();
    notifyListeners();
  }

  void clearReferences() {
    driftRefs.clear();
    driftOn = false;
    notifyListeners();
  }

  void setDriftOn(bool v) {
    driftOn = v && driftRefs.length >= 2;
    notifyListeners();
  }

  List<double> _driftFixed(List<double> src) {
    if (!driftOn || driftRefs.length < 2) return src;
    final refs = List<List<double>>.from(driftRefs)
      ..sort((a, b) => a[0].compareTo(b[0]));
    double at(double pos) {
      if (pos <= refs.first[0]) return refs.first[1];
      if (pos >= refs.last[0]) return refs.last[1];
      for (int i = 0; i < refs.length - 1; i++) {
        final a = refs[i];
        final b = refs[i + 1];
        if (pos >= a[0] && pos <= b[0]) {
          final span = b[0] - a[0];
          final f = span <= 0 ? 0.0 : (pos - a[0]) / span;
          return a[1] + (b[1] - a[1]) * f;
        }
      }
      return refs.last[1];
    }

    final base = refs.first[1];
    final out = List<double>.from(src);
    for (int i = 0; i < totalCells; i++) {
      final p = _coord(i);
      final k = p[1] * cols + p[0];
      if (k < out.length && !out[k].isNaN) {
        out[k] = out[k] - (at(i.toDouble()) - base);
      }
    }
    return out;
  }

  // ---- audio tone while scanning -------------------------------------------
  bool toneOn = false;

  void setToneOn(bool v) {
    toneOn = v;
    notifyListeners();
  }

  void _toneFor(double v) {
    final recent =
        live.length > 60 ? live.sublist(live.length - 60) : List<double>.from(live);
    if (recent.length < 5) return;
    final base = medianOf(recent);
    final mad = medianOf(recent.map((e) => (e - base).abs()).toList()) * 1.4826;
    final spread = math.max(mad * 3, 0.5);
    unawaited(ToneService.beep((v - base) / spread));
  }

  // ---- field learning (found / false marks) -------------------------------
  List<LearnRec> learnRecs = <LearnRec>[];

  double? get learnedContrast => Learning.threshold(learnRecs);

  void markTarget(double contrast, bool found) {
    learnRecs.add(LearnRec(contrast, found));
    if (learnRecs.length > 200) {
      learnRecs.removeRange(0, learnRecs.length - 200);
    }
    notifyListeners();
    _savePrefs();
  }

  void resetLearning() {
    learnRecs = <LearnRec>[];
    notifyListeners();
    _savePrefs();
  }

  bool destripe = false;
  int gridView = 0;

  // ---- satellite backdrop (needs GPS of the grid centre + internet) --------
  ScanGeoLocation? gridGeo;
  ui.Image? satImage;
  bool satOn = false;
  bool satLoading = false;
  String? satError;
  double satOpacity = 0.6;

  void setSatOn(bool v) {
    satOn = v && satImage != null;
    notifyListeners();
  }

  void setSatOpacity(double v) {
    satOpacity = v.clamp(0.0, 1.0).toDouble();
    notifyListeners();
  }

  void _dropSatellite() {
    satImage = null;
    satOn = false;
  }

  /// Downloads the satellite picture for the current grid. The GPS position
  /// is the saved one (opened scan) or the phone's position right now, taken
  /// as the centre of the grid.
  Future<void> loadSatellite() async {
    if (satLoading) return;
    satLoading = true;
    satError = null;
    notifyListeners();
    try {
      final g = gridGeo ?? await _captureGeo();
      if (g == null) throw StateError('sat_no_gps');
      gridGeo = g;
      satImage = await SatelliteLoader.load(g, cols, rows, cellCm / 100.0);
      satOn = true;
    } catch (e) {
      satOn = false;
      satError = e is StateError ? e.message : 'sat_failed';
    }
    satLoading = false;
    notifyListeners();
  }

  void setDestripe(bool v) {
    destripe = v;
    notifyListeners();
  }

  void setGridView(int v) {
    gridView = v;
    notifyListeners();
  }

  /// Steps back one cell and clears it so it can be measured again.
  void prevCell() {
    if (cellIdx <= 0) return;
    cellIdx = math.min(cellIdx, totalCells) - 1;
    final p = _coord(cellIdx);
    cells[p[1] * cols + p[0]] = double.nan;
    cellSum = 0;
    inCell = 0;
    notifyListeners();
  }

  /// Jumps the scan position to cell number [n] (1-based, in scan order).
  void jumpToCell(int n) {
    cellIdx = (n - 1).clamp(0, totalCells).toInt();
    cellSum = 0;
    inCell = 0;
    notifyListeners();
  }

  // ---- paired devices & discovery ----------------------------------------
  List<BluetoothDevice> bonded = <BluetoothDevice>[];
  bool showUnnamed = true;
  /// 0 = auto (try classic SPP, then BLE), 1 = BLE only, 2 = classic only.
  int connMode = 0;
  bool geotag = false; // store GPS position with saved scans
  int ignoreBelow = 0; // drop readings below this value (sensor glitches)
  bool get deviceClassic => connMode == 2;
  /// Remembered working link type for the selected device: 'classic' | 'ble'.
  String devKind = '';

  void setShowUnnamed(bool v) {
    showUnnamed = v;
    notifyListeners();
  }

  void setConnMode(int v) {
    connMode = v;
    notifyListeners();
    _savePrefs();
  }

  void selectBonded(BluetoothDevice d) {
    connMode = 0; // paired devices: try classic first, then BLE
    deviceId = d.remoteId.str;
    deviceName = d.platformName;
    devKind = '';
    notifyListeners();
    _savePrefs();
    unawaited(reconnect());
  }

  // ---- lifecycle ---------------------------------------------------------
  Future<void> init() async {
    await _loadPrefs();
    _resetCells();
    sessions = await SessionStore.loadAll();
    notifyListeners();
    // Connect straight away so the status is live without pressing anything.
    if (deviceId != null) {
      unawaited(connect());
    }
  }

  void _resetCells() {
    cells = List<double>.filled(cols * rows, double.nan);
    cellIdx = 0;
    inCell = 0;
    cellSum = 0;
  }

  Future<void> _loadPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      locale = Locale(p.getString('lang') ?? 'ar');
      cols = p.getInt('cols') ?? 16;
      rows = p.getInt('rows') ?? 16;
      samplesPerCell = p.getInt('spc2') ?? 1;
      devKind = p.getString('devKind') ?? '';
      serviceUuid = p.getString('svc') ?? '';
      charUuid = p.getString('chr') ?? '';
      final fi = p.getInt('format') ?? 0;
      format = PacketFormat
          .values[math.min(math.max(fi, 0), PacketFormat.values.length - 1)];
      scale = p.getDouble('scale') ?? 1.0;
      axes = p.getInt('axes') ?? 1;
      geotag = p.getBool('geotag') ?? false;
      ignoreBelow = p.getInt('ignoreBelow') ?? 0;
      alerts = p.getBool('alerts') ?? true;
      deviceId = p.getString('devId');
      connMode = 0; // automatic only
      deviceName = p.getString('devName') ?? '';
      minSpan = p.getDouble('minSpan') ?? 2.0;
      palette = (p.getInt('palette2') ?? 0).clamp(0, kPalettes.length - 1).toInt();
      kPalette = palette;
      themeIdx = (p.getInt('theme2') ?? 7).clamp(0, kThemes.length - 1).toInt();
      Pal.apply(themeIdx);
      rtl = p.getBool('rtl') ?? false;
      zigzag = p.getBool('zigzag') ?? true;
      manualThr = p.getBool('manualThr') ?? false;
      thrUT = p.getDouble('thrUT') ?? 1.0;
      cellCm = (p.getDouble('cellCm') ?? 40).clamp(30.0, 50.0).toDouble();
      scanHeading = p.getDouble('scanHeading') ?? 0;
      homeList = p.getBool('homeList') ?? false;
      soilIdx = (p.getInt('soil') ?? 0).clamp(0, kSoils.length - 1).toInt();
      final lr = p.getString('learn');
      if (lr != null) {
        learnRecs = (jsonDecode(lr) as List<dynamic>)
            .map((dynamic e) => LearnRec.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      final f = p.getString('filters');
      if (f != null) {
        filters = FilterConfig.fromJson(jsonDecode(f) as Map<String, dynamic>);
      }
    } catch (_) {}
  }

  Future<void> _savePrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('lang', locale.languageCode);
      await p.setInt('cols', cols);
      await p.setInt('rows', rows);
      await p.setInt('spc2', samplesPerCell);
      await p.setString('devKind', devKind);
      await p.setString('svc', serviceUuid);
      await p.setString('chr', charUuid);
      await p.setInt('format', format.index);
      await p.setDouble('scale', scale);
      await p.setInt('axes', axes);
      await p.setBool('geotag', geotag);
      await p.setInt('ignoreBelow', ignoreBelow);
      await p.setBool('alerts', alerts);
      if (deviceId != null) await p.setString('devId', deviceId!);
      await p.setString('devName', deviceName);
      await p.setInt('connMode', connMode);
      await p.setDouble('minSpan', minSpan);
      await p.setInt('palette2', palette);
      await p.setInt('theme2', themeIdx);
      await p.setBool('rtl', rtl);
      await p.setBool('zigzag', zigzag);
      await p.setBool('manualThr', manualThr);
      await p.setDouble('thrUT', thrUT);
      await p.setDouble('cellCm', cellCm);
      await p.setInt('soil', soilIdx);
      await p.setBool('homeList', homeList);
      await p.setDouble('scanHeading', scanHeading);
      await p.setString('filters', jsonEncode(filters.toJson()));
      await p.setString(
          'learn', jsonEncode(learnRecs.map((LearnRec r) => r.toJson()).toList()));
    } catch (_) {}
  }

  // ---- settings setters --------------------------------------------------
  void setLocale(String code) {
    locale = Locale(code);
    notifyListeners();
    _savePrefs();
  }

  void setFilters(FilterConfig f) {
    filters = f;
    notifyListeners();
    _savePrefs();
  }

  void setGrid(int c, int r) {
    if (scanning) return;
    cols = c.clamp(2, 48).toInt();
    rows = r.clamp(2, 48).toInt();
    _dropSatellite();
    clearData();
    _savePrefs();
  }

  void setRtl(bool v) {
    if (scanning) return;
    rtl = v;
    notifyListeners();
    _savePrefs();
  }

  void setZigzag(bool v) {
    if (scanning) return;
    zigzag = v;
    notifyListeners();
    _savePrefs();
  }

  void setManualThr(bool v) {
    manualThr = v;
    _evaluate();
    notifyListeners();
    _savePrefs();
  }

  void setThrUT(double v) {
    thrUT = v;
    _evaluate();
    notifyListeners();
    _savePrefs();
  }

  void setCellCm(double v) {
    cellCm = v.clamp(30.0, 50.0).toDouble();
    _dropSatellite();
    notifyListeners();
    _savePrefs();
  }

  Soil get soil => kSoils[soilIdx.clamp(0, kSoils.length - 1).toInt()];

  /// Sensitivity corrected for the soil type.
  double get effSens => filters.sensitivity * soil.kFactor;

  void setSoil(int v) {
    soilIdx = v;
    _evaluate();
    notifyListeners();
    _savePrefs();
  }

  void setHomeList(bool v) {
    homeList = v;
    notifyListeners();
    _savePrefs();
  }

  void setLabelMode(int v) {
    labelMode = v;
    notifyListeners();
  }

  /// Detection limit in uT: manual, or sensitivity x current noise.
  double get threshold => manualThr ? thrUT : effSens * sigma;

  /// 0 = nothing, 1 = metal-like (above the level), 2 = void-like (below).
  int get kind => !alarm ? 0 : (dev >= 0 ? 1 : 2);

  /// Grid anomalies using the active threshold.
  List<CellAnomaly> get gridAnomalies => findCellAnomalies(
      cells, cols, rows, effSens + 1.0,
      absThreshold: manualThr ? thrUT : null);

  void setTheme(int v) {
    themeIdx = v;
    Pal.apply(v);
    notifyListeners();
    _savePrefs();
  }

  void setPalette(int v) {
    palette = v;
    kPalette = v;
    notifyListeners();
    _savePrefs();
  }

  void setMinSpan(double v) {
    minSpan = v;
    notifyListeners();
    _savePrefs();
  }

  void setSamplesPerCell(int v) {
    samplesPerCell = v.clamp(1, 200).toInt();
    notifyListeners();
    _savePrefs();
  }

  void setBleConfig({
    String? service,
    String? characteristic,
    PacketFormat? fmt,
    double? scaleFactor,
    int? axisCount,
  }) {
    if (service != null) serviceUuid = service;
    if (characteristic != null) charUuid = characteristic;
    if (fmt != null) format = fmt;
    if (scaleFactor != null) scale = scaleFactor;
    if (axisCount != null) axes = axisCount;
    notifyListeners();
    _savePrefs();
  }

  // ---- scan data ---------------------------------------------------------
  void clearData() {
    live.clear();
    allRaw = <double>[];
    lastValue = double.nan;
    dev = 0;
    alarm = false;
    refValue = double.nan;
    driftRefs.clear();
    driftOn = false;
    _resetCells();
    notifyListeners();
  }

  int get filledCells {
    int n = 0;
    for (final v in cells) {
      if (!v.isNaN) n++;
    }
    return n;
  }

  void setAlerts(bool v) {
    alerts = v;
    notifyListeners();
    _savePrefs();
  }

  /// Uses the current filtered level as the "ground" reference.
  void calibrate() {
    if (live.length < 10) return;
    final f = filteredLive;
    final tail = f.length > 40 ? f.sublist(f.length - 40) : f;
    baselineRef = medianOf(tail);
    _evaluate();
    notifyListeners();
  }

  void resetCalibration() {
    baselineRef = null;
    _evaluate();
    notifyListeners();
  }

  /// Compares the latest filtered reading with the reference level and
  /// decides whether it is an anomaly (and vibrates if alerts are on).
  void _evaluate() {
    if (live.length < 20) {
      dev = 0;
      alarm = false;
      return;
    }
    final tail = live.length > 150
        ? live.sublist(live.length - 150)
        : List<double>.from(live);
    final f = filters.apply(tail);
    if (f.isEmpty) return;
    final med = medianOf(f);
    final mad = medianOf(f.map((e) => (e - med).abs()).toList()) * 1.4826;
    sigma = math.max(mad, 0.05);
    final ref = baselineRef ?? med;
    refValue = ref;
    dev = f.last - ref;
    alarm = dev.abs() > threshold;
    if (!alarm) {
      _alarmSince = null;
    } else {
      _alarmSince ??= DateTime.now();
    }
    if (alarm && alerts && conn == ConnState.connected) {
      final now = DateTime.now();
      if (now.difference(_lastBuzz).inMilliseconds > 700) {
        _lastBuzz = now;
        HapticFeedback.mediumImpact();
      }
    }
  }

  /// Every pass runs from the bottom (south) of the grid to the top (north);
  /// the first pass is the left or the right edge ([rtl]) and the next passes
  /// follow towards the other side.
  List<int> _coord(int idx) {
    final pass = idx ~/ rows;
    final step = idx % rows;
    final y = rows - 1 - step;
    final x = rtl ? cols - 1 - pass : pass;
    return <int>[x, y];
  }

  /// Grid coordinate (x, y) of the cell currently being filled, if scanning.
  List<int>? get cursor {
    if (!scanning || cellIdx >= totalCells) return null;
    return _coord(cellIdx);
  }

  void setIgnoreBelow(int v) {
    ignoreBelow = v;
    notifyListeners();
    _savePrefs();
  }

  void _onSample(double v) {
    if (!v.isFinite) return;
    if (ignoreBelow > 0 && v < ignoreBelow) return;
    lastValue = v;
    live.add(v);
    if (live.length > 1000) {
      live.removeRange(0, live.length - 1000);
    }
    _rateCount++;
    // Readings only fill the 3D grid while a 3D scan is running; live
    // detection just watches the stream.
    if (scanning && cellIdx < totalCells) {
      if (toneOn) _toneFor(v);
      if (allRaw.length < 300000) allRaw.add(v);
      cellSum += v;
      inCell++;
      final p = _coord(cellIdx);
      cells[p[1] * cols + p[0]] = cellSum / inCell;
      if (inCell >= samplesPerCell) {
        cellIdx++;
        cellSum = 0;
        inCell = 0;
        if (cellIdx >= totalCells) {
          scanning = false;
          HapticFeedback.heavyImpact();
        } else {
          HapticFeedback.lightImpact();
        }
      }
    }
    _dirty = true;
  }

  void nextCell() {
    if (cellIdx < totalCells) {
      cellIdx++;
      cellSum = 0;
      inCell = 0;
      notifyListeners();
    }
  }

  SampleSource Function(bool classic)? _makeSource;

  /// Opens the data link (auto: remembered type first, then the other one).
  Future<void> connect() async {
    if (conn == ConnState.connecting || conn == ConnState.connected) return;
    conn = ConnState.connecting;
    errorKey = null;
    errorDetail = '';
    packetCount = 0;
    lastPacketHex = '';
    notifyListeners();
    try {
      if (useBle) {
        if (deviceId == null) throw StateError('no_device');
        if (!await ensureBlePermissions()) throw StateError('perm');
        void onPk(List<int> d) {
          packetCount++;
          lastPacketHex = d
              .take(24)
              .map((int b) => b.toRadixString(16).padLeft(2, '0'))
              .join(' ');
        }

        _makeSource = (bool classic) => classic
            ? ClassicSource(
                address: deviceId!,
                format: format,
                scale: scale,
                axes: axes,
                onPacket: onPk,
              )
            : BleSource(
                device: BluetoothDevice.fromId(deviceId!),
                serviceUuid: serviceUuid,
                charUuid: charUuid,
                format: format,
                scale: scale,
                axes: axes,
                onPacket: onPk,
              );
        final order = devKind == 'ble' ? <bool>[false, true] : <bool>[true, false];
        final errs = <String>[];
        bool ok = false;
        for (final classic in order) {
          _source = _makeSource!(classic);
          _sub = _source!.samples.listen(
            _onSample,
            onError: (Object e) => _fail('disconnected'),
          );
          try {
            await _source!.start();
            ok = true;
            devKind = classic ? 'classic' : 'ble';
            break;
          } catch (e) {
            errs.add('${classic ? 'SPP' : 'BLE'}: $e');
            await _sub?.cancel();
            _sub = null;
            try {
              await _source?.stop();
            } catch (_) {}
            _source?.dispose();
            _source = null;
          }
        }
        if (!ok) throw Exception(errs.join(' | '));
      }
      conn = ConnState.connected;
      _ticker = Timer.periodic(const Duration(milliseconds: 80), (_) {
        if (_dirty) {
          _dirty = false;
          _evaluate();
          notifyListeners();
        }
      });
      _rateCount = 0;
      _rateTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        sampleRate = _rateCount.toDouble();
        _rateCount = 0;
        _dirty = true;
      });
      _savePrefs();
    } catch (e) {
      await _teardown();
      scanning = false;
      conn = ConnState.error;
      errorKey = e is StateError ? e.message : 'conn_failed';
      errorDetail = e is StateError ? '' : e.toString();
    }
    notifyListeners();
  }

  /// Drops the current link and opens a new one (device or source changed).
  Future<void> reconnect() async {
    if (scanning) return;
    await _teardown();
    conn = ConnState.idle;
    errorKey = null;
    notifyListeners();
    if (deviceId != null) await connect();
  }

  /// Reconnects when the link is down (called when a screen is opened).
  void ensureConnected() {
    if (conn == ConnState.idle || conn == ConnState.error) {
      unawaited(connect());
    }
  }

  /// Action of the Bluetooth icon: connect, or disconnect when already
  /// connected. Returns false when no device has been chosen yet.
  Future<bool> toggleLink() async {
    if (conn == ConnState.connecting || scanning) return true;
    if (conn == ConnState.connected) {
      await disconnect();
      return true;
    }
    if (deviceId == null) return false;
    await connect();
    return true;
  }

  Future<void> disconnect() async {
    await _teardown();
    scanning = false;
    conn = ConnState.idle;
    errorKey = null;
    notifyListeners();
  }

  /// Starts a 3D scan: readings now fill the grid cell by cell.
  Future<void> startScan() async {
    if (scanning) return;
    if (conn != ConnState.connected) await connect();
    if (conn != ConnState.connected) return;
    if (cellIdx >= totalCells) clearData();
    scanning = true;
    notifyListeners();
  }

  /// Stops filling the grid; the connection stays open.
  void stopScan() {
    scanning = false;
    notifyListeners();
  }

  Future<void> _teardown() async {
    _ticker?.cancel();
    _ticker = null;
    _rateTimer?.cancel();
    _rateTimer = null;
    sampleRate = 0;
    await _sub?.cancel();
    _sub = null;
    try {
      await _source?.stop();
    } catch (_) {}
    _source?.dispose();
    _source = null;
  }

  void _fail(String key) {
    _teardown().then((_) {
      scanning = false;
      conn = ConnState.error;
      errorKey = key;
      notifyListeners();
    });
  }

  // ---- Bluetooth discovery -----------------------------------------------
  Future<bool> ensureBlePermissions() async {
    final res = await <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
    final scanOk = res[Permission.bluetoothScan]?.isGranted ?? false;
    final connOk = res[Permission.bluetoothConnect]?.isGranted ?? false;
    final locOk = res[Permission.locationWhenInUse]?.isGranted ?? false;
    return (scanOk && connOk) || locOk;
  }

  Future<void> searchDevices() async {
    if (searching) return;
    errorKey = null;
    if (!await ensureBlePermissions()) {
      errorKey = 'perm';
      notifyListeners();
      return;
    }
    bleResults = <ScanResult>[];
    searching = true;
    notifyListeners();
    try {
      bonded = await FlutterBluePlus.bondedDevices;
    } catch (_) {
      bonded = <BluetoothDevice>[];
    }
    await _scanSub?.cancel();
    _scanSub = FlutterBluePlus.scanResults.listen((List<ScanResult> r) {
      final sorted = List<ScanResult>.from(r)
        ..sort((a, b) => b.rssi.compareTo(a.rssi));
      bleResults = sorted;
      notifyListeners();
    });
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 12));
      await FlutterBluePlus.isScanning.where((bool s) => s == false).first;
    } catch (_) {
      errorKey = 'conn_failed';
    }
    await _scanSub?.cancel();
    _scanSub = null;
    searching = false;
    notifyListeners();
  }

  String nameOf(ScanResult r) {
    final n = r.device.platformName;
    if (n.isNotEmpty) return n;
    return r.advertisementData.advName;
  }

  void selectDevice(ScanResult r) {
    connMode = 0;
    deviceId = r.device.remoteId.str;
    deviceName = nameOf(r);
    devKind = '';
    notifyListeners();
    _savePrefs();
    unawaited(reconnect());
  }

  // ---- sessions ----------------------------------------------------------
  /// The current grid as a session object (not saved to disk).
  ScanSession snapshot(String name) {
    final now = DateTime.now();
    return ScanSession(
      id: now.millisecondsSinceEpoch.toString(),
      name: name,
      createdAt: now,
      source: useBle ? 'ble' : 'sim',
      raw: List<double>.from(allRaw),
      cols: cols,
      rows: rows,
      cells: List<double>.from(cells),
    );
  }

  void setGeotag(bool v) {
    geotag = v;
    notifyListeners();
    _savePrefs();
  }

  Future<ScanGeoLocation?> currentGeo() => _captureGeo();

  Future<ScanGeoLocation?> _captureGeo() async {
    try {
      final st = await Permission.locationWhenInUse.request();
      if (!st.isGranted) return null;
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          timeLimit: Duration(seconds: 15),
        ),
      );
      return ScanGeoLocation(
        latitude: p.latitude,
        longitude: p.longitude,
        altitude: p.altitude,
        accuracy: p.accuracy,
        heading: scanHeading,
      );
    } catch (_) {
      return null;
    }
  }

  Future<ScanSession> saveCurrent(String name) async {
    final now = DateTime.now();
    final geo = geotag ? await _captureGeo() : null;
    final s = ScanSession(
      id: now.millisecondsSinceEpoch.toString(),
      name: name,
      createdAt: now,
      source: useBle ? 'ble' : 'sim',
      raw: List<double>.from(allRaw),
      cols: cols,
      rows: rows,
      cells: List<double>.from(cells),
      geo: geo,
    );
    await SessionStore.save(s);
    sessions.insert(0, s);
    notifyListeners();
    return s;
  }

  /// Saves an imported session and opens it.
  Future<void> importSession(ScanSession s) async {
    await SessionStore.save(s);
    sessions.insert(0, s);
    await loadSession(s);
  }

  Future<void> loadSession(ScanSession s) async {
    if (scanning) stopScan();
    cols = s.cols;
    rows = s.rows;
    gridGeo = s.geo;
    _dropSatellite();
    cells = List<double>.from(s.cells);
    allRaw = List<double>.from(s.raw);
    live.clear();
    final from = math.max(0, allRaw.length - 1000);
    live.addAll(allRaw.sublist(from));
    lastValue = live.isEmpty ? double.nan : live.last;
    cellIdx = filledCells;
    inCell = 0;
    cellSum = 0;
    alarm = false;
    dev = 0;
    notifyListeners();
  }

  Future<void> renameSession(ScanSession s, String name) async {
    final n = name.trim();
    if (n.isEmpty) return;
    final i = sessions.indexWhere((e) => e.id == s.id);
    if (i < 0) return;
    final renamed = s.withName(n);
    sessions[i] = renamed;
    if (compareRef?.id == s.id) compareRef = renamed;
    notifyListeners();
    await SessionStore.save(renamed);
  }

  Future<void> deleteSession(ScanSession s) async {
    await SessionStore.delete(s);
    sessions.removeWhere((e) => e.id == s.id);
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _rateTimer?.cancel();
    _sub?.cancel();
    _scanSub?.cancel();
    super.dispose();
  }
}
