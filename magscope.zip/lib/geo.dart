/// GPS position stored with a saved scan.
class ScanGeoLocation {
  const ScanGeoLocation({
    required this.latitude,
    required this.longitude,
    required this.altitude,
    required this.accuracy,
    this.heading = 0.0,
  });

  final double latitude;
  final double longitude;
  final double altitude;
  final double accuracy;

  /// Compass bearing (degrees clockwise from north) the scan's "up" side
  /// (the walking direction of every pass) points to.
  final double heading;

  ScanGeoLocation withHeading(double h) => ScanGeoLocation(
        latitude: latitude,
        longitude: longitude,
        altitude: altitude,
        accuracy: accuracy,
        heading: h,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'lat': latitude,
        'lon': longitude,
        'alt': altitude,
        'acc': accuracy,
        'hdg': heading,
      };

  factory ScanGeoLocation.fromJson(Map<String, dynamic> j) {
    return ScanGeoLocation(
      latitude: (j['lat'] as num?)?.toDouble() ?? 0.0,
      longitude: (j['lon'] as num?)?.toDouble() ?? 0.0,
      altitude: (j['alt'] as num?)?.toDouble() ?? 0.0,
      accuracy: (j['acc'] as num?)?.toDouble() ?? 0.0,
      heading: (j['hdg'] as num?)?.toDouble() ?? 0.0,
    );
  }

  String formatCoordinates() {
    return '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)}'
        '  (${altitude.toStringAsFixed(0)} m, ±${accuracy.toStringAsFixed(0)} m)';
  }
}
