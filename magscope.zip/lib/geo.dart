/// GPS position stored with a saved scan.
class ScanGeoLocation {
  const ScanGeoLocation({
    required this.latitude,
    required this.longitude,
    required this.altitude,
    required this.accuracy,
  });

  final double latitude;
  final double longitude;
  final double altitude;
  final double accuracy;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'lat': latitude,
        'lon': longitude,
        'alt': altitude,
        'acc': accuracy,
      };

  factory ScanGeoLocation.fromJson(Map<String, dynamic> j) {
    return ScanGeoLocation(
      latitude: (j['lat'] as num?)?.toDouble() ?? 0.0,
      longitude: (j['lon'] as num?)?.toDouble() ?? 0.0,
      altitude: (j['alt'] as num?)?.toDouble() ?? 0.0,
      accuracy: (j['acc'] as num?)?.toDouble() ?? 0.0,
    );
  }

  String formatCoordinates() {
    return '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)}'
        '  (${altitude.toStringAsFixed(0)} m, ±${accuracy.toStringAsFixed(0)} m)';
  }
}
