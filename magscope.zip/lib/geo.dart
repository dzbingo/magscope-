/// GPS position stored with a saved scan.
class ScanGeoLocation {
  const ScanGeoLocation({
    required this.latitude,
    required this.longitude,
    required this.altitude,
    required this.accuracy,
    this.heading = 0.0,
    this.corners,
  });

  final double latitude;
  final double longitude;
  final double altitude;
  final double accuracy;

  /// Compass bearing (degrees clockwise from north) the scan's "up" side
  /// (the walking direction of every pass) points to.
  final double heading;

  /// The four recorded corners of the scan square as [lat, lon], in the order
  /// start (lower-left), lower-right, upper-right, upper-left (scan frame:
  /// "up" = walking direction). Null when they were not recorded.
  final List<List<double>>? corners;

  ScanGeoLocation withHeading(double h) => ScanGeoLocation(
        latitude: latitude,
        longitude: longitude,
        altitude: altitude,
        accuracy: accuracy,
        heading: h,
        corners: corners,
      );

  /// Same position moved by a number of degrees (used for manual shifting).
  ScanGeoLocation moved(double dLat, double dLon) => ScanGeoLocation(
        latitude: latitude + dLat,
        longitude: longitude + dLon,
        altitude: altitude,
        accuracy: accuracy,
        heading: heading,
        corners: corners
            ?.map((List<double> c) => <double>[c[0] + dLat, c[1] + dLon])
            .toList(),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'lat': latitude,
        'lon': longitude,
        'alt': altitude,
        'acc': accuracy,
        'hdg': heading,
        if (corners != null) 'cor': corners,
      };

  factory ScanGeoLocation.fromJson(Map<String, dynamic> j) {
    return ScanGeoLocation(
      latitude: (j['lat'] as num?)?.toDouble() ?? 0.0,
      longitude: (j['lon'] as num?)?.toDouble() ?? 0.0,
      altitude: (j['alt'] as num?)?.toDouble() ?? 0.0,
      accuracy: (j['acc'] as num?)?.toDouble() ?? 0.0,
      heading: (j['hdg'] as num?)?.toDouble() ?? 0.0,
      corners: _readCorners(j['cor']),
    );
  }

  static List<List<double>>? _readCorners(dynamic v) {
    if (v is! List || v.length != 4) return null;
    final out = <List<double>>[];
    for (final e in v) {
      if (e is! List || e.length < 2) return null;
      out.add(<double>[(e[0] as num).toDouble(), (e[1] as num).toDouble()]);
    }
    return out;
  }

  String formatCoordinates() {
    return '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)}'
        '  (${altitude.toStringAsFixed(0)} m, ±${accuracy.toStringAsFixed(0)} m)';
  }
}
