import 'dart:math' as math;

import 'dsp.dart' show CellAnomaly, medianOf;

/// Target detection that treats voids and metals fairly.
///
/// Why this exists: a magnetometer grid always carries a smooth regional
/// trend (ground geology, a slope, sensor drift). Judging cells against the
/// grid median lets that trend win, so the strongest "anomaly" is just the
/// highest corner and small local lows (voids) are never reported.
///
/// The steps are the standard ones in magnetic surveying:
///  1. fit and remove a plane (robust, so real targets do not bend it),
///  2. look for local extremes of the residual in both directions,
///  3. high residual = metal candidate; low residual = void candidate,
///  4. a low that sits right next to a high of similar size is the other lobe
///     of the same metal object (a dipole), not a void, so it is dropped.
class Detect {
  /// How much more a void counts than a metal of equal strength when ranking
  /// (1 = equal). Set from the settings.
  static double voidBias = 1.5;

  /// Grid minus its robust plane trend. Empty cells stay NaN.
  static List<double> residual(List<double> cells, int cols, int rows) {
    final out = List<double>.filled(cells.length, double.nan);
    final idx = <int>[];
    for (int i = 0; i < cells.length; i++) {
      if (!cells[i].isNaN && cells[i].isFinite) idx.add(i);
    }
    if (idx.length < 6 || cols < 2 || rows < 2) {
      final v = idx.map((i) => cells[i]).toList();
      final m = v.isEmpty ? 0.0 : medianOf(v);
      for (final i in idx) {
        out[i] = cells[i] - m;
      }
      return out;
    }
    // iteratively re-weighted least squares for z = a + b*x + c*y
    var w = List<double>.filled(idx.length, 1.0);
    double a = 0, b = 0, c = 0;
    for (int it = 0; it < 5; it++) {
      double s = 0, sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0;
      double sz = 0, sxz = 0, syz = 0;
      for (int k = 0; k < idx.length; k++) {
        final i = idx[k];
        final x = (i % cols).toDouble();
        final y = (i ~/ cols).toDouble();
        final z = cells[i];
        final wk = w[k];
        s += wk;
        sx += wk * x;
        sy += wk * y;
        sxx += wk * x * x;
        sxy += wk * x * y;
        syy += wk * y * y;
        sz += wk * z;
        sxz += wk * x * z;
        syz += wk * y * z;
      }
      final sol = _solve3(<List<double>>[
        <double>[s, sx, sy, sz],
        <double>[sx, sxx, sxy, sxz],
        <double>[sy, sxy, syy, syz],
      ]);
      if (sol == null) break;
      a = sol[0];
      b = sol[1];
      c = sol[2];
      final res = <double>[];
      for (final i in idx) {
        res.add(cells[i] - (a + b * (i % cols) + c * (i ~/ cols)));
      }
      final sc = math.max(
          medianOf(res.map((e) => e.abs()).toList()) * 1.4826, 1e-6);
      w = res
          .map((e) => e.abs() <= 1.5 * sc ? 1.0 : 1.5 * sc / e.abs())
          .toList();
    }
    final r = <double>[];
    for (final i in idx) {
      r.add(cells[i] - (a + b * (i % cols) + c * (i ~/ cols)));
    }
    final med = medianOf(r);
    for (int k = 0; k < idx.length; k++) {
      out[idx[k]] = r[k] - med;
    }
    return out;
  }

  static List<double>? _solve3(List<List<double>> m) {
    for (int col = 0; col < 3; col++) {
      int piv = col;
      for (int r = col + 1; r < 3; r++) {
        if (m[r][col].abs() > m[piv][col].abs()) piv = r;
      }
      if (m[piv][col].abs() < 1e-12) return null;
      final t = m[col];
      m[col] = m[piv];
      m[piv] = t;
      for (int r = 0; r < 3; r++) {
        if (r == col) continue;
        final f = m[r][col] / m[col][col];
        for (int k = col; k < 4; k++) {
          m[r][k] -= f * m[col][k];
        }
      }
    }
    return <double>[m[0][3] / m[0][0], m[1][3] / m[1][1], m[2][3] / m[2][2]];
  }

  /// Robust noise of a residual grid.
  static double sigmaOf(List<double> res) {
    final v = res.where((e) => !e.isNaN).toList();
    if (v.length < 5) return 1.0;
    return math.max(
        medianOf(v.map((e) => e.abs()).toList()) * 1.4826, 0.05);
  }

  static List<CellAnomaly> _spread(List<CellAnomaly> sorted, int r) {
    final keep = <CellAnomaly>[];
    for (final a in sorted) {
      bool near = false;
      for (final k in keep) {
        if ((k.x - a.x).abs() <= r && (k.y - a.y).abs() <= r) {
          near = true;
          break;
        }
      }
      if (!near) keep.add(a);
    }
    return keep;
  }

  /// Local extremes above the limit, metals and voids ranked together with the
  /// void bias. At most 6 of each kind are kept so neither can crowd out the
  /// other.
  static List<CellAnomaly> find(List<double> cells, int cols, int rows, double k,
          {double? absThreshold}) =>
      _split(cells, cols, rows, k, absThreshold).kept;

  /// The low extremes that [find] leaves out because a metal peak sits next to
  /// them (probably the negative lobe of that metal, but possibly a real void).
  static List<CellAnomaly> lobes(List<double> cells, int cols, int rows, double k,
          {double? absThreshold}) =>
      _split(cells, cols, rows, k, absThreshold).lobes;

  static ({List<CellAnomaly> kept, List<CellAnomaly> lobes}) _split(
      List<double> cells, int cols, int rows, double k, double? absThreshold) {
    final res = residual(cells, cols, rows);
    final valid = res.where((e) => !e.isNaN).toList();
    if (valid.length < 6) {
      return (kept: <CellAnomaly>[], lobes: <CellAnomaly>[]);
    }
    final lim = absThreshold ?? k * sigmaOf(res);
    final pos = <CellAnomaly>[];
    final neg = <CellAnomaly>[];
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final v = res[y * cols + x];
        if (v.isNaN || v.abs() <= lim) continue;
        bool isMax = true, isMin = true;
        for (int dy = -1; dy <= 1; dy++) {
          for (int dx = -1; dx <= 1; dx++) {
            if (dx == 0 && dy == 0) continue;
            final nx = x + dx, ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
            final n = res[ny * cols + nx];
            if (n.isNaN) continue;
            if (n > v) isMax = false;
            if (n < v) isMin = false;
          }
        }
        if (v > 0 && isMax) pos.add(CellAnomaly(x, y, v));
        if (v < 0 && isMin) neg.add(CellAnomaly(x, y, v));
      }
    }
    pos.sort((a, b) => b.deviation.compareTo(a.deviation));
    neg.sort((a, b) => a.deviation.compareTo(b.deviation));
    // one blob = one target: keep only the strongest extreme inside a radius
    final r = math.max(2, (math.max(cols, rows) * 0.08).round());
    final posK = _spread(pos, r);
    final negK = _spread(neg, r);
    pos
      ..clear()
      ..addAll(posK);
    neg
      ..clear()
      ..addAll(negK);
    // the low lobe of a metal dipole is not a void
    final voids = <CellAnomaly>[];
    final lobeList = <CellAnomaly>[];
    for (final n in neg) {
      bool lobe = false;
      for (final p in pos) {
        if ((p.x - n.x).abs() <= 3 &&
            (p.y - n.y).abs() <= 3 &&
            p.deviation >= 0.5 * n.deviation.abs()) {
          lobe = true;
          break;
        }
      }
      if (lobe) {
        lobeList.add(n);
      } else {
        voids.add(n);
      }
    }
    final all = <CellAnomaly>[...pos.take(6), ...voids.take(6)];
    all.sort((a, b) {
      final sa = a.deviation.abs() * (a.deviation < 0 ? voidBias : 1.0);
      final sb = b.deviation.abs() * (b.deviation < 0 ? voidBias : 1.0);
      return sb.compareTo(sa);
    });
    return (kept: all, lobes: lobeList);
  }
}
