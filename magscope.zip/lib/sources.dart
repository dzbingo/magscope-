import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show Offset;

import 'package:flutter_blue_classic/flutter_blue_classic.dart'
    show FlutterBlueClassic;
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// How raw Bluetooth packets are turned into numbers.
/// The device protocol is configurable because it differs per hardware.
enum PacketFormat { ascii, int16le, float32le }

double _combine(List<double> vals, int axes) {
  if (axes >= 3 && vals.length >= 3) {
    return math.sqrt(
        vals[0] * vals[0] + vals[1] * vals[1] + vals[2] * vals[2]);
  }
  return vals.first;
}

/// Parses one notification payload into zero or more readings.
List<double> parsePacket(
    List<int> data, PacketFormat format, double scale, int axes) {
  final out = <double>[];
  final ax = axes < 1 ? 1 : axes;
  if (format == PacketFormat.ascii) {
    final text = utf8.decode(data, allowMalformed: true);
    for (final line in text.split(RegExp(r'[\r\n;]+'))) {
      final t = line.trim();
      if (t.isEmpty) continue;
      final nums = RegExp(r'-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
          .allMatches(t)
          .map((m) => double.tryParse(m.group(0)!))
          .whereType<double>()
          .toList();
      if (nums.isEmpty) continue;
      out.add(_combine(nums, ax) * scale);
    }
    return out;
  }
  final width = format == PacketFormat.int16le ? 2 : 4;
  final step = width * ax;
  final bd = ByteData.sublistView(Uint8List.fromList(data));
  for (int i = 0; i + step <= data.length; i += step) {
    final vals = <double>[];
    for (int a = 0; a < ax; a++) {
      final off = i + a * width;
      if (width == 2) {
        vals.add(bd.getInt16(off, Endian.little).toDouble());
      } else {
        vals.add(bd.getFloat32(off, Endian.little));
      }
    }
    out.add(_combine(vals, ax) * scale);
  }
  return out;
}

abstract class SampleSource {
  Stream<double> get samples;
  Future<void> start();
  Future<void> stop();
  void dispose();
}

/// Built-in simulator: a ~50 uT background field with drift, noise, rare
/// spikes and a few buried anomalies, sampled along the current scan position.
class MockSource implements SampleSource {
  MockSource(this.positionOf);

  /// Current virtual position in a 16 x 16 field.
  final Offset Function() positionOf;

  final StreamController<double> _ctrl = StreamController<double>.broadcast();
  final math.Random _rng = math.Random();
  Timer? _timer;
  int _tick = 0;

  // cx, cy, amplitude (uT), radius
  static const List<List<double>> _anomalies = <List<double>>[
    <double>[4.0, 5.0, 9.0, 1.4],
    <double>[11.0, 10.0, -6.0, 1.8],
    <double>[8.0, 3.0, 14.0, 0.9],
  ];

  @override
  Stream<double> get samples => _ctrl.stream;

  double _field(double x, double y) {
    double v = 48.0 +
        0.6 * math.sin(_tick / 90.0) +
        (_rng.nextDouble() - 0.5) * 0.8;
    for (final a in _anomalies) {
      final dx = x - a[0];
      final dy = y - a[1];
      v += a[2] * math.exp(-(dx * dx + dy * dy) / (2 * a[3] * a[3]));
    }
    if (_rng.nextDouble() < 0.01) {
      v += (_rng.nextDouble() - 0.5) * 6;
    }
    return v;
  }

  @override
  Future<void> start() async {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 60), (_) {
      _tick++;
      final p = positionOf();
      _ctrl.add(_field(p.dx, p.dy));
    });
  }

  @override
  Future<void> stop() async {
    _timer?.cancel();
    _timer = null;
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ctrl.close();
  }
}

/// Bluetooth Low Energy source: connects to a device, finds a notifying
/// characteristic (optionally filtered by UUID) and parses its packets.
class BleSource implements SampleSource {
  BleSource({
    required this.device,
    required this.serviceUuid,
    required this.charUuid,
    required this.format,
    required this.scale,
    required this.axes,
    this.onPacket,
  });

  final void Function(List<int> data)? onPacket;
  final BluetoothDevice device;
  final String serviceUuid;
  final String charUuid;
  final PacketFormat format;
  final double scale;
  final int axes;

  final StreamController<double> _ctrl = StreamController<double>.broadcast();
  StreamSubscription<List<int>>? _sub;
  StreamSubscription<BluetoothConnectionState>? _connSub;
  bool _stopping = false;

  @override
  Stream<double> get samples => _ctrl.stream;

  @override
  Future<void> start() async {
    _stopping = false;
    await device.connect(timeout: const Duration(seconds: 15));
    final services = await device.discoverServices();

    final su = serviceUuid.trim().toLowerCase();
    final cu = charUuid.trim().toLowerCase();
    BluetoothCharacteristic? target;
    for (final s in services) {
      if (su.isNotEmpty && !s.uuid.toString().toLowerCase().contains(su)) {
        continue;
      }
      for (final c in s.characteristics) {
        final uuidOk = cu.isEmpty || c.uuid.toString().toLowerCase().contains(cu);
        if (uuidOk && (c.properties.notify || c.properties.indicate)) {
          target = c;
          break;
        }
      }
      if (target != null) break;
    }
    if (target == null) {
      try {
        await device.disconnect();
      } catch (_) {}
      throw StateError('no_char');
    }

    await target.setNotifyValue(true);
    _sub = target.onValueReceived.listen((List<int> data) {
      onPacket?.call(data);
      for (final v in parsePacket(data, format, scale, axes)) {
        _ctrl.add(v);
      }
    });
    _connSub = device.connectionState.listen((BluetoothConnectionState s) {
      if (s == BluetoothConnectionState.disconnected && !_stopping) {
        _ctrl.addError('disconnected');
      }
    });
  }

  @override
  Future<void> stop() async {
    _stopping = true;
    await _sub?.cancel();
    await _connSub?.cancel();
    _sub = null;
    _connSub = null;
    try {
      await device.disconnect();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ctrl.close();
  }
}


/// Classic Bluetooth (SPP / serial) source, e.g. an ESP32 running the
/// BluetoothSerial library. Text lines are reassembled before parsing.
///
/// The plugin is used through `dynamic` so that small API differences between
/// plugin versions cannot break the build; problems show up as a connection
/// error instead.
class ClassicSource implements SampleSource {
  ClassicSource({
    required this.address,
    required this.format,
    required this.scale,
    required this.axes,
    this.onPacket,
  });

  final String address;
  final PacketFormat format;
  final double scale;
  final int axes;
  final void Function(List<int> data)? onPacket;

  final StreamController<double> _ctrl = StreamController<double>.broadcast();
  StreamSubscription<dynamic>? _sub;
  dynamic _conn;
  bool _stopping = false;
  String _buf = '';

  @override
  Stream<double> get samples => _ctrl.stream;

  void _handle(List<int> data) {
    onPacket?.call(data);
    if (format == PacketFormat.ascii) {
      _buf += utf8.decode(data, allowMalformed: true);
      if (_buf.length > 4096) _buf = _buf.substring(_buf.length - 1024);
      int nl;
      while ((nl = _buf.indexOf('\n')) >= 0) {
        final line = _buf.substring(0, nl);
        _buf = _buf.substring(nl + 1);
        for (final v
            in parsePacket(utf8.encode(line), format, scale, axes)) {
          _ctrl.add(v);
        }
      }
    } else {
      for (final v in parsePacket(data, format, scale, axes)) {
        _ctrl.add(v);
      }
    }
  }

  @override
  Future<void> start() async {
    _stopping = false;
    final dynamic fbc = FlutterBlueClassic();
    _conn = await fbc.connect(address);
    if (_conn == null) throw StateError('conn_failed');
    final dynamic input = _conn.input;
    if (input == null) throw StateError('conn_failed');
    _sub = (input as Stream<dynamic>).listen(
      (dynamic d) => _handle((d as List<dynamic>).cast<int>()),
      onError: (Object e) {
        if (!_stopping) _ctrl.addError('disconnected');
      },
      onDone: () {
        if (!_stopping) _ctrl.addError('disconnected');
      },
    );
  }

  @override
  Future<void> stop() async {
    _stopping = true;
    await _sub?.cancel();
    _sub = null;
    try {
      await _conn?.close();
    } catch (_) {}
    try {
      _conn?.dispose();
    } catch (_) {}
    _conn = null;
  }

  @override
  void dispose() {
    _ctrl.close();
  }
}
