import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_blue_classic/flutter_blue_classic.dart'
    show FlutterBlueClassic;
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// How raw Bluetooth packets are turned into numbers.
/// The device protocol is configurable because it differs per hardware.
enum PacketFormat { ascii, int16le, float32le, uint8, auto }

/// True when the bytes look like printable text (digits, signs, separators).
bool looksLikeText(List<int> d) {
  if (d.isEmpty) return false;
  int digits = 0;
  for (final b in d) {
    final ok = (b >= 32 && b < 127) || b == 10 || b == 13 || b == 9;
    if (!ok) return false;
    if (b >= 48 && b <= 57) digits++;
  }
  return digits > 0;
}

/// Picks a binary layout for a packet that is not text.
PacketFormat guessBinary(List<int> d) {
  if (d.length >= 4 && d.length % 4 == 0) {
    final bd = ByteData.sublistView(Uint8List.fromList(d));
    bool good = true;
    for (int i = 0; i + 4 <= d.length; i += 4) {
      final v = bd.getFloat32(i, Endian.little);
      if (v.isNaN || v.isInfinite || v.abs() > 1e6) {
        good = false;
        break;
      }
    }
    if (good) return PacketFormat.float32le;
  }
  if (d.length >= 2 && d.length % 2 == 0) return PacketFormat.int16le;
  return PacketFormat.uint8;
}

double _combine(List<double> vals, int axes) {
  if (axes >= 3 && vals.length >= 3) {
    return math.sqrt(
        vals[0] * vals[0] + vals[1] * vals[1] + vals[2] * vals[2]);
  }
  return vals.first;
}

/// Parses one notification payload into zero or more readings.
List<double> parsePacket(
    List<int> data, PacketFormat format, double scale, int axes) {
  final out = <double>[];
  final ax = axes < 1 ? 1 : axes;
  if (format == PacketFormat.auto) {
    format = looksLikeText(data) ? PacketFormat.ascii : guessBinary(data);
  }
  if (format == PacketFormat.ascii) {
    final text = utf8.decode(data, allowMalformed: true);
    for (final line in text.split(RegExp(r'[\r\n;]+'))) {
      final t = line.trim();
      if (t.isEmpty) continue;
      final nums = RegExp(r'-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
          .allMatches(t)
          .map((m) => double.tryParse(m.group(0)!))
          .whereType<double>()
          .toList();
      if (nums.isEmpty) continue;
      out.add(_combine(nums, ax) * scale);
    }
    return out;
  }
  final width = format == PacketFormat.uint8
      ? 1
      : (format == PacketFormat.int16le ? 2 : 4);
  final step = width * ax;
  final bd = ByteData.sublistView(Uint8List.fromList(data));
  for (int i = 0; i + step <= data.length; i += step) {
    final vals = <double>[];
    for (int a = 0; a < ax; a++) {
      final off = i + a * width;
      if (width == 1) {
        vals.add(bd.getUint8(off).toDouble());
      } else if (width == 2) {
        vals.add(bd.getInt16(off, Endian.little).toDouble());
      } else {
        vals.add(bd.getFloat32(off, Endian.little));
      }
    }
    out.add(_combine(vals, ax) * scale);
  }
  return out;
}

abstract class SampleSource {
  Stream<double> get samples;
  Future<void> start();
  Future<void> stop();
  void dispose();
}

/// Bluetooth Low Energy source: connects to a device, finds a notifying
/// characteristic (optionally filtered by UUID) and parses its packets.
class BleSource implements SampleSource {
  BleSource({
    required this.device,
    required this.serviceUuid,
    required this.charUuid,
    required this.format,
    required this.scale,
    required this.axes,
    this.onPacket,
  });

  final void Function(List<int> data)? onPacket;
  final BluetoothDevice device;
  final String serviceUuid;
  final String charUuid;
  final PacketFormat format;
  final double scale;
  final int axes;

  final StreamController<double> _ctrl = StreamController<double>.broadcast();
  StreamSubscription<List<int>>? _sub;
  StreamSubscription<BluetoothConnectionState>? _connSub;
  bool _stopping = false;

  @override
  Stream<double> get samples => _ctrl.stream;

  @override
  Future<void> start() async {
    _stopping = false;
    await device.connect(timeout: const Duration(seconds: 15));
    final services = await device.discoverServices();

    final su = serviceUuid.trim().toLowerCase();
    final cu = charUuid.trim().toLowerCase();
    BluetoothCharacteristic? target;
    for (final s in services) {
      if (su.isNotEmpty && !s.uuid.toString().toLowerCase().contains(su)) {
        continue;
      }
      for (final c in s.characteristics) {
        final uuidOk = cu.isEmpty || c.uuid.toString().toLowerCase().contains(cu);
        if (uuidOk && (c.properties.notify || c.properties.indicate)) {
          target = c;
          break;
        }
      }
      if (target != null) break;
    }
    if (target == null) {
      try {
        await device.disconnect();
      } catch (_) {}
      throw StateError('no_char');
    }

    await target.setNotifyValue(true);
    _sub = target.onValueReceived.listen((List<int> data) {
      onPacket?.call(data);
      for (final v in parsePacket(data, format, scale, axes)) {
        _ctrl.add(v);
      }
    });
    _connSub = device.connectionState.listen((BluetoothConnectionState s) {
      if (s == BluetoothConnectionState.disconnected && !_stopping) {
        _ctrl.addError('disconnected');
      }
    });
  }

  @override
  Future<void> stop() async {
    _stopping = true;
    await _sub?.cancel();
    await _connSub?.cancel();
    _sub = null;
    _connSub = null;
    try {
      await device.disconnect();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ctrl.close();
  }
}


/// Classic Bluetooth (SPP / serial) source, e.g. an ESP32 running the
/// BluetoothSerial library. Text lines are reassembled before parsing.
///
/// The plugin is used through `dynamic` so that small API differences between
/// plugin versions cannot break the build; problems show up as a connection
/// error instead.
class ClassicSource implements SampleSource {
  ClassicSource({
    required this.address,
    required this.format,
    required this.scale,
    required this.axes,
    this.onPacket,
  });

  final String address;
  final PacketFormat format;
  final double scale;
  final int axes;
  final void Function(List<int> data)? onPacket;

  final StreamController<double> _ctrl = StreamController<double>.broadcast();
  StreamSubscription<dynamic>? _sub;
  dynamic _conn;
  bool _stopping = false;
  String _buf = '';

  @override
  Stream<double> get samples => _ctrl.stream;

  void _handle(List<int> data) {
    if (data.isEmpty) return;
    onPacket?.call(data);
    final text = format == PacketFormat.ascii ||
        (format == PacketFormat.auto && (looksLikeText(data) || _buf.isNotEmpty));
    if (text) {
      _buf += utf8.decode(data, allowMalformed: true);
      if (_buf.length > 4096) _buf = _buf.substring(_buf.length - 1024);
      int nl;
      while ((nl = _buf.indexOf('\n')) >= 0) {
        final line = _buf.substring(0, nl).trim();
        _buf = _buf.substring(nl + 1);
        if (line.isEmpty) continue;
        for (final v
            in parsePacket(utf8.encode(line), PacketFormat.ascii, scale, axes)) {
          _ctrl.add(v);
        }
      }
    } else {
      for (final v in parsePacket(data, format, scale, axes)) {
        _ctrl.add(v);
      }
    }
  }

  @override
  Future<void> start() async {
    _stopping = false;
    final dynamic fbc = FlutterBlueClassic();
    // Discovery running in the background makes Android's RFCOMM connect
    // slow or fail, so stop it first.
    try {
      fbc.stopScan();
    } catch (_) {}
    Object? lastErr;
    for (int attempt = 0; attempt < 3 && _conn == null; attempt++) {
      try {
        _conn = await (fbc.connect(address) as Future<dynamic>)
            .timeout(const Duration(seconds: 20));
      } catch (e) {
        lastErr = e;
        _conn = null;
        await Future<void>.delayed(const Duration(milliseconds: 1500));
      }
    }
    if (_conn == null) {
      if (lastErr != null) throw Exception('SPP: $lastErr');
      throw StateError('conn_failed');
    }
    // The data stream has had different names across plugin versions.
    dynamic input;
    try {
      input = _conn.input;
    } catch (_) {}
    if (input == null) {
      try {
        input = _conn.onDataReceived;
      } catch (_) {}
    }
    if (input == null) throw StateError('conn_failed');
    _sub = (input as Stream<dynamic>).listen(
      (dynamic d) {
        if (d is List) _handle(d.cast<int>());
      },
      onError: (Object e) {
        if (!_stopping) _ctrl.addError('disconnected');
      },
      onDone: () {
        if (!_stopping) _ctrl.addError('disconnected');
      },
    );
  }

  @override
  Future<void> stop() async {
    _stopping = true;
    await _sub?.cancel();
    _sub = null;
    try {
      await _conn?.close();
    } catch (_) {}
    try {
      _conn?.dispose();
    } catch (_) {}
    _conn = null;
  }

  @override
  void dispose() {
    _ctrl.close();
  }
}
