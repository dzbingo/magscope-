import 'dart:io';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';

import 'dsp.dart';
import 'ger_xml.dart';
import 'models.dart';
import 'widgets.dart' show heatColor;

/// Export formats for a scanned grid. The Z value is the scan reading (relative, no unit).
enum ExportFormat { surfer, xyz, esri, csv, gerXml, kml }

extension ExportFormatInfo on ExportFormat {
  String get ext {
    switch (this) {
      case ExportFormat.surfer:
        return 'grd';
      case ExportFormat.xyz:
        return 'xyz';
      case ExportFormat.esri:
        return 'asc';
      case ExportFormat.csv:
        return 'csv';
      case ExportFormat.gerXml:
        return 'xml';
      case ExportFormat.kml:
        return 'kml';
    }
  }

  String get title {
    switch (this) {
      case ExportFormat.surfer:
        return 'Surfer ASCII grid (.grd)';
      case ExportFormat.xyz:
        return 'XYZ points (.xyz)';
      case ExportFormat.esri:
        return 'ESRI ASCII grid (.asc)';
      case ExportFormat.csv:
        return 'CSV matrix (.csv)';
      case ExportFormat.gerXml:
        return 'GER3D XML (.xml)';
      case ExportFormat.kml:
        return 'KML - Google Earth (.kml)';
    }
  }

  String get note {
    switch (this) {
      case ExportFormat.surfer:
        return 'Surfer, Grapher, QGIS, Global Mapper';
      case ExportFormat.xyz:
        return 'Surfer (import data), Voxler, Excel, most 3D tools';
      case ExportFormat.esri:
        return 'QGIS, ArcGIS, Global Mapper';
      case ExportFormat.csv:
        return 'Excel, Python, MATLAB';
      case ExportFormat.gerXml:
        return 'GER3D-style scan file (import back into MagVision Pro)';
      case ExportFormat.kml:
        return 'Google Earth overlay on satellite imagery (needs GPS)';
    }
  }
}

const String _blank = '1.70141e+38'; // Surfer "blank" node value

class Exporter {
  /// Builds the file text. [cellM] is the cell size in metres.
  static String build(ScanSession s, ExportFormat f, double cellM) {
    final cols = s.cols;
    final rows = s.rows;
    final valid = s.cells.where((e) => !e.isNaN).toList();
    final zmin = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a < b ? a : b);
    final zmax = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a > b ? a : b);
    if (f == ExportFormat.gerXml) return GerXml.build(s);
    if (f == ExportFormat.kml) return _kml(s, cellM);
    final b = StringBuffer();
    switch (f) {
      case ExportFormat.surfer:
        b.writeln('DSAA');
        b.writeln('$cols $rows');
        b.writeln('0 ${(cols - 1) * cellM}');
        b.writeln('0 ${(rows - 1) * cellM}');
        b.writeln('$zmin $zmax');
        for (int y = 0; y < rows; y++) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? _blank : v.toStringAsFixed(4));
          }
          b.writeln(row.join(' '));
        }
        break;
      case ExportFormat.xyz:
        for (int y = 0; y < rows; y++) {
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            if (v.isNaN) continue;
            b.writeln(
                '${(x * cellM).toStringAsFixed(4)} ${(y * cellM).toStringAsFixed(4)} ${v.toStringAsFixed(4)}');
          }
        }
        break;
      case ExportFormat.esri:
        b.writeln('ncols $cols');
        b.writeln('nrows $rows');
        b.writeln('xllcorner 0');
        b.writeln('yllcorner 0');
        b.writeln('cellsize $cellM');
        b.writeln('NODATA_value -9999');
        // ESRI rows go from the top (largest y) down
        for (int y = rows - 1; y >= 0; y--) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? '-9999' : v.toStringAsFixed(4));
          }
          b.writeln(row.join(' '));
        }
        break;
      case ExportFormat.gerXml:
      case ExportFormat.kml:
        break;
      case ExportFormat.csv:
        for (int y = 0; y < rows; y++) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? '' : v.toStringAsFixed(4));
          }
          b.writeln(row.join(','));
        }
        break;
    }
    return b.toString();
  }

  static String _esc(String v) => v
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  /// KML hex colour is aabbggrr.
  static String _kmlColor(int argb, int alpha) {
    final r = (argb >> 16) & 0xFF;
    final g = (argb >> 8) & 0xFF;
    final b = argb & 0xFF;
    String h(int v) => v.toRadixString(16).padLeft(2, '0');
    return '${h(alpha)}${h(b)}${h(g)}${h(r)}';
  }

  /// Google Earth file: every measured cell is a coloured polygon draped on
  /// the ground, anomalies get pins. The grid is assumed north-up and the GPS
  /// position is taken as the centre of the grid (row 0 = north edge).
  static String _kml(ScanSession s, double cellM) {
    final geo = s.geo;
    if (geo == null) return '';
    final cols = s.cols;
    final rows = s.rows;
    final valid = s.cells.where((e) => !e.isNaN).toList();
    double lo = valid.isEmpty ? 0.0 : valid.reduce(math.min);
    double hi = valid.isEmpty ? 1.0 : valid.reduce(math.max);
    if (hi - lo < 1e-6) hi = lo + 1.0;
    const mPerDegLat = 111320.0;
    final mPerDegLon =
        mPerDegLat * math.cos(geo.latitude * math.pi / 180.0).abs().clamp(0.01, 1.0);
    double lat(double northM) => geo.latitude + northM / mPerDegLat;
    double lon(double eastM) => geo.longitude + eastM / mPerDegLon;
    final halfW = cols * cellM / 2;
    final halfH = rows * cellM / 2;
    String pt(double eastM, double northM) =>
        '${lon(eastM).toStringAsFixed(8)},${lat(northM).toStringAsFixed(8)},0';

    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document>');
    b.writeln('<name>${_esc(s.name)}</name>');
    b.writeln(
        '<description>MagVision Pro magnetometer scan. Grid ${cols}x$rows, cell ${(cellM * 100).toStringAsFixed(0)} cm, north-up, GPS point = grid centre (accuracy ±${geo.accuracy.toStringAsFixed(0)} m). Values ${lo.toStringAsFixed(2)} to ${hi.toStringAsFixed(2)}.</description>');
    b.writeln('<Folder><name>Cells</name>');
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final v = s.cells[y * cols + x];
        if (v.isNaN) continue;
        final w = -halfW + x * cellM;
        final e = w + cellM;
        final n = halfH - y * cellM;
        final so = n - cellM;
        final col = heatColor((v - lo) / (hi - lo));
        b.write('<Placemark><name>${v.toStringAsFixed(1)}</name>');
        b.write(
            '<Style><PolyStyle><color>${_kmlColor(col.value, 170)}</color><outline>0</outline></PolyStyle></Style>');
        b.write(
            '<Polygon><tessellate>1</tessellate><outerBoundaryIs><LinearRing><coordinates>');
        b.write('${pt(w, n)} ${pt(e, n)} ${pt(e, so)} ${pt(w, so)} ${pt(w, n)}');
        b.writeln('</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>');
      }
    }
    b.writeln('</Folder>');
    final an = findCellAnomalies(s.cells, cols, rows, 3.0);
    b.writeln('<Folder><name>Anomalies</name>');
    int k = 1;
    for (final a in an.take(30)) {
      final v = s.cells[a.y * cols + a.x];
      final cx = -halfW + (a.x + 0.5) * cellM;
      final cy = halfH - (a.y + 0.5) * cellM;
      b.writeln(
          '<Placemark><name>#${k++}</name><description>${v.toStringAsFixed(2)} (${a.deviation >= 0 ? '+' : ''}${a.deviation.toStringAsFixed(2)}) cell ${a.x + 1},${a.y + 1}</description><Point><coordinates>${pt(cx, cy)}</coordinates></Point></Placemark>');
    }
    b.writeln('</Folder>');
    b.writeln(
        '<Placemark><name>Grid centre</name><Point><coordinates>${pt(0, 0)}</coordinates></Point></Placemark>');
    b.writeln('</Document></kml>');
    return b.toString();
  }

  /// Writes the file into the app's export folder and returns its path.
  static Future<String> write(
      ScanSession s, ExportFormat f, double cellM) async {
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final path = '${base.path}/${clean}_${s.id}.${f.ext}';
    await File(path).writeAsString(build(s, f, cellM));
    return path;
  }
}
