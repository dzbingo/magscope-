import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'ger_xml.dart';
import 'models.dart';

/// Export formats for a scanned grid. The Z value is the field in uT.
enum ExportFormat { surfer, xyz, esri, csv, gerXml }

extension ExportFormatInfo on ExportFormat {
  String get ext {
    switch (this) {
      case ExportFormat.surfer:
        return 'grd';
      case ExportFormat.xyz:
        return 'xyz';
      case ExportFormat.esri:
        return 'asc';
      case ExportFormat.csv:
        return 'csv';
      case ExportFormat.gerXml:
        return 'xml';
    }
  }

  String get title {
    switch (this) {
      case ExportFormat.surfer:
        return 'Surfer ASCII grid (.grd)';
      case ExportFormat.xyz:
        return 'XYZ points (.xyz)';
      case ExportFormat.esri:
        return 'ESRI ASCII grid (.asc)';
      case ExportFormat.csv:
        return 'CSV matrix (.csv)';
      case ExportFormat.gerXml:
        return 'GER3D XML (.xml)';
    }
  }

  String get note {
    switch (this) {
      case ExportFormat.surfer:
        return 'Surfer, Grapher, QGIS, Global Mapper';
      case ExportFormat.xyz:
        return 'Surfer (import data), Voxler, Excel, most 3D tools';
      case ExportFormat.esri:
        return 'QGIS, ArcGIS, Global Mapper';
      case ExportFormat.csv:
        return 'Excel, Python, MATLAB';
      case ExportFormat.gerXml:
        return 'GER3D-style scan file (import back into Sniper-Dz)';
    }
  }
}

const String _blank = '1.70141e+38'; // Surfer "blank" node value

class Exporter {
  /// Builds the file text. [cellM] is the cell size in metres.
  static String build(ScanSession s, ExportFormat f, double cellM) {
    final cols = s.cols;
    final rows = s.rows;
    final valid = s.cells.where((e) => !e.isNaN).toList();
    final zmin = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a < b ? a : b);
    final zmax = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a > b ? a : b);
    if (f == ExportFormat.gerXml) return GerXml.build(s);
    final b = StringBuffer();
    switch (f) {
      case ExportFormat.surfer:
        b.writeln('DSAA');
        b.writeln('$cols $rows');
        b.writeln('0 ${(cols - 1) * cellM}');
        b.writeln('0 ${(rows - 1) * cellM}');
        b.writeln('$zmin $zmax');
        for (int y = 0; y < rows; y++) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? _blank : v.toStringAsFixed(4));
          }
          b.writeln(row.join(' '));
        }
        break;
      case ExportFormat.xyz:
        for (int y = 0; y < rows; y++) {
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            if (v.isNaN) continue;
            b.writeln(
                '${(x * cellM).toStringAsFixed(4)} ${(y * cellM).toStringAsFixed(4)} ${v.toStringAsFixed(4)}');
          }
        }
        break;
      case ExportFormat.esri:
        b.writeln('ncols $cols');
        b.writeln('nrows $rows');
        b.writeln('xllcorner 0');
        b.writeln('yllcorner 0');
        b.writeln('cellsize $cellM');
        b.writeln('NODATA_value -9999');
        // ESRI rows go from the top (largest y) down
        for (int y = rows - 1; y >= 0; y--) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? '-9999' : v.toStringAsFixed(4));
          }
          b.writeln(row.join(' '));
        }
        break;
      case ExportFormat.gerXml:
        break;
      case ExportFormat.csv:
        for (int y = 0; y < rows; y++) {
          final row = <String>[];
          for (int x = 0; x < cols; x++) {
            final v = s.cells[y * cols + x];
            row.add(v.isNaN ? '' : v.toStringAsFixed(4));
          }
          b.writeln(row.join(','));
        }
        break;
    }
    return b.toString();
  }

  /// Writes the file into the app's export folder and returns its path.
  static Future<String> write(
      ScanSession s, ExportFormat f, double cellM) async {
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final path = '${base.path}/${clean}_${s.id}.${f.ext}';
    await File(path).writeAsString(build(s, f, cellM));
    return path;
  }
}
