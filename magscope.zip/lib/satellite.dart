import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'geo.dart';

/// Downloads a satellite picture of the scanned area (Esri World Imagery,
/// exported as a single image) and crops it to the grid footprint.
/// Needs an internet connection; the picture is not stored offline.
class SatelliteLoader {
  static const String attribution = 'Imagery: Esri, Maxar, Earthstar Geographics';

  static Future<ui.Image> load(
      ScanGeoLocation g, int cols, int rows, double cellM) async {
    final wM = cols * cellM;
    final hM = rows * cellM;
    // Ask for a wider area than a tiny grid: the server has no data at very
    // small extents. The grid footprint is cropped out afterwards.
    final ext = math.max(math.max(wM, hM), 80.0);
    const mPerDegLat = 111320.0;
    final mPerDegLon =
        mPerDegLat * math.cos(g.latitude * math.pi / 180.0).abs().clamp(0.01, 1.0);
    final dLat = ext / 2 / mPerDegLat;
    final dLon = ext / 2 / mPerDegLon;
    final w = g.longitude - dLon;
    final e = g.longitude + dLon;
    final s = g.latitude - dLat;
    final n = g.latitude + dLat;
    final url = Uri.parse(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/export'
        '?bbox=${w.toStringAsFixed(8)},${s.toStringAsFixed(8)},${e.toStringAsFixed(8)},${n.toStringAsFixed(8)}'
        '&bboxSR=4326&imageSR=4326&size=1024,1024&format=jpg&f=image');

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    Uint8List bytes;
    try {
      final req = await client.getUrl(url).timeout(const Duration(seconds: 20));
      final res = await req.close().timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        throw HttpException('HTTP ${res.statusCode}');
      }
      final ct = res.headers.contentType?.mimeType ?? '';
      if (!ct.startsWith('image')) {
        throw const HttpException('not an image');
      }
      final b = BytesBuilder(copy: false);
      await for (final chunk in res.timeout(const Duration(seconds: 30))) {
        b.add(chunk);
      }
      bytes = b.takeBytes();
    } finally {
      client.close(force: true);
    }

    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final full = frame.image;

    final fw = (wM / ext).clamp(0.05, 1.0).toDouble();
    final fh = (hM / ext).clamp(0.05, 1.0).toDouble();
    final iw = full.width.toDouble();
    final ih = full.height.toDouble();
    final src = ui.Rect.fromLTWH(
        (1 - fw) / 2 * iw, (1 - fh) / 2 * ih, fw * iw, fh * ih);
    final outW = math.max(32, (fw * iw).round());
    final outH = math.max(32, (fh * ih).round());
    final rec = ui.PictureRecorder();
    final canvas = ui.Canvas(rec);
    canvas.drawImageRect(
      full,
      src,
      ui.Rect.fromLTWH(0, 0, outW.toDouble(), outH.toDouble()),
      ui.Paint()..filterQuality = ui.FilterQuality.high,
    );
    return rec.endRecording().toImage(outW, outH);
  }
}
