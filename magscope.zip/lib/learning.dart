/// One target the user confirmed in the field: its contrast (peak divided by
/// the background noise) and whether it turned out to be real.
class LearnRec {
  const LearnRec(this.contrast, this.found);

  final double contrast;
  final bool found;

  Map<String, dynamic> toJson() => <String, dynamic>{'c': contrast, 'f': found};

  static LearnRec fromJson(Map<String, dynamic> j) =>
      LearnRec((j['c'] as num).toDouble(), j['f'] == true);
}

class Learning {
  /// Smallest contrast that has separated real targets from false ones so
  /// far, or null when there are not yet at least two of each kind.
  static double? threshold(List<LearnRec> recs) {
    final real = recs.where((r) => r.found).map((r) => r.contrast).toList();
    final fake = recs.where((r) => !r.found).map((r) => r.contrast).toList();
    if (real.length < 2 || fake.length < 2) return null;
    double mean(List<double> v) => v.reduce((a, b) => a + b) / v.length;
    final minReal = real.reduce((a, b) => a < b ? a : b);
    final maxFake = fake.reduce((a, b) => a > b ? a : b);
    if (maxFake < minReal) return (minReal + maxFake) / 2;
    return (mean(real) + mean(fake)) / 2;
  }
}
