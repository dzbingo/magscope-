import 'dart:io';
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// Keeps the last errors in a small text file so the user can share it and the
/// problem can be fixed from facts instead of guesses. Nothing is sent
/// anywhere; the file leaves the phone only when the user shares it.
class Diag {
  static const int _maxBytes = 120 * 1024;

  static Future<File> _file() async {
    final base = await getApplicationDocumentsDirectory();
    return File('${base.path}/diagnostics.log');
  }

  static void init() {
    final previous = FlutterError.onError;
    FlutterError.onError = (FlutterErrorDetails d) {
      unawaited(record('FlutterError', d.exceptionAsString(), d.stack));
      if (previous != null) previous(d);
    };
    PlatformDispatcher.instance.onError = (Object e, StackTrace st) {
      unawaited(record('Uncaught', e.toString(), st));
      return true;
    };
  }

  static void unawaited(Future<void> f) {}

  static Future<void> record(String kind, String message, StackTrace? st) async {
    try {
      final f = await _file();
      final line = StringBuffer()
        ..writeln('--- ${DateTime.now().toIso8601String()}  $kind')
        ..writeln(message);
      if (st != null) {
        final lines = st.toString().split('\n');
        line.writeln(lines.take(14).join('\n'));
      }
      var old = '';
      if (await f.exists()) {
        old = await f.readAsString();
        if (old.length > _maxBytes) old = old.substring(old.length - _maxBytes ~/ 2);
      }
      await f.writeAsString(old + line.toString());
    } catch (_) {}
  }

  /// Path of the log file when it exists and has content, otherwise null.
  static Future<String?> path() async {
    try {
      final f = await _file();
      if (await f.exists() && await f.length() > 0) return f.path;
    } catch (_) {}
    return null;
  }

  static Future<void> clear() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
