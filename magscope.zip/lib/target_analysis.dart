import 'dart:math' as math;

import 'dsp.dart';

/// Shape measurements of one anomaly (a target candidate).
class TargetInfo {
  const TargetInfo({
    required this.deviation,
    required this.contrast,
    required this.widthM,
    required this.aspect,
    required this.symmetry,
    required this.peaks,
    required this.cells,
    required this.depthM,
  });

  /// Peak minus background (signed).
  final double deviation;

  /// |deviation| divided by the background noise.
  final double contrast;

  /// Equivalent width of the half-maximum area, metres.
  final double widthM;

  /// Elongation: 1 = round, large = long strip.
  final double aspect;

  /// 1 = perfectly symmetric around the peak, 0 = lopsided.
  final double symmetry;

  /// Number of separate maxima inside the anomaly (1 = single target).
  final int peaks;

  /// Cells above half of the peak.
  final int cells;

  /// Estimated depth in metres (null when it cannot be estimated).
  final double? depthM;

  /// Rough depth range: the estimate is only good to about +-40%.
  (double, double)? get depthRange =>
      depthM == null ? null : (depthM! * 0.6, depthM! * 1.4);

  /// Plain-language guess about what the anomaly looks like. A hint only.
  String get kindKey {
    if (peaks >= 3 || (symmetry < 0.35 && contrast < 6)) return 'tk_noise';
    if (aspect >= 2.8) return 'tk_linear';
    if (widthM > 1.8 && contrast < 6) return 'tk_geology';
    return 'tk_single';
  }

  List<double> get features => <double>[
        math.log(1 + contrast),
        widthM,
        math.min(aspect, 6),
        symmetry,
        math.min(peaks, 5).toDouble(),
        deviation >= 0 ? 1 : 0,
      ];
}

class TargetAnalysis {
  /// Measures the anomaly whose peak is the cell ([x], [y]).
  static TargetInfo analyze(List<double> cells, int cols, int rows, int x,
      int y, double cellM, double noise) {
    final valid = cells.where((double e) => !e.isNaN).toList();
    final med = valid.isEmpty ? 0.0 : medianOf(valid);
    final peakV = cells[y * cols + x];
    final dev = peakV - med;
    final sign = dev >= 0 ? 1.0 : -1.0;
    final half = dev.abs() / 2;
    // flood fill over cells at least half as strong, same sign
    final seen = <int>{};
    final stack = <int>[y * cols + x];
    final region = <int>[];
    while (stack.isNotEmpty && region.length < 400) {
      final i = stack.removeLast();
      if (!seen.add(i)) continue;
      final v = cells[i];
      if (v.isNaN || (v - med) * sign < half) continue;
      region.add(i);
      final cx = i % cols;
      final cy = i ~/ cols;
      if (cx > 0) stack.add(i - 1);
      if (cx < cols - 1) stack.add(i + 1);
      if (cy > 0) stack.add(i - cols);
      if (cy < rows - 1) stack.add(i + cols);
    }
    if (region.isEmpty) region.add(y * cols + x);
    // weighted centroid and second moments
    double sw = 0, mx = 0, my = 0;
    for (final i in region) {
      final w = (cells[i] - med).abs();
      sw += w;
      mx += w * (i % cols);
      my += w * (i ~/ cols);
    }
    mx /= sw <= 0 ? 1 : sw;
    my /= sw <= 0 ? 1 : sw;
    double sxx = 0, syy = 0, sxy = 0;
    for (final i in region) {
      final dx = (i % cols) - mx;
      final dy = (i ~/ cols) - my;
      sxx += dx * dx;
      syy += dy * dy;
      sxy += dx * dy;
    }
    final n = region.length.toDouble();
    sxx = sxx / n + 1 / 12;
    syy = syy / n + 1 / 12;
    sxy /= n;
    final tr = sxx + syy;
    final det = sxx * syy - sxy * sxy;
    final disc = math.sqrt(math.max(0, tr * tr / 4 - det));
    final l1 = tr / 2 + disc;
    final l2 = math.max(1e-6, tr / 2 - disc);
    final aspect = math.sqrt(l1 / l2);
    // symmetry: distance between the peak and the centroid, relative to size
    final off = math.sqrt(math.pow(x - mx, 2) + math.pow(y - my, 2));
    final radius = math.max(0.7, math.sqrt(n / math.pi));
    final symmetry = (1 - off / (radius * 1.5)).clamp(0.0, 1.0).toDouble();
    // separate maxima inside the region
    int peaks = 0;
    for (final i in region) {
      final cx = i % cols;
      final cy = i ~/ cols;
      bool top = true;
      for (int dy = -1; dy <= 1 && top; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
          if (dx == 0 && dy == 0) continue;
          final nx = cx + dx;
          final ny = cy + dy;
          if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
          final v = cells[ny * cols + nx];
          if (v.isNaN) continue;
          if ((v - med) * sign > (cells[i] - med) * sign + 1e-9) {
            top = false;
            break;
          }
        }
      }
      if (top) peaks++;
    }
    final de = estimateDepth(cells, cols, rows, x, y, cellM);
    return TargetInfo(
      deviation: dev,
      contrast: dev.abs() / math.max(noise, 0.05),
      widthM: 2 * radius * cellM,
      aspect: aspect,
      symmetry: symmetry,
      peaks: math.max(1, peaks),
      cells: region.length,
      depthM: de?.depthM,
    );
  }
}

/// One confirmed field result: the target's measurements and the verdict.
class FeatRec {
  const FeatRec(this.f, this.found);
  final List<double> f;
  final bool found;

  Map<String, dynamic> toJson() => <String, dynamic>{'f': f, 'y': found};
  static FeatRec fromJson(Map<String, dynamic> j) => FeatRec(
      (j['f'] as List<dynamic>).map((dynamic e) => (e as num).toDouble()).toList(),
      j['y'] == true);
}

/// Small logistic-regression model trained on the user's own verdicts.
/// It is only used when there is enough data, and its measured accuracy
/// (cross-validated) is always shown together with the probability.
class LocalModel {
  LocalModel._(this._w, this._mu, this._sd, this.samples, this.accuracy);

  static const int minSamples = 30;
  static const int minPerClass = 8;

  final List<double> _w; // bias + weights
  final List<double> _mu;
  final List<double> _sd;
  final int samples;

  /// Cross-validated accuracy, 0..1.
  final double accuracy;

  static (int, int) counts(List<FeatRec> r) =>
      (r.where((FeatRec e) => e.found).length, r.where((FeatRec e) => !e.found).length);

  static bool enough(List<FeatRec> r) {
    final c = counts(r);
    return r.length >= minSamples && c.$1 >= minPerClass && c.$2 >= minPerClass;
  }

  static double _sig(double z) => 1 / (1 + math.exp(-z.clamp(-30, 30)));

  static List<double> _fit(List<List<double>> x, List<bool> y) {
    final d = x.first.length;
    final w = List<double>.filled(d + 1, 0);
    for (int it = 0; it < 400; it++) {
      final g = List<double>.filled(d + 1, 0);
      for (int i = 0; i < x.length; i++) {
        double z = w[0];
        for (int k = 0; k < d; k++) {
          z += w[k + 1] * x[i][k];
        }
        final e = _sig(z) - (y[i] ? 1 : 0);
        g[0] += e;
        for (int k = 0; k < d; k++) {
          g[k + 1] += e * x[i][k];
        }
      }
      for (int k = 0; k <= d; k++) {
        final reg = k == 0 ? 0.0 : 0.05 * w[k]; // light L2 regularisation
        w[k] -= 0.3 * (g[k] / x.length + reg);
      }
    }
    return w;
  }

  /// Returns null when there is not enough data.
  static LocalModel? train(List<FeatRec> recs) {
    if (!enough(recs)) return null;
    final d = recs.first.f.length;
    final mu = List<double>.filled(d, 0);
    final sd = List<double>.filled(d, 1);
    for (int k = 0; k < d; k++) {
      mu[k] = recs.map((FeatRec r) => r.f[k]).reduce((double a, double b) => a + b) / recs.length;
      final v = recs.map((FeatRec r) => math.pow(r.f[k] - mu[k], 2).toDouble()).reduce((double a, double b) => a + b) / recs.length;
      sd[k] = math.max(math.sqrt(v), 1e-6);
    }
    List<double> norm(List<double> f) =>
        <double>[for (int k = 0; k < d; k++) (f[k] - mu[k]) / sd[k]];
    final xs = recs.map((FeatRec r) => norm(r.f)).toList();
    final ys = recs.map((FeatRec r) => r.found).toList();
    // 5-fold cross-validation for an honest accuracy figure
    int ok = 0;
    for (int fold = 0; fold < 5; fold++) {
      final tx = <List<double>>[];
      final ty = <bool>[];
      final vx = <List<double>>[];
      final vy = <bool>[];
      for (int i = 0; i < xs.length; i++) {
        if (i % 5 == fold) {
          vx.add(xs[i]);
          vy.add(ys[i]);
        } else {
          tx.add(xs[i]);
          ty.add(ys[i]);
        }
      }
      if (tx.isEmpty || vx.isEmpty) continue;
      final w = _fit(tx, ty);
      for (int i = 0; i < vx.length; i++) {
        double z = w[0];
        for (int k = 0; k < d; k++) {
          z += w[k + 1] * vx[i][k];
        }
        if ((_sig(z) >= 0.5) == vy[i]) ok++;
      }
    }
    final w = _fit(xs, ys);
    return LocalModel._(w, mu, sd, recs.length, ok / recs.length);
  }

  /// Probability (0..1) that the target is real.
  double probability(List<double> f) {
    double z = _w[0];
    for (int k = 0; k < f.length; k++) {
      z += _w[k + 1] * (f[k] - _mu[k]) / _sd[k];
    }
    return _sig(z);
  }
}
