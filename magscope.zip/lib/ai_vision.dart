import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:path_provider/path_provider.dart';

import 'dsp.dart';
import 'soil.dart';

/// Rough soil guess from the average colour of a ground photo.
/// This is a colour rule, NOT a trained vision model: lighting, moisture and
/// shadows change the colour a lot, so the confidence is always low.
class SoilGuess {
  const SoilGuess(this.soilIdx, this.confidence, this.r, this.g, this.b);
  final int soilIdx;
  final double confidence;
  final int r;
  final int g;
  final int b;
}

/// Everything the "AI manager" sets by itself for a scan.
class AiPlan {
  const AiPlan({
    required this.soilIdx,
    required this.filters,
    required this.destripe,
    required this.gridView,
    required this.reasons,
  });
  final int soilIdx;
  final FilterConfig filters;
  final bool destripe;
  final int gridView;

  /// Translation keys explaining each decision.
  final List<String> reasons;
}

class AiVision {
  /// Average colour of the centre of the photo, mapped to a soil class.
  static Future<SoilGuess> guessSoil(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: 96);
    final frame = await codec.getNextFrame();
    final img = frame.image;
    final bd = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    codec.dispose();
    if (bd == null) return const SoilGuess(0, 0, 0, 0, 0);
    final w = img.width;
    final h = img.height;
    double sr = 0, sg = 0, sb = 0;
    int n = 0;
    for (int y = (h * 0.2).floor(); y < (h * 0.8).ceil(); y++) {
      for (int x = (w * 0.2).floor(); x < (w * 0.8).ceil(); x++) {
        final o = (y * w + x) * 4;
        sr += bd.getUint8(o);
        sg += bd.getUint8(o + 1);
        sb += bd.getUint8(o + 2);
        n++;
      }
    }
    if (n == 0) return const SoilGuess(0, 0, 0, 0, 0);
    final r = sr / n / 255.0;
    final g = sg / n / 255.0;
    final b = sb / n / 255.0;
    final mx = math.max(r, math.max(g, b));
    final mn = math.min(r, math.min(g, b));
    final v = mx;
    final s = mx <= 0 ? 0.0 : (mx - mn) / mx;
    double hue = 0;
    final d = mx - mn;
    if (d > 1e-6) {
      if (mx == r) {
        hue = 60 * (((g - b) / d) % 6);
      } else if (mx == g) {
        hue = 60 * (((b - r) / d) + 2);
      } else {
        hue = 60 * (((r - g) / d) + 4);
      }
    }
    if (hue < 0) hue += 360;

    int idx = 0;
    double conf = 0.2;
    if ((hue < 22 || hue > 340) && s > 0.38 && v > 0.3) {
      idx = 6; // reddish -> iron-rich / laterite
      conf = 0.35 + math.min(0.25, (s - 0.38));
    } else if (v < 0.26 && s < 0.25) {
      idx = 7; // very dark and grey -> volcanic / basalt
      conf = 0.3;
    } else if (v < 0.42 && hue >= 15 && hue <= 50 && s >= 0.25) {
      idx = 4; // dark brown -> humic topsoil
      conf = 0.3;
    } else if (v > 0.62 && hue >= 28 && hue <= 60 && s >= 0.18) {
      idx = 1; // light tan -> sand
      conf = 0.4;
    } else if (v > 0.6 && s < 0.14) {
      idx = 2; // pale grey / white -> limestone
      conf = 0.35;
    } else if (hue >= 15 && hue <= 45 && s >= 0.2) {
      idx = 3; // mid brown -> clay
      conf = 0.3;
    } else if (s < 0.14 && v >= 0.26 && v <= 0.62) {
      idx = 5; // mid grey -> granite / crystalline
      conf = 0.25;
    }
    return SoilGuess(idx, math.min(conf, 0.6), (r * 255).round(),
        (g * 255).round(), (b * 255).round());
  }

  /// The filters and settings the AI manager picks for a soil and conditions.
  static AiPlan plan({
    required int soilIdx,
    required bool humid,
    required bool night,
  }) {
    final soil = kSoils[soilIdx.clamp(0, kSoils.length - 1).toInt()];
    final noisy = soil.kFactor >= 1.5;
    final mid = soil.kFactor >= 1.15;
    final reasons = <String>[];

    double sens = 3.0;
    int medianWin = 5;
    int gridPasses = 1;
    bool baseline = false;
    bool destripe = false;
    int view = 0;

    if (noisy) {
      medianWin = 7;
      gridPasses = 2;
      baseline = true;
      destripe = true;
      view = 1; // high-pass view hides the natural background
      reasons.add('ai_why_noisy');
    } else if (mid) {
      gridPasses = 2;
      destripe = true;
      reasons.add('ai_why_mid');
    } else {
      reasons.add('ai_why_quiet');
    }
    if (humid) {
      sens += 0.5;
      medianWin = math.min(7, medianWin + 2);
      reasons.add('ai_why_humid');
    }
    if (night) {
      reasons.add('ai_why_night');
    }
    reasons.add('ai_why_soil_k');

    return AiPlan(
      soilIdx: soilIdx,
      filters: FilterConfig(
        despike: true,
        despikeK: noisy ? 3.5 : 4.0,
        median: true,
        medianWindow: medianWin,
        baseline: baseline,
        average: true,
        gridSmooth: true,
        gridPasses: gridPasses,
        sensitivity: sens,
      ),
      destripe: destripe,
      gridView: view,
      reasons: reasons,
    );
  }

  /// Saves an anonymous field package (no photo, no name, no GPS): the soil
  /// colour, conditions, the measured grid and the user's verdict.
  /// It stays on the phone; the user may share the file by hand.
  static Future<String> savePackage({
    required int cols,
    required int rows,
    required double cellCm,
    required List<double> cells,
    required int soilIdx,
    SoilGuess? guess,
    required bool humid,
    required bool night,
    required double contrast,
    required int score,
    required bool found,
  }) async {
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/ai_packages');
    if (!dir.existsSync()) dir.createSync(recursive: true);
    final now = DateTime.now();
    final data = <String, dynamic>{
      'version': 1,
      'time': now.toUtc().toIso8601String().substring(0, 10),
      'cols': cols,
      'rows': rows,
      'cell_cm': cellCm,
      'soil': kSoils[soilIdx.clamp(0, kSoils.length - 1).toInt()].key,
      'photo_rgb': guess == null
          ? null
          : <int>[guess.r, guess.g, guess.b],
      'humid': humid,
      'night': night,
      'contrast': double.parse(contrast.toStringAsFixed(2)),
      'score': score,
      'found': found,
      'cells': <dynamic>[
        for (final v in cells) v.isNaN ? null : double.parse(v.toStringAsFixed(2))
      ],
    };
    final path = '${dir.path}/pkg_${now.millisecondsSinceEpoch}.json';
    await File(path).writeAsString(jsonEncode(data));
    return path;
  }

  static List<File> packages(Directory base) {
    final dir = Directory('${base.path}/ai_packages');
    if (!dir.existsSync()) return <File>[];
    return dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.json'))
        .toList();
  }
}
