import 'dart:math' as math;
import 'anomaly.dart';

// ---------------------------------------------------------------------------
// Standard signal-processing helpers for magnetometer data.
// All filters here are textbook algorithms (median, moving average,
// exponential smoothing, baseline removal, MAD-based spike rejection).
// ---------------------------------------------------------------------------

double meanOf(List<double> v) {
  if (v.isEmpty) return 0;
  double s = 0;
  for (final x in v) {
    s += x;
  }
  return s / v.length;
}

double stdOf(List<double> v) {
  if (v.length < 2) return 0;
  final m = meanOf(v);
  double s = 0;
  for (final x in v) {
    s += (x - m) * (x - m);
  }
  return math.sqrt(s / (v.length - 1));
}

double medianOf(List<double> v) {
  if (v.isEmpty) return 0;
  final s = List<double>.from(v)..sort();
  final n = s.length;
  if (n.isOdd) return s[n ~/ 2];
  return (s[n ~/ 2 - 1] + s[n ~/ 2]) / 2;
}

/// Causal moving average with window [w].
List<double> movingAverage(List<double> x, int w) {
  if (w <= 1 || x.isEmpty) return List<double>.from(x);
  final out = List<double>.filled(x.length, 0);
  double sum = 0;
  for (int i = 0; i < x.length; i++) {
    sum += x[i];
    if (i >= w) sum -= x[i - w];
    final n = math.min(i + 1, w);
    out[i] = sum / n;
  }
  return out;
}

/// Causal median filter with window [w].
List<double> medianFilter(List<double> x, int w) {
  if (w <= 1 || x.isEmpty) return List<double>.from(x);
  final out = List<double>.filled(x.length, 0);
  for (int i = 0; i < x.length; i++) {
    final start = math.max(0, i - w + 1);
    out[i] = medianOf(x.sublist(start, i + 1));
  }
  return out;
}

/// Exponential smoothing, alpha in (0, 1]. Higher alpha = less smoothing.
List<double> expSmooth(List<double> x, double alpha) {
  if (x.isEmpty) return <double>[];
  final a = alpha.clamp(0.01, 1.0).toDouble();
  final out = List<double>.filled(x.length, 0);
  out[0] = x[0];
  for (int i = 1; i < x.length; i++) {
    out[i] = a * x[i] + (1 - a) * out[i - 1];
  }
  return out;
}

/// Removes slow drift: value minus its running mean over [w] samples.
List<double> baselineRemove(List<double> x, int w) {
  if (x.isEmpty) return <double>[];
  final ma = movingAverage(x, w);
  final out = List<double>.filled(x.length, 0);
  for (int i = 0; i < x.length; i++) {
    out[i] = x[i] - ma[i];
  }
  return out;
}

/// Replaces isolated single-sample spikes using a robust (median / MAD) test.
/// A sample is only treated as a spike if the NEXT sample returns to the
/// normal range, so real step changes (a genuine anomaly) are preserved.
List<double> despikeFilter(List<double> x, int w, double k) {
  if (x.length < 5) return List<double>.from(x);
  final out = List<double>.from(x);
  for (int i = 3; i < x.length - 1; i++) {
    final start = math.max(0, i - w);
    final win = out.sublist(start, i);
    final m = medianOf(win);
    final dev = win.map((e) => (e - m).abs()).toList();
    final mad = medianOf(dev) * 1.4826;
    final lim = k * math.max(mad, 1e-6);
    final isOut = (x[i] - m).abs() > lim;
    final nextNormal = (x[i + 1] - m).abs() <= lim;
    if (isOut && nextNormal) out[i] = m;
  }
  return out;
}

/// 3x3 binomial smoothing on a grid, ignoring empty (NaN) cells.
List<double> smoothGrid(List<double> g, int cols, int rows, int passes) {
  var cur = List<double>.from(g);
  for (int p = 0; p < passes; p++) {
    final next = List<double>.from(cur);
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final c = cur[y * cols + x];
        if (c.isNaN) continue;
        double s = 0;
        double ws = 0;
        for (int dy = -1; dy <= 1; dy++) {
          for (int dx = -1; dx <= 1; dx++) {
            final nx = x + dx;
            final ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
            final v = cur[ny * cols + nx];
            if (v.isNaN) continue;
            final wgt = (dx == 0 ? 2.0 : 1.0) * (dy == 0 ? 2.0 : 1.0);
            s += v * wgt;
            ws += wgt;
          }
        }
        next[y * cols + x] = s / ws;
      }
    }
    cur = next;
  }
  return cur;
}

class SeriesStats {
  const SeriesStats(this.min, this.max, this.mean, this.std);
  final double min;
  final double max;
  final double mean;
  final double std;
  double get span => max - min;
}

SeriesStats statsOf(List<double> v) {
  final valid = v.where((e) => !e.isNaN).toList();
  if (valid.isEmpty) return const SeriesStats(0, 0, 0, 0);
  double lo = valid.first;
  double hi = valid.first;
  for (final x in valid) {
    if (x < lo) lo = x;
    if (x > hi) hi = x;
  }
  return SeriesStats(lo, hi, meanOf(valid), stdOf(valid));
}

/// Indices of local peaks of |x| above [threshold], at least [minDistance] apart.
List<int> findPeaks(List<double> x, double threshold, int minDistance) {
  final a = x.map((e) => e.abs()).toList();
  final peaks = <int>[];
  for (int i = 1; i < a.length - 1; i++) {
    if (a[i] >= threshold && a[i] > a[i - 1] && a[i] >= a[i + 1]) {
      if (peaks.isNotEmpty && i - peaks.last < minDistance) {
        if (a[i] > a[peaks.last]) peaks[peaks.length - 1] = i;
      } else {
        peaks.add(i);
      }
    }
  }
  return peaks;
}

class CellAnomaly {
  const CellAnomaly(this.x, this.y, this.deviation);
  final int x;
  final int y;
  final double deviation;
}

/// Cells whose value deviates from the grid median by more than
/// [k] robust standard deviations (MAD based). Strongest first.
List<CellAnomaly> findCellAnomalies(
        List<double> cells, int cols, int rows, double k,
        {double? absThreshold}) =>
    Detect.find(cells, cols, rows, k, absThreshold: absThreshold);

/// User-adjustable filter chain applied to the raw sample stream.
class FilterConfig {
  const FilterConfig({
    this.despike = true,
    this.despikeK = 4.0,
    this.median = true,
    this.medianWindow = 5,
    this.baseline = false,
    this.baselineWindow = 120,
    this.average = true,
    this.averageWindow = 6,
    this.ema = false,
    this.emaAlpha = 0.3,
    this.gridSmooth = false,
    this.gridPasses = 1,
    this.sensitivity = 3.0,
  });

  final bool despike;
  final double despikeK;
  final bool median;
  final int medianWindow;
  final bool baseline;
  final int baselineWindow;
  final bool average;
  final int averageWindow;
  final bool ema;
  final double emaAlpha;
  final bool gridSmooth;
  final int gridPasses;
  final double sensitivity;

  FilterConfig copyWith({
    bool? despike,
    double? despikeK,
    bool? median,
    int? medianWindow,
    bool? baseline,
    int? baselineWindow,
    bool? average,
    int? averageWindow,
    bool? ema,
    double? emaAlpha,
    bool? gridSmooth,
    int? gridPasses,
    double? sensitivity,
  }) {
    return FilterConfig(
      despike: despike ?? this.despike,
      despikeK: despikeK ?? this.despikeK,
      median: median ?? this.median,
      medianWindow: medianWindow ?? this.medianWindow,
      baseline: baseline ?? this.baseline,
      baselineWindow: baselineWindow ?? this.baselineWindow,
      average: average ?? this.average,
      averageWindow: averageWindow ?? this.averageWindow,
      ema: ema ?? this.ema,
      emaAlpha: emaAlpha ?? this.emaAlpha,
      gridSmooth: gridSmooth ?? this.gridSmooth,
      gridPasses: gridPasses ?? this.gridPasses,
      sensitivity: sensitivity ?? this.sensitivity,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'despike': despike,
        'despikeK': despikeK,
        'median': median,
        'medianWindow': medianWindow,
        'baseline': baseline,
        'baselineWindow': baselineWindow,
        'average': average,
        'averageWindow': averageWindow,
        'ema': ema,
        'emaAlpha': emaAlpha,
        'gridSmooth': gridSmooth,
        'gridPasses': gridPasses,
        'sensitivity': sensitivity,
      };

  static double _d(dynamic v, double def) => v is num ? v.toDouble() : def;
  static int _i(dynamic v, int def) => v is num ? v.toInt() : def;
  static bool _b(dynamic v, bool def) => v is bool ? v : def;

  factory FilterConfig.fromJson(Map<String, dynamic> j) {
    const d = FilterConfig();
    return FilterConfig(
      despike: _b(j['despike'], d.despike),
      despikeK: _d(j['despikeK'], d.despikeK),
      median: _b(j['median'], d.median),
      medianWindow: _i(j['medianWindow'], d.medianWindow),
      baseline: _b(j['baseline'], d.baseline),
      baselineWindow: _i(j['baselineWindow'], d.baselineWindow),
      average: _b(j['average'], d.average),
      averageWindow: _i(j['averageWindow'], d.averageWindow),
      ema: _b(j['ema'], d.ema),
      emaAlpha: _d(j['emaAlpha'], d.emaAlpha),
      gridSmooth: _b(j['gridSmooth'], d.gridSmooth),
      gridPasses: _i(j['gridPasses'], d.gridPasses),
      sensitivity: _d(j['sensitivity'], d.sensitivity),
    );
  }

  /// Order: spike rejection -> median -> baseline -> average -> exp. smoothing.
  List<double> apply(List<double> x) {
    var y = x;
    if (despike) y = despikeFilter(y, 9, despikeK);
    if (median) y = medianFilter(y, medianWindow);
    if (baseline) y = baselineRemove(y, baselineWindow);
    if (average) y = movingAverage(y, averageWindow);
    if (ema) y = expSmooth(y, emaAlpha);
    return y;
  }
}


/// Rough depth estimate for the anomaly centred on cell ([px], [py]).
///
/// Uses the full width at half maximum (FWHM) of the anomaly. For a compact
/// source whose field falls off like 1/r^3 the FWHM is about 1.53 x the depth
/// of its centre, so depth ~ FWHM / 1.53. This is only an order-of-magnitude
/// estimate: real objects are not point sources.
class DepthEstimate {
  const DepthEstimate(this.depthM, this.fwhmM,
      {this.slopeDepthM = 0,
      this.minDepthM = 0,
      this.maxDepthM = 0,
      this.methodsAgree = true});
  final double depthM; // 60% width-at-half-max + 40% half-slope
  final double fwhmM;
  final double slopeDepthM;
  final double minDepthM;
  final double maxDepthM;
  final bool methodsAgree; // the two methods are within 25% of each other
}

DepthEstimate? estimateDepth(
    List<double> cellsIn, int cols, int rows, int px, int py, double cellM) {
  // work on the residual (regional trend removed) so a slope cannot distort
  // the width of the anomaly
  final cells = Detect.residual(cellsIn, cols, rows);
  final valid = cells.where((e) => !e.isNaN).toList();
  if (valid.length < 6 || cellM <= 0) return null;
  final bg = medianOf(valid);
  final v0 = cells[py * cols + px];
  if (v0.isNaN) return null;
  final amp = v0 - bg;
  if (amp.abs() < 1e-6) return null;
  final half = amp / 2;

  double v(int x, int y) {
    final c = cells[y * cols + x];
    return c.isNaN ? 0.0 : c - bg;
  }

  // distance (in cells) from the peak to where the profile falls below half
  double reach(int dx, int dy) {
    double prev = amp;
    int x = px;
    int y = py;
    double dist = 0;
    while (true) {
      x += dx;
      y += dy;
      if (x < 0 || y < 0 || x >= cols || y >= rows) return dist;
      final cur = v(x, y);
      final below = amp > 0 ? cur <= half : cur >= half;
      if (below) {
        final denom = prev - cur;
        final f = denom.abs() < 1e-9 ? 0.5 : (prev - half) / denom;
        return dist + f.clamp(0.0, 1.0).toDouble();
      }
      prev = cur;
      dist += 1;
    }
  }

  final w = reach(-1, 0) + reach(1, 0);
  final h = reach(0, -1) + reach(0, 1);
  var fwhmCells = (w + h) / 2;
  if (fwhmCells < 1.0) fwhmCells = 1.0; // cannot resolve below one cell
  final fwhm = fwhmCells * cellM;
  final depthFwhm = fwhm / 1.53;

  // second, independent method: half-slope. The steepest gradient around the
  // peak gives an effective width = amplitude / max slope.
  double maxGrad = 0.0;
  double at(int x, int y) {
    if (x < 0 || y < 0 || x >= cols || y >= rows) return 0.0;
    return v(x, y);
  }

  for (int r = 1; r <= 3; r++) {
    final g = <double>[
      (at(px - r + 1, py) - at(px - r, py)).abs(),
      (at(px + r - 1, py) - at(px + r, py)).abs(),
      (at(px, py - r + 1) - at(px, py - r)).abs(),
      (at(px, py + r - 1) - at(px, py + r)).abs(),
    ];
    for (final x in g) {
      if (x > maxGrad) maxGrad = x;
    }
  }
  final slopeWidth = maxGrad > 1e-6
      ? ((amp.abs() / maxGrad) * cellM).clamp(cellM, fwhm * 1.5).toDouble()
      : fwhm;
  final depthSlope = slopeWidth / 1.60;

  final blended = depthFwhm * 0.6 + depthSlope * 0.4;
  final lowM = math.min(depthFwhm, depthSlope);
  final highM = math.max(depthFwhm, depthSlope);
  final agree = (depthFwhm - depthSlope).abs() / math.max(blended, 0.1) < 0.25;
  return DepthEstimate(blended, fwhm,
      slopeDepthM: depthSlope,
      minDepthM: math.max(0.05, lowM * 0.85),
      maxDepthM: highM * 1.15,
      methodsAgree: agree);
}

/// Removes pass-to-pass level offsets (every pass of the scan is one column,
/// from south to north).
///
/// Each column is compared with its neighbours (two on each side, row by
/// row), so a broad regional slope is not touched. The estimated offset is
/// applied only when it looks like ordinary stripe jitter; a column whose
/// offset is far larger than the others (3 robust deviations) is left alone,
/// because that is more likely a real target than a level error. This is why
/// a large target is no longer erased by this option.
List<double> destripeGrid(List<double> g, int cols, int rows) {
  final valid = g.where((e) => !e.isNaN).toList();
  if (valid.length < 6 || cols < 3) return g;
  final offs = List<double>.filled(cols, 0.0);
  final has = List<bool>.filled(cols, false);
  for (int x = 0; x < cols; x++) {
    final diffs = <double>[];
    for (int y = 0; y < rows; y++) {
      final v = g[y * cols + x];
      if (v.isNaN) continue;
      final nb = <double>[];
      for (int dx = -2; dx <= 2; dx++) {
        final nx = x + dx;
        if (dx == 0 || nx < 0 || nx >= cols) continue;
        final w = g[y * cols + nx];
        if (!w.isNaN) nb.add(w);
      }
      if (nb.length < 2) continue;
      diffs.add(v - medianOf(nb));
    }
    if (diffs.length >= 3) {
      offs[x] = medianOf(diffs);
      has[x] = true;
    }
  }
  final hv = <double>[];
  for (int x = 0; x < cols; x++) {
    if (has[x]) hv.add(offs[x]);
  }
  if (hv.length < 3) return g;
  final m = medianOf(hv);
  final spread =
      math.max(medianOf(hv.map((e) => (e - m).abs()).toList()) * 1.4826, 1e-6);
  final out = List<double>.from(g);
  for (int x = 0; x < cols; x++) {
    if (!has[x]) continue;
    final off = offs[x] - m;
    if (off.abs() > 3 * spread) continue; // probably a real target
    for (int y = 0; y < rows; y++) {
      final i = y * cols + x;
      if (!out[i].isNaN) out[i] = out[i] - off;
    }
  }
  return out;
}

/// High-pass: grid minus a heavily smoothed copy. Removes the slowly varying
/// regional field and keeps small local anomalies.
List<double> highPassGrid(List<double> g, int cols, int rows) {
  final low = smoothGrid(g, cols, rows, 8);
  final out = List<double>.from(g);
  for (int i = 0; i < out.length; i++) {
    if (out[i].isNaN || low[i].isNaN) continue;
    out[i] = out[i] - low[i];
  }
  return out;
}

/// Horizontal gradient magnitude: bright where the field changes quickly,
/// which outlines the edges of buried objects.
List<double> gradientGrid(List<double> g, int cols, int rows) {
  final out = List<double>.filled(g.length, double.nan);
  double at(int x, int y, double fallback) {
    if (x < 0 || y < 0 || x >= cols || y >= rows) return fallback;
    final v = g[y * cols + x];
    return v.isNaN ? fallback : v;
  }

  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      final c = g[y * cols + x];
      if (c.isNaN) continue;
      final gx = (at(x + 1, y, c) - at(x - 1, y, c)) / 2;
      final gy = (at(x, y + 1, c) - at(x, y - 1, c)) / 2;
      out[y * cols + x] = math.sqrt(gx * gx + gy * gy);
    }
  }
  return out;
}


/// Approximate analytic-signal amplitude: sqrt(gx^2 + gy^2 + gz^2), where the
/// vertical derivative gz is estimated from the difference to a smoothed copy.
/// Its peaks sit over the edges/centre of a body almost independently of the
/// magnetisation direction, which makes targets easier to locate.
List<double> analyticSignalGrid(List<double> g, int cols, int rows) {
  final low = smoothGrid(g, cols, rows, 3);
  final out = List<double>.filled(g.length, double.nan);
  double at(int x, int y, double fallback) {
    if (x < 0 || y < 0 || x >= cols || y >= rows) return fallback;
    final v = g[y * cols + x];
    return v.isNaN ? fallback : v;
  }

  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      final i = y * cols + x;
      final c = g[i];
      if (c.isNaN) continue;
      final gx = (at(x + 1, y, c) - at(x - 1, y, c)) / 2;
      final gy = (at(x, y + 1, c) - at(x, y - 1, c)) / 2;
      final l = low[i];
      final gz = l.isNaN ? 0.0 : (c - l);
      out[i] = math.sqrt(gx * gx + gy * gy + gz * gz);
    }
  }
  return out;
}
