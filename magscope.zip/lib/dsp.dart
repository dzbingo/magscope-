import 'dart:math' as math;

// ---------------------------------------------------------------------------
// Standard signal-processing helpers for magnetometer data.
// All filters here are textbook algorithms (median, moving average,
// exponential smoothing, baseline removal, MAD-based spike rejection).
// ---------------------------------------------------------------------------

double meanOf(List<double> v) {
  if (v.isEmpty) return 0;
  double s = 0;
  for (final x in v) {
    s += x;
  }
  return s / v.length;
}

double stdOf(List<double> v) {
  if (v.length < 2) return 0;
  final m = meanOf(v);
  double s = 0;
  for (final x in v) {
    s += (x - m) * (x - m);
  }
  return math.sqrt(s / (v.length - 1));
}

double medianOf(List<double> v) {
  if (v.isEmpty) return 0;
  final s = List<double>.from(v)..sort();
  final n = s.length;
  if (n.isOdd) return s[n ~/ 2];
  return (s[n ~/ 2 - 1] + s[n ~/ 2]) / 2;
}

/// Causal moving average with window [w].
List<double> movingAverage(List<double> x, int w) {
  if (w <= 1 || x.isEmpty) return List<double>.from(x);
  final out = List<double>.filled(x.length, 0);
  double sum = 0;
  for (int i = 0; i < x.length; i++) {
    sum += x[i];
    if (i >= w) sum -= x[i - w];
    final n = math.min(i + 1, w);
    out[i] = sum / n;
  }
  return out;
}

/// Causal median filter with window [w].
List<double> medianFilter(List<double> x, int w) {
  if (w <= 1 || x.isEmpty) return List<double>.from(x);
  final out = List<double>.filled(x.length, 0);
  for (int i = 0; i < x.length; i++) {
    final start = math.max(0, i - w + 1);
    out[i] = medianOf(x.sublist(start, i + 1));
  }
  return out;
}

/// Exponential smoothing, alpha in (0, 1]. Higher alpha = less smoothing.
List<double> expSmooth(List<double> x, double alpha) {
  if (x.isEmpty) return <double>[];
  final a = alpha.clamp(0.01, 1.0).toDouble();
  final out = List<double>.filled(x.length, 0);
  out[0] = x[0];
  for (int i = 1; i < x.length; i++) {
    out[i] = a * x[i] + (1 - a) * out[i - 1];
  }
  return out;
}

/// Removes slow drift: value minus its running mean over [w] samples.
List<double> baselineRemove(List<double> x, int w) {
  if (x.isEmpty) return <double>[];
  final ma = movingAverage(x, w);
  final out = List<double>.filled(x.length, 0);
  for (int i = 0; i < x.length; i++) {
    out[i] = x[i] - ma[i];
  }
  return out;
}

/// Replaces isolated single-sample spikes using a robust (median / MAD) test.
/// A sample is only treated as a spike if the NEXT sample returns to the
/// normal range, so real step changes (a genuine anomaly) are preserved.
List<double> despikeFilter(List<double> x, int w, double k) {
  if (x.length < 5) return List<double>.from(x);
  final out = List<double>.from(x);
  for (int i = 3; i < x.length - 1; i++) {
    final start = math.max(0, i - w);
    final win = out.sublist(start, i);
    final m = medianOf(win);
    final dev = win.map((e) => (e - m).abs()).toList();
    final mad = medianOf(dev) * 1.4826;
    final lim = k * math.max(mad, 1e-6);
    final isOut = (x[i] - m).abs() > lim;
    final nextNormal = (x[i + 1] - m).abs() <= lim;
    if (isOut && nextNormal) out[i] = m;
  }
  return out;
}

/// 3x3 binomial smoothing on a grid, ignoring empty (NaN) cells.
List<double> smoothGrid(List<double> g, int cols, int rows, int passes) {
  var cur = List<double>.from(g);
  for (int p = 0; p < passes; p++) {
    final next = List<double>.from(cur);
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final c = cur[y * cols + x];
        if (c.isNaN) continue;
        double s = 0;
        double ws = 0;
        for (int dy = -1; dy <= 1; dy++) {
          for (int dx = -1; dx <= 1; dx++) {
            final nx = x + dx;
            final ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
            final v = cur[ny * cols + nx];
            if (v.isNaN) continue;
            final wgt = (dx == 0 ? 2.0 : 1.0) * (dy == 0 ? 2.0 : 1.0);
            s += v * wgt;
            ws += wgt;
          }
        }
        next[y * cols + x] = s / ws;
      }
    }
    cur = next;
  }
  return cur;
}

class SeriesStats {
  const SeriesStats(this.min, this.max, this.mean, this.std);
  final double min;
  final double max;
  final double mean;
  final double std;
  double get span => max - min;
}

SeriesStats statsOf(List<double> v) {
  final valid = v.where((e) => !e.isNaN).toList();
  if (valid.isEmpty) return const SeriesStats(0, 0, 0, 0);
  double lo = valid.first;
  double hi = valid.first;
  for (final x in valid) {
    if (x < lo) lo = x;
    if (x > hi) hi = x;
  }
  return SeriesStats(lo, hi, meanOf(valid), stdOf(valid));
}

/// Indices of local peaks of |x| above [threshold], at least [minDistance] apart.
List<int> findPeaks(List<double> x, double threshold, int minDistance) {
  final a = x.map((e) => e.abs()).toList();
  final peaks = <int>[];
  for (int i = 1; i < a.length - 1; i++) {
    if (a[i] >= threshold && a[i] > a[i - 1] && a[i] >= a[i + 1]) {
      if (peaks.isNotEmpty && i - peaks.last < minDistance) {
        if (a[i] > a[peaks.last]) peaks[peaks.length - 1] = i;
      } else {
        peaks.add(i);
      }
    }
  }
  return peaks;
}

class CellAnomaly {
  const CellAnomaly(this.x, this.y, this.deviation);
  final int x;
  final int y;
  final double deviation;
}

/// Cells whose value deviates from the grid median by more than
/// [k] robust standard deviations (MAD based). Strongest first.
List<CellAnomaly> findCellAnomalies(
    List<double> cells, int cols, int rows, double k) {
  final valid = cells.where((e) => !e.isNaN).toList();
  if (valid.length < 6) return <CellAnomaly>[];
  final m = medianOf(valid);
  final mad = medianOf(valid.map((e) => (e - m).abs()).toList()) * 1.4826;
  final lim = k * math.max(mad, 0.05);
  final out = <CellAnomaly>[];
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      final v = cells[y * cols + x];
      if (v.isNaN) continue;
      final d = v - m;
      if (d.abs() > lim) out.add(CellAnomaly(x, y, d));
    }
  }
  out.sort((a, b) => b.deviation.abs().compareTo(a.deviation.abs()));
  return out.length > 10 ? out.sublist(0, 10) : out;
}

/// User-adjustable filter chain applied to the raw sample stream.
class FilterConfig {
  const FilterConfig({
    this.despike = true,
    this.despikeK = 4.0,
    this.median = true,
    this.medianWindow = 5,
    this.baseline = false,
    this.baselineWindow = 120,
    this.average = true,
    this.averageWindow = 6,
    this.ema = false,
    this.emaAlpha = 0.3,
    this.gridSmooth = true,
    this.gridPasses = 1,
    this.sensitivity = 3.0,
  });

  final bool despike;
  final double despikeK;
  final bool median;
  final int medianWindow;
  final bool baseline;
  final int baselineWindow;
  final bool average;
  final int averageWindow;
  final bool ema;
  final double emaAlpha;
  final bool gridSmooth;
  final int gridPasses;
  final double sensitivity;

  FilterConfig copyWith({
    bool? despike,
    double? despikeK,
    bool? median,
    int? medianWindow,
    bool? baseline,
    int? baselineWindow,
    bool? average,
    int? averageWindow,
    bool? ema,
    double? emaAlpha,
    bool? gridSmooth,
    int? gridPasses,
    double? sensitivity,
  }) {
    return FilterConfig(
      despike: despike ?? this.despike,
      despikeK: despikeK ?? this.despikeK,
      median: median ?? this.median,
      medianWindow: medianWindow ?? this.medianWindow,
      baseline: baseline ?? this.baseline,
      baselineWindow: baselineWindow ?? this.baselineWindow,
      average: average ?? this.average,
      averageWindow: averageWindow ?? this.averageWindow,
      ema: ema ?? this.ema,
      emaAlpha: emaAlpha ?? this.emaAlpha,
      gridSmooth: gridSmooth ?? this.gridSmooth,
      gridPasses: gridPasses ?? this.gridPasses,
      sensitivity: sensitivity ?? this.sensitivity,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'despike': despike,
        'despikeK': despikeK,
        'median': median,
        'medianWindow': medianWindow,
        'baseline': baseline,
        'baselineWindow': baselineWindow,
        'average': average,
        'averageWindow': averageWindow,
        'ema': ema,
        'emaAlpha': emaAlpha,
        'gridSmooth': gridSmooth,
        'gridPasses': gridPasses,
        'sensitivity': sensitivity,
      };

  static double _d(dynamic v, double def) => v is num ? v.toDouble() : def;
  static int _i(dynamic v, int def) => v is num ? v.toInt() : def;
  static bool _b(dynamic v, bool def) => v is bool ? v : def;

  factory FilterConfig.fromJson(Map<String, dynamic> j) {
    const d = FilterConfig();
    return FilterConfig(
      despike: _b(j['despike'], d.despike),
      despikeK: _d(j['despikeK'], d.despikeK),
      median: _b(j['median'], d.median),
      medianWindow: _i(j['medianWindow'], d.medianWindow),
      baseline: _b(j['baseline'], d.baseline),
      baselineWindow: _i(j['baselineWindow'], d.baselineWindow),
      average: _b(j['average'], d.average),
      averageWindow: _i(j['averageWindow'], d.averageWindow),
      ema: _b(j['ema'], d.ema),
      emaAlpha: _d(j['emaAlpha'], d.emaAlpha),
      gridSmooth: _b(j['gridSmooth'], d.gridSmooth),
      gridPasses: _i(j['gridPasses'], d.gridPasses),
      sensitivity: _d(j['sensitivity'], d.sensitivity),
    );
  }

  /// Order: spike rejection -> median -> baseline -> average -> exp. smoothing.
  List<double> apply(List<double> x) {
    var y = x;
    if (despike) y = despikeFilter(y, 9, despikeK);
    if (median) y = medianFilter(y, medianWindow);
    if (baseline) y = baselineRemove(y, baselineWindow);
    if (average) y = movingAverage(y, averageWindow);
    if (ema) y = expSmooth(y, emaAlpha);
    return y;
  }
}
