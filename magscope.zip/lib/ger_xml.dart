import 'dsp.dart';
import 'models.dart';

/// Reader/writer for the XML scan files used by GER3D-style detectors.
///
/// Layout (as seen in a real file):
///   <metadata> <width/> <height/> <creationtime/> <sensorcount/>
///     <countperpath/> <sampleperpath/> <samplingmode/> <devicetype/>
///     <rawpoints> <path><values>..</values>...</path> ... </rawpoints>
///
/// Each <path> is one scan line. The detector is walked in a zigzag, so the
/// samples of every second path are stored in walking order and have to be
/// reversed to put them in the right place on the map. Here every path
/// becomes one column of the grid and every sample one row.
class GerXml {
  static int? _int(String xml, String tag) {
    final m = RegExp('<$tag>\\s*(-?\\d+)\\s*</$tag>').firstMatch(xml);
    return m == null ? null : int.tryParse(m.group(1)!);
  }

  static ScanSession? parse(String xml, String name) {
    final paths = <List<double>>[];
    for (final m
        in RegExp(r'<path>(.*?)</path>', dotAll: true).allMatches(xml)) {
      final vals = <double>[];
      for (final v in RegExp(r'<values>\s*([-+0-9.eE]+)\s*</values>')
          .allMatches(m.group(1)!)) {
        final d = double.tryParse(v.group(1)!);
        if (d != null) vals.add(d);
      }
      if (vals.isNotEmpty) paths.add(vals);
    }
    if (paths.isEmpty) return null;
    final cols = paths.length;
    var rows = 0;
    for (final p in paths) {
      if (p.length > rows) rows = p.length;
    }
    if (cols < 2 || rows < 2 || cols * rows > 10000) return null;

    final cells = List<double>.filled(cols * rows, double.nan);
    final raw = <double>[];
    for (int x = 0; x < cols; x++) {
      final p = paths[x];
      for (int s = 0; s < p.length; s++) {
        final y = x.isOdd ? p.length - 1 - s : s;
        cells[y * cols + x] = p[s];
        raw.add(p[s]);
      }
    }

    _repairGlitches(cells, cols, rows);

    DateTime created = DateTime.now();
    final ct = RegExp(r'<creationtime>\s*(\d{14})\s*</creationtime>')
        .firstMatch(xml)
        ?.group(1);
    if (ct != null) {
      created = DateTime(
        int.parse(ct.substring(0, 4)),
        int.parse(ct.substring(4, 6)),
        int.parse(ct.substring(6, 8)),
        int.parse(ct.substring(8, 10)),
        int.parse(ct.substring(10, 12)),
        int.parse(ct.substring(12, 14)),
      );
    }
    return ScanSession(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name.isEmpty ? 'GER3D' : name,
      createdAt: created,
      source: 'ble',
      raw: raw,
      cols: cols,
      rows: rows,
      cells: cells,
    );
  }

  /// Detector files contain sensor dropouts (for example 1 or 28 while the
  /// normal level is about 128). Values far below the median are replaced by
  /// the average of their valid neighbours.
  static void _repairGlitches(List<double> cells, int cols, int rows) {
    final valid = cells.where((e) => !e.isNaN).toList();
    if (valid.length < 6) return;
    final m = medianOf(valid);
    if (m < 40) return; // only for byte-style data centred well above zero
    final bad = <int>[];
    for (int i = 0; i < cells.length; i++) {
      if (!cells[i].isNaN && cells[i] < m * 0.5) bad.add(i);
    }
    final orig = List<double>.from(cells);
    for (final i in bad) {
      final x = i % cols;
      final y = i ~/ cols;
      double sum = 0;
      int n = 0;
      for (final d in const <List<int>>[
        <int>[1, 0],
        <int>[-1, 0],
        <int>[0, 1],
        <int>[0, -1],
      ]) {
        final nx = x + d[0];
        final ny = y + d[1];
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        final v = orig[ny * cols + nx];
        if (v.isNaN || v < m * 0.5) continue;
        sum += v;
        n++;
      }
      cells[i] = n == 0 ? m : sum / n;
    }
  }

  static String build(ScanSession s) {
    String two(int n) => n.toString().padLeft(2, '0');
    final d = s.createdAt;
    final ct = '${d.year}${two(d.month)}${two(d.day)}'
        '${two(d.hour)}${two(d.minute)}${two(d.second)}';
    final b = StringBuffer()
      ..write("<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>")
      ..write('<metadata><note></note>')
      ..write('<width>${s.cols * 2}</width>')
      ..write('<height>${s.rows * 2}</height>')
      ..write('<creationtime>$ct</creationtime>')
      ..write('<sensorcount>1</sensorcount>')
      ..write('<countperpath>${s.cols}</countperpath>')
      ..write('<sampleperpath>${s.rows}</sampleperpath>')
      ..write('<samplingmode>4</samplingmode>')
      ..write('<devicetype>1</devicetype>')
      ..write('<rawpoints>');
    for (int x = 0; x < s.cols; x++) {
      b.write('<path>');
      for (int i = 0; i < s.rows; i++) {
        final y = x.isOdd ? s.rows - 1 - i : i;
        final v = s.cells[y * s.cols + x];
        b.write('<values>${(v.isNaN ? 0.0 : v).toStringAsFixed(1)}</values>');
      }
      b.write('</path>');
    }
    b.write('</rawpoints></metadata>');
    return b.toString();
  }
}
