import 'dart:convert';
import 'dart:typed_data';

import 'models.dart';

/// EXPERIMENTAL writer for OKM ".v3d" scan files (for Visualizer 3D).
///
/// The layout is inferred from five sample files and has not been opened in
/// OKM software: a 479-byte header copied from a real zig-zag scan (only the
/// row count at byte 175 and the date at bytes 379-386 are patched), then
/// 36-byte records of little-endian float32: value, x, y and six zeros.
/// y = 0 is the south row. Passes run along y and alternate direction.
class V3dExport {
  static const String _header = 'ClYzRC5WM0QuMDEKVjNELlYzRC4wMScoQykyMDAyLTIwMTggYnkgT0tNIE9ydHVuZ3N0ZWNobmlrIEdtYkgAAAAAAAAAAAAAABdPS00gT3J0dW5nc3RlY2huaWsgR21iSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIMTIwMzA0LzEAAAAAAAAABVJaODlJBTA5T1BMBTRaSjgxBVJKQldJBVVONzk4AAAAABMAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAPwAAgD8AAIA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAPwAAgD8AAIA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAALTCAAAAAAAAAAAAAAAAAACAPwAAgD8AAIA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAADTCAAAAAAAANMIAAAAAAACAPwAAgD8AAIA/AAAAAImTInRAMuZAAAAAACQAAABEAGUAdgBpAGMAZQA6ACAAUgBvAHYAZQByACAAQwA0AA0ACgBTAGMAYQBuACAATQBvAGQAZQA6ACAAWgBpAGcALQBaAGEAZwAAAAAAAAAAAAAAAAA=';

  static Uint8List build(ScanSession s, {DateTime? now}) {
    final cols = s.cols, rows = s.rows;
    if (cols < 2 || rows < 2 || rows > 255 || cols > 255) {
      throw ArgumentError('grid size not supported by .v3d');
    }
    final valid = s.cells.where((e) => !e.isNaN).toList()..sort();
    final fill = valid.isEmpty ? 0.0 : valid[valid.length ~/ 2];
    final head = Uint8List.fromList(base64Decode(_header));
    head[175] = rows;
    // OLE automation date: days since 1899-12-30
    final t = (now ?? DateTime.now()).toUtc();
    final days =
        t.difference(DateTime.utc(1899, 12, 30)).inMilliseconds / 86400000.0;
    ByteData.sublistView(head).setFloat64(379, days, Endian.little);
    final out = BytesBuilder();
    out.add(head);
    final rec = Uint8List(36);
    final bd = ByteData.sublistView(rec);
    for (int x = 0; x < cols; x++) {
      for (int k = 0; k < rows; k++) {
        final y = x.isEven ? k : rows - 1 - k;
        final v = s.cells[(rows - 1 - y) * cols + x];
        bd.setFloat32(0, v.isNaN ? fill : v, Endian.little);
        bd.setFloat32(4, x.toDouble(), Endian.little);
        bd.setFloat32(8, y.toDouble(), Endian.little);
        out.add(rec);
      }
    }
    return out.toBytes();
  }
}
