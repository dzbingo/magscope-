import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:path_provider/path_provider.dart';

import 'dsp.dart';
import 'geo.dart';
import 'imaging.dart';
import 'models.dart';

/// A point on the ground.
class GeoPt {
  const GeoPt(this.lat, this.lon);
  final double lat;
  final double lon;
}

/// Geographic placement of a scan grid: the GPS point is the grid centre, the
/// grid's "up" side (north edge, the walking direction of every pass) points
/// to [headingDeg] (clockwise from north), and each cell is [cellM] metres.
class GeoFrame {
  GeoFrame(this.geo, this.cols, this.rows, this.cellM, this.headingDeg);

  final ScanGeoLocation geo;
  final int cols;
  final int rows;
  final double cellM;
  final double headingDeg;

  static const double _mLat = 111320.0;

  /// (e, n) = metres right / up in the grid's own frame, from its centre.
  GeoPt at(double e, double n) {
    final cr = geo.corners;
    if (cr != null && cr.length == 4 && cols > 0 && rows > 0) {
      // placed from the four recorded corners (bilinear)
      final u = ((e + halfW) / (2 * halfW)).clamp(-0.5, 1.5).toDouble();
      final v = ((n + halfH) / (2 * halfH)).clamp(-0.5, 1.5).toDouble();
      double mix(int k) =>
          cr[0][k] * (1 - u) * (1 - v) +
          cr[1][k] * u * (1 - v) +
          cr[2][k] * u * v +
          cr[3][k] * (1 - u) * v;
      return GeoPt(mix(0), mix(1));
    }
    final h = headingDeg * math.pi / 180.0;
    final east = e * math.cos(h) + n * math.sin(h);
    final north = -e * math.sin(h) + n * math.cos(h);
    final mLon = _mLat * math.cos(geo.latitude * math.pi / 180.0).abs().clamp(0.01, 1.0);
    return GeoPt(geo.latitude + north / _mLat, geo.longitude + east / mLon);
  }

  double get halfW => cols * cellM / 2;
  double get halfH => rows * cellM / 2;
  GeoPt get topLeft => at(-halfW, halfH);
  GeoPt get topRight => at(halfW, halfH);
  GeoPt get bottomRight => at(halfW, -halfH);
  GeoPt get bottomLeft => at(-halfW, -halfH);
}

/// Builds the .kmz file (Google Earth): the colour picture draped on the real
/// ground, rotated to the scan heading, plus pins on the strongest anomalies.
class GeoOverlayExport {
  static String _esc(String v) =>
      v.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static Future<String> writeKmz(ScanSession s, GeoFrame f,
      {double sensitivity = 3.0, int alpha = 215}) async {
    final png = await Imaging.overlayPng(s.cells, s.cols, s.rows, alpha: alpha);
    String c(GeoPt p) =>
        '${p.lon.toStringAsFixed(8)},${p.lat.toStringAsFixed(8)},0';
    final b = StringBuffer();
    b.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    b.writeln(
        '<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2"><Document>');
    b.writeln('<name>${_esc(s.name)}</name>');
    b.writeln(
        '<description>MagVision Pro scan ${s.cols}x${s.rows}, cell ${(f.cellM * 100).toStringAsFixed(0)} cm, heading ${f.headingDeg.toStringAsFixed(0)} deg from north, GPS = grid centre (accuracy ±${f.geo.accuracy.toStringAsFixed(0)} m).</description>');
    b.writeln('<GroundOverlay><name>Scan</name><drawOrder>1</drawOrder>');
    b.writeln('<Icon><href>files/overlay.png</href></Icon>');
    // corners counter-clockwise from the lower-left
    b.writeln(
        '<gx:LatLonQuad><coordinates>${c(f.bottomLeft)} ${c(f.bottomRight)} ${c(f.topRight)} ${c(f.topLeft)}</coordinates></gx:LatLonQuad>');
    b.writeln('</GroundOverlay>');
    final an = findCellAnomalies(s.cells, s.cols, s.rows, sensitivity + 1.0);
    int k = 1;
    for (final a in an.take(20)) {
      final e = (a.x + 0.5) * f.cellM - f.halfW;
      final n = f.halfH - (a.y + 0.5) * f.cellM;
      b.writeln(
          '<Placemark><name>#${k++} ${a.deviation >= 0 ? 'metal' : 'void'}</name><Point><coordinates>${c(f.at(e, n))}</coordinates></Point></Placemark>');
    }
    b.writeln(
        '<Placemark><name>Grid centre</name><Point><coordinates>${c(f.at(0, 0))}</coordinates></Point></Placemark>');
    b.writeln('</Document></kml>');
    final kml = Uint8List.fromList(utf8.encode(b.toString()));
    final arch = Archive()
      ..addFile(ArchiveFile('doc.kml', kml.length, kml))
      ..addFile(ArchiveFile('files/overlay.png', png.length, png));
    final zip = ZipEncoder().encode(arch);
    if (zip == null) throw StateError('zip');
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final path = '${base.path}/${clean}_${s.id}.kmz';
    await File(path).writeAsBytes(zip);
    return path;
  }

}
