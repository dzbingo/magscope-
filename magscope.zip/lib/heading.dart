import 'dart:async';
import 'dart:math' as math;

import 'package:sensors_plus/sensors_plus.dart';

/// Reads the phone compass for a moment and returns the MAGNETIC heading
/// (degrees clockwise from north, tilt-compensated). Returns null when the
/// phone has no magnetometer.
class HeadingService {
  static Future<double?> sample({
    Duration duration = const Duration(milliseconds: 1600),
  }) async {
    List<double>? acc;
    double sx = 0;
    double sy = 0;
    int n = 0;
    StreamSubscription<AccelerometerEvent>? as;
    StreamSubscription<MagnetometerEvent>? ms;
    try {
      as = accelerometerEventStream(
        samplingPeriod: const Duration(milliseconds: 40),
      ).listen((AccelerometerEvent a) => acc = <double>[a.x, a.y, a.z],
          onError: (Object _) {});
      ms = magnetometerEventStream(
        samplingPeriod: const Duration(milliseconds: 40),
      ).listen((MagnetometerEvent e) {
        double az;
        final a = acc;
        final g = a == null
            ? 0.0
            : math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (a != null && g > 1.0) {
          var hx = e.y * a[2] - e.z * a[1];
          var hy = e.z * a[0] - e.x * a[2];
          var hz = e.x * a[1] - e.y * a[0];
          final nh = math.sqrt(hx * hx + hy * hy + hz * hz);
          if (nh < 1e-6) return;
          hx /= nh;
          hy /= nh;
          hz /= nh;
          final ax = a[0] / g;
          final az2 = a[2] / g;
          final my = az2 * hx - ax * hz;
          az = math.atan2(hy, my);
        } else {
          az = math.atan2(-e.x, e.y);
        }
        sx += math.cos(az);
        sy += math.sin(az);
        n++;
      }, onError: (Object _) {});
      await Future<void>.delayed(duration);
    } catch (_) {
      // no sensor
    } finally {
      await as?.cancel();
      await ms?.cancel();
    }
    if (n == 0) return null;
    final deg = math.atan2(sy, sx) * 180 / math.pi;
    return ((deg % 360) + 360) % 360;
  }

  /// Live smoothed magnetic heading (degrees), about 10 updates per second.
  static Stream<double> stream() async* {
    final ctl = StreamController<double>();
    List<double>? acc;
    double sx = 0, sy = 0;
    bool first = true;
    DateTime last = DateTime.fromMillisecondsSinceEpoch(0);
    final as = accelerometerEventStream(
      samplingPeriod: const Duration(milliseconds: 60),
    ).listen((AccelerometerEvent a) => acc = <double>[a.x, a.y, a.z],
        onError: (Object _) {});
    final ms = magnetometerEventStream(
      samplingPeriod: const Duration(milliseconds: 60),
    ).listen((MagnetometerEvent e) {
      double az;
      final a = acc;
      final g = a == null ? 0.0 : math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
      if (a != null && g > 1.0) {
        var hx = e.y * a[2] - e.z * a[1];
        var hy = e.z * a[0] - e.x * a[2];
        var hz = e.x * a[1] - e.y * a[0];
        final nh = math.sqrt(hx * hx + hy * hy + hz * hz);
        if (nh < 1e-6) return;
        hx /= nh;
        hy /= nh;
        hz /= nh;
        final my = (a[2] / g) * hx - (a[0] / g) * hz;
        az = math.atan2(hy, my);
      } else {
        az = math.atan2(-e.x, e.y);
      }
      if (first) {
        sx = math.cos(az);
        sy = math.sin(az);
        first = false;
      } else {
        sx = sx * 0.85 + math.cos(az) * 0.15;
        sy = sy * 0.85 + math.sin(az) * 0.15;
      }
      final now = DateTime.now();
      if (now.difference(last).inMilliseconds < 100) return;
      last = now;
      final deg = math.atan2(sy, sx) * 180 / math.pi;
      ctl.add(((deg % 360) + 360) % 360);
    }, onError: (Object _) {});
    ctl.onCancel = () async {
      await as.cancel();
      await ms.cancel();
    };
    yield* ctl.stream;
  }
}
