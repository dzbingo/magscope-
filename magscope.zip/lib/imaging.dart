import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/painting.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'widgets.dart' show heatColor;

/// Renders the scanned grid as a picture (PNG / JPG) and as a transparent
/// overlay for maps. Values are shown with the active colour palette.
class Imaging {
  static (double, double) range(List<double> cells) {
    final valid = cells.where((e) => !e.isNaN).toList();
    if (valid.isEmpty) return (0.0, 1.0);
    double lo = valid.reduce(math.min);
    double hi = valid.reduce(math.max);
    if (hi - lo < 1e-6) hi = lo + 1.0;
    return (lo, hi);
  }

  /// Smooth (bilinear) colour pixels, RGBA. Empty cells stay transparent.
  static Uint8List _rgba(List<double> cells, int cols, int rows, double lo,
      double hi, int scale, int alpha) {
    final w = cols * scale;
    final h = rows * scale;
    final out = Uint8List(w * h * 4);
    final span = (hi - lo) <= 0 ? 1.0 : (hi - lo);
    for (int py = 0; py < h; py++) {
      final cy = (py + 0.5) / scale - 0.5;
      final y0 = cy.floor();
      final ty = cy - y0;
      final cellY = py ~/ scale;
      for (int px = 0; px < w; px++) {
        final cellX = px ~/ scale;
        if (cells[cellY * cols + cellX].isNaN) continue;
        final cx = (px + 0.5) / scale - 0.5;
        final x0 = cx.floor();
        final tx = cx - x0;
        double sum = 0;
        double ws = 0;
        for (int dy = 0; dy <= 1; dy++) {
          for (int dx = 0; dx <= 1; dx++) {
            final gx = x0 + dx;
            final gy = y0 + dy;
            if (gx < 0 || gy < 0 || gx >= cols || gy >= rows) continue;
            final v = cells[gy * cols + gx];
            if (v.isNaN) continue;
            final wt = (dx == 0 ? 1 - tx : tx) * (dy == 0 ? 1 - ty : ty);
            sum += v * wt;
            ws += wt;
          }
        }
        if (ws <= 0) continue;
        final c = heatColor((sum / ws - lo) / span).value;
        final i = (py * w + px) * 4;
        out[i] = (c >> 16) & 0xFF;
        out[i + 1] = (c >> 8) & 0xFF;
        out[i + 2] = c & 0xFF;
        out[i + 3] = alpha;
      }
    }
    return out;
  }

  static Future<ui.Image> _toImage(Uint8List rgba, int w, int h) {
    final c = Completer<ui.Image>();
    ui.decodeImageFromPixels(rgba, w, h, ui.PixelFormat.rgba8888, c.complete);
    return c.future;
  }

  /// Transparent PNG of just the coloured cells (for Google Earth / maps).
  static Future<Uint8List> overlayPng(List<double> cells, int cols, int rows,
      {int alpha = 215}) async {
    final (lo, hi) = range(cells);
    final scale = math.max(4, math.min(24, 1400 ~/ math.max(cols, rows)));
    final rgba = _rgba(cells, cols, rows, lo, hi, scale, alpha);
    final image = await _toImage(rgba, cols * scale, rows * scale);
    final bd = await image.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  /// Finished picture: title, the map and a colour bar with min / max.
  static Future<ui.Image> _poster(
      List<double> cells, int cols, int rows, String title) async {
    final (lo, hi) = range(cells);
    final scale = math.max(8, math.min(40, 1400 ~/ math.max(cols, rows)));
    final mapW = cols * scale;
    final mapH = rows * scale;
    final heat = await _toImage(
        _rgba(cells, cols, rows, lo, hi, scale, 255), mapW, mapH);
    const pad = 40.0;
    const top = 90.0;
    const bottom = 150.0;
    final w = mapW + pad * 2;
    final h = mapH + top + bottom;
    final rec = ui.PictureRecorder();
    final canvas = ui.Canvas(rec);
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, w, h),
        ui.Paint()..color = const ui.Color(0xFF0B0B0B));
    canvas.drawRect(ui.Rect.fromLTWH(pad, top, mapW.toDouble(), mapH.toDouble()),
        ui.Paint()..color = const ui.Color(0xFF222222));
    canvas.drawImage(heat, const ui.Offset(pad, top), ui.Paint());
    if (scale >= 20) {
      final gp = ui.Paint()
        ..color = const ui.Color(0x33000000)
        ..strokeWidth = 1;
      for (int x = 1; x < cols; x++) {
        canvas.drawLine(ui.Offset(pad + x * scale, top),
            ui.Offset(pad + x * scale, top + mapH), gp);
      }
      for (int y = 1; y < rows; y++) {
        canvas.drawLine(ui.Offset(pad, top + y * scale),
            ui.Offset(pad + mapW, top + y * scale), gp);
      }
    }
    void text(String t, double x, double y, double size,
        {double? maxW, ui.TextAlign align = ui.TextAlign.left}) {
      final tp = TextPainter(
        text: TextSpan(
            text: t,
            style: TextStyle(
                color: const ui.Color(0xFFF2E6C8),
                fontSize: size,
                fontWeight: ui.FontWeight.w700)),
        textDirection: ui.TextDirection.ltr,
        textAlign: align,
      )..layout(maxWidth: maxW ?? w);
      tp.paint(canvas, ui.Offset(x, y));
    }

    text(title, pad, 28, 34, maxW: w - pad * 2);
    final barTop = top + mapH + 34;
    final stops = <ui.Color>[
      for (int i = 0; i <= 10; i++) heatColor(i / 10),
    ];
    final rect = ui.Rect.fromLTWH(pad, barTop, mapW.toDouble(), 34);
    canvas.drawRect(
        rect,
        ui.Paint()
          ..shader = ui.Gradient.linear(
              rect.centerLeft, rect.centerRight, stops));
    text(lo.toStringAsFixed(2), pad, barTop + 44, 28);
    final hiT = hi.toStringAsFixed(2);
    text(hiT, w - pad - 14.0 * hiT.length, barTop + 44, 28);
    return rec.endRecording().toImage(w.round(), h.round());
  }

  static Future<Uint8List> posterPng(
      List<double> cells, int cols, int rows, String title) async {
    final im = await _poster(cells, cols, rows, title);
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    return bd!.buffer.asUint8List();
  }

  static Future<Uint8List> posterJpg(
      List<double> cells, int cols, int rows, String title) async {
    final im = await _poster(cells, cols, rows, title);
    final bd = await im.toByteData(format: ui.ImageByteFormat.rawRgba);
    final raw = bd!.buffer.asUint8List();
    final pic = img.Image.fromBytes(
        width: im.width, height: im.height, bytes: raw.buffer, numChannels: 4);
    return Uint8List.fromList(img.encodeJpg(pic, quality: 92));
  }

  static Future<Directory> _dir() async {
    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    return ext ?? await getApplicationDocumentsDirectory();
  }

  /// Saves the picture and returns the file path.
  static Future<String> saveImage(ScanSession s, {required bool jpg}) async {
    final bytes = jpg
        ? await posterJpg(s.cells, s.cols, s.rows, s.name)
        : await posterPng(s.cells, s.cols, s.rows, s.name);
    final clean = s.name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final path = '${(await _dir()).path}/${clean}_${s.id}.${jpg ? 'jpg' : 'png'}';
    await File(path).writeAsBytes(bytes);
    return path;
  }
}
