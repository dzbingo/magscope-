import 'dart:math' as math;

import 'dsp.dart';

/// Quality check of a scan: coverage, noise, drift, spikes, stripes.
class ScanQuality {
  ScanQuality(this.score, this.issues);

  /// 0..100
  final int score;

  /// Keys of translated messages describing what is wrong.
  final List<String> issues;

  static ScanQuality of({
    required List<double> cells,
    required int cols,
    required int rows,
    required List<double> raw,
    double? calSigma,
  }) {
    final issues = <String>[];
    double score = 100;
    final valid = cells.where((double e) => !e.isNaN).toList();
    if (valid.length < 6) return ScanQuality(0, <String>['q_nodata']);
    // coverage
    final cov = valid.length / cells.length;
    if (cov < 0.98) {
      score -= (1 - cov) * 60;
      issues.add('q_gaps');
    }
    final med = medianOf(valid);
    final mad = medianOf(valid.map((double e) => (e - med).abs()).toList()) * 1.4826;
    final sorted = List<double>.from(valid)..sort();
    final span = sorted[(sorted.length * 0.95).floor().clamp(0, sorted.length - 1).toInt()] -
        sorted[(sorted.length * 0.05).floor()];
    // signal to noise: the picture should stand out of the noise
    final noise = math.max(calSigma ?? 0, 0.05);
    final snr = span / noise;
    if (snr < 4) {
      score -= 18;
      issues.add('q_lowsnr');
    }
    // spikes in the raw stream
    if (raw.length > 50) {
      final r = raw.length > 6000 ? raw.sublist(raw.length - 6000) : raw;
      final rm = medianOf(r);
      final rmad = math.max(medianOf(r.map((double e) => (e - rm).abs()).toList()) * 1.4826, 0.05);
      final spikes = r.where((double e) => (e - rm).abs() > 8 * rmad).length / r.length;
      if (spikes > 0.03) {
        score -= math.min(20, spikes * 300);
        issues.add('q_spikes');
      }
      // drift: first vs last tenth of the walk
      final k = math.max(10, raw.length ~/ 10);
      final a = medianOf(raw.sublist(0, k));
      final b = medianOf(raw.sublist(raw.length - k));
      final drift = (b - a).abs();
      final ref = math.max(span, mad * 4);
      if (ref > 0 && drift > 0.5 * ref && drift > 3 * noise) {
        score -= 18;
        issues.add('q_drift');
      }
    }
    // stripes: neighbouring walking passes differ by a constant offset
    if (cols >= 4 && rows >= 4) {
      final cm = <double>[];
      for (int x = 0; x < cols; x++) {
        final col = <double>[];
        for (int y = 0; y < rows; y++) {
          final v = cells[y * cols + x];
          if (!v.isNaN) col.add(v);
        }
        cm.add(col.isEmpty ? double.nan : medianOf(col));
      }
      double acc = 0;
      int n = 0;
      for (int x = 1; x < cols; x++) {
        if (cm[x].isNaN || cm[x - 1].isNaN) continue;
        acc += (cm[x] - cm[x - 1]).abs();
        n++;
      }
      if (n > 0 && span > 0 && acc / n > 0.25 * span) {
        score -= 12;
        issues.add('q_stripes');
      }
    }
    return ScanQuality(score.round().clamp(0, 100).toInt(), issues);
  }
}
