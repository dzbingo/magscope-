import 'dart:math' as math;

import 'dsp.dart';

/// Quality check of a scan: coverage, noise, drift, spikes, stripes.
class ScanQuality {
  ScanQuality(this.score, this.issues, {this.noise = 0, this.snr = 0});

  /// Noise level used (same unit as the readings) and signal/noise ratio.
  final double noise;
  final double snr;

  /// Noise of the grid itself: each cell against the mean of its neighbours
  /// (robust). Real smooth anomalies cancel out, random jitter does not.
  static double localNoise(List<double> cells, int cols, int rows) {
    final d = <double>[];
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        final v = cells[y * cols + x];
        if (v.isNaN) continue;
        double sum = 0;
        int n = 0;
        for (final o in const <List<int>>[
          <int>[1, 0],
          <int>[-1, 0],
          <int>[0, 1],
          <int>[0, -1]
        ]) {
          final nx = x + o[0], ny = y + o[1];
          if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
          final w = cells[ny * cols + nx];
          if (w.isNaN) continue;
          sum += w;
          n++;
        }
        if (n >= 2) d.add(v - sum / n);
      }
    }
    if (d.length < 4) return 0;
    final m = medianOf(d);
    // white noise: var(diff) = sigma^2 (1 + 1/n), n ~ 3-4
    return medianOf(d.map((double e) => (e - m).abs()).toList()) * 1.4826 / 1.15;
  }

  /// 0..100
  final int score;

  /// Keys of translated messages describing what is wrong.
  final List<String> issues;

  static ScanQuality of({
    required List<double> cells,
    required int cols,
    required int rows,
    required List<double> raw,
    double? calSigma,
  }) {
    final issues = <String>[];
    double score = 100;
    final valid = cells.where((double e) => !e.isNaN).toList();
    if (valid.length < 6) return ScanQuality(0, <String>['q_nodata']);
    // coverage
    final cov = valid.length / cells.length;
    if (cov < 0.98) {
      score -= (1 - cov) * 60;
      issues.add('q_gaps');
    }
    // identical readings everywhere (e.g. all zeros): the device sent no real
    // measurement, so the scan cannot be good whatever the other tests say
    if (valid.length >= 6) {
      final mn = valid.reduce(math.min);
      final mx = valid.reduce(math.max);
      if (mx - mn < 1e-9) {
        return ScanQuality(0, <String>['q_flat'], noise: 0, snr: 0);
      }
    }
    final med = medianOf(valid);
    final mad = medianOf(valid.map((double e) => (e - med).abs()).toList()) * 1.4826;
    final sorted = List<double>.from(valid)..sort();
    final span = sorted[(sorted.length * 0.95).floor().clamp(0, sorted.length - 1).toInt()] -
        sorted[(sorted.length * 0.05).floor()];
    // signal to noise: the picture should stand out of the noise
    // without a calibration the noise is taken from the grid itself, so the
    // meter can no longer say 100% for a scan that is only noise
    final noise = math.max(calSigma ?? localNoise(cells, cols, rows), 0.05);
    final snr = span / noise;
    if (cells.length < 16) {
      score -= 30;
      issues.add('q_small');
    }
    if (snr < 4) {
      // a picture that does not stand out of its own noise is weak evidence
      score -= snr < 1.5 ? 55 : 18;
      issues.add('q_lowsnr');
    }
    // spikes in the raw stream
    if (raw.length > 50) {
      final r = raw.length > 6000 ? raw.sublist(raw.length - 6000) : raw;
      final rm = medianOf(r);
      final rmad = math.max(medianOf(r.map((double e) => (e - rm).abs()).toList()) * 1.4826, 0.05);
      final spikes = r.where((double e) => (e - rm).abs() > 8 * rmad).length / r.length;
      if (spikes > 0.03) {
        score -= math.min(20, spikes * 300);
        issues.add('q_spikes');
      }
      // drift: first vs last tenth of the walk
      final k = math.max(10, raw.length ~/ 10);
      final a = medianOf(raw.sublist(0, k));
      final b = medianOf(raw.sublist(raw.length - k));
      final drift = (b - a).abs();
      final ref = math.max(span, mad * 4);
      if (ref > 0 && drift > 0.5 * ref && drift > 3 * noise) {
        score -= 18;
        issues.add('q_drift');
      }
    }
    // stripes: neighbouring walking passes differ by a constant offset
    if (cols >= 4 && rows >= 4) {
      final cm = <double>[];
      for (int x = 0; x < cols; x++) {
        final col = <double>[];
        for (int y = 0; y < rows; y++) {
          final v = cells[y * cols + x];
          if (!v.isNaN) col.add(v);
        }
        cm.add(col.isEmpty ? double.nan : medianOf(col));
      }
      double acc = 0;
      int n = 0;
      for (int x = 1; x < cols; x++) {
        if (cm[x].isNaN || cm[x - 1].isNaN) continue;
        acc += (cm[x] - cm[x - 1]).abs();
        n++;
      }
      if (n > 0 && span > 0 && acc / n > 0.25 * span) {
        score -= 12;
        issues.add('q_stripes');
      }
    }
    return ScanQuality(score.round().clamp(0, 100).toInt(), issues,
        noise: noise, snr: snr);
  }
}
