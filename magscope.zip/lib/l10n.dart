/// Minimal built-in translations. Order of each list: [Arabic, English, French].
const Map<String, List<String>> kStrings = <String, List<String>>{
  'app_name': ['ماغ سكوب', 'MagScope', 'MagScope'],
  'tab_live': ['مباشر', 'Live', 'Direct'],
  'tab_map': ['الخريطة', 'Map', 'Carte'],
  'tab_analysis': ['التحليل', 'Analysis', 'Analyse'],
  'tab_files': ['الملفات', 'Files', 'Fichiers'],
  'tab_settings': ['الإعدادات', 'Settings', 'Réglages'],
  'start': ['ابدأ المسح', 'Start scan', 'Démarrer'],
  'stop': ['إيقاف', 'Stop', 'Arrêter'],
  'next_cell': ['الخلية التالية', 'Next cell', 'Cellule suivante'],
  'clear': ['مسح البيانات', 'Clear', 'Effacer'],
  'save': ['حفظ', 'Save', 'Enregistrer'],
  'cancel': ['إلغاء', 'Cancel', 'Annuler'],
  'raw': ['خام', 'Raw', 'Brut'],
  'filtered': ['بعد الفلترة', 'Filtered', 'Filtré'],
  'reading': ['القراءة الحالية', 'Current reading', 'Lecture actuelle'],
  'cell': ['الخلية', 'Cell', 'Cellule'],
  'idle': ['متوقف', 'Idle', 'Inactif'],
  'connecting': ['جارٍ الاتصال', 'Connecting', 'Connexion'],
  'connected': ['متصل', 'Connected', 'Connecté'],
  'error': ['خطأ', 'Error', 'Erreur'],
  'no_device': [
    'اختر جهازًا من الإعدادات أولًا',
    'Pick a device in Settings first',
    "Choisissez d'abord un appareil dans Réglages"
  ],
  'perm': [
    'يلزم منح أذونات البلوتوث',
    'Bluetooth permissions are required',
    'Les autorisations Bluetooth sont requises'
  ],
  'disconnected': [
    'انقطع الاتصال بالجهاز',
    'Device disconnected',
    "L'appareil est déconnecté"
  ],
  'conn_failed': [
    'تعذّر الاتصال. تأكد من تشغيل البلوتوث والجهاز',
    'Connection failed. Check that Bluetooth and the device are on',
    'Échec de connexion. Vérifiez le Bluetooth et l\'appareil'
  ],
  'no_char': [
    'لم أجد خاصية بيانات مناسبة في الجهاز. راجع معرّفات UUID في الإعدادات',
    'No suitable data characteristic found. Check the UUIDs in Settings',
    'Aucune caractéristique de données trouvée. Vérifiez les UUID dans Réglages'
  ],
  'view_2d': ['خريطة حرارية', 'Heatmap', 'Carte thermique'],
  'view_3d': ['ثلاثي الأبعاد', '3D', '3D'],
  'rotation': ['الدوران', 'Rotation', 'Rotation'],
  'height': ['الارتفاع', 'Height', 'Hauteur'],
  'filters': ['الفلاتر', 'Filters', 'Filtres'],
  'despike': ['إزالة القفزات', 'Spike removal', 'Anti-pics'],
  'median': ['فلتر وسيط', 'Median filter', 'Filtre médian'],
  'baseline': [
    'إزالة الانحراف البطيء',
    'Baseline (drift) removal',
    'Suppression de la dérive'
  ],
  'average': ['متوسط متحرك', 'Moving average', 'Moyenne mobile'],
  'ema': ['تنعيم أُسّي', 'Exponential smoothing', 'Lissage exponentiel'],
  'grid_smooth': ['تنعيم الخريطة', 'Map smoothing', 'Lissage de la carte'],
  'window': ['النافذة', 'Window', 'Fenêtre'],
  'strength': ['القوة', 'Strength', 'Force'],
  'passes': ['عدد المرات', 'Passes', 'Passes'],
  'sensitivity': ['حساسية الكشف', 'Detection sensitivity', 'Sensibilité'],
  'sensitivity_hint': [
    'رقم أقل = كشف أكثر (وإنذارات كاذبة أكثر)',
    'Lower = detects more (and more false alarms)',
    'Plus bas = plus de détections (et de fausses alertes)'
  ],
  'stats': ['إحصاءات', 'Statistics', 'Statistiques'],
  'min': ['الأدنى', 'Min', 'Min'],
  'max': ['الأعلى', 'Max', 'Max'],
  'mean': ['المتوسط', 'Mean', 'Moyenne'],
  'std': ['الانحراف', 'Std dev', 'Écart-type'],
  'span': ['المدى', 'Span', 'Étendue'],
  'anomalies': [
    'الشذوذات المكتشفة',
    'Detected anomalies',
    'Anomalies détectées'
  ],
  'none_found': ['لا شيء ظاهر', 'Nothing detected', 'Rien de détecté'],
  'samples': ['عدد القراءات', 'Samples', 'Mesures'],
  'sample_no': ['القراءة', 'Sample', 'Mesure'],
  'no_data': [
    'لا توجد بيانات بعد. ابدأ مسحًا من تبويب مباشر.',
    'No data yet. Start a scan from the Live tab.',
    "Aucune donnée. Lancez un scan depuis l'onglet Direct."
  ],
  'files_empty': [
    'لا توجد جلسات محفوظة',
    'No saved sessions',
    'Aucune session enregistrée'
  ],
  'session_name': ['اسم الجلسة', 'Session name', 'Nom de la session'],
  'saved': ['تم الحفظ', 'Saved', 'Enregistré'],
  'loaded': ['تم فتح الجلسة', 'Session opened', 'Session ouverte'],
  'open': ['فتح', 'Open', 'Ouvrir'],
  'export_csv': ['تصدير CSV', 'Export CSV', 'Exporter CSV'],
  'exported_to': ['تم التصدير إلى', 'Exported to', 'Exporté vers'],
  'delete': ['حذف', 'Delete', 'Supprimer'],
  'language': ['اللغة', 'Language', 'Langue'],
  'source': ['مصدر البيانات', 'Data source', 'Source de données'],
  'simulator': ['محاكاة', 'Simulator', 'Simulateur'],
  'ble': ['بلوتوث BLE', 'Bluetooth LE', 'Bluetooth LE'],
  'device': ['الجهاز', 'Device', 'Appareil'],
  'scan_devices': ['ابحث عن أجهزة', 'Search devices', 'Chercher des appareils'],
  'searching': ['جارٍ البحث…', 'Searching…', 'Recherche…'],
  'no_selected': ['لم يُختر جهاز', 'No device selected', 'Aucun appareil'],
  'unnamed': ['بدون اسم', 'Unnamed', 'Sans nom'],
  'service_uuid': [
    'معرّف الخدمة UUID (اختياري)',
    'Service UUID (optional)',
    'UUID du service (optionnel)'
  ],
  'char_uuid': [
    'معرّف الخاصية UUID (اختياري)',
    'Characteristic UUID (optional)',
    'UUID de la caractéristique (optionnel)'
  ],
  'uuid_hint': [
    'اتركهما فارغين ليختار التطبيق أول خاصية ترسل إشعارات',
    'Leave empty to use the first notifying characteristic',
    'Laissez vide pour utiliser la première caractéristique notifiante'
  ],
  'packet_format': ['صيغة الحزمة', 'Packet format', 'Format du paquet'],
  'fmt_ascii': ['نص', 'Text', 'Texte'],
  'fmt_int16': ['int16', 'int16', 'int16'],
  'fmt_float': ['float32', 'float32', 'float32'],
  'scale': ['معامل الضرب', 'Scale factor', "Facteur d'échelle"],
  'axes': ['عدد المحاور', 'Axes', 'Axes'],
  'axes_hint': [
    '3 = حساب المقدار من X و Y و Z',
    '3 = magnitude from X, Y, Z',
    '3 = module de X, Y, Z'
  ],
  'grid_size': ['حجم الشبكة', 'Grid size', 'Taille de la grille'],
  'columns': ['الأعمدة', 'Columns', 'Colonnes'],
  'rows': ['الصفوف', 'Rows', 'Lignes'],
  'per_cell': [
    'قراءات لكل خلية',
    'Samples per cell',
    'Mesures par cellule'
  ],
  'about': ['حول التطبيق', 'About', 'À propos'],
  'about_text': [
    'تطبيق مستقل لقياس المجال المغناطيسي وعرضه. النتائج تقديرية وقد تتأثر بالمعادن القريبة والتداخلات، ولا تضمن وجود أو غياب أي شيء تحت الأرض.',
    'An independent app for measuring and visualising magnetic fields. Results are estimates affected by nearby metal and interference, and do not guarantee anything is or is not underground.',
    "Application indépendante de mesure et de visualisation du champ magnétique. Les résultats sont des estimations influencées par les métaux proches et les interférences."
  ],
  'unit': ['µT', 'µT', 'µT'],
  'alerts': ['تنبيه بالاهتزاز', 'Vibration alert', 'Alerte par vibration'],
  'alerts_hint': [
    'يهتز الهاتف عند تجاوز القراءة حدّ الحساسية',
    'Vibrates when the reading passes the sensitivity limit',
    'Vibre quand la lecture dépasse la sensibilité'
  ],
  'detection': ['الكشف', 'Detection', 'Détection'],
  'calibrate': ['معايرة', 'Calibrate', 'Calibrer'],
  'calibrated': ['تمت المعايرة على المستوى الحالي', 'Calibrated to the current level', 'Calibré sur le niveau actuel'],
  'reset_ref': ['إلغاء المعايرة', 'Reset', 'Réinitialiser'],
  'reference': ['المرجع', 'Reference', 'Référence'],
  'deviation': ['الانحراف', 'Deviation', 'Écart'],
  'noise': ['الضجيج', 'Noise', 'Bruit'],
  'alarm_on': ['شذوذ!', 'Anomaly!', 'Anomalie !'],
  'tap_cell': [
    'المس خلية لعرض قيمتها',
    'Tap a cell to inspect it',
    'Touchez une cellule pour la voir'
  ],
  'drag_hint': [
    'اسحب بإصبعك لتدوير العرض وإمالته',
    'Drag to rotate and tilt',
    'Glissez pour tourner et incliner'
  ],
  'vs_median': ['عن الوسيط', 'vs median', 'vs médiane'],
  'scanned': ['تم مسحها', 'scanned', 'scannées'],
  'rate': ['المعدل', 'Rate', 'Cadence'],
  'color_range': ['مدى الألوان', 'Colour range', 'Plage de couleurs'],
  'palette': ['لوحة الألوان', 'Colour palette', 'Palette'],
  'pal_0': ['حراري', 'Thermal', 'Thermique'],
  'pal_1': ['قوس قزح', 'Rainbow', 'Arc-en-ciel'],
  'pal_2': ['تباين عالٍ', 'High contrast', 'Contraste élevé'],
  'pal_3': ['طيف الحديد', 'Iron', 'Fer'],
  'home_live': ['الكشف المباشر', 'Live detection', 'Détection directe'],
  'home_map': ['الخريطة الحرارية', 'Heat map', 'Carte thermique'],
  'home_analysis': ['التحليل والفلترة', 'Analysis & filters', 'Analyse et filtres'],
  'home_files': ['الملفات المحفوظة', 'Saved scans', 'Scans enregistrés'],
  'home_settings': ['الإعدادات', 'Settings', 'Réglages'],
  'home_compass': ['البوصلة', 'Compass', 'Boussole'],
  'tab_home': ['الرئيسية', 'Home', 'Accueil'],
  'status_sim': ['وضع المحاكاة', 'Simulator mode', 'Mode simulation'],
  'status_ble': ['جهاز البلوتوث', 'Bluetooth device', 'Appareil Bluetooth'],
  'last_scan': ['آخر مسح', 'Last scan', 'Dernier scan'],
  'no_sensor': ['لا يوجد حساس مغناطيسي في هذا الهاتف', 'No magnetometer on this phone', 'Pas de magnétomètre sur ce téléphone'],
  'field_strength': ['شدة المجال', 'Field strength', 'Intensité du champ'],
  'compass_hint': ['ضع الهاتف أفقيًا وابعده عن المعادن. القراءة تقريبية.', 'Hold the phone flat, away from metal. Reading is approximate.', 'Tenez le téléphone à plat, loin du métal. Lecture approximative.'],
  'heading': ['الاتجاه', 'Heading', 'Cap'],
  'dir_n': ['ش', 'N', 'N'],
  'dir_e': ['شرق', 'E', 'E'],
  'dir_s': ['ج', 'S', 'S'],
  'dir_w': ['غرب', 'W', 'O'],
};
