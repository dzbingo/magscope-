import 'dart:math' as math;

/// Potential-field tools: upward continuation, reduction to the pole, a point
/// dipole fit with an uncertainty interval, and Euler deconvolution.
///
/// The maths was checked with a numpy prototype on synthetic dipole data
/// (reduction to pole about 3-4 % error, upward continuation 0.2 %, dipole fit
/// within one 5 cm depth step at a signal-to-noise ratio above 8). None of it
/// has been checked on real field data. All of it assumes ONE compact body
/// magnetised along the Earth's field, and the fit reports only the part of the
/// uncertainty that comes from noise, not from a wrong model.
class _C {
  const _C(this.re, this.im);
  final double re, im;
}

int _pow2(int n) {
  var p = 16;
  while (p < n) {
    p <<= 1;
  }
  return p;
}

void _fft(List<double> re, List<double> im, bool inverse) {
  final n = re.length;
  for (int i = 1, j = 0; i < n; i++) {
    int bit = n >> 1;
    for (; (j & bit) != 0; bit >>= 1) {
      j ^= bit;
    }
    j ^= bit;
    if (i < j) {
      final tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      final ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }
  for (int len = 2; len <= n; len <<= 1) {
    final ang = 2 * math.pi / len * (inverse ? 1 : -1);
    final wr = math.cos(ang), wi = math.sin(ang);
    final half = len >> 1;
    for (int i = 0; i < n; i += len) {
      double cr = 1, ci = 0;
      for (int k = 0; k < half; k++) {
        final a = i + k, b = i + k + half;
        final xr = re[b] * cr - im[b] * ci;
        final xi = re[b] * ci + im[b] * cr;
        re[b] = re[a] - xr;
        im[b] = im[a] - xi;
        re[a] += xr;
        im[a] += xi;
        final ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
  if (inverse) {
    for (int i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

/// A padded, tapered copy of a grid in the Fourier domain.
class _Spec {
  _Spec(this.pw, this.ph, this.ox, this.oy, this.re, this.im);
  final int pw, ph, ox, oy;
  final List<double> re, im;
}

_Spec _forward(List<double> g, int cols, int rows) {
  final valid = g.where((double e) => !e.isNaN).toList();
  double mean = 0;
  for (final v in valid) {
    mean += v;
  }
  mean = valid.isEmpty ? 0 : mean / valid.length;
  final pw = _pow2((cols * 1.5).ceil());
  final ph = _pow2((rows * 1.5).ceil());
  final ox = (pw - cols) ~/ 2, oy = (ph - rows) ~/ 2;
  final padX = math.min(ox, pw - cols - ox).toDouble();
  final padY = math.min(oy, ph - rows - oy).toDouble();
  final re = List<double>.filled(pw * ph, 0.0);
  final im = List<double>.filled(pw * ph, 0.0);
  for (int y = 0; y < ph; y++) {
    final gy = (y - oy).clamp(0, rows - 1).toInt();
    final dy = math.max(0, math.max(oy - y, y - (oy + rows - 1))).toDouble();
    for (int x = 0; x < pw; x++) {
      final gx = (x - ox).clamp(0, cols - 1).toInt();
      final dx = math.max(0, math.max(ox - x, x - (ox + cols - 1))).toDouble();
      var v = g[gy * cols + gx];
      if (v.isNaN) v = mean;
      double w = 1.0;
      if (dx > 0 && padX > 0) {
        w *= 0.5 * (1 + math.cos(math.pi * math.min(dx, padX) / padX));
      }
      if (dy > 0 && padY > 0) {
        w *= 0.5 * (1 + math.cos(math.pi * math.min(dy, padY) / padY));
      }
      re[y * pw + x] = mean + (v - mean) * w;
    }
  }
  // rows, then columns
  final rr = List<double>.filled(pw, 0.0), ri = List<double>.filled(pw, 0.0);
  for (int y = 0; y < ph; y++) {
    for (int x = 0; x < pw; x++) {
      rr[x] = re[y * pw + x];
      ri[x] = im[y * pw + x];
    }
    _fft(rr, ri, false);
    for (int x = 0; x < pw; x++) {
      re[y * pw + x] = rr[x];
      im[y * pw + x] = ri[x];
    }
  }
  final cr = List<double>.filled(ph, 0.0), ci = List<double>.filled(ph, 0.0);
  for (int x = 0; x < pw; x++) {
    for (int y = 0; y < ph; y++) {
      cr[y] = re[y * pw + x];
      ci[y] = im[y * pw + x];
    }
    _fft(cr, ci, false);
    for (int y = 0; y < ph; y++) {
      re[y * pw + x] = cr[y];
      im[y * pw + x] = ci[y];
    }
  }
  return _Spec(pw, ph, ox, oy, re, im);
}

List<double> _inverse(_Spec s, List<double> re, List<double> im, int cols,
    int rows) {
  final pw = s.pw, ph = s.ph;
  final a = List<double>.from(re), b = List<double>.from(im);
  final cr = List<double>.filled(ph, 0.0), ci = List<double>.filled(ph, 0.0);
  for (int x = 0; x < pw; x++) {
    for (int y = 0; y < ph; y++) {
      cr[y] = a[y * pw + x];
      ci[y] = b[y * pw + x];
    }
    _fft(cr, ci, true);
    for (int y = 0; y < ph; y++) {
      a[y * pw + x] = cr[y];
      b[y * pw + x] = ci[y];
    }
  }
  final rr = List<double>.filled(pw, 0.0), ri = List<double>.filled(pw, 0.0);
  for (int y = 0; y < ph; y++) {
    for (int x = 0; x < pw; x++) {
      rr[x] = a[y * pw + x];
      ri[x] = b[y * pw + x];
    }
    _fft(rr, ri, true);
    for (int x = 0; x < pw; x++) {
      a[y * pw + x] = rr[x];
    }
  }
  final out = List<double>.filled(cols * rows, 0.0);
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < cols; x++) {
      out[y * cols + x] = a[(y + s.oy) * pw + (x + s.ox)];
    }
  }
  return out;
}

/// Wavenumbers (rad/m) of padded index [u] on an axis of [n] samples.
double _wave(int u, int n, double cellM) =>
    2 * math.pi * (u <= n ~/ 2 ? u : u - n) / (n * cellM);

/// Applies a wavenumber filter. Grid columns run east; grid rows run SOUTH,
/// so the north wavenumber is minus the row wavenumber.
List<double> _applyFilter(List<double> g, int cols, int rows, double cellM,
    _C Function(double kE, double kN, double k) f) {
  final s = _forward(g, cols, rows);
  final re = List<double>.filled(s.re.length, 0.0);
  final im = List<double>.filled(s.re.length, 0.0);
  for (int v = 0; v < s.ph; v++) {
    final kN = -_wave(v, s.ph, cellM);
    for (int u = 0; u < s.pw; u++) {
      final kE = _wave(u, s.pw, cellM);
      final k = math.sqrt(kE * kE + kN * kN);
      final c = f(kE, kN, k);
      final i = v * s.pw + u;
      re[i] = s.re[i] * c.re - s.im[i] * c.im;
      im[i] = s.re[i] * c.im + s.im[i] * c.re;
    }
  }
  return _inverse(s, re, im, cols, rows);
}

/// Smallest grid the Fourier tools are offered for.
const int kPotMinSide = 8;

bool potApplicable(int cols, int rows) =>
    cols >= kPotMinSide && rows >= kPotMinSide;

/// Upward continuation by [heightM] metres: damps small, shallow sources
/// (soil noise) and keeps larger, deeper ones.
List<double> upwardContinue(
    List<double> g, int cols, int rows, double cellM, double heightM) {
  if (!potApplicable(cols, rows) || heightM <= 0) return g;
  final out = _applyFilter(g, cols, rows, cellM,
      (double kE, double kN, double k) => _C(math.exp(-k * heightM), 0));
  return <double>[
    for (int i = 0; i < g.length; i++) g[i].isNaN ? double.nan : out[i]
  ];
}

/// Smallest inclination for which reduction to the pole is offered: nearer the
/// equator the operator blows the noise up.
const double kRtpMinInc = 25.0;

/// Reduction to the pole for TOTAL-FIELD data and induced magnetisation:
/// turns the paired positive/negative lobes of a body into one peak above it.
List<double> reduceToPole(List<double> g, int cols, int rows, double cellM,
    double incDeg, double decDeg) {
  if (!potApplicable(cols, rows) || incDeg.abs() < kRtpMinInc) return g;
  final ir = incDeg * math.pi / 180, dr = decDeg * math.pi / 180;
  final mN = math.cos(ir) * math.cos(dr);
  final mE = math.cos(ir) * math.sin(dr);
  final mD = math.sin(ir);
  final out = _applyFilter(g, cols, rows, cellM,
      (double kE, double kN, double k) {
    if (k < 1e-12) return const _C(1, 0);
    final a = mD;
    final b = (mN * kN + mE * kE) / k;
    final t2r = a * a - b * b, t2i = 2 * a * b;
    final den = t2r * t2r + t2i * t2i + 0.01;
    return _C(t2r / den, -t2i / den);
  });
  return <double>[
    for (int i = 0; i < g.length; i++) g[i].isNaN ? double.nan : out[i]
  ];
}

// ------------------------------------------------------------ dipole model

/// Reasons a depth fit is refused (keys of the translated texts).
const String kInvOk = 'inv_ok';

class InverseFit {
  InverseFit({
    required this.reason,
    this.depthM = 0,
    this.depthLo = 0,
    this.depthHi = 0,
    this.snr = 0,
    this.moment = 0,
    this.eulerM,
    this.eulerSe,
    this.points = 0,
  });

  /// [kInvOk] or the key of the reason the fit cannot be trusted.
  final String reason;
  final double depthM, depthLo, depthHi, snr, moment;
  final double? eulerM, eulerSe;
  final int points;
  bool get ok => reason == kInvOk;

  /// Euler agrees with the fit when both depths are within 35 %.
  bool get eulerAgrees =>
      eulerM != null && ok && (eulerM! - depthM).abs() <= 0.35 * depthM;
}

/// Total-field (or vertical-component) anomaly of an induced point dipole of
/// unit moment at depth [z] below the sensor plane, east/north offsets [de],
/// [dn] of the sensor from the source.
double _dipole(double de, double dn, double z, double fN, double fE, double fD,
    bool vertical) {
  final rN = dn, rE = de, rD = -z;
  final r2 = rN * rN + rE * rE + rD * rD;
  final r = math.sqrt(r2);
  final fr = fN * rN + fE * rE + fD * rD;
  final cr = vertical ? rD : fr;
  final cf = vertical ? fD : 1.0;
  return (3 * fr * cr / r2 - cf) / (r2 * r);
}

class _Pt {
  _Pt(this.e, this.n, this.v);
  final double e, n, v;
}

/// Fits a point dipole to the window around cell ([cx], [cy]) of the
/// (trend-removed) grid [g] and estimates the depth below the sensor with a
/// 95 % noise interval; also runs Euler deconvolution as a check that does not
/// depend on the magnetisation direction.
InverseFit inverseFit(List<double> g, int cols, int rows, int cx, int cy,
    double cellM,
    {required double incDeg, required double decDeg, bool vertical = false}) {
  final half = (1.5 / cellM).round().clamp(3, 8).toInt();
  final pts = <_Pt>[];
  for (int y = math.max(0, cy - half); y <= math.min(rows - 1, cy + half); y++) {
    for (int x = math.max(0, cx - half); x <= math.min(cols - 1, cx + half); x++) {
      final v = g[y * cols + x];
      if (v.isNaN) continue;
      pts.add(_Pt((x - cx) * cellM, -(y - cy) * cellM, v));
    }
  }
  final n = pts.length;
  if (n < 30) return InverseFit(reason: 'inv_few', points: n);
  final ir = incDeg * math.pi / 180, dr = decDeg * math.pi / 180;
  final fN = math.cos(ir) * math.cos(dr);
  final fE = math.cos(ir) * math.sin(dr);
  final fD = math.sin(ir);

  double syy = 0, sy = 0;
  for (final p in pts) {
    sy += p.v;
    syy += p.v * p.v;
  }
  final basis = List<double>.filled(n, 0.0);
  // linear parts (moment, constant) solved exactly for each position/depth
  double rss(double x0, double y0, double z, List<double> out) {
    double sg = 0, sgg = 0, sgy = 0;
    for (int i = 0; i < n; i++) {
      final b = _dipole(pts[i].e - x0, pts[i].n - y0, z, fN, fE, fD, vertical);
      out[i] = b;
      sg += b;
      sgg += b * b;
      sgy += b * pts[i].v;
    }
    final den = n * sgg - sg * sg;
    if (den.abs() < 1e-18) return double.infinity;
    final m = (n * sgy - sg * sy) / den;
    final c = (sy - m * sg) / n;
    final r = syy - m * sgy - c * sy;
    return r < 0 ? 0.0 : r;
  }

  // start at the strongest point of the window
  double bx = 0, by = 0;
  double bv = -1;
  final med = _median(pts.map((_Pt p) => p.v).toList());
  for (final p in pts) {
    if ((p.v - med).abs() > bv) {
      bv = (p.v - med).abs();
      bx = p.e;
      by = p.n;
    }
  }

  const zStep = 0.05;
  final zs = <double>[for (double z = 0.1; z <= 3.0001; z += zStep) z];
  final prof = List<double>.filled(zs.length, double.infinity);
  final px = List<double>.filled(zs.length, 0.0);
  final py = List<double>.filled(zs.length, 0.0);
  var sx = bx, sy2 = by;
  for (int i = 0; i < zs.length; i++) {
    final z = zs[i];
    final r = _nelderMead(
        (double a, double b) => rss(a, b, z, basis), sx, sy2, cellM * 0.7);
    prof[i] = r[2];
    px[i] = r[0];
    py[i] = r[1];
    sx = r[0];
    sy2 = r[1];
  }
  int best = 0;
  for (int i = 1; i < zs.length; i++) {
    if (prof[i] < prof[best]) best = i;
  }
  if (!prof[best].isFinite) return InverseFit(reason: 'inv_fail', points: n);
  final rssMin = prof[best];
  final nu = n - 5;
  final sigma = math.sqrt(rssMin / nu);
  final limit = rssMin * (1 + 3.84 / nu);
  int lo = best, hi = best;
  while (lo > 0 && prof[lo - 1] <= limit) {
    lo--;
  }
  while (hi < zs.length - 1 && prof[hi + 1] <= limit) {
    hi++;
  }
  // amplitude of the fitted anomaly over the noise
  rss(px[best], py[best], zs[best], basis);
  double sg = 0, sgg = 0, sgy = 0;
  for (int i = 0; i < n; i++) {
    sg += basis[i];
    sgg += basis[i] * basis[i];
    sgy += basis[i] * pts[i].v;
  }
  final m = (n * sgy - sg * sy) / (n * sgg - sg * sg);
  double bmax = 0, bmin = double.infinity;
  for (final b in basis) {
    bmax = math.max(bmax, m * b);
    bmin = math.min(bmin, m * b);
  }
  final amp = (bmax - bmin) / 2;
  final snr = sigma < 1e-12 ? 1e6 : amp / sigma;
  final dz = zs[best];
  String reason = kInvOk;
  if (best == 0 || best == zs.length - 1) {
    reason = 'inv_edge';
  } else if (snr < 4) {
    reason = 'inv_lowsnr';
  } else if ((zs[hi] - zs[lo]) > 0.8 * dz) {
    reason = 'inv_wide';
  }
  double? em, es;
  if (snr >= 10) {
    final e = _euler(g, cols, rows, cx, cy, cellM, half);
    if (e != null && e[0] > 0.05 && e[0] < 5) {
      em = e[0];
      es = e[1];
    }
  }
  return InverseFit(
    reason: reason,
    depthM: dz,
    depthLo: zs[lo],
    depthHi: zs[hi],
    snr: snr,
    moment: m,
    eulerM: em,
    eulerSe: es,
    points: n,
  );
}

double _median(List<double> v) {
  final s = List<double>.from(v)..sort();
  if (s.isEmpty) return 0;
  final k = s.length ~/ 2;
  return s.length.isOdd ? s[k] : (s[k - 1] + s[k]) / 2;
}

/// Minimises f(x, y) with a small Nelder-Mead simplex. Returns [x, y, f].
List<double> _nelderMead(
    double Function(double, double) f, double x0, double y0, double step) {
  final p = <List<double>>[
    <double>[x0, y0],
    <double>[x0 + step, y0],
    <double>[x0, y0 + step],
  ];
  final v = <double>[for (final q in p) f(q[0], q[1])];
  for (int it = 0; it < 70; it++) {
    final idx = <int>[0, 1, 2]..sort((int a, int b) => v[a].compareTo(v[b]));
    final b = idx[0], m = idx[1], w = idx[2];
    if ((v[w] - v[b]).abs() < 1e-12 * (1 + v[b].abs())) break;
    final cx = (p[b][0] + p[m][0]) / 2, cy = (p[b][1] + p[m][1]) / 2;
    final rx = cx + (cx - p[w][0]), ry = cy + (cy - p[w][1]);
    final fr = f(rx, ry);
    if (fr < v[b]) {
      final ex = cx + 2 * (cx - p[w][0]), ey = cy + 2 * (cy - p[w][1]);
      final fe = f(ex, ey);
      if (fe < fr) {
        p[w] = <double>[ex, ey];
        v[w] = fe;
      } else {
        p[w] = <double>[rx, ry];
        v[w] = fr;
      }
    } else if (fr < v[m]) {
      p[w] = <double>[rx, ry];
      v[w] = fr;
    } else {
      final kx = cx + 0.5 * (p[w][0] - cx), ky = cy + 0.5 * (p[w][1] - cy);
      final fk = f(kx, ky);
      if (fk < v[w]) {
        p[w] = <double>[kx, ky];
        v[w] = fk;
      } else {
        for (final i in <int>[m, w]) {
          p[i] = <double>[
            (p[i][0] + p[b][0]) / 2,
            (p[i][1] + p[b][1]) / 2
          ];
          v[i] = f(p[i][0], p[i][1]);
        }
      }
    }
  }
  int b = 0;
  for (int i = 1; i < 3; i++) {
    if (v[i] < v[b]) b = i;
  }
  return <double>[p[b][0], p[b][1], v[b]];
}

/// Euler deconvolution (structural index 3, a compact body) in the window
/// around ([cx], [cy]). Returns [depth, standard error] or null. It needs no
/// magnetisation direction, but noise in the derivatives pulls the depth
/// shallow, so it is only a cross-check and only run at a high signal.
List<double>? _euler(
    List<double> g, int cols, int rows, int cx, int cy, double cellM, int half) {
  if (!potApplicable(cols, rows)) return null;
  final s = _forward(g, cols, rows);
  List<double> deriv(_C Function(double kE, double kN, double k) f) {
    final re = List<double>.filled(s.re.length, 0.0);
    final im = List<double>.filled(s.re.length, 0.0);
    for (int v = 0; v < s.ph; v++) {
      final kN = -_wave(v, s.ph, cellM);
      for (int u = 0; u < s.pw; u++) {
        final kE = _wave(u, s.pw, cellM);
        final k = math.sqrt(kE * kE + kN * kN);
        final c = f(kE, kN, k);
        final i = v * s.pw + u;
        re[i] = s.re[i] * c.re - s.im[i] * c.im;
        im[i] = s.re[i] * c.im + s.im[i] * c.re;
      }
    }
    return _inverse(s, re, im, cols, rows);
  }

  final tx = deriv((double kE, double kN, double k) => _C(0, kE));
  final tn = deriv((double kE, double kN, double k) => _C(0, kN));
  final tz = deriv((double kE, double kN, double k) => _C(k, 0));
  const si = 3.0;
  final a = List<List<double>>.generate(4, (_) => List<double>.filled(4, 0.0));
  final b = List<double>.filled(4, 0.0);
  int cnt = 0;
  final rowsA = <List<double>>[];
  final rhs = <double>[];
  final t = g;
  for (int y = math.max(0, cy - half); y <= math.min(rows - 1, cy + half); y++) {
    for (int x = math.max(0, cx - half); x <= math.min(cols - 1, cx + half); x++) {
      final i = y * cols + x;
      if (t[i].isNaN) continue;
      final e = (x - cx) * cellM, nn = -(y - cy) * cellM;
      rowsA.add(<double>[tx[i], tn[i], tz[i], si]);
      rhs.add(e * tx[i] + nn * tn[i] + si * t[i]);
      cnt++;
    }
  }
  if (cnt < 20) return null;
  for (int r = 0; r < cnt; r++) {
    for (int i = 0; i < 4; i++) {
      b[i] += rowsA[r][i] * rhs[r];
      for (int j = 0; j < 4; j++) {
        a[i][j] += rowsA[r][i] * rowsA[r][j];
      }
    }
  }
  final inv = _invert(a);
  if (inv == null) return null;
  final c = List<double>.filled(4, 0.0);
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      c[i] += inv[i][j] * b[j];
    }
  }
  double rs = 0;
  for (int r = 0; r < cnt; r++) {
    double p = 0;
    for (int i = 0; i < 4; i++) {
      p += rowsA[r][i] * c[i];
    }
    rs += (rhs[r] - p) * (rhs[r] - p);
  }
  final s2 = rs / (cnt - 4);
  final se = math.sqrt(math.max(0.0, s2 * inv[2][2]));
  return <double>[c[2], se];
}

List<List<double>>? _invert(List<List<double>> m) {
  final n = m.length;
  final a = <List<double>>[
    for (int i = 0; i < n; i++)
      <double>[...m[i], for (int j = 0; j < n; j++) i == j ? 1.0 : 0.0]
  ];
  for (int c = 0; c < n; c++) {
    int p = c;
    for (int r = c + 1; r < n; r++) {
      if (a[r][c].abs() > a[p][c].abs()) p = r;
    }
    if (a[p][c].abs() < 1e-14) return null;
    final tmp = a[c];
    a[c] = a[p];
    a[p] = tmp;
    final d = a[c][c];
    for (int j = 0; j < 2 * n; j++) {
      a[c][j] /= d;
    }
    for (int r = 0; r < n; r++) {
      if (r == c) continue;
      final f = a[r][c];
      if (f == 0) continue;
      for (int j = 0; j < 2 * n; j++) {
        a[r][j] -= f * a[c][j];
      }
    }
  }
  return <List<double>>[for (int i = 0; i < n; i++) a[i].sublist(n)];
}
