/// Soil types used to tune the analysis. Based on the typical magnetic
/// susceptibility (SI x 1e-5) of soils and rocks: sand/limestone are almost
/// non-magnetic, clay and topsoil are weakly magnetic, laterite, basalt and
/// some granites are strongly magnetic and make a noisy background.
/// The numbers are rough rules of thumb, not a laboratory measurement.
class Soil {
  const Soil(this.key, this.kFactor, this.widespread, this.voidVisibility,
      this.susceptibility);

  final String key;

  /// Multiplier on the detection threshold (noisier soil -> higher).
  final double kFactor;

  /// Fraction of cells that may be "anomalous" before the area is judged to be
  /// naturally magnetic rather than containing one target.
  final double widespread;

  /// 0..2: how well a void shows up (2 = clearly, 0 = nearly invisible).
  final int voidVisibility;

  /// Typical susceptibility range, for display only.
  final String susceptibility;
}

const List<Soil> kSoils = <Soil>[
  Soil('soil_auto', 1.0, 0.25, 1, '-'),
  Soil('soil_sand', 0.8, 0.20, 2, '0 - 10'),
  Soil('soil_limestone', 0.85, 0.20, 2, '0 - 20'),
  Soil('soil_clay', 1.0, 0.25, 1, '20 - 100'),
  Soil('soil_agri', 1.15, 0.30, 1, '40 - 200'),
  Soil('soil_granite', 1.25, 0.30, 1, '10 - 300'),
  Soil('soil_laterite', 1.6, 0.40, 0, '300 - 1500'),
  Soil('soil_volcanic', 1.9, 0.45, 0, '500 - 5000'),
  Soil('soil_concrete', 1.35, 0.30, 1, '10 - 100 (+ rebar)'),
  Soil('soil_stony', 1.1, 0.25, 1, '5 - 150'),
  Soil('soil_organic', 0.9, 0.20, 2, '-1 - 20'),
  Soil('soil_lime', 0.9, 0.20, 2, '0 - 15'),
  Soil('soil_mineral', 1.5, 0.40, 0, '200 - 3000'),
  Soil('soil_anthro', 1.5, 0.50, 0, '100 - 1500'),
];
