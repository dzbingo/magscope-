import 'package:flutter/material.dart';

/// Start screen shown while the settings and saved scans are loading.
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: ColoredBox(
        color: const Color(0xFF0B1114),
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Image.asset('assets/splash/splash.jpg', fit: BoxFit.cover),
            Align(
              alignment: const FractionalOffset(0.5, 0.905),
              child: SizedBox(
                width: 190,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: const LinearProgressIndicator(
                        minHeight: 4,
                        color: Color(0xFFFFB020),
                        backgroundColor: Color(0x33FFFFFF),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Loading settings...',
                      style: TextStyle(
                        color: Color(0xCCFFFFFF),
                        fontSize: 12,
                        decoration: TextDecoration.none,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
