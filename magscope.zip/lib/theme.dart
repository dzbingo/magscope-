import 'package:flutter/material.dart';

/// MagScope's own colour palette: graphite surfaces, amber and violet accents.
class Pal {
  static const Color bg = Color(0xFF0E1116);
  static const Color surface = Color(0xFF171C24);
  static const Color surface2 = Color(0xFF1F2630);
  static const Color outline = Color(0xFF2B3442);
  static const Color text = Color(0xFFE8ECF2);
  static const Color muted = Color(0xFF8A94A6);
  static const Color amber = Color(0xFFFFA43A);
  static const Color violet = Color(0xFF8B7CFF);
  static const Color good = Color(0xFF4ADE80);
  static const Color bad = Color(0xFFFF5D5D);
}

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    primary: Pal.amber,
    onPrimary: Color(0xFF1A1206),
    secondary: Pal.violet,
    onSecondary: Colors.white,
    surface: Pal.surface,
    onSurface: Pal.text,
    error: Pal.bad,
  );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'IBMPlexArabic',
    colorScheme: scheme,
    scaffoldBackgroundColor: Pal.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: Pal.bg,
      foregroundColor: Pal.text,
      elevation: 0,
      centerTitle: false,
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: Pal.surface,
      indicatorColor: Color(0x33FFA43A),
    ),
  );
}
