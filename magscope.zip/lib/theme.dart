import 'package:flutter/material.dart';

/// One colour theme. "amber"/"violet" are the two accent colours.
class ThemeDef {
  const ThemeDef({
    required this.nameKey,
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.outline,
    required this.text,
    required this.muted,
    required this.amber,
    required this.violet,
    required this.good,
    required this.bad,
    this.light = false,
  });

  final String nameKey;
  final Color bg;
  final Color surface;
  final Color surface2;
  final Color outline;
  final Color text;
  final Color muted;
  final Color amber;
  final Color violet;
  final Color good;
  final Color bad;
  final bool light;
}

const List<ThemeDef> kThemes = <ThemeDef>[
  ThemeDef(
    nameKey: 'th_0',
    bg: Color(0xFF0E1116),
    surface: Color(0xFF171C24),
    surface2: Color(0xFF1F2630),
    outline: Color(0xFF2B3442),
    text: Color(0xFFE8ECF2),
    muted: Color(0xFF8A94A6),
    amber: Color(0xFFFFA43A),
    violet: Color(0xFF8B7CFF),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D5D),
  ),
  ThemeDef(
    nameKey: 'th_1',
    bg: Color(0xFF0A1220),
    surface: Color(0xFF111C30),
    surface2: Color(0xFF182642),
    outline: Color(0xFF23365A),
    text: Color(0xFFE6EEFB),
    muted: Color(0xFF8496B8),
    amber: Color(0xFF3DD6F5),
    violet: Color(0xFF7C9DFF),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D6C),
  ),
  ThemeDef(
    nameKey: 'th_2',
    bg: Color(0xFF08130E),
    surface: Color(0xFF0F1D16),
    surface2: Color(0xFF16291F),
    outline: Color(0xFF22402F),
    text: Color(0xFFE4F3EA),
    muted: Color(0xFF84A394),
    amber: Color(0xFF34D399),
    violet: Color(0xFFA3E635),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF6B5D),
  ),
  ThemeDef(
    nameKey: 'th_3',
    bg: Color(0xFF0D0B0C),
    surface: Color(0xFF1A1516),
    surface2: Color(0xFF251D1E),
    outline: Color(0xFF3A2B2D),
    text: Color(0xFFF3EAEA),
    muted: Color(0xFFA08F90),
    amber: Color(0xFFFF4D4D),
    violet: Color(0xFFFF9F43),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF2D55),
  ),
  ThemeDef(
    nameKey: 'th_4',
    bg: Color(0xFF14110B),
    surface: Color(0xFF201B12),
    surface2: Color(0xFF2B2418),
    outline: Color(0xFF42381F),
    text: Color(0xFFF5EEDC),
    muted: Color(0xFFA99F86),
    amber: Color(0xFFE9B949),
    violet: Color(0xFFC084FC),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D5D),
  ),
  ThemeDef(
    nameKey: 'th_5',
    bg: Color(0xFFF4F6FA),
    surface: Color(0xFFFFFFFF),
    surface2: Color(0xFFEEF1F6),
    outline: Color(0xFFD5DBE6),
    text: Color(0xFF151A22),
    muted: Color(0xFF5E6878),
    amber: Color(0xFFE07B00),
    violet: Color(0xFF5B4BDB),
    good: Color(0xFF16A34A),
    bad: Color(0xFFDC2626),
    light: true,
  ),
];

/// Currently active palette. Switched at runtime with [Pal.apply].
class Pal {
  static int index = 0;
  static bool light = false;
  static Color bg = kThemes[0].bg;
  static Color surface = kThemes[0].surface;
  static Color surface2 = kThemes[0].surface2;
  static Color outline = kThemes[0].outline;
  static Color text = kThemes[0].text;
  static Color muted = kThemes[0].muted;
  static Color amber = kThemes[0].amber;
  static Color violet = kThemes[0].violet;
  static Color good = kThemes[0].good;
  static Color bad = kThemes[0].bad;

  static void apply(int i) {
    final t = kThemes[i.clamp(0, kThemes.length - 1).toInt()];
    index = kThemes.indexOf(t);
    light = t.light;
    bg = t.bg;
    surface = t.surface;
    surface2 = t.surface2;
    outline = t.outline;
    text = t.text;
    muted = t.muted;
    amber = t.amber;
    violet = t.violet;
    good = t.good;
    bad = t.bad;
  }
}

ThemeData buildTheme() {
  final scheme = Pal.light
      ? ColorScheme.light(
          primary: Pal.amber,
          onPrimary: Colors.white,
          secondary: Pal.violet,
          onSecondary: Colors.white,
          surface: Pal.surface,
          onSurface: Pal.text,
          error: Pal.bad,
        )
      : ColorScheme.dark(
          primary: Pal.amber,
          onPrimary: const Color(0xFF14100A),
          secondary: Pal.violet,
          onSecondary: Colors.white,
          surface: Pal.surface,
          onSurface: Pal.text,
          error: Pal.bad,
        );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'IBMPlexArabic',
    brightness: Pal.light ? Brightness.light : Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: Pal.bg,
    appBarTheme: AppBarTheme(
      backgroundColor: Pal.bg,
      foregroundColor: Pal.text,
      elevation: 0,
      centerTitle: false,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Pal.surface,
      indicatorColor: Pal.amber.withAlpha(50),
    ),
  );
}
