import 'package:flutter/material.dart';

/// One colour theme. "amber"/"violet" are the two accent colours.
class ThemeDef {
  const ThemeDef({
    required this.nameKey,
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.outline,
    required this.text,
    required this.muted,
    required this.amber,
    required this.violet,
    required this.good,
    required this.bad,
    this.light = false,
    this.neon = false,
  });

  final String nameKey;
  final Color bg;
  final Color surface;
  final Color surface2;
  final Color outline;
  final Color text;
  final Color muted;
  final Color amber;
  final Color violet;
  final Color good;
  final Color bad;
  final bool light;
  final bool neon;
}

/// Graphite (th_0) is the default theme: its position in [kThemes].
const int kDefaultTheme = 1;

const List<ThemeDef> kThemes = <ThemeDef>[
  ThemeDef(
    nameKey: 'th_6',
    bg: Color(0xFF040817),
    surface: Color(0xFF0A1128),
    surface2: Color(0xFF101A3A),
    outline: Color(0xFF1B2B5E),
    text: Color(0xFFF2F6FF),
    muted: Color(0xFF8FA2CE),
    amber: Color(0xFF00F0FF),
    violet: Color(0xFFE000FF),
    good: Color(0xFF00FF66),
    bad: Color(0xFFFF3B6B),
    neon: true,
  ),
  ThemeDef(
    nameKey: 'th_0',
    bg: Color(0xFF0E1116),
    surface: Color(0xFF171C24),
    surface2: Color(0xFF1F2630),
    outline: Color(0xFF2B3442),
    text: Color(0xFFE8ECF2),
    muted: Color(0xFF8A94A6),
    amber: Color(0xFFFFA43A),
    violet: Color(0xFF8B7CFF),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D5D),
  ),
  ThemeDef(
    nameKey: 'th_1',
    bg: Color(0xFF0A1220),
    surface: Color(0xFF111C30),
    surface2: Color(0xFF182642),
    outline: Color(0xFF23365A),
    text: Color(0xFFE6EEFB),
    muted: Color(0xFF8496B8),
    amber: Color(0xFF3DD6F5),
    violet: Color(0xFF7C9DFF),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D6C),
  ),
  ThemeDef(
    nameKey: 'th_2',
    bg: Color(0xFF08130E),
    surface: Color(0xFF0F1D16),
    surface2: Color(0xFF16291F),
    outline: Color(0xFF22402F),
    text: Color(0xFFE4F3EA),
    muted: Color(0xFF84A394),
    amber: Color(0xFF34D399),
    violet: Color(0xFFA3E635),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF6B5D),
  ),
  ThemeDef(
    nameKey: 'th_8',
    bg: Color(0xFF080000),
    surface: Color(0xFF140404),
    surface2: Color(0xFF1E0707),
    outline: Color(0xFF4A1111),
    text: Color(0xFFFF6B5B),
    muted: Color(0xFFD05A48),
    amber: Color(0xFFFF3B2F),
    violet: Color(0xFFD1342A),
    good: Color(0xFFCC4B3C),
    bad: Color(0xFFFF8A7A),
  ),
  ThemeDef(
    nameKey: 'th_7',
    bg: Color(0xFF0A0907),
    surface: Color(0xFF15120C),
    surface2: Color(0xFF211B10),
    outline: Color(0xFF6E5522),
    text: Color(0xFFF5EBD0),
    muted: Color(0xFFB59D68),
    amber: Color(0xFFE2B452),
    violet: Color(0xFFFFE08A),
    good: Color(0xFF4ADE80),
    bad: Color(0xFFFF5D5D),
    neon: true,
  ),
];

/// Currently active palette. Switched at runtime with [Pal.apply].
class Pal {
  static int index = kDefaultTheme;
  static bool light = false;
  static bool neon = false;
  static Color bg = kThemes[kDefaultTheme].bg;
  static Color surface = kThemes[kDefaultTheme].surface;
  static Color surface2 = kThemes[kDefaultTheme].surface2;
  static Color outline = kThemes[kDefaultTheme].outline;
  static Color text = kThemes[kDefaultTheme].text;
  static Color muted = kThemes[kDefaultTheme].muted;
  static Color amber = kThemes[kDefaultTheme].amber;
  static Color violet = kThemes[kDefaultTheme].violet;
  static Color good = kThemes[kDefaultTheme].good;
  static Color bad = kThemes[kDefaultTheme].bad;

  static void apply(int i) {
    final t = kThemes[i.clamp(0, kThemes.length - 1).toInt()];
    index = kThemes.indexOf(t);
    light = t.light;
    neon = t.neon;
    bg = t.bg;
    surface = t.surface;
    surface2 = t.surface2;
    outline = t.outline;
    text = t.text;
    muted = t.muted;
    amber = t.amber;
    violet = t.violet;
    good = t.good;
    bad = t.bad;
  }
}

/// Dark or white text, whichever reads better on [c] (WCAG-style crossover).
Color onColor(Color c) =>
    c.computeLuminance() > 0.179 ? const Color(0xFF0B0E14) : Colors.white;

ThemeData buildTheme() {
  final scheme = Pal.light
      ? ColorScheme.light(
          primary: Pal.amber,
          onPrimary: onColor(Pal.amber),
          secondary: Pal.violet,
          onSecondary: onColor(Pal.violet),
          surface: Pal.surface,
          onSurface: Pal.text,
          error: Pal.bad,
        )
      : ColorScheme.dark(
          primary: Pal.amber,
          onPrimary: onColor(Pal.amber),
          secondary: Pal.violet,
          onSecondary: onColor(Pal.violet),
          surface: Pal.surface,
          onSurface: Pal.text,
          error: Pal.bad,
        );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'AppArabic',
    brightness: Pal.light ? Brightness.light : Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: Pal.bg,
    appBarTheme: AppBarTheme(
      backgroundColor: Pal.bg,
      foregroundColor: Pal.text,
      elevation: 0,
      centerTitle: false,
    ),
    filledButtonTheme: Pal.neon
        ? FilledButtonThemeData(
            style: FilledButton.styleFrom(
              elevation: 8,
              shadowColor: Pal.amber,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(color: Pal.amber.withAlpha(150)),
              ),
            ),
          )
        : null,
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Pal.surface,
      indicatorColor: Pal.amber.withAlpha(50),
    ),
  );
}
