import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_shell.dart';
import 'state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.init();
  runApp(MagScopeApp(state: state));
}

class MagScopeApp extends StatelessWidget {
  const MagScopeApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: Builder(
        builder: (BuildContext context) {
          final s = AppScope.of(context);
          return MaterialApp(
            title: 'Sniper-Dz',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(),
            locale: s.locale,
            supportedLocales: const <Locale>[
              Locale('ar'),
              Locale('en'),
              Locale('fr'),
            ],
            localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const HomeShell(),
          );
        },
      ),
    );
  }
}
