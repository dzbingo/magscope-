import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'diag.dart';
import 'screens/home_shell.dart';
import 'splash.dart';
import 'state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Diag.init();
  runApp(const MaterialApp(
      debugShowCheckedModeBanner: false, home: SplashScreen()));
  final state = AppState();
  await Future.wait<void>(<Future<void>>[
    state.init(),
    Future<void>.delayed(const Duration(milliseconds: 1400)),
  ]);
  runApp(MagScopeApp(state: state));
}

class MagScopeApp extends StatelessWidget {
  const MagScopeApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: Builder(
        builder: (BuildContext context) {
          final s = AppScope.of(context);
          return MaterialApp(
            title: 'MagVision Pro',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(),
            locale: s.locale,
            supportedLocales: const <Locale>[
              Locale('ar'),
              Locale('en'),
              Locale('fr'),
              Locale('fa'),
            ],
            localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const HomeShell(),
          );
        },
      ),
    );
  }
}
