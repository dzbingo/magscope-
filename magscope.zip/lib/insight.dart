import 'dsp.dart';

/// Simple rule-based reading of a scan grid. This is NOT a trained model: it
/// only compares the strongest cell with the typical background and noise.
class Insight {
  const Insight({
    required this.kind,
    this.level = 0,
    this.x = 0,
    this.y = 0,
    this.deviation = 0,
    this.contrast = 0,
    this.depthM,
    this.suggestView = 0,
    this.coverage = 0,
  });

  /// -1 = not enough data, 0 = nothing stands out, 1 = metal-like, 2 = void-like.
  final int kind;

  /// Reliability 0 = low, 1 = medium, 2 = high.
  final int level;
  final int x;
  final int y;
  final double deviation;

  /// Strongest anomaly divided by the robust background noise.
  final double contrast;
  final double? depthM;

  /// Suggested grid view: 0 normal, 1 high-pass, 2 gradient.
  final int suggestView;

  /// Fraction of the grid that has been measured (0..1).
  final double coverage;
}

class InsightEngine {
  static Insight analyze(
    List<double> cells,
    int cols,
    int rows, {
    required double sensitivity,
    double? absThreshold,
    required double cellM,
  }) {
    final valid = cells.where((e) => !e.isNaN && e.isFinite).toList();
    final coverage = cells.isEmpty ? 0.0 : valid.length / cells.length;
    if (valid.length < 10) return Insight(kind: -1, coverage: coverage);

    final hits = findCellAnomalies(cells, cols, rows, sensitivity + 1.0,
        absThreshold: absThreshold);
    if (hits.isEmpty) {
      return Insight(kind: 0, suggestView: 0, coverage: coverage);
    }
    final top = hits.first;
    final m = medianOf(valid);
    final mad =
        medianOf(valid.map((e) => (e - m).abs()).toList()) * 1.4826;
    final contrast = top.deviation.abs() / (mad < 1e-6 ? 1e-6 : mad);

    var level = contrast >= 8 ? 2 : (contrast >= 4 ? 1 : 0);
    if (coverage < 0.5 && level > 1) level = 1;
    if (coverage < 0.25) level = 0;

    final depth = estimateDepth(cells, cols, rows, top.x, top.y, cellM);
    final metal = top.deviation > 0;
    return Insight(
      kind: metal ? 1 : 2,
      level: level,
      x: top.x,
      y: top.y,
      deviation: top.deviation,
      contrast: contrast,
      depthM: depth?.depthM,
      suggestView: metal ? 2 : 1,
      coverage: coverage,
    );
  }
}
