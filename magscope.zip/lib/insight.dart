import 'dart:math' as math;
import 'anomaly.dart';

import 'dsp.dart';

/// Simple rule-based reading of a scan grid. This is NOT a trained model: it
/// only compares the strongest cell with the typical background and noise.
class Insight {
  const Insight({
    required this.kind,
    this.level = 0,
    this.x = 0,
    this.y = 0,
    this.deviation = 0,
    this.contrast = 0,
    this.depthM,
    this.suggestView = 0,
    this.coverage = 0,
    this.dipole = false,
    this.isolated = false,
    this.widespread = false,
    this.score = 0,
    this.metalPct = 0,
    this.voidPct = 0,
    this.falseRisk = 0,
    this.belowLearned = false,
    this.sizeClass = -1,
  });

  /// -1 = not enough data, 0 = nothing stands out, 1 = metal-like, 2 = void-like.
  final int kind;

  /// Rough size class 0 small / 1 medium / 2 large (-1 unknown). Metal: from
  /// amplitude x depth^3 (dipole law). Void: from the anomaly width.
  final int sizeClass;

  /// Reliability 0 = low, 1 = medium, 2 = high.
  final int level;
  final int x;
  final int y;
  final double deviation;

  /// Strongest anomaly divided by the robust background noise.
  final double contrast;
  final double? depthM;

  /// Suggested grid view: 0 normal, 1 high-pass, 2 gradient.
  final int suggestView;

  /// Fraction of the grid that has been measured (0..1).
  final double coverage;

  /// An opposite-sign lobe sits next to the peak (typical of iron objects).
  final bool dipole;

  /// The peak has no supporting neighbours (possible glitch / false reading).
  final bool isolated;

  /// Anomalies cover a large part of the grid (ground mineralisation).
  final bool widespread;

  /// Heuristic target score 0..100 and false-alarm risk 0 low .. 2 high.
  final int score;
  final int falseRisk;

  /// The same rule-based score (0..100, NOT a measured probability) for the
  /// best metal-like and the best void-like candidate; 0 = none found.
  final int metalPct;
  final int voidPct;

  /// The contrast is below the level that separated false from real targets
  /// in the user's own field marks.
  final bool belowLearned;
}

class InsightEngine {
  /// Robust background noise (median absolute deviation) of the grid.
  static double noiseOf(List<double> cells) {
    final valid = cells.where((e) => !e.isNaN && e.isFinite).toList();
    if (valid.length < 5) return 1.0;
    final m = medianOf(valid);
    final mad = medianOf(valid.map((e) => (e - m).abs()).toList()) * 1.4826;
    return mad < 1e-6 ? 1e-6 : mad;
  }

  static ({int score, bool isolated, bool dipole, bool widespread}) _evalHit(
      List<double> res,
      int cols,
      int rows,
      CellAnomaly h,
      double noise,
      double coverage,
      int nHits,
      int nValid,
      double widespreadFrac) {
    final contrast = h.deviation.abs() / noise;
    double nbSum = 0;
    int nbN = 0;
    for (int dy = -1; dy <= 1; dy++) {
      for (int dx = -1; dx <= 1; dx++) {
        if (dx == 0 && dy == 0) continue;
        final xx = h.x + dx;
        final yy = h.y + dy;
        if (xx < 0 || yy < 0 || xx >= cols || yy >= rows) continue;
        final v = res[yy * cols + xx];
        if (v.isNaN) continue;
        nbSum += v;
        nbN++;
      }
    }
    final nbMean = nbN == 0 ? 0.0 : nbSum / nbN;
    final isolated = nbN >= 3 && nbMean.abs() < 0.25 * h.deviation.abs();
    bool dipole = false;
    for (int dy = -3; dy <= 3 && !dipole; dy++) {
      for (int dx = -3; dx <= 3; dx++) {
        final xx = h.x + dx;
        final yy = h.y + dy;
        if (xx < 0 || yy < 0 || xx >= cols || yy >= rows) continue;
        final v = res[yy * cols + xx];
        if (v.isNaN) continue;
        if (v * h.deviation < 0 && v.abs() >= 0.3 * h.deviation.abs()) {
          dipole = true;
          break;
        }
      }
    }
    final widespread = nHits > widespreadFrac * nValid;
    double sc = math.min(55.0, contrast * 5) + coverage * 20;
    if (dipole && h.deviation > 0) sc += 15;
    if (isolated) sc -= 25;
    if (widespread) sc -= 20;
    return (
      score: sc.clamp(0.0, 100.0).round(),
      isolated: isolated,
      dipole: dipole,
      widespread: widespread
    );
  }

  static Insight analyze(
    List<double> cells,
    int cols,
    int rows, {
    required double sensitivity,
    double? absThreshold,
    required double cellM,
    double? learnedContrast,
    double widespreadFrac = 0.12,
    double? calSigma,
  }) {
    final valid = cells.where((e) => !e.isNaN && e.isFinite).toList();
    final coverage = cells.isEmpty ? 0.0 : valid.length / cells.length;
    if (valid.length < 10) return Insight(kind: -1, coverage: coverage);

    final hits = findCellAnomalies(cells, cols, rows, sensitivity + 1.0,
        absThreshold: absThreshold);
    if (hits.isEmpty) {
      return Insight(kind: 0, suggestView: 0, coverage: coverage);
    }
    final top = hits.first;
    // everything below is judged on the residual (regional trend removed)
    final res = Detect.residual(cells, cols, rows);
    final mad = Detect.sigmaOf(res);
    // the noise can never be lower than the one measured while standing still
    final noise = math.max(mad < 1e-6 ? 1e-6 : mad, calSigma ?? 0.0);
    final contrast = top.deviation.abs() / noise;

    var level = contrast >= 8 ? 2 : (contrast >= 4 ? 1 : 0);
    if (coverage < 0.5 && level > 1) level = 1;
    if (coverage < 0.25) level = 0;

    final depth = estimateDepth(res, cols, rows, top.x, top.y, cellM, isResidual: true);
    final metal = top.deviation > 0;
    int sizeClass = -1;
    if (depth != null) {
      if (metal) {
        // field of a small magnetised body falls as 1/r^3, so amplitude x
        // depth^3 is proportional to its magnetic moment (rough: 1 uT at 1 m
        // is about 5 A*m2 for an on-axis dipole)
        final moment = 5.0 * top.deviation.abs() * depth.depthM * depth.depthM * depth.depthM;
        sizeClass = moment < 0.5 ? 0 : (moment < 50 ? 1 : 2);
      } else {
        sizeClass = depth.fwhmM < 0.6 ? 0 : (depth.fwhmM < 2.5 ? 1 : 2);
      }
    }

    // neighbourhood checks around the strongest cell
    final ev = _evalHit(res, cols, rows, top, noise, coverage, hits.length, valid.length, widespreadFrac);
    final isolated = ev.isolated;
    final dipole = ev.dipole;
    final widespread = ev.widespread;

    // the same rule-based score for the best metal-like and the best
    // void-like candidate, so the user sees both side by side
    int metalPct = 0;
    int voidPct = 0;
    for (final h in hits) {
      if (h.deviation > 0 && metalPct == 0) {
        metalPct = _evalHit(res, cols, rows, h, noise, coverage, hits.length, valid.length, widespreadFrac).score;
      } else if (h.deviation < 0 && voidPct == 0) {
        voidPct = _evalHit(res, cols, rows, h, noise, coverage, hits.length, valid.length, widespreadFrac).score;
      }
    }

    final sc = ev.score.toDouble();
    // a tiny grid cannot support a "good" verdict
    if (cols * rows < 16 && level > 1) level = 1;
    final score = sc.clamp(0.0, 100.0).round();
    final belowLearned = learnedContrast != null && contrast < learnedContrast;
    final falseRisk = (isolated || widespread || level == 0 || belowLearned)
        ? 2
        : (coverage < 0.5 ? 1 : 0);

    // reliability must not say "good" while the false-alarm risk is high
    if (falseRisk == 2 && level > 1) level = 1;
    return Insight(
      kind: metal ? 1 : 2,
      level: level,
      x: top.x,
      y: top.y,
      deviation: top.deviation,
      contrast: contrast,
      depthM: depth?.depthM,
      sizeClass: sizeClass,
      suggestView: metal ? 2 : 1,
      coverage: coverage,
      dipole: dipole,
      isolated: isolated,
      widespread: widespread,
      score: score,
      metalPct: metalPct,
      voidPct: voidPct,
      falseRisk: falseRisk,
      belowLearned: belowLearned,
    );
  }
}
