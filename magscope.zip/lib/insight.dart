import 'dart:math' as math;

import 'dsp.dart';

/// Simple rule-based reading of a scan grid. This is NOT a trained model: it
/// only compares the strongest cell with the typical background and noise.
class Insight {
  const Insight({
    required this.kind,
    this.level = 0,
    this.x = 0,
    this.y = 0,
    this.deviation = 0,
    this.contrast = 0,
    this.depthM,
    this.suggestView = 0,
    this.coverage = 0,
    this.dipole = false,
    this.isolated = false,
    this.widespread = false,
    this.score = 0,
    this.falseRisk = 0,
    this.belowLearned = false,
  });

  /// -1 = not enough data, 0 = nothing stands out, 1 = metal-like, 2 = void-like.
  final int kind;

  /// Reliability 0 = low, 1 = medium, 2 = high.
  final int level;
  final int x;
  final int y;
  final double deviation;

  /// Strongest anomaly divided by the robust background noise.
  final double contrast;
  final double? depthM;

  /// Suggested grid view: 0 normal, 1 high-pass, 2 gradient.
  final int suggestView;

  /// Fraction of the grid that has been measured (0..1).
  final double coverage;

  /// An opposite-sign lobe sits next to the peak (typical of iron objects).
  final bool dipole;

  /// The peak has no supporting neighbours (possible glitch / false reading).
  final bool isolated;

  /// Anomalies cover a large part of the grid (ground mineralisation).
  final bool widespread;

  /// Heuristic target score 0..100 and false-alarm risk 0 low .. 2 high.
  final int score;
  final int falseRisk;

  /// The contrast is below the level that separated false from real targets
  /// in the user's own field marks.
  final bool belowLearned;
}

class InsightEngine {
  /// Robust background noise (median absolute deviation) of the grid.
  static double noiseOf(List<double> cells) {
    final valid = cells.where((e) => !e.isNaN && e.isFinite).toList();
    if (valid.length < 5) return 1.0;
    final m = medianOf(valid);
    final mad = medianOf(valid.map((e) => (e - m).abs()).toList()) * 1.4826;
    return mad < 1e-6 ? 1e-6 : mad;
  }

  static Insight analyze(
    List<double> cells,
    int cols,
    int rows, {
    required double sensitivity,
    double? absThreshold,
    required double cellM,
    double? learnedContrast,
    double widespreadFrac = 0.12,
  }) {
    final valid = cells.where((e) => !e.isNaN && e.isFinite).toList();
    final coverage = cells.isEmpty ? 0.0 : valid.length / cells.length;
    if (valid.length < 10) return Insight(kind: -1, coverage: coverage);

    final hits = findCellAnomalies(cells, cols, rows, sensitivity + 1.0,
        absThreshold: absThreshold);
    if (hits.isEmpty) {
      return Insight(kind: 0, suggestView: 0, coverage: coverage);
    }
    final top = hits.first;
    final m = medianOf(valid);
    final mad =
        medianOf(valid.map((e) => (e - m).abs()).toList()) * 1.4826;
    final contrast = top.deviation.abs() / (mad < 1e-6 ? 1e-6 : mad);

    var level = contrast >= 8 ? 2 : (contrast >= 4 ? 1 : 0);
    if (coverage < 0.5 && level > 1) level = 1;
    if (coverage < 0.25) level = 0;

    final depth = estimateDepth(cells, cols, rows, top.x, top.y, cellM);
    final metal = top.deviation > 0;

    // neighbourhood checks around the strongest cell
    double nbSum = 0;
    int nbN = 0;
    for (int dy = -1; dy <= 1; dy++) {
      for (int dx = -1; dx <= 1; dx++) {
        if (dx == 0 && dy == 0) continue;
        final xx = top.x + dx;
        final yy = top.y + dy;
        if (xx < 0 || yy < 0 || xx >= cols || yy >= rows) continue;
        final v = cells[yy * cols + xx];
        if (v.isNaN) continue;
        nbSum += v - m;
        nbN++;
      }
    }
    final nbMean = nbN == 0 ? 0.0 : nbSum / nbN;
    final isolated =
        nbN >= 3 && nbMean.abs() < 0.25 * top.deviation.abs();

    bool dipole = false;
    for (int dy = -3; dy <= 3 && !dipole; dy++) {
      for (int dx = -3; dx <= 3; dx++) {
        final xx = top.x + dx;
        final yy = top.y + dy;
        if (xx < 0 || yy < 0 || xx >= cols || yy >= rows) continue;
        final v = cells[yy * cols + xx];
        if (v.isNaN) continue;
        final d = v - m;
        if (d * top.deviation < 0 && d.abs() >= 0.3 * top.deviation.abs()) {
          dipole = true;
          break;
        }
      }
    }
    final widespread = hits.length > widespreadFrac * valid.length;

    double sc = math.min(55.0, contrast * 5) + coverage * 20;
    if (dipole && metal) sc += 15;
    if (isolated) sc -= 25;
    if (widespread) sc -= 20;
    final score = sc.clamp(0.0, 100.0).round();
    final belowLearned = learnedContrast != null && contrast < learnedContrast;
    final falseRisk = (isolated || widespread || level == 0 || belowLearned)
        ? 2
        : (coverage < 0.5 ? 1 : 0);

    return Insight(
      kind: metal ? 1 : 2,
      level: level,
      x: top.x,
      y: top.y,
      deviation: top.deviation,
      contrast: contrast,
      depthM: depth?.depthM,
      suggestView: metal ? 2 : 1,
      coverage: coverage,
      dipole: dipole,
      isolated: isolated,
      widespread: widespread,
      score: score,
      falseRisk: falseRisk,
      belowLearned: belowLearned,
    );
  }
}
