import 'dart:math' as math;
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';

/// Short beeps whose pitch follows the reading, so a scan can be followed by
/// ear without looking at the screen.
class ToneService {
  static AudioPlayer? _player;
  static final Map<int, Uint8List> _cache = <int, Uint8List>{};

  static Uint8List _wav(double hz) {
    const rate = 22050;
    const ms = 130;
    final n = rate * ms ~/ 1000;
    final data = ByteData(44 + n * 2);
    void str(int off, String s) {
      for (int i = 0; i < s.length; i++) {
        data.setUint8(off + i, s.codeUnitAt(i));
      }
    }

    str(0, 'RIFF');
    data.setUint32(4, 36 + n * 2, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    data.setUint32(16, 16, Endian.little);
    data.setUint16(20, 1, Endian.little);
    data.setUint16(22, 1, Endian.little);
    data.setUint32(24, rate, Endian.little);
    data.setUint32(28, rate * 2, Endian.little);
    data.setUint16(32, 2, Endian.little);
    data.setUint16(34, 16, Endian.little);
    str(36, 'data');
    data.setUint32(40, n * 2, Endian.little);
    for (int i = 0; i < n; i++) {
      final fade = math.min(1.0, math.min(i, n - i) / 300.0);
      final v = math.sin(2 * math.pi * hz * i / rate) * 0.6 * fade;
      data.setInt16(44 + i * 2, (v * 32767).round(), Endian.little);
    }
    return data.buffer.asUint8List();
  }

  /// [norm] is the reading relative to the background, about -1 (low) .. +1
  /// (high). The pitch goes from 400 Hz to 1600 Hz.
  static Future<void> beep(double norm) async {
    try {
      final level = (((norm.clamp(-1.0, 1.0) + 1) / 2) * 15).round();
      final bytes =
          _cache.putIfAbsent(level, () => _wav(400 + level * 80.0));
      final p = _player ??= AudioPlayer();
      await p.stop();
      await p.play(BytesSource(bytes));
    } catch (_) {}
  }
}
