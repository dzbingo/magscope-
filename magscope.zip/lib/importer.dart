import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'dsp.dart';
import 'ger_xml.dart';
import 'models.dart';

/// Reads a scan file of (almost) any known format and turns it into a
/// [ScanSession]. The format is detected from the content, not the extension:
///  * MagVision Pro session JSON, or a JSON array of rows
///  * GER3D XML
///  * Surfer ASCII grid (DSAA), Surfer 6 binary (DSBB), Surfer 7 binary (DSRB)
///  * ESRI ASCII grid (ncols / nrows header)
///  * XYZ point lists (space, comma, tab or semicolon separated, with or
///    without a header line, extra columns are ignored)
///  * CSV / text matrices (one row of values per line)
///  * a single column of values (laid out as a square grid when possible)
class ScanImporter {
  static const int _maxSide = 160;

  /// True for Surfer grids written by pwr-3d / GER-style apps: their file is
  /// the picture turned the other way (the file rows are the picture
  /// columns, read from the far side), so it is turned back on import.
  static bool pwrStyle = false;

  /// pwr-3d grids carry a recognisable signature: the x and y ranges are the
  /// plain cell indices (0 .. n-1) and the value-range line starts with a
  /// space. Files from Surfer, QGIS or our own export do not.
  static bool _looksPwr(String text) {
    final l = text.split(RegExp(r'\r?\n'));
    if (l.length < 6) return false;
    final dims = l[1].trim().split(RegExp(r'\s+'));
    if (dims.length < 2) return false;
    final nx = int.tryParse(dims[0]), ny = int.tryParse(dims[1]);
    if (nx == null || ny == null) return false;
    bool idx(String s, int n) {
      final p = s.trim().split(RegExp(r'\s+'));
      return p.length == 2 && p[0] == '0' && p[1] == '${n - 1}';
    }

    return idx(l[2], nx) && idx(l[3], ny) && l[4].startsWith(' ');
  }

  /// Whether the bytes are a Surfer grid (the only format where the
  /// orientation depends on the app that wrote it).
  static bool isSurfer(Uint8List b) {
    if (b.length < 4) return false;
    final tag = String.fromCharCodes(b.sublist(0, 4));
    return tag == 'DSAA' || tag == 'DSBB' || tag == 'DSRB';
  }

  /// Picture of a Surfer grid: standard (south row first) or pwr-3d style.
  static _Grid? _surferGrid(int cols, int rows, List<double> v) {
    if (!pwrStyle) return _grid(cols, rows, _flipRows(v, cols, rows));
    // result[i][j] = file[nc-1-j][nr-1-i]
    final nc = rows, nr = cols;
    final o = List<double>.filled(v.length, double.nan);
    for (int i = 0; i < nr; i++) {
      for (int j = 0; j < nc; j++) {
        o[i * nc + j] = v[(nc - 1 - j) * cols + (nr - 1 - i)];
      }
    }
    return _grid(nc, nr, o);
  }

  /// Returns null when nothing usable is found.
  static ScanSession? parse(Uint8List bytes, String name) {
    if (bytes.isEmpty) return null;
    try {
      if (_isV3d(bytes)) return _wrap(_v3d(bytes), name);
      if (bytes.length >= 4) {
        final tag = String.fromCharCodes(bytes.sublist(0, 4));
        if (tag == 'DSBB') return _wrap(_dsbb(bytes), name);
        if (tag == 'DSRB') return _wrap(_dsrb(bytes), name);
      }
      final text = _decode(bytes);
      final head = text.trimLeft();
      if (head.isEmpty) return null;
      // XML
      if (head.startsWith('<')) {
        final g = GerXml.parse(text, name);
        if (g != null) return g;
        return _wrap(_xmlNumbers(text), name);
      }
      // JSON
      if (head.startsWith('{') || head.startsWith('[')) {
        return _json(head, name);
      }
      if (head.startsWith('DSAA')) {
        pwrStyle = _looksPwr(head);
        try {
          return _wrap(_dsaa(text), name);
        } finally {
          pwrStyle = false;
        }
      }
      if (RegExp(r'^\s*ncols\s', caseSensitive: false).hasMatch(head)) {
        return _wrap(_esri(text), name);
      }
      return _wrap(_delimited(text), name);
    } catch (_) {
      return null;
    }
  }


  // ------------------------------------------------------------ OKM .v3d

  /// OKM "V3D" scan file (binary). Layout worked out from sample files, not
  /// from a specification: a text header (with UTF-16 "Device"/"Scan Mode"
  /// lines), then 36-byte records of little-endian float32: value, x, y and
  /// six more fields (zero or leftover bytes, ignored). x and y are whole
  /// cell indices from 0.
  static bool _isV3d(Uint8List b) {
    if (b.length < 600) return false;
    final head = String.fromCharCodes(b.sublist(0, 16));
    return head.contains('V3D.V3D');
  }

  static _Grid? _v3d(Uint8List b) {
    final bd = ByteData.sublistView(b);
    // the header length varies, so find the start where the rest of the file
    // is made of whole records that form one complete grid
    for (int start = 300; start < math.min(b.length - 36 * 4, 900); start++) {
      final rest = b.length - start;
      if (rest % 36 != 0) continue;
      final n = rest ~/ 36;
      int maxX = -1, maxY = -1;
      bool ok = true;
      final xs = List<int>.filled(n, 0), ys = List<int>.filled(n, 0);
      final vs = List<double>.filled(n, 0);
      for (int k = 0; k < n && ok; k++) {
        final o = start + 36 * k;
        final v = bd.getFloat32(o, Endian.little);
        final x = bd.getFloat32(o + 4, Endian.little);
        final y = bd.getFloat32(o + 8, Endian.little);
        if (!v.isFinite || !x.isFinite || !y.isFinite) {
          ok = false;
          break;
        }
        if (x < 0 || y < 0 || x > 400 || y > 400 || x != x.roundToDouble() ||
            y != y.roundToDouble()) {
          ok = false;
          break;
        }
        xs[k] = x.toInt();
        ys[k] = y.toInt();
        vs[k] = v;
        if (xs[k] > maxX) maxX = xs[k];
        if (ys[k] > maxY) maxY = ys[k];
      }
      if (!ok) continue;
      final cols = maxX + 1, rows = maxY + 1;
      if (cols < 2 || rows < 2 || cols * rows != n) continue;
      // OKM fills the points that were never measured (end of an unfinished
      // scan) with one repeated average value that is not a whole number:
      // those are treated as missing, not as readings
      int tail = 0;
      final lastV = vs[n - 1];
      if (lastV != lastV.roundToDouble()) {
        while (tail < n && (vs[n - 1 - tail] - lastV).abs() < 0.001) {
          tail++;
        }
      }
      if (tail >= 2) {
        for (int k = n - tail; k < n; k++) {
          vs[k] = double.nan;
        }
      }
      final cells = List<double>.filled(n, double.nan);
      final seen = List<bool>.filled(n, false);
      bool dup = false;
      for (int k = 0; k < n; k++) {
        // y = 0 is the south edge (row 0 of our grid is north); x = 0 is the
        // east edge: checked against one scan shown in OKM Visualizer 3D,
        // where six features all appeared mirrored left-right compared with
        // a plain west-to-east reading
        final idx = (rows - 1 - ys[k]) * cols + (cols - 1 - xs[k]);
        if (seen[idx]) {
          dup = true;
          break;
        }
        seen[idx] = true;
        cells[idx] = vs[k];
      }
      if (dup) continue;
      return _Grid(cols, rows, cells);
    }
    return null;
  }

  // ---------------------------------------------------------------- helpers

  static String _decode(Uint8List b) {
    if (b.length >= 2 && b[0] == 0xFF && b[1] == 0xFE) {
      final u = <int>[];
      for (int i = 2; i + 1 < b.length; i += 2) {
        u.add(b[i] | (b[i + 1] << 8));
      }
      return String.fromCharCodes(u);
    }
    if (b.length >= 2 && b[0] == 0xFE && b[1] == 0xFF) {
      final u = <int>[];
      for (int i = 2; i + 1 < b.length; i += 2) {
        u.add((b[i] << 8) | b[i + 1]);
      }
      return String.fromCharCodes(u);
    }
    var t = utf8.decode(b, allowMalformed: true);
    if (t.isNotEmpty && t.codeUnitAt(0) == 0xFEFF) t = t.substring(1);
    return t;
  }

  static bool _blank(double v) =>
      v.isNaN || v.isInfinite || v.abs() > 1e30 || v == -9999 || v == -99999;

  static final RegExp _numRe = RegExp(r'^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$');

  static double? _num(String s) {
    var t = s.trim();
    if (t.isEmpty) return null;
    if (!_numRe.hasMatch(t)) {
      // decimal comma ("12,5") only when the cell is otherwise a number
      final c = t.replaceAll(',', '.');
      if (!_numRe.hasMatch(c)) return null;
      t = c;
    }
    return double.tryParse(t);
  }

  /// Raw grid, row 0 = south (our convention).
  static _Grid? _grid(int cols, int rows, List<double> v) {
    if (cols < 2 || rows < 2 || v.length != cols * rows) return null;
    return _Grid(cols, rows, v.map((e) => _blank(e) ? double.nan : e).toList());
  }

  static ScanSession? _wrap(_Grid? g, String name) {
    if (g == null) return null;
    var grid = g._reduced(_maxSide);
    final valid = grid.cells.where((e) => !e.isNaN).toList();
    if (valid.length < 4) return null;
    return ScanSession(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name.isEmpty ? 'Import' : name,
      createdAt: DateTime.now(),
      source: 'ble',
      raw: valid,
      cols: grid.cols,
      rows: grid.rows,
      cells: grid.cells,
    );
  }

  // ------------------------------------------------------------------- JSON

  static ScanSession? _json(String text, String name) {
    final j = jsonDecode(text);
    if (j is Map<String, dynamic>) {
      if (j['cells'] is List && j['cols'] is num && j['rows'] is num) {
        final base = ScanSession.fromJson(<String, dynamic>{
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'name': name.isEmpty ? 'Import' : name,
          'createdAt': DateTime.now().toIso8601String(),
          'raw': <dynamic>[],
          ...j,
        });
        return base;
      }
      for (final k in <String>['data', 'values', 'grid', 'matrix', 'z']) {
        if (j[k] is List) return _json(jsonEncode(j[k]), name);
      }
      return null;
    }
    if (j is List && j.isNotEmpty) {
      if (j.first is List) {
        final rowsL = j
            .map((r) => (r as List)
                .map((e) => e is num ? e.toDouble() : double.nan)
                .toList())
            .toList();
        return _wrap(_fromRows(rowsL), name);
      }
      if (j.first is Map) {
        final pts = <List<double>>[];
        for (final e in j) {
          final m = e as Map;
          final x = _pick(m, const <String>['x', 'lon', 'lng', 'longitude']);
          final y = _pick(m, const <String>['y', 'lat', 'latitude']);
          final z = _pick(m, const <String>['z', 'value', 'v', 'val', 'field']);
          if (x != null && y != null && z != null) pts.add(<double>[x, y, z]);
        }
        return _wrap(_scatter(pts), name);
      }
      final flat = j.whereType<num>().map((e) => e.toDouble()).toList();
      return _wrap(_column(flat), name);
    }
    return null;
  }

  static double? _pick(Map m, List<String> keys) {
    for (final e in m.entries) {
      if (keys.contains(e.key.toString().toLowerCase()) && e.value is num) {
        return (e.value as num).toDouble();
      }
    }
    return null;
  }

  // --------------------------------------------------------- Surfer / ESRI

  static List<double> _tokens(String text) {
    final out = <double>[];
    for (final t in text.split(RegExp(r'[\s,;]+'))) {
      final d = _num(t);
      if (d != null) out.add(d);
    }
    return out;
  }

  /// Surfer files list the south row first; our row 0 is the north row.
  static List<double> _flipRows(List<double> v, int cols, int rows) {
    final o = List<double>.filled(v.length, double.nan);
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x++) {
        o[(rows - 1 - y) * cols + x] = v[y * cols + x];
      }
    }
    return o;
  }

  static _Grid? _dsaa(String text) {
    final lines = text.split(RegExp(r'\r?\n'));
    final body = lines.skip(1).join(' ');
    final t = _tokens(body);
    if (t.length < 6) return null;
    final cols = t[0].toInt(), rows = t[1].toInt();
    final data = t.sublist(8); // nx ny, x range, y range, z range, then the values
    if (data.length < cols * rows) return null;
    return _surferGrid(cols, rows, data.sublist(0, cols * rows));
  }

  static _Grid? _esri(String text) {
    final lines = text.split(RegExp(r'\r?\n'));
    int? cols, rows;
    double nodata = -9999;
    int i = 0;
    for (; i < lines.length; i++) {
      final p = lines[i].trim().split(RegExp(r'\s+'));
      if (p.length < 2 || _num(p[1]) == null) break;
      final k = p[0].toLowerCase();
      if (!RegExp(r'^[a-z_]+$').hasMatch(k)) break;
      final v = _num(p[1])!;
      if (k == 'ncols') cols = v.toInt();
      if (k == 'nrows') rows = v.toInt();
      if (k == 'nodata_value') nodata = v;
    }
    if (cols == null || rows == null) return null;
    final t = _tokens(lines.skip(i).join(' '));
    if (t.length < cols * rows) return null;
    // rows go from the north edge down, like our grid (row 0 = north)
    final v = List<double>.generate(
        cols * rows, (i) => t[i] == nodata ? double.nan : t[i]);
    return _grid(cols, rows, v);
  }

  static _Grid? _dsbb(Uint8List b) {
    if (b.length < 56) return null;
    final d = ByteData.sublistView(b);
    final nx = d.getInt16(4, Endian.little);
    final ny = d.getInt16(6, Endian.little);
    if (b.length < 56 + nx * ny * 4) return null;
    final v = List<double>.generate(
        nx * ny, (i) => d.getFloat32(56 + i * 4, Endian.little));
    return _surferGrid(nx, ny, v);
  }

  static _Grid? _dsrb(Uint8List b) {
    final d = ByteData.sublistView(b);
    int pos = 0;
    int? nr, nc;
    while (pos + 8 <= b.length) {
      final tag = String.fromCharCodes(b.sublist(pos, pos + 4));
      final size = d.getUint32(pos + 4, Endian.little);
      final body = pos + 8;
      if (tag == 'GRID' && body + 8 <= b.length) {
        nr = d.getUint32(body, Endian.little);
        nc = d.getUint32(body + 4, Endian.little);
      } else if (tag == 'DATA' && nr != null && nc != null) {
        if (body + nr * nc * 8 > b.length) return null;
        final v = List<double>.generate(
            nr * nc, (i) => d.getFloat64(body + i * 8, Endian.little));
        return _surferGrid(nc, nr, v);
      }
      pos = body + size;
    }
    return null;
  }

  // -------------------------------------------------------- text / numbers

  static _Grid? _xmlNumbers(String text) {
    // Generic XML: every element that holds only a number, grouped by the
    // parent element → rows.
    final rowsL = <List<double>>[];
    for (final m in RegExp(r'<(\w+)[^>]*>((?:\s*<\w+[^>]*>\s*[-+0-9.eE]+\s*</\w+>\s*)+)</\1>',
            dotAll: true)
        .allMatches(text)) {
      final vals = RegExp(r'>\s*([-+]?[0-9.]+(?:[eE][-+]?\d+)?)\s*<')
          .allMatches(m.group(2)!)
          .map((e) => double.tryParse(e.group(1)!) ?? double.nan)
          .toList();
      if (vals.length > 1) rowsL.add(vals);
    }
    return _fromRows(rowsL);
  }

  static _Grid? _delimited(String text) {
    final lines = text
        .split(RegExp(r'\r?\n'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty && !e.startsWith('#') && !e.startsWith('//'))
        .toList();
    if (lines.isEmpty) return null;
    final delim = _delim(lines);
    List<String> split(String l) => delim == null
        ? l.split(RegExp(r'\s+'))
        : l.split(delim).map((e) => e.trim()).toList();

    final table = lines.map(split).toList();
    // header: first line with non-numeric cells
    List<String>? header;
    int start = 0;
    if (table.first.any((c) => c.isNotEmpty && _num(c) == null)) {
      header = table.first.map((e) => e.toLowerCase()).toList();
      start = 1;
    }
    final body = table.skip(start).toList();
    if (body.isEmpty) return null;

    final nums = body
        .map((r) => r.map((c) => _num(c) ?? double.nan).toList())
        .toList();
    final widths = nums.map((r) => r.length).toSet();
    final width = nums.map((r) => r.length).reduce(math.max);

    // XYZ: named columns, or 3 columns whose first two repeat
    if (header != null) {
      int ix = header.indexWhere((h) => h == 'x' || h.startsWith('x ') || h == 'lon' || h == 'longitude' || h == 'easting');
      int iy = header.indexWhere((h) => h == 'y' || h.startsWith('y ') || h == 'lat' || h == 'latitude' || h == 'northing');
      int iz = header.indexWhere((h) => h == 'z' || h.startsWith('z ') || h == 'value' || h == 'field' || h == 'mag' || h == 'nt');
      if (ix >= 0 && iy >= 0 && iz >= 0) {
        return _scatter(_cols(nums, ix, iy, iz));
      }
    }
    if (width >= 3 && widths.length <= 2 && nums.length > 6) {
      final c3 = _cols(nums, 0, 1, 2);
      if (c3.length > 6 && _looksXyz(c3, width)) return _scatter(c3);
    }
    // matrix
    if (width >= 2 && nums.length >= 2) return _fromRows(nums);
    if (width == 1) {
      return _column(nums.map((r) => r.first).toList());
    }
    return null;
  }

  static String? _delim(List<String> lines) {
    final sample = lines.take(20).toList();
    for (final d in <String>[';', '\t', ',']) {
      final counts = sample.map((l) => d.allMatches(l).length).toSet();
      if (counts.length == 1 && counts.first > 0) return d;
    }
    // comma plus spaces (e.g. "1, 2, 3")
    final c = sample.map((l) => ','.allMatches(l).length).toSet();
    if (c.length <= 2 && c.every((e) => e > 0)) return ',';
    return null; // whitespace
  }

  static List<List<double>> _cols(List<List<double>> t, int a, int b, int c) {
    final out = <List<double>>[];
    for (final r in t) {
      if (r.length <= math.max(a, math.max(b, c))) continue;
      final x = r[a], y = r[b], z = r[c];
      if (x.isNaN || y.isNaN) continue;
      out.add(<double>[x, y, z]);
    }
    return out;
  }

  /// XYZ lists repeat their x and y values; a matrix almost never does that.
  static bool _looksXyz(List<List<double>> p, int width) {
    final xs = p.map((e) => e[0]).toSet().length;
    final ys = p.map((e) => e[1]).toSet().length;
    if (width > 3) return xs * ys >= p.length * 0.8 && xs < p.length * 0.6;
    return xs < p.length * 0.6 || ys < p.length * 0.6;
  }

  static _Grid? _fromRows(List<List<double>> rowsL) {
    if (rowsL.length < 2) return null;
    final cols = rowsL.map((r) => r.length).reduce(math.max);
    if (cols < 2) return null;
    final rows = rowsL.length;
    final v = List<double>.filled(cols * rows, double.nan);
    // text matrices are written top (north) first as readable tables, but
    // MagVision Pro CSV writes the south row first; keep file order, which
    // round-trips our own exports, and let the user flip nothing.
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < rowsL[r].length; c++) {
        v[r * cols + c] = rowsL[r][c];
      }
    }
    return _grid(cols, rows, v);
  }

  static _Grid? _column(List<double> vals) {
    final n = vals.length;
    if (n < 4) return null;
    final side = math.sqrt(n).round();
    if (side * side == n) return _grid(side, side, vals);
    // try the most square factor pair
    for (int c = side; c >= 2; c--) {
      if (n % c == 0) return _grid(n ~/ c, c, vals);
    }
    return null;
  }

  /// Scattered or regular points → grid. Distinct x/y values are used when the
  /// points lie on a lattice; otherwise the points are binned.
  static _Grid? _scatter(List<List<double>> p) {
    if (p.length < 4) return null;
    double minX = p.first[0], maxX = minX, minY = p.first[1], maxY = minY;
    for (final e in p) {
      minX = math.min(minX, e[0]);
      maxX = math.max(maxX, e[0]);
      minY = math.min(minY, e[1]);
      maxY = math.max(maxY, e[1]);
    }
    final dx = maxX - minX, dy = maxY - minY;
    if (dx <= 0 || dy <= 0) return null;
    final tolX = dx * 1e-6, tolY = dy * 1e-6;

    List<double> uniq(List<double> v, double tol) {
      final s = List<double>.from(v)..sort();
      final u = <double>[];
      for (final e in s) {
        if (u.isEmpty || e - u.last > tol) u.add(e);
      }
      return u;
    }

    final ux = uniq(p.map((e) => e[0]).toList(), tolX);
    final uy = uniq(p.map((e) => e[1]).toList(), tolY);
    int cols, rows;
    final lattice = ux.length * uy.length <= p.length * 4 &&
        ux.length <= 400 &&
        uy.length <= 400;
    if (lattice) {
      cols = ux.length;
      rows = uy.length;
    } else {
      final n = math.sqrt(p.length).ceil();
      final asp = dx / dy;
      cols = (n * math.sqrt(asp)).round().clamp(2, 200).toInt();
      rows = (n / math.sqrt(asp)).round().clamp(2, 200).toInt();
    }
    final sum = List<double>.filled(cols * rows, 0);
    final cnt = List<int>.filled(cols * rows, 0);
    for (final e in p) {
      if (e[2].isNaN || _blank(e[2])) continue;
      final cx = lattice
          ? _nearest(ux, e[0])
          : ((e[0] - minX) / dx * cols).floor().clamp(0, cols - 1).toInt();
      final cy = lattice
          ? _nearest(uy, e[1])
          : ((e[1] - minY) / dy * rows).floor().clamp(0, rows - 1).toInt();
      final ry = rows - 1 - cy; // larger y = north = top row
      sum[ry * cols + cx] += e[2];
      cnt[ry * cols + cx]++;
    }
    final v = List<double>.generate(
        cols * rows, (i) => cnt[i] == 0 ? double.nan : sum[i] / cnt[i]);
    if (!lattice) _fill(v, cols, rows);
    return _grid(cols, rows, v);
  }

  static int _nearest(List<double> u, double x) {
    int lo = 0, hi = u.length - 1;
    while (lo < hi) {
      final m = (lo + hi) ~/ 2;
      if (u[m] < x) {
        lo = m + 1;
      } else {
        hi = m;
      }
    }
    if (lo > 0 && (x - u[lo - 1]).abs() < (u[lo] - x).abs()) return lo - 1;
    return lo;
  }

  /// Fills small gaps of binned data with the mean of valid neighbours.
  static void _fill(List<double> v, int cols, int rows) {
    for (int pass = 0; pass < 3; pass++) {
      final o = List<double>.from(v);
      for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
          if (!o[y * cols + x].isNaN) continue;
          double s = 0;
          int n = 0;
          for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
              final nx = x + dx, ny = y + dy;
              if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
              final e = o[ny * cols + nx];
              if (e.isNaN) continue;
              s += e;
              n++;
            }
          }
          if (n >= 3) v[y * cols + x] = s / n;
        }
      }
    }
  }
}

class _Grid {
  _Grid(this.cols, this.rows, this.cells);
  final int cols;
  final int rows;
  final List<double> cells;

  /// Block-averages grids larger than [max] cells per side.
  _Grid _reduced(int max) {
    if (cols <= max && rows <= max) return this;
    final f = math.max((cols / max).ceil(), (rows / max).ceil());
    final nc = (cols / f).ceil(), nr = (rows / f).ceil();
    final out = List<double>.filled(nc * nr, double.nan);
    for (int y = 0; y < nr; y++) {
      for (int x = 0; x < nc; x++) {
        final blk = <double>[];
        for (int j = y * f; j < math.min(rows, (y + 1) * f); j++) {
          for (int i = x * f; i < math.min(cols, (x + 1) * f); i++) {
            final e = cells[j * cols + i];
            if (!e.isNaN) blk.add(e);
          }
        }
        if (blk.isNotEmpty) out[y * nc + x] = medianOf(blk);
      }
    }
    return _Grid(nc, nr, out);
  }
}
