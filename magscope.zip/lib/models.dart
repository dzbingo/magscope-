import 'geo.dart';

/// One saved scan: the raw sample stream plus the grid of cell averages.
class ScanSession {
  ScanSession({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.source,
    required this.raw,
    required this.cols,
    required this.rows,
    required this.cells,
    this.geo,
  });

  final String id;
  final String name;
  final DateTime createdAt;
  final String source;
  final List<double> raw;
  final int cols;
  final int rows;
  final List<double> cells;
  final ScanGeoLocation? geo;

  ScanSession withName(String newName) => ScanSession(
        id: id,
        name: newName,
        createdAt: createdAt,
        source: source,
        raw: raw,
        cols: cols,
        rows: rows,
        cells: cells,
        geo: geo,
      );

  ScanSession withGeo(ScanGeoLocation g) => ScanSession(
        id: id,
        name: name,
        createdAt: createdAt,
        source: source,
        raw: raw,
        cols: cols,
        rows: rows,
        cells: cells,
        geo: g,
      );

  int get filledCells => cells.where((e) => !e.isNaN).length;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'source': source,
        'cols': cols,
        'rows': rows,
        'raw': raw.map((e) => e.isFinite ? e : 0.0).toList(),
        'cells': cells.map((e) => e.isNaN ? null : e).toList(),
        if (geo != null) 'geo': geo!.toJson(),
      };

  factory ScanSession.fromJson(Map<String, dynamic> j) {
    return ScanSession(
      id: j['id'] as String,
      name: j['name'] as String,
      createdAt: DateTime.parse(j['createdAt'] as String),
      source: (j['source'] as String?) ?? 'sim',
      cols: (j['cols'] as num).toInt(),
      rows: (j['rows'] as num).toInt(),
      raw: (j['raw'] as List<dynamic>)
          .map((e) => (e as num).toDouble())
          .toList(),
      cells: (j['cells'] as List<dynamic>)
          .map((e) => e == null ? double.nan : (e as num).toDouble())
          .toList(),
      geo: j['geo'] is Map<String, dynamic>
          ? ScanGeoLocation.fromJson(j['geo'] as Map<String, dynamic>)
          : null,
    );
  }
}
