import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:path_provider/path_provider.dart';

import 'dsp.dart';
import 'insight.dart';
import 'state.dart';
import 'widgets.dart';

/// Builds a self-contained HTML report (open it in a browser; "Print > Save as
/// PDF" turns it into a PDF). HTML is used because it shows Arabic correctly.
class ReportBuilder {
  static Future<Uint8List?> _heatPng(
      List<double> cells, int cols, int rows, double lo, double hi) async {
    const w = 720.0;
    final h = w * rows / cols;
    final rec = ui.PictureRecorder();
    final canvas = ui.Canvas(rec);
    HeatPainter(cells: cells, cols: cols, rows: rows, lo: lo, hi: hi)
        .paint(canvas, ui.Size(w, h));
    final img = await rec.endRecording().toImage(w.round(), h.round());
    final bd = await img.toByteData(format: ui.ImageByteFormat.png);
    return bd?.buffer.asUint8List();
  }

  static String _esc(String v) => v
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  /// Writes the report and returns the file path.
  static Future<String> create(AppState s) async {
    final cells = s.displayCells;
    final st = statsOf(cells);
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }
    final png = await _heatPng(cells, s.cols, s.rows, lo, hi);
    final ins = InsightEngine.analyze(
      s.cells,
      s.cols,
      s.rows,
      sensitivity: s.effSens,
      absThreshold: s.manualThr ? s.thrUT : null,
      cellM: s.cellCm / 100.0,
      learnedContrast: s.learnedContrast,
    );
    final hits = findCellAnomalies(s.cells, s.cols, s.rows,
        s.effSens + 1.0,
        absThreshold: s.manualThr ? s.thrUT : null);
    final noise = InsightEngine.noiseOf(s.cells);
    final rtl = s.locale.languageCode == 'ar';
    final now = DateTime.now();

    final b = StringBuffer();
    b.writeln('<!DOCTYPE html><html lang="${s.locale.languageCode}" dir="${rtl ? 'rtl' : 'ltr'}"><head><meta charset="utf-8">');
    b.writeln('<meta name="viewport" content="width=device-width, initial-scale=1">');
    b.writeln('<title>${_esc(s.t('report_title'))}</title><style>'
        'body{font-family:sans-serif;margin:18px;color:#111;background:#fff}'
        'h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:18px 0 6px;border-bottom:2px solid #ccc;padding-bottom:3px}'
        'table{border-collapse:collapse;width:100%;font-size:14px}td,th{border:1px solid #ccc;padding:5px 8px;text-align:start}'
        'th{background:#f0f0f0}img{max-width:100%;border:1px solid #ccc}.m{color:#666;font-size:12px}'
        '</style></head><body>');
    b.writeln('<h1>${_esc(s.t('app_name'))} - ${_esc(s.t('report_title'))}</h1>');
    b.writeln('<div class="m">${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} '
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}</div>');

    b.writeln('<h2>${_esc(s.t('scan_setup'))}</h2><table>');
    b.writeln('<tr><th>${_esc(s.t('columns'))} x ${_esc(s.t('rows'))}</th><td dir="ltr">${s.cols} x ${s.rows}</td></tr>');
    b.writeln('<tr><th>${_esc(s.t('cell_size'))}</th><td dir="ltr">${s.cellCm.toStringAsFixed(0)} cm</td></tr>');
    b.writeln('<tr><th>${_esc(s.t('coverage'))}</th><td dir="ltr">${(ins.coverage * 100).toStringAsFixed(0)}%</td></tr>');
    final g = s.gridGeo;
    if (g != null) {
      b.writeln('<tr><th>GPS</th><td dir="ltr">${g.latitude.toStringAsFixed(6)}, ${g.longitude.toStringAsFixed(6)} (±${g.accuracy.toStringAsFixed(0)} m)</td></tr>');
    }
    b.writeln('</table>');

    b.writeln('<h2>${_esc(s.t('stats'))}</h2><table dir="ltr">');
    b.writeln('<tr><th>min</th><th>max</th><th>mean</th><th>std</th></tr>');
    b.writeln('<tr><td>${st.min.toStringAsFixed(2)}</td><td>${st.max.toStringAsFixed(2)}</td><td>${st.mean.toStringAsFixed(2)}</td><td>${st.std.toStringAsFixed(2)}</td></tr></table>');

    if (png != null) {
      b.writeln('<h2>${_esc(s.t('view_2d'))}</h2>');
      b.writeln('<img alt="map" src="data:image/png;base64,${base64Encode(png)}">');
      b.writeln('<div class="m" dir="ltr">${lo.toStringAsFixed(2)} ... ${hi.toStringAsFixed(2)} uT</div>');
    }

    b.writeln('<h2>${_esc(s.t('insight'))}</h2>');
    if (ins.kind <= 0) {
      b.writeln('<p>${_esc(ins.kind == -1 ? s.t('insight_low_data') : s.t('insight_none'))}</p>');
    } else {
      b.writeln('<p><b>${_esc(s.t(ins.kind == 1 ? 'insight_metal' : 'insight_void'))}</b></p>');
      b.writeln('<p dir="ltr">${_esc(s.t('target_score'))}: ${ins.score}/100 &nbsp; ${_esc(s.t('false_risk'))}: ${_esc(s.t('risk_${ins.falseRisk}'))}</p>');
      if (ins.dipole) b.writeln('<p class="m">${_esc(s.t('insight_dipole'))}</p>');
      if (ins.isolated) b.writeln('<p class="m">${_esc(s.t('insight_isolated'))}</p>');
      if (ins.widespread) b.writeln('<p class="m">${_esc(s.t('insight_widespread'))}</p>');
    }

    if (hits.isNotEmpty) {
      b.writeln('<h2>${_esc(s.t('anomalies'))}</h2><table dir="ltr">');
      b.writeln('<tr><th>#</th><th>${_esc(s.t('cell'))}</th><th>${_esc(s.t('kind_metal'))} / ${_esc(s.t('kind_void'))}</th><th>dev (uT)</th><th>${_esc(s.t('contrast'))}</th><th>${_esc(s.t('depth'))} (m)</th></tr>');
      int k = 1;
      for (final h in hits.take(15)) {
        final de = estimateDepth(
            s.cells, s.cols, s.rows, h.x, h.y, s.cellCm / 100.0);
        b.writeln('<tr><td>${k++}</td><td>${h.x + 1}, ${h.y + 1}</td>'
            '<td>${_esc(h.deviation >= 0 ? s.t('kind_metal') : s.t('kind_void'))}</td>'
            '<td>${h.deviation >= 0 ? '+' : ''}${h.deviation.toStringAsFixed(2)}</td>'
            '<td>${(h.deviation.abs() / math.max(noise, 1e-6)).toStringAsFixed(1)}x</td>'
            '<td>${de == null ? '-' : '~${de.depthM.toStringAsFixed(2)}'}</td></tr>');
      }
      b.writeln('</table>');
    }

    b.writeln('<p class="m">${_esc(s.t('report_disclaimer'))}</p>');
    b.writeln('</body></html>');

    Directory? ext;
    try {
      ext = await getExternalStorageDirectory();
    } catch (_) {}
    final base = ext ?? await getApplicationDocumentsDirectory();
    final path = '${base.path}/Sniper-Dz_report_${stamp(now)}.html';
    await File(path).writeAsString(b.toString());
    return path;
  }
}
