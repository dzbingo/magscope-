import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../report.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Advanced tools: compare two scans, drift correction, field learning and
/// the HTML report.
class ProTools extends StatefulWidget {
  const ProTools({super.key});

  @override
  State<ProTools> createState() => _ProToolsState();
}

class _ProToolsState extends State<ProTools> {
  bool _busy = false;

  Future<void> _report(AppState s) async {
    setState(() => _busy = true);
    try {
      final path = await ReportBuilder.create(s);
      await Share.shareXFiles(<XFile>[XFile(path, mimeType: 'text/html')]);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(s.t('share_failed'))));
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  Widget _title(String text) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 2),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)),
      );

  Widget _hint(String text) =>
      Text(text, style: TextStyle(color: Pal.muted, fontSize: 11));

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final candidates = <ScanSession>[
      for (final e in s.sessions)
        if (e.cols == s.cols && e.rows == s.rows) e
    ];
    String? current;
    for (final e in candidates) {
      if (s.compareRef != null && e.id == s.compareRef!.id) current = e.id;
    }
    final found = s.learnRecs.where((r) => r.found).length;
    final fake = s.learnRecs.length - found;
    final thr = s.learnedContrast;

    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('pro_tools')),
          _title(s.t('compare_title')),
          _hint(s.t('compare_hint')),
          Row(
            children: <Widget>[
              Expanded(
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: current,
                  hint: Text(candidates.isEmpty
                      ? s.t('compare_empty')
                      : s.t('compare_none')),
                  items: <DropdownMenuItem<String>>[
                    for (final e in candidates)
                      DropdownMenuItem<String>(
                        value: e.id,
                        child: Text(e.name, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (String? id) {
                    for (final e in candidates) {
                      if (e.id == id) {
                        s.setCompare(e);
                        s.setGridView(4);
                      }
                    }
                  },
                ),
              ),
              if (s.compareRef != null)
                IconButton(
                  tooltip: s.t('compare_clear'),
                  icon: const Icon(Icons.close),
                  onPressed: () => s.setCompare(null),
                ),
            ],
          ),
          const Divider(),
          _title(s.t('drift_title')),
          _hint(s.t('drift_hint')),
          Row(
            children: <Widget>[
              Expanded(
                child: Text('${s.t('drift_refs')}: ${s.driftRefs.length}'),
              ),
              Switch(
                value: s.driftOn,
                onChanged: s.driftRefs.length >= 2 ? s.setDriftOn : null,
              ),
              TextButton(
                onPressed: s.driftRefs.isEmpty ? null : s.clearReferences,
                child: Text(s.t('clear')),
              ),
            ],
          ),
          const Divider(),
          _title(s.t('learn_title')),
          _hint(s.t('learn_hint')),
          const SizedBox(height: 4),
          Text('${s.t('learn_found')}: $found     ${s.t('learn_fake')}: $fake'),
          Text(
            thr == null
                ? s.t('learn_need')
                : '${s.t('learn_threshold')}: ${thr.toStringAsFixed(1)}x',
            style: TextStyle(color: thr == null ? Pal.muted : Pal.good),
          ),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton(
              onPressed: s.learnRecs.isEmpty ? null : s.resetLearning,
              child: Text(s.t('learn_reset')),
            ),
          ),
          const Divider(),
          FilledButton.tonalIcon(
            onPressed: _busy ? null : () => _report(s),
            icon: _busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.description_outlined),
            label: Text(s.t('report_btn')),
          ),
          const SizedBox(height: 4),
          _hint(s.t('report_hint')),
        ],
      ),
    );
  }
}
