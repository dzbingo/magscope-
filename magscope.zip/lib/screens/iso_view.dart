import 'package:flutter/material.dart';

import '../dsp.dart';
import '../satellite.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Puts the satellite picture (if loaded and switched on) under a heat map.
Widget withSatBackdrop(AppState s, Widget heat) {
  final img = s.satImage;
  if (!s.satOn || img == null) return heat;
  return Stack(
    fit: StackFit.expand,
    children: <Widget>[
      Opacity(
        opacity: s.satOpacity,
        child: RawImage(image: img, fit: BoxFit.fill),
      ),
      Opacity(opacity: 0.6, child: heat),
    ],
  );
}

/// Strongest targets with a rough depth, for the 3D "ground sheet" view.
List<DepthPin> depthPinsFor(AppState s) {
  final hits = findCellAnomalies(
      s.cells, s.cols, s.rows, s.filters.sensitivity + 1.0,
      absThreshold: s.manualThr ? s.thrUT : null);
  final out = <DepthPin>[];
  for (final h in hits.take(4)) {
    final d = estimateDepth(s.cells, s.cols, s.rows, h.x, h.y, s.cellCm / 100.0);
    if (d == null) continue;
    out.add(DepthPin(h.x, h.y, d.depthM, h.deviation > 0));
  }
  return out;
}

/// 3D view controlled only by fingers: drag sideways to rotate, drag up or
/// down to change the viewing angle, pinch to zoom, double tap to reset.
class Iso3DView extends StatefulWidget {
  const Iso3DView({
    super.key,
    required this.cells,
    required this.lo,
    required this.hi,
    this.height = 340,
    this.solid = false,
  });

  final List<double> cells;
  final double lo;
  final double hi;
  final double height;
  final bool solid;

  @override
  State<Iso3DView> createState() => _Iso3DViewState();
}

class _Iso3DViewState extends State<Iso3DView> {
  double _angle = 0.6;
  double _tilt = 0.5;
  double _zoom = 1.0;
  double _baseZoom = 1.0;
  bool _ground = true;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final showImg = s.satOn && s.satImage != null;
    return Column(
      children: <Widget>[
        SizedBox(
          height: widget.height,
          width: double.infinity,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onDoubleTap: () => setState(() {
              _zoom = 1.0;
              _angle = 0.6;
              _tilt = 0.5;
            }),
            onScaleStart: (ScaleStartDetails d) => _baseZoom = _zoom,
            onScaleUpdate: (ScaleUpdateDetails d) {
              setState(() {
                _zoom = (_baseZoom * d.scale).clamp(0.6, 4.0).toDouble();
                _angle += d.focalPointDelta.dx * 0.012 + d.rotation * 0.02;
                _tilt = (_tilt + d.focalPointDelta.dy * 0.003)
                    .clamp(0.22, 0.9)
                    .toDouble();
              });
            },
            child: ClipRect(
              child: Transform.scale(
                scale: _zoom,
                child: CustomPaint(
                  painter: IsoPainter(
                    cells: widget.cells,
                    cols: s.cols,
                    rows: s.rows,
                    lo: widget.lo,
                    hi: widget.hi,
                    angle: _angle,
                    heightScale: 1.0,
                    tilt: _tilt,
                    solid: widget.solid,
                    showGround: _ground,
                    groundImage: showImg ? s.satImage : null,
                    groundOpacity: s.satOpacity,
                    pins: _ground ? depthPinsFor(s) : const <DepthPin>[],
                    cellM: s.cellCm / 100.0,
                    groundLabel: s.t('ground_level'),
                  ),
                  size: Size.infinite,
                ),
              ),
            ),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: Text(s.t('show_ground')),
          subtitle: Text(s.t('ground_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          value: _ground,
          onChanged: (bool v) => setState(() => _ground = v),
        ),
        Text(s.t('finger_hint'),
            textAlign: TextAlign.center,
            style: TextStyle(color: Pal.muted, fontSize: 11)),
      ],
    );
  }
}

/// Load / show the satellite picture and set its transparency.
class SatelliteControls extends StatelessWidget {
  const SatelliteControls({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final has = s.satImage != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(s.t('satellite'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            FilledButton.tonalIcon(
              onPressed: s.satLoading ? null : s.loadSatellite,
              icon: s.satLoading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.satellite_alt),
              label: Text(has ? s.t('sat_reload') : s.t('sat_load')),
            ),
          ],
        ),
        if (s.satError != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(s.t(s.satError!),
                style: TextStyle(color: Pal.bad, fontSize: 12)),
          ),
        if (has) ...<Widget>[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: Text(s.t('sat_show')),
            value: s.satOn,
            onChanged: s.setSatOn,
          ),
          Row(
            children: <Widget>[
              Text(s.t('sat_opacity'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
              Expanded(
                child: Slider(
                  value: s.satOpacity,
                  min: 0,
                  max: 1,
                  onChanged: s.setSatOpacity,
                ),
              ),
              SizedBox(
                width: 40,
                child: Num('${(s.satOpacity * 100).round()}%',
                    style: TextStyle(color: Pal.muted, fontSize: 11)),
              ),
            ],
          ),
          Text(SatelliteLoader.attribution,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 10)),
        ],
        const SizedBox(height: 4),
        Text(s.t('sat_hint'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
      ],
    );
  }
}
