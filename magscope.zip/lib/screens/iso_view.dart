import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../anomaly.dart';

import '../dsp.dart';
import '../satellite.dart';
import '../soil.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Puts the satellite picture (if loaded and switched on) under a heat map.
Widget withSatBackdrop(AppState s, Widget heat) {
  final img = s.satImage;
  if (!s.satOn || img == null) return heat;
  return Stack(
    fit: StackFit.expand,
    children: <Widget>[
      Opacity(
        opacity: s.satOpacity,
        child: RawImage(image: img, fit: BoxFit.fill),
      ),
      Opacity(opacity: 0.6, child: heat),
    ],
  );
}

/// Targets used for depth: the confident detections first, then every other
/// clear blob (metal or void) that is at least 30% as strong as the strongest
/// one, so a picture with a metal, a void and a second metal gets three
/// depths and not just one.
List<CellAnomaly> depthTargets(AppState s) {
  final hits = s.gridAnomalies;
  final out = <CellAnomaly>[...hits];
  final r = math.max(2, (math.max(s.cols, s.rows) * 0.08).round());
  double top = 0;
  for (final h in hits) {
    top = math.max(top, h.deviation.abs());
  }
  final more = Detect.find(s.corrected, s.cols, s.rows, 1.2);
  if (top == 0 && more.isNotEmpty) top = more.first.deviation.abs();
  for (final m in more) {
    if (out.length >= 10) break;
    if (m.deviation.abs() < 0.3 * top) continue;
    bool near = false;
    for (final o in out) {
      if ((o.x - m.x).abs() <= r && (o.y - m.y).abs() <= r) {
        near = true;
        break;
      }
    }
    if (!near) out.add(m);
  }
  if (out.isNotEmpty) return out;
  final res = Detect.residual(s.corrected, s.cols, s.rows);
  int bi = -1;
  double bs = 0, bd = 0;
  for (int i = 0; i < res.length; i++) {
    final v = res[i];
    if (v.isNaN) continue;
    final sc = v.abs() * (v < 0 ? Detect.voidBias : 1.0);
    if (sc > bs) {
      bs = sc;
      bd = v;
      bi = i;
    }
  }
  if (bi < 0) return out;
  return <CellAnomaly>[CellAnomaly(bi % s.cols, bi ~/ s.cols, bd)];
}

/// Strongest targets with a rough depth, for the 3D "ground sheet" view.
List<DepthPin> depthPinsFor(AppState s) {
  final hits = depthTargets(s);
  final out = <DepthPin>[];
  for (final h in hits.take(10)) {
    final d = estimateDepth(s.corrected, s.cols, s.rows, h.x, h.y, s.cellCm / 100.0);
    if (d == null) continue;
    out.add(DepthPin(h.x, h.y, d.depthM, h.deviation > 0));
  }
  return out;
}

/// 3D view controlled only by fingers: drag sideways to rotate, drag up or
/// down to change the viewing angle, pinch to zoom, double tap to reset.
class Iso3DView extends StatefulWidget {
  const Iso3DView({
    super.key,
    required this.cells,
    required this.lo,
    required this.hi,
    this.height,
    this.solid = false,
    this.showPins = false,
  });

  final List<double> cells;
  final double lo;
  final double hi;
  /// Fixed height, or null to fill the space the parent gives.
  final double? height;

  /// Solid mode: the map sits on a block of layered soil with the ground sheet.
  final bool solid;

  /// Show the estimated depth of the strongest targets on the surface.
  final bool showPins;

  @override
  State<Iso3DView> createState() => _Iso3DViewState();
}

class _Iso3DViewState extends State<Iso3DView> {
  double _angle = 0.6; // spin around the vertical axis, unlimited
  double _pitch = 0.9; // viewing elevation, unlimited (negative = from below)
  double _roll = 0.0; // twist of the whole picture
  double _zoom = 1.0;
  double _hs = 1.0; // height exaggeration
  double _baseZoom = 1.0;
  double _baseRoll = 0.0;

  void _view(double yaw, double pitch) => setState(() {
        _angle = yaw;
        _pitch = pitch;
        _roll = 0.0;
      });

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final showImg = widget.solid && s.satOn && s.satImage != null;
    final area = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onDoubleTap: () => setState(() {
        _zoom = 1.0;
        _angle = 0.6;
        _pitch = 0.9;
        _roll = 0.0;
      }),
      onScaleStart: (ScaleStartDetails d) {
        _baseZoom = _zoom;
        _baseRoll = _roll;
      },
      onScaleUpdate: (ScaleUpdateDetails d) {
        setState(() {
          _zoom = (_baseZoom * d.scale).clamp(0.4, 8.0).toDouble();
          if (d.pointerCount >= 2) {
            _roll = _baseRoll + d.rotation;
          }
          // one finger: free orbit in every direction
          _angle += d.focalPointDelta.dx * 0.012;
          _pitch += d.focalPointDelta.dy * 0.012;
          const tau = 6.283185307179586;
          if (_pitch > 3.14159) _pitch -= tau;
          if (_pitch < -3.14159) _pitch += tau;
          if (_angle > tau) _angle -= tau;
          if (_angle < -tau) _angle += tau;
        });
      },
      child: ClipRect(
        child: Transform.rotate(
          angle: _roll,
          child: Transform.scale(
            scale: _zoom,
            child: CustomPaint(
              painter: IsoPainter(
                cells: widget.cells,
                cols: s.cols,
                rows: s.rows,
                lo: widget.lo,
                hi: widget.hi,
                angle: _angle,
                heightScale: _hs,
                pitch: _pitch,
                solid: false,
                block: widget.solid,
                showGround: widget.solid || (s.under && !widget.solid),
                under: s.under && !widget.solid,
                groundImage: showImg ? s.satImage : null,
                groundOpacity: s.satOpacity,
                pins: (widget.solid || widget.showPins || s.under)
                    ? depthPinsFor(s)
                    : const <DepthPin>[],
                cellM: s.cellCm / 100.0,
                groundLabel: s.t('ground_level'),
              ),
              size: Size.infinite,
            ),
          ),
        ),
      ),
    );
    final h = widget.height;
    final withSlider = Stack(
      children: <Widget>[
        Positioned.fill(child: area),
        Positioned(
          left: 12,
          right: 12,
          bottom: 2,
          child: Row(
            children: <Widget>[
              SegmentedButton<bool>(
                showSelectedIcon: false,
                style: const ButtonStyle(visualDensity: VisualDensity.compact),
                segments: <ButtonSegment<bool>>[
                  ButtonSegment<bool>(
                      value: true,
                      label: Text(s.t('mode_under'),
                          style: const TextStyle(fontSize: 11))),
                  ButtonSegment<bool>(
                      value: false,
                      label: Text(s.t('mode_geo'),
                          style: const TextStyle(fontSize: 11))),
                ],
                selected: <bool>{s.under},
                onSelectionChanged: (Set<bool> v) => s.setUnder(v.first),
              ),
              const SizedBox(width: 6),
              Icon(Icons.height, size: 16, color: Pal.muted),
              Expanded(
                child: Slider(
                  value: _hs,
                  min: 0.1,
                  max: 1.5,
                  onChanged: (double v) => setState(() => _hs = v),
                ),
              ),
            ],
          ),
        ),
      ],
    );
    return h == null
        ? SizedBox.expand(child: withSlider)
        : SizedBox(height: h, width: double.infinity, child: withSlider);
  }
}

/// Load / show the satellite picture and set its transparency.
class SatelliteControls extends StatelessWidget {
  const SatelliteControls({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final has = s.satImage != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(s.t('satellite'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
            FilledButton.tonalIcon(
              onPressed: s.satLoading ? null : s.loadSatellite,
              icon: s.satLoading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.satellite_alt),
              label: Text(has ? s.t('sat_reload') : s.t('sat_load')),
            ),
          ],
        ),
        if (s.satError != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(s.t(s.satError!),
                style: TextStyle(color: Pal.bad, fontSize: 12)),
          ),
        if (has) ...<Widget>[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: Text(s.t('sat_show')),
            value: s.satOn,
            onChanged: s.setSatOn,
          ),
          Row(
            children: <Widget>[
              Text(s.t('sat_opacity'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
              Expanded(
                child: Slider(
                  value: s.satOpacity,
                  min: 0,
                  max: 1,
                  onChanged: s.setSatOpacity,
                ),
              ),
              SizedBox(
                width: 40,
                child: Num('${(s.satOpacity * 100).round()}%',
                    style: TextStyle(color: Pal.muted, fontSize: 11)),
              ),
            ],
          ),
          Text(SatelliteLoader.attribution,
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 10)),
        ],
        const SizedBox(height: 4),
        Text(s.t('sat_hint'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
      ],
    );
  }
}

/// Text for every square: the reading, or the estimated depth of targets.
List<String?>? cellLabelsFor(AppState s, List<double> cells) {
  if (s.labelMode == 0) return null;
  final out = List<String?>.filled(s.cols * s.rows, null);
  if (s.labelMode == 1) {
    // the real measured values (not smoothed), as whole numbers when the
    // device sends whole numbers
    final raw = s.cells;
    final whole = raw.every((double e) => e.isNaN || (e - e.roundToDouble()).abs() < 1e-6);
    for (int i = 0; i < out.length && i < raw.length; i++) {
      if (cells[i].isNaN || raw[i].isNaN) continue;
      out[i] = whole ? raw[i].round().toString() : raw[i].toStringAsFixed(1);
    }
    return out;
  }
  final hits = depthTargets(s);
  for (final h in hits.take(12)) {
    final d = estimateDepth(
        s.corrected, s.cols, s.rows, h.x, h.y, s.cellCm / 100.0);
    if (d != null) out[h.y * s.cols + h.x] = '${d.depthM.toStringAsFixed(2)}m';
  }
  return out;
}

/// Switch: nothing / values / depth written on every square.
class LabelModeBar extends StatelessWidget {
  const LabelModeBar({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Row(
      children: <Widget>[
        Text(s.t('labels_title'),
            style: TextStyle(color: Pal.muted, fontSize: 12)),
        const SizedBox(width: 8),
        Expanded(
          child: SegmentedButton<int>(
            showSelectedIcon: false,
            segments: <ButtonSegment<int>>[
              ButtonSegment<int>(value: 0, label: Text(s.t('labels_none'))),
              ButtonSegment<int>(value: 1, label: Text(s.t('labels_values'))),
              ButtonSegment<int>(value: 2, label: Text(s.t('labels_depth'))),
            ],
            selected: <int>{s.labelMode},
            onSelectionChanged: (Set<int> v) => s.setLabelMode(v.first),
          ),
        ),
      ],
    );
  }
}

/// Soil type + scan step size (30..50 cm).
class SoilAndStep extends StatelessWidget {
  const SoilAndStep({
    super.key,
    this.stepEnabled = true,
    this.showSoil = true,
    this.showStep = true,
  });
  final bool showStep;
  final bool stepEnabled;
  final bool showSoil;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final soil = s.soil;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (showStep) ...<Widget>[
        Text(s.t('step_size'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        Row(
          children: <Widget>[
            Expanded(
              child: Slider(
                value: s.cellCm.clamp(30.0, 50.0).toDouble(),
                min: 30,
                max: 50,
                divisions: 4,
                label: '${s.cellCm.round()}',
                onChanged: stepEnabled ? s.setCellCm : null,
              ),
            ),
            SizedBox(
              width: 48,
              child: Num('${s.cellCm.round()} cm',
                  style: TextStyle(color: Pal.amber, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
        ],
        if (showSoil) ...<Widget>[
        Text(s.t('soil_title'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        DropdownButton<int>(
          isExpanded: true,
          value: s.soilIdx,
          items: <DropdownMenuItem<int>>[
            for (int i = 0; i < kSoils.length; i++)
              DropdownMenuItem<int>(value: i, child: Text(s.t(kSoils[i].key))),
          ],
          onChanged: (int? v) {
            if (v != null) s.setSoil(v);
          },
        ),
        if (s.soilIdx != 0)
          Text(
            '${s.t('soil_susc')}: ${soil.susceptibility}\n${s.t('${soil.key}_note')}',
            style: TextStyle(color: Pal.muted, fontSize: 11),
          ),
        Text(s.t('soil_hint'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ],
    );
  }
}
