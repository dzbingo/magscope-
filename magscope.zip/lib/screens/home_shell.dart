import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import 'analysis_screen.dart';
import 'files_screen.dart';
import 'live_screen.dart';
import 'map_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  Widget _statusChip(AppState s) {
    final Color color;
    switch (s.conn) {
      case ConnState.connected:
        color = Pal.good;
        break;
      case ConnState.connecting:
        color = Pal.amber;
        break;
      case ConnState.error:
        color = Pal.bad;
        break;
      case ConnState.idle:
        color = Pal.muted;
        break;
    }
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 12),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 9, color: color),
          const SizedBox(width: 6),
          Text(s.t(s.conn.name),
              style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _page() {
    switch (_index) {
      case 0:
        return const LiveScreen();
      case 1:
        return const MapScreen();
      case 2:
        return const AnalysisScreen();
      case 3:
        return FilesScreen(onOpened: () => setState(() => _index = 1));
      default:
        return const SettingsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          s.t('app_name'),
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: <Widget>[_statusChip(s)],
      ),
      body: SafeArea(child: _page()),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (int i) => setState(() => _index = i),
        destinations: <NavigationDestination>[
          NavigationDestination(
              icon: const Icon(Icons.show_chart), label: s.t('tab_live')),
          NavigationDestination(
              icon: const Icon(Icons.grid_view), label: s.t('tab_map')),
          NavigationDestination(
              icon: const Icon(Icons.tune), label: s.t('tab_analysis')),
          NavigationDestination(
              icon: const Icon(Icons.folder_open), label: s.t('tab_files')),
          NavigationDestination(
              icon: const Icon(Icons.settings), label: s.t('tab_settings')),
        ],
      ),
    );
  }
}
