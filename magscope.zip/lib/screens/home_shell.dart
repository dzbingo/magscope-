import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'analysis_screen.dart';
import 'compass_screen.dart';
import 'home_screen.dart';
import 'files_screen.dart';
import 'map_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  static const List<int> _order = <int>[0, 2, 3, 4, 6, 5];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) AppScope.of(context).requestStartupPermissions();
    });
  }

  /// Swipe left-to-right = next section, right-to-left = back.
  void _swipe(double v) {
    if (v.abs() < 350) return;
    final i = _order.indexOf(_index);
    if (i < 0) return;
    final j = v > 0 ? i + 1 : i - 1;
    if (j < 0 || j >= _order.length) return;
    _goto(_order[j]);
  }

  Widget _statusChip(AppState s) {
    final Color color;
    switch (s.conn) {
      case ConnState.connected:
        color = Pal.good;
        break;
      case ConnState.connecting:
        color = Pal.amber;
        break;
      case ConnState.error:
        color = Pal.bad;
        break;
      case ConnState.idle:
        color = Pal.muted;
        break;
    }
    return GestureDetector(
      onTap: () async {
        HapticFeedback.selectionClick();
        final ok = await s.toggleLink();
        if (!ok && mounted) setState(() => _index = 5);
      },
      child: _chipBody(s, color),
    );
  }

  Widget _chipBody(AppState s, Color color) {
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 12),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(
              s.conn == ConnState.connected
                  ? Icons.bluetooth_connected
                  : Icons.bluetooth,
              size: 14,
              color: color),
          const SizedBox(width: 6),
          Text(s.t(s.conn.name),
              style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }

  void _goto(int i) {
    if (i == 2 || i == 6) AppScope.of(context).ensureConnected();
    setState(() => _index = i);
  }

  Widget _page() {
    switch (_index) {
      case 0:
        return HomeScreen(onGo: _goto);
      case 2:
        return const MapScreen();
      case 3:
        return const AnalysisScreen();
      case 4:
        return FilesScreen(onOpened: () => showAnalysisViewer(context));
      case 6:
        return const CompassScreen();
      default:
        return const SettingsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) setState(() => _index = 0);
      },
      child: Scaffold(
      appBar: AppBar(
        leading: _index == 0
            ? null
            : IconButton(
                icon: Icon(Icons.home_rounded, color: Pal.amber),
                onPressed: () => setState(() => _index = 0),
              ),
        centerTitle: true,
        title: Text(
          s.t('app_name'),
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: _index == 0
            ? <Widget>[
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 14),
                  child: Center(
                    child: Text('v 1.0',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(color: Pal.muted, fontSize: 10)),
                  ),
                ),
              ]
            : <Widget>[_statusChip(s)],
      ),
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onHorizontalDragEnd: (DragEndDetails d) =>
            _swipe(d.primaryVelocity ?? 0),
        child: SafeArea(
        child: Stack(
          children: <Widget>[
             Positioned.fill(
              child: IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(0.9, -1.0),
                      radius: 1.3,
                      colors: <Color>[
                        (Pal.neon ? Pal.violet : Pal.amber).withAlpha(Pal.neon ? 46 : 31),
                        const Color(0x00000000)
                      ],
                    ),
                  ),
                ),
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (Widget child, Animation<double> anim) {
                return FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0.05, 0),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                );
              },
              child: KeyedSubtree(
                key: ValueKey<int>(_index),
                child: _page(),
              ),
            ),
          ],
        ),
      ),
      ),
    ),
    );
  }
}
