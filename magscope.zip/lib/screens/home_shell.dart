import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'analysis_screen.dart';
import 'compass_screen.dart';
import 'home_screen.dart';
import 'files_screen.dart';
import 'live_screen.dart';
import 'map_screen.dart';
import 'settings_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  Widget _statusChip(AppState s) {
    final Color color;
    switch (s.conn) {
      case ConnState.connected:
        color = Pal.good;
        break;
      case ConnState.connecting:
        color = Pal.amber;
        break;
      case ConnState.error:
        color = Pal.bad;
        break;
      case ConnState.idle:
        color = Pal.muted;
        break;
    }
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 12),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(Icons.circle, size: 9, color: color),
          const SizedBox(width: 6),
          Text(s.t(s.conn.name),
              style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }

  void _goto(int i) {
    if (i == 1 || i == 2 || i == 6) AppScope.of(context).ensureConnected();
    setState(() => _index = i);
  }

  Widget _page() {
    switch (_index) {
      case 0:
        return HomeScreen(onGo: _goto);
      case 1:
        return const LiveScreen();
      case 2:
        return const MapScreen();
      case 3:
        return const AnalysisScreen();
      case 4:
        return FilesScreen(onOpened: () => setState(() => _index = 2));
      case 6:
        return const CompassScreen();
      default:
        return const SettingsScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const AppMark(size: 30),
            const SizedBox(width: 10),
            Text(
              s.t('app_name'),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ],
        ),
        actions: _index == 0 ? null : <Widget>[_statusChip(s)],
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
             Positioned.fill(
              child: IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment(0.9, -1.0),
                      radius: 1.3,
                      colors: <Color>[
                        (Pal.neon ? Pal.violet : Pal.amber).withAlpha(Pal.neon ? 46 : 31),
                        const Color(0x00000000)
                      ],
                    ),
                  ),
                ),
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (Widget child, Animation<double> anim) {
                return FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0.05, 0),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                );
              },
              child: KeyedSubtree(
                key: ValueKey<int>(_index),
                child: _page(),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _navBar(s),
    );
  }

  static const List<List<Object>> _tabs = <List<Object>>[
    <Object>[Icons.home_rounded, 'tab_home', 0],
    <Object>[Icons.show_chart, 'tab_live', 1],
    <Object>[Icons.grid_view, 'tab_map', 2],
    <Object>[Icons.tune, 'tab_analysis', 3],
    <Object>[Icons.folder_open, 'tab_files', 4],
    <Object>[Icons.settings, 'tab_settings', 5],
  ];

  Widget _navBar(AppState s) {
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 10),
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: Pal.surface,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(
              color: Pal.neon ? Pal.amber.withAlpha(190) : Pal.outline,
              width: Pal.neon ? 1.6 : 1.0),
          boxShadow: <BoxShadow>[
            const BoxShadow(color: Color(0x66000000), blurRadius: 18),
            if (Pal.neon) BoxShadow(color: Pal.amber.withAlpha(60), blurRadius: 16),
            if (Pal.neon) BoxShadow(color: Pal.violet.withAlpha(40), blurRadius: 24),
          ],
        ),
        child: Row(
          children: <Widget>[
            for (int i = 0; i < _tabs.length; i++)
              Expanded(
                flex: _tabs[i][2] == _index ? 3 : 2,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    HapticFeedback.selectionClick();
                    _goto(_tabs[i][2] as int);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _tabs[i][2] == _index
                          ? Pal.amber.withAlpha(40)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Pal.neon && _tabs[i][2] == _index
                          ? Border.all(color: Pal.amber.withAlpha(170))
                          : null,
                      boxShadow: Pal.neon && _tabs[i][2] == _index
                          ? <BoxShadow>[
                              BoxShadow(
                                  color: Pal.amber.withAlpha(90), blurRadius: 14)
                            ]
                          : null,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        AnimatedScale(
                          scale: _tabs[i][2] == _index ? 1.2 : 1.0,
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutBack,
                          child: Icon(
                            _tabs[i][0] as IconData,
                            size: 22,
                            color:
                                _tabs[i][2] == _index ? Pal.amber : Pal.muted,
                          ),
                        ),
                        if (_tabs[i][2] == _index) ...<Widget>[
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(
                              s.t(_tabs[i][1] as String),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style:  TextStyle(
                                color: Pal.amber,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
