import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class _Step {
  _Step(this.kind, this.d);

  /// 'g1' ground before, 'g2' ground after, 'd' metal at [d] cm.
  final String kind;
  final double? d;
  final List<double> vals = <double>[];
  DateTime? at;
  bool done = false;

  double get mean => vals.isEmpty ? double.nan : vals.reduce((a, b) => a + b) / vals.length;
  double get minV => vals.isEmpty ? double.nan : vals.reduce(math.min);
  double get maxV => vals.isEmpty ? double.nan : vals.reduce(math.max);
  double get sd {
    if (vals.length < 2) return 0;
    final m = mean;
    double q = 0;
    for (final v in vals) {
      q += (v - m) * (v - m);
    }
    return math.sqrt(q / (vals.length - 1));
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'kind': kind,
        'd': d,
        'n': vals.length,
        'mean': double.parse(mean.toStringAsFixed(3)),
        'min': minV,
        'max': maxV,
        'sd': double.parse(sd.toStringAsFixed(3)),
        'at': (at ?? DateTime.now()).toIso8601String(),
        'raw': vals.length > 400 ? vals.sublist(vals.length - 400) : vals,
      };
}

/// Guided capture: one screen per step (ground with no metal, then the metal at
/// each distance). Every reading that arrives from the device while a step is
/// open is added to it; accepting the step stores mean / min / max / spread and
/// the raw values. The device may send only when its button is pressed, so no
/// timer is used.
class FieldCaptureScreen extends StatefulWidget {
  const FieldCaptureScreen({super.key, required this.distances});
  final List<double> distances;

  @override
  State<FieldCaptureScreen> createState() => _FieldCaptureScreenState();
}

class _FieldCaptureScreenState extends State<FieldCaptureScreen> {
  late final List<_Step> _steps;
  int _i = 0;
  final TextEditingController _manual = TextEditingController();
  AppState? _state;

  @override
  void initState() {
    super.initState();
    _steps = <_Step>[
      _Step('g1', null),
      for (final d in widget.distances) _Step('d', d),
      _Step('g2', null),
    ];
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final s = AppScope.of(context);
    if (!identical(_state, s)) {
      _state?.sampleTap = null;
      _state = s;
      s.sampleTap = _onSample;
    }
  }

  @override
  void dispose() {
    if (_state != null && _state!.sampleTap == _onSample) _state!.sampleTap = null;
    _manual.dispose();
    super.dispose();
  }

  void _onSample(double v) {
    if (!mounted || _i >= _steps.length) return;
    setState(() => _steps[_i].vals.add(v));
  }

  int get _doneCount => _steps.where((_Step e) => e.done).length;

  void _accept() {
    final s = AppScope.of(context);
    final st = _steps[_i];
    if (st.vals.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('fc_need'))));
      return;
    }
    st.done = true;
    st.at = DateTime.now();
    if (_i < _steps.length - 1) {
      setState(() => _i++);
    } else {
      _finish();
    }
  }

  void _skip() {
    if (_i < _steps.length - 1) {
      setState(() => _i++);
    } else {
      _finish();
    }
  }

  void _finish() {
    Navigator.of(context).pop(<Map<String, dynamic>>[
      for (final st in _steps)
        if (st.done) st.toJson(),
    ]);
  }

  String _title(AppState s, _Step st) {
    if (st.kind == 'g1') return s.t('fc_g1');
    if (st.kind == 'g2') return s.t('fc_g2');
    final d = st.d ?? 0;
    return '${s.t('fc_metal_at')} ${d == d.roundToDouble() ? d.toInt() : d} cm';
  }

  String _f(double v) => v.isNaN ? '-' : v.toStringAsFixed(v == v.roundToDouble() ? 0 : 2);

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final st = _steps[_i];
    return PopScope(
      canPop: _doneCount == 0,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (didPop) return;
        final ok = await showDialog<bool>(
          context: context,
          builder: (BuildContext c) => AlertDialog(
            content: Text(s.t('fc_exit_q')),
            actions: <Widget>[
              TextButton(onPressed: () => Navigator.pop(c, false), child: Text(s.t('cancel'))),
              TextButton(onPressed: () => Navigator.pop(c, true), child: Text(s.t('fc_leave'))),
            ],
          ),
        );
        if (ok == true && context.mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.t('fc_title')),
          actions: <Widget>[
            TextButton(
              onPressed: _doneCount == 0 ? null : _finish,
              child: Text('${s.t('fc_finish')} ($_doneCount)'),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            LinearProgressIndicator(value: (_i + 1) / _steps.length),
            const SizedBox(height: 8),
            Text('${s.t('fc_step')} ${_i + 1} / ${_steps.length}',
                style: TextStyle(color: Pal.muted)),
            const SizedBox(height: 6),
            Text(_title(s, st),
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(s.t(st.kind == 'd' ? 'fc_instr_d' : 'fc_instr_g'),
                style: TextStyle(color: Pal.muted)),
            const SizedBox(height: 14),
            if (s.conn != ConnState.connected)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(s.t('fc_not_conn'), style: TextStyle(color: Pal.amber, fontSize: 12)),
              ),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('${s.t('fc_live')}:  ${_f(s.lastValue)}',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                      textDirection: TextDirection.ltr),
                  const SizedBox(height: 8),
                  Text(
                    '${s.t('fc_count')}: ${st.vals.length}    ${s.t('fc_mean')}: ${_f(st.mean)}'
                    '    ${s.t('fc_min')}: ${_f(st.minV)}    ${s.t('fc_max')}: ${_f(st.maxV)}',
                    textDirection: TextDirection.ltr,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: <Widget>[
                      for (final v in st.vals.reversed.take(24))
                        Chip(
                          label: Text(_f(v)),
                          visualDensity: VisualDensity.compact,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _manual,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                        labelText: s.t('fc_manual'), border: const OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () {
                    final v = double.tryParse(_manual.text.trim().replaceAll(',', '.'));
                    if (v == null) return;
                    setState(() => st.vals.add(v));
                    _manual.clear();
                  },
                  child: Text(s.t('fc_add')),
                ),
              ],
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _accept,
              icon: const Icon(Icons.navigate_before),
              label: Text(_i == _steps.length - 1 ? s.t('fc_finish') : s.t('fc_accept')),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: <Widget>[
                OutlinedButton(
                  onPressed: st.vals.isEmpty ? null : () => setState(st.vals.clear),
                  child: Text(s.t('fc_redo')),
                ),
                OutlinedButton(onPressed: _skip, child: Text(s.t('fc_skip'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
