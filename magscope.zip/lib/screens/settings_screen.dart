import 'package:flutter/material.dart';

import '../sources.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _svc = TextEditingController();
  final TextEditingController _chr = TextEditingController();
  final TextEditingController _scale = TextEditingController();
  bool _initialised = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialised) {
      final s = AppScope.of(context);
      _svc.text = s.serviceUuid;
      _chr.text = s.charUuid;
      _scale.text = s.scale.toString();
      _initialised = true;
    }
  }

  @override
  void dispose() {
    _svc.dispose();
    _chr.dispose();
    _scale.dispose();
    super.dispose();
  }

  Widget _sliderRow(String label, int value, int min, int max, bool enabled,
      ValueChanged<int> onChanged) {
    return Row(
      children: <Widget>[
        SizedBox(
          width: 110,
          child: Text(label, style: const TextStyle(color: Pal.muted)),
        ),
        Expanded(
          child: Slider(
            value: value
                .toDouble()
                .clamp(min.toDouble(), max.toDouble())
                .toDouble(),
            min: min.toDouble(),
            max: max.toDouble(),
            divisions: max - min,
            onChanged: enabled ? (double v) => onChanged(v.round()) : null,
          ),
        ),
        SizedBox(
          width: 28,
          child: Text('$value', textAlign: TextAlign.end),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);

    final deviceCard = <Widget>[
      Text(
        s.deviceId == null
            ? s.t('no_selected')
            : '${s.deviceName.isEmpty ? s.t('unnamed') : s.deviceName}  (${s.deviceId})',
        style: const TextStyle(color: Pal.text),
      ),
      const SizedBox(height: 10),
      FilledButton.tonalIcon(
        onPressed: s.searching ? null : s.searchDevices,
        icon: const Icon(Icons.bluetooth_searching),
        label: Text(s.searching ? s.t('searching') : s.t('scan_devices')),
      ),
      if (s.errorKey != null && !s.scanning)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(s.t(s.errorKey!),
              style: const TextStyle(color: Pal.bad, fontSize: 12)),
        ),
      for (final r in s.bleResults.take(12))
        ListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: Text(s.nameOf(r).isEmpty ? s.t('unnamed') : s.nameOf(r)),
          subtitle: Text('${r.device.remoteId.str}   RSSI ${r.rssi}',
              style: const TextStyle(color: Pal.muted, fontSize: 11)),
          trailing: s.deviceId == r.device.remoteId.str
              ? const Icon(Icons.check_circle, color: Pal.good)
              : null,
          onTap: () => s.selectDevice(r),
        ),
      const Divider(color: Pal.outline),
      TextField(
        controller: _svc,
        decoration: InputDecoration(labelText: s.t('service_uuid')),
        onChanged: (String v) => s.setBleConfig(service: v),
      ),
      const SizedBox(height: 10),
      TextField(
        controller: _chr,
        decoration: InputDecoration(labelText: s.t('char_uuid')),
        onChanged: (String v) => s.setBleConfig(characteristic: v),
      ),
      const SizedBox(height: 6),
      Text(s.t('uuid_hint'),
          style: const TextStyle(color: Pal.muted, fontSize: 11)),
      const SizedBox(height: 14),
      Text(s.t('packet_format'),
          style: const TextStyle(color: Pal.muted, fontSize: 13)),
      const SizedBox(height: 6),
      SegmentedButton<PacketFormat>(
        segments: <ButtonSegment<PacketFormat>>[
          ButtonSegment<PacketFormat>(
              value: PacketFormat.ascii, label: Text(s.t('fmt_ascii'))),
          ButtonSegment<PacketFormat>(
              value: PacketFormat.int16le, label: Text(s.t('fmt_int16'))),
          ButtonSegment<PacketFormat>(
              value: PacketFormat.float32le, label: Text(s.t('fmt_float'))),
        ],
        selected: <PacketFormat>{s.format},
        onSelectionChanged: (Set<PacketFormat> v) =>
            s.setBleConfig(fmt: v.first),
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _scale,
        keyboardType: const TextInputType.numberWithOptions(
            decimal: true, signed: true),
        decoration: InputDecoration(labelText: s.t('scale')),
        onChanged: (String v) {
          final d = double.tryParse(v.replaceAll(',', '.'));
          if (d != null) s.setBleConfig(scaleFactor: d);
        },
      ),
      const SizedBox(height: 14),
      Text(s.t('axes'), style: const TextStyle(color: Pal.muted, fontSize: 13)),
      const SizedBox(height: 6),
      SegmentedButton<int>(
        segments: const <ButtonSegment<int>>[
          ButtonSegment<int>(value: 1, label: Text('1')),
          ButtonSegment<int>(value: 3, label: Text('3')),
        ],
        selected: <int>{s.axes == 3 ? 3 : 1},
        onSelectionChanged: (Set<int> v) => s.setBleConfig(axisCount: v.first),
      ),
      const SizedBox(height: 4),
      Text(s.t('axes_hint'),
          style: const TextStyle(color: Pal.muted, fontSize: 11)),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('language')),
              SegmentedButton<String>(
                segments: const <ButtonSegment<String>>[
                  ButtonSegment<String>(value: 'ar', label: Text('العربية')),
                  ButtonSegment<String>(value: 'en', label: Text('English')),
                  ButtonSegment<String>(value: 'fr', label: Text('Français')),
                ],
                selected: <String>{s.locale.languageCode},
                onSelectionChanged: (Set<String> v) => s.setLocale(v.first),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('source')),
              SegmentedButton<bool>(
                segments: <ButtonSegment<bool>>[
                  ButtonSegment<bool>(
                    value: false,
                    label: Text(s.t('simulator')),
                    icon: const Icon(Icons.science_outlined),
                  ),
                  ButtonSegment<bool>(
                    value: true,
                    label: Text(s.t('ble')),
                    icon: const Icon(Icons.bluetooth),
                  ),
                ],
                selected: <bool>{s.useBle},
                onSelectionChanged: s.scanning
                    ? null
                    : (Set<bool> v) => s.setUseBle(v.first),
              ),
              if (s.useBle) ...<Widget>[
                const SizedBox(height: 14),
                SectionTitle(s.t('device')),
                ...deviceCard,
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('grid_size')),
              _sliderRow(s.t('columns'), s.cols, 4, 32, !s.scanning,
                  (int v) => s.setGrid(v, s.rows)),
              _sliderRow(s.t('rows'), s.rows, 4, 32, !s.scanning,
                  (int v) => s.setGrid(s.cols, v)),
              _sliderRow(s.t('per_cell'), s.samplesPerCell, 1, 30, true,
                  (int v) => s.setSamplesPerCell(v)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('detection')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('alerts')),
                subtitle: Text(s.t('alerts_hint'),
                    style: const TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.alerts,
                onChanged: s.setAlerts,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('about')),
              Text(s.t('about_text'),
                  style: const TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
      ],
    );
  }
}
