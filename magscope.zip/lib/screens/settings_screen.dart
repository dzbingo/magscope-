import 'package:flutter/material.dart';

import '../sources.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'inspector_screen.dart';
import 'num_stepper.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _svc = TextEditingController();
  final TextEditingController _chr = TextEditingController();
  final TextEditingController _scale = TextEditingController();
  bool _initialised = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialised) {
      final s = AppScope.of(context);
      _svc.text = s.serviceUuid;
      _chr.text = s.charUuid;
      _scale.text = s.scale.toString();
      _initialised = true;
    }
  }

  @override
  void dispose() {
    _svc.dispose();
    _chr.dispose();
    _scale.dispose();
    super.dispose();
  }

  Widget _sliderRow(String label, int value, int min, int max, bool enabled,
      ValueChanged<int> onChanged) {
    return Row(
      children: <Widget>[
        SizedBox(
          width: 110,
          child: Text(label, style:  TextStyle(color: Pal.muted)),
        ),
        Expanded(
          child: Slider(
            value: value
                .toDouble()
                .clamp(min.toDouble(), max.toDouble())
                .toDouble(),
            min: min.toDouble(),
            max: max.toDouble(),
            divisions: max - min,
            onChanged: enabled ? (double v) => onChanged(v.round()) : null,
          ),
        ),
        SizedBox(
          width: 28,
          child: Text('$value', textAlign: TextAlign.end),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);

    final deviceCard = <Widget>[
      Text(s.t('classic_hint'),
          style: TextStyle(color: Pal.muted, fontSize: 11)),
      const SizedBox(height: 10),
      Text(
        s.deviceId == null
            ? s.t('no_selected')
            : '${s.deviceName.isEmpty ? s.t('unnamed') : s.deviceName}  (${s.deviceId})',
        style:  TextStyle(color: Pal.text),
      ),
      const SizedBox(height: 10),
      FilledButton.tonalIcon(
        onPressed: s.searching ? null : s.searchDevices,
        icon: const Icon(Icons.bluetooth_searching),
        label: Text(s.searching ? s.t('searching') : s.t('scan_devices')),
      ),
      if (s.deviceId != null)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: OutlinedButton.icon(
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (BuildContext c) =>
                      InspectorScreen(deviceId: s.deviceId!),
                ),
              );
              if (!mounted) return;
              setState(() {
                _svc.text = s.serviceUuid;
                _chr.text = s.charUuid;
              });
            },
            icon: const Icon(Icons.manage_search),
            label: Text(s.t('inspector')),
          ),
        ),
      if (s.errorKey != null && !s.scanning)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(s.t(s.errorKey!),
                  style: TextStyle(color: Pal.bad, fontSize: 12)),
              if (s.errorDetail.isNotEmpty)
                SelectableText(s.errorDetail,
                    textDirection: TextDirection.ltr,
                    style: TextStyle(color: Pal.muted, fontSize: 10)),
            ],
          ),
        ),
      if (s.bonded.isNotEmpty) ...<Widget>[
        const SizedBox(height: 10),
        Text(s.t('paired'),
            style:  TextStyle(color: Pal.muted, fontSize: 13)),
        for (final d in s.bonded)
          ListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            leading:  Icon(Icons.link, color: Pal.violet),
            title: Text(d.platformName.isEmpty
                ? s.t('unnamed')
                : d.platformName),
            subtitle: Text(d.remoteId.str,
                style:  TextStyle(color: Pal.muted, fontSize: 11)),
            trailing: s.deviceId == d.remoteId.str
                ?  Icon(Icons.check_circle, color: Pal.good)
                : null,
            onTap: () => s.selectBonded(d),
          ),
      ],
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        title: Text(s.t('show_unnamed')),
        value: s.showUnnamed,
        onChanged: s.setShowUnnamed,
      ),
      if (s.bleResults.isNotEmpty)
        Text(
          '${s.t('found')}: ${s.bleResults.where((r) => s.showUnnamed || s.nameOf(r).isNotEmpty).length}',
          style:  TextStyle(color: Pal.muted, fontSize: 12),
        ),
      for (final r in s.bleResults
          .where((r) => s.showUnnamed || s.nameOf(r).isNotEmpty)
          .take(30))
        ListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: Text(s.nameOf(r).isEmpty ? s.t('unnamed') : s.nameOf(r)),
          leading: Icon(
            r.rssi > -60
                ? Icons.signal_cellular_alt
                : (r.rssi > -80
                    ? Icons.signal_cellular_alt_2_bar
                    : Icons.signal_cellular_alt_1_bar),
            color: Pal.amber,
          ),
          subtitle: Text('${r.device.remoteId.str}   RSSI ${r.rssi}',
              textDirection: TextDirection.ltr,
              style:  TextStyle(color: Pal.muted, fontSize: 11)),
          trailing: s.deviceId == r.device.remoteId.str
              ?  Icon(Icons.check_circle, color: Pal.good)
              : null,
          onTap: () => s.selectDevice(r),
        ),
      ...<Widget>[
       Divider(color: Pal.outline),
      TextField(
        controller: _svc,
        decoration: InputDecoration(labelText: s.t('service_uuid')),
        onChanged: (String v) => s.setBleConfig(service: v),
      ),
      const SizedBox(height: 10),
      TextField(
        controller: _chr,
        decoration: InputDecoration(labelText: s.t('char_uuid')),
        onChanged: (String v) => s.setBleConfig(characteristic: v),
      ),
      const SizedBox(height: 6),
      Text(s.t('uuid_hint'),
          style:  TextStyle(color: Pal.muted, fontSize: 11)),
      ],
      const SizedBox(height: 14),
      Text(s.t('packet_format'),
          style:  TextStyle(color: Pal.muted, fontSize: 13)),
      const SizedBox(height: 6),
      SegmentedButton<PacketFormat>(
        segments: <ButtonSegment<PacketFormat>>[
          ButtonSegment<PacketFormat>(
              value: PacketFormat.ascii, label: Text(s.t('fmt_ascii'))),
          ButtonSegment<PacketFormat>(
              value: PacketFormat.int16le, label: Text(s.t('fmt_int16'))),
          ButtonSegment<PacketFormat>(
              value: PacketFormat.float32le, label: Text(s.t('fmt_float'))),
          ButtonSegment<PacketFormat>(
              value: PacketFormat.uint8, label: Text(s.t('fmt_uint8'))),
        ],
        selected: <PacketFormat>{s.format},
        onSelectionChanged: (Set<PacketFormat> v) =>
            s.setBleConfig(fmt: v.first),
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _scale,
        keyboardType: const TextInputType.numberWithOptions(
            decimal: true, signed: true),
        decoration: InputDecoration(labelText: s.t('scale')),
        onChanged: (String v) {
          final d = double.tryParse(v.replaceAll(',', '.'));
          if (d != null) s.setBleConfig(scaleFactor: d);
        },
      ),
      const SizedBox(height: 14),
      Text(s.t('axes'), style:  TextStyle(color: Pal.muted, fontSize: 13)),
      const SizedBox(height: 6),
      SegmentedButton<int>(
        segments: const <ButtonSegment<int>>[
          ButtonSegment<int>(value: 1, label: Text('1')),
          ButtonSegment<int>(value: 3, label: Text('3')),
        ],
        selected: <int>{s.axes == 3 ? 3 : 1},
        onSelectionChanged: (Set<int> v) => s.setBleConfig(axisCount: v.first),
      ),
      const SizedBox(height: 4),
      Text(s.t('axes_hint'),
          style:  TextStyle(color: Pal.muted, fontSize: 11)),
      const SizedBox(height: 10),
      NumStepper(
        label: s.t('ignore_below'),
        value: s.ignoreBelow,
        min: 0,
        max: 255,
        onChanged: s.setIgnoreBelow,
      ),
      Text(s.t('ignore_below_hint'),
          style: TextStyle(color: Pal.muted, fontSize: 11)),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('language')),
              SegmentedButton<String>(
                segments: const <ButtonSegment<String>>[
                  ButtonSegment<String>(value: 'ar', label: Text('العربية')),
                  ButtonSegment<String>(value: 'en', label: Text('English')),
                  ButtonSegment<String>(value: 'fr', label: Text('Français')),
                ],
                selected: <String>{s.locale.languageCode},
                onSelectionChanged: (Set<String> v) => s.setLocale(v.first),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('theme')),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: <Widget>[
                  for (int i = 0; i < kThemes.length; i++)
                    GestureDetector(
                      onTap: () => s.setTheme(i),
                      child: Container(
                        width: 96,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: kThemes[i].bg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: s.themeIdx == i
                                ? kThemes[i].amber
                                : kThemes[i].outline,
                            width: s.themeIdx == i ? 2.5 : 1,
                          ),
                        ),
                        child: Column(
                          children: <Widget>[
                            Container(
                              height: 26,
                              decoration: BoxDecoration(
                                color: kThemes[i].surface,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].amber),
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].violet),
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].good),
                                ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              s.t(kThemes[i].nameKey),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: kThemes[i].text,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('source')),
              SegmentedButton<bool>(
                segments: <ButtonSegment<bool>>[
                  ButtonSegment<bool>(
                    value: false,
                    label: Text(s.t('simulator')),
                    icon: const Icon(Icons.science_outlined),
                  ),
                  ButtonSegment<bool>(
                    value: true,
                    label: Text(s.t('ble')),
                    icon: const Icon(Icons.bluetooth),
                  ),
                ],
                selected: <bool>{s.useBle},
                onSelectionChanged: s.scanning
                    ? null
                    : (Set<bool> v) => s.setUseBle(v.first),
              ),
              if (s.useBle) ...<Widget>[
                const SizedBox(height: 14),
                SectionTitle(s.t('device')),
                ...deviceCard,
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('grid_size')),
              NumStepper(
                label: s.t('columns'),
                value: s.cols,
                min: 2,
                max: 48,
                enabled: !s.scanning,
                onChanged: (int v) => s.setGrid(v, s.rows),
              ),
              NumStepper(
                label: s.t('rows'),
                value: s.rows,
                min: 2,
                max: 48,
                enabled: !s.scanning,
                onChanged: (int v) => s.setGrid(s.cols, v),
              ),
              NumStepper(
                label: s.t('per_cell'),
                value: s.samplesPerCell,
                min: 1,
                max: 200,
                onChanged: s.setSamplesPerCell,
              ),
              const SizedBox(height: 4),
              Text(
                '${s.t('total_cells')}: ${s.cols * s.rows}   |   '
                '${(s.cols * s.cellCm / 100).toStringAsFixed(1)} x ${(s.rows * s.cellCm / 100).toStringAsFixed(1)} m',
                textDirection: TextDirection.ltr,
                style:  TextStyle(color: Pal.muted, fontSize: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('scan_path')),
              SegmentedButton<bool>(
                segments: <ButtonSegment<bool>>[
                  ButtonSegment<bool>(
                      value: true, label: Text(s.t('path_zigzag'))),
                  ButtonSegment<bool>(
                      value: false, label: Text(s.t('path_parallel'))),
                ],
                selected: <bool>{s.zigzag},
                onSelectionChanged:
                    s.scanning ? null : (Set<bool> v) => s.setZigzag(v.first),
              ),
              const SizedBox(height: 10),
              SegmentedButton<bool>(
                segments: <ButtonSegment<bool>>[
                  ButtonSegment<bool>(
                      value: false, label: Text(s.t('dir_ltr'))),
                  ButtonSegment<bool>(
                      value: true, label: Text(s.t('dir_rtl'))),
                ],
                selected: <bool>{s.rtl},
                onSelectionChanged:
                    s.scanning ? null : (Set<bool> v) => s.setRtl(v.first),
              ),
              const SizedBox(height: 8),
              Text(s.t('path_hint'),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  SizedBox(
                    width: 110,
                    child: Text(s.t('cell_size'),
                        style:  TextStyle(color: Pal.muted)),
                  ),
                  Expanded(
                    child: Slider(
                      value: s.cellCm.clamp(5.0, 200.0).toDouble(),
                      min: 5,
                      max: 200,
                      onChanged: s.setCellCm,
                    ),
                  ),
                  SizedBox(
                    width: 40,
                    child: Num(s.cellCm.toStringAsFixed(0)),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('detection')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('geotag')),
                subtitle: Text(s.t('geotag_hint'),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.geotag,
                onChanged: s.setGeotag,
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('thr_manual')),
                subtitle: Text(s.t('thr_manual_hint'),
                    style:  TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.manualThr,
                onChanged: s.setManualThr,
              ),
              if (s.manualThr)
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 110,
                      child: Text(s.t('thr_value'),
                          style:  TextStyle(color: Pal.muted)),
                    ),
                    Expanded(
                      child: Slider(
                        value: s.thrUT.clamp(0.1, 20.0).toDouble(),
                        min: 0.1,
                        max: 20,
                        onChanged: s.setThrUT,
                      ),
                    ),
                    SizedBox(
                      width: 56,
                      child: Num('${s.thrUT.toStringAsFixed(1)} ${s.t('unit')}'),
                    ),
                  ],
                ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('alerts')),
                subtitle: Text(s.t('alerts_hint'),
                    style:  TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.alerts,
                onChanged: s.setAlerts,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('about')),
              Text(s.t('about_text'),
                  style:  TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
      ],
    );
  }
}
