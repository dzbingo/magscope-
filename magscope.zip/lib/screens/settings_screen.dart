import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'inspector_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Widget _infoRow(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: <Widget>[
          SizedBox(
            width: 90,
            child: Text(k, style: TextStyle(color: Pal.muted, fontSize: 13)),
          ),
          Expanded(
            child: SelectableText(v,
                textDirection: TextDirection.ltr,
                style: TextStyle(color: Pal.text, fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Widget _sliderRow(String label, int value, int min, int max, bool enabled,
      ValueChanged<int> onChanged) {
    return Row(
      children: <Widget>[
        SizedBox(
          width: 110,
          child: Text(label, style:  TextStyle(color: Pal.muted)),
        ),
        Expanded(
          child: Slider(
            value: value
                .toDouble()
                .clamp(min.toDouble(), max.toDouble())
                .toDouble(),
            min: min.toDouble(),
            max: max.toDouble(),
            divisions: max - min,
            onChanged: enabled ? (double v) => onChanged(v.round()) : null,
          ),
        ),
        SizedBox(
          width: 28,
          child: Text('$value', textAlign: TextAlign.end),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);

    final deviceCard = <Widget>[
      Text(s.t('classic_hint'),
          style: TextStyle(color: Pal.muted, fontSize: 11)),
      const SizedBox(height: 10),
      Text(
        s.deviceId == null
            ? s.t('no_selected')
            : '${s.deviceName.isEmpty ? s.t('unnamed') : s.deviceName}  (${s.deviceId})',
        style:  TextStyle(color: Pal.text),
      ),
      const SizedBox(height: 10),
      FilledButton.tonalIcon(
        onPressed: s.searching ? null : s.searchDevices,
        icon: const Icon(Icons.bluetooth_searching),
        label: Text(s.searching ? s.t('searching') : s.t('scan_devices')),
      ),
      if (s.deviceId != null)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: OutlinedButton.icon(
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (BuildContext c) =>
                      InspectorScreen(deviceId: s.deviceId!),
                ),
              );
              if (!mounted) return;
              setState(() {});
            },
            icon: const Icon(Icons.manage_search),
            label: Text(s.t('inspector')),
          ),
        ),
      if (s.errorKey != null && !s.scanning)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(s.t(s.errorKey!),
                  style: TextStyle(color: Pal.bad, fontSize: 12)),
              if (s.errorDetail.isNotEmpty)
                SelectableText(s.errorDetail,
                    textDirection: TextDirection.ltr,
                    style: TextStyle(color: Pal.muted, fontSize: 10)),
            ],
          ),
        ),
      if (s.bonded.isNotEmpty) ...<Widget>[
        const SizedBox(height: 10),
        Text(s.t('paired'),
            style:  TextStyle(color: Pal.muted, fontSize: 13)),
        for (final d in s.bonded)
          ListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            leading:  Icon(Icons.link, color: Pal.violet),
            title: Text(d.platformName.isEmpty
                ? s.t('unnamed')
                : d.platformName),
            subtitle: Text(d.remoteId.str,
                style:  TextStyle(color: Pal.muted, fontSize: 11)),
            trailing: s.deviceId == d.remoteId.str
                ?  Icon(Icons.check_circle, color: Pal.good)
                : null,
            onTap: () => s.selectBonded(d),
          ),
      ],
      if (s.bleResults.isNotEmpty)
        Text(
          '${s.t('found')}: ${s.bleResults.length}',
          style:  TextStyle(color: Pal.muted, fontSize: 12),
        ),
      for (final r in s.bleResults.take(30))
        ListTile(
          contentPadding: EdgeInsets.zero,
          dense: true,
          title: Text(s.nameOf(r).isEmpty ? s.t('unnamed') : s.nameOf(r)),
          leading: Icon(
            r.rssi > -60
                ? Icons.signal_cellular_alt
                : (r.rssi > -80
                    ? Icons.signal_cellular_alt_2_bar
                    : Icons.signal_cellular_alt_1_bar),
            color: Pal.amber,
          ),
          subtitle: Text('${r.device.remoteId.str}   RSSI ${r.rssi}',
              textDirection: TextDirection.ltr,
              style:  TextStyle(color: Pal.muted, fontSize: 11)),
          trailing: s.deviceId == r.device.remoteId.str
              ?  Icon(Icons.check_circle, color: Pal.good)
              : null,
          onTap: () => s.selectDevice(r),
        ),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('language')),
              SegmentedButton<String>(
                segments: const <ButtonSegment<String>>[
                  ButtonSegment<String>(value: 'ar', label: Text('العربية')),
                  ButtonSegment<String>(value: 'en', label: Text('English')),
                  ButtonSegment<String>(value: 'fr', label: Text('Français')),
                  ButtonSegment<String>(value: 'fa', label: Text('فارسی')),
                ],
                selected: <String>{s.locale.languageCode},
                onSelectionChanged: (Set<String> v) => s.setLocale(v.first),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('theme')),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: <Widget>[
                  for (int i = 0; i < kThemes.length; i++)
                    GestureDetector(
                      onTap: () => s.setTheme(i),
                      child: Container(
                        width: 96,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: kThemes[i].bg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: s.themeIdx == i
                                ? kThemes[i].amber
                                : kThemes[i].outline,
                            width: s.themeIdx == i ? 2.5 : 1,
                          ),
                        ),
                        child: Column(
                          children: <Widget>[
                            Container(
                              height: 26,
                              decoration: BoxDecoration(
                                color: kThemes[i].surface,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].amber),
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].violet),
                                  Icon(Icons.circle,
                                      size: 12, color: kThemes[i].good),
                                ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              s.t(kThemes[i].nameKey),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: kThemes[i].text,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('device')),
              ...deviceCard,
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('detection')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('geotag')),
                subtitle: Text(s.t('geotag_hint'),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.geotag,
                onChanged: s.setGeotag,
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('alerts')),
                subtitle: Text(s.t('alerts_hint'),
                    style:  TextStyle(color: Pal.muted, fontSize: 12)),
                value: s.alerts,
                onChanged: s.setAlerts,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('app_name')),
              _infoRow(s.t('dev_label'), 'Sniper-Dz'),
              _infoRow(s.t('version_label'), 'v 1.0'),
              _infoRow(s.t('contact_label'), 'Zeemasoft@gmail.com'),
              const SizedBox(height: 6),
              Text(s.t('rights'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('about')),
              Text(s.t('about_text'),
                  style:  TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
      ],
    );
  }
}
