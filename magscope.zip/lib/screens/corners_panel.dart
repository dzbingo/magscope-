import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'compass_screen.dart';

/// Records the scan heading (from the phone compass) and the GPS position of
/// the four corners of the scan square, so the picture can be projected onto
/// the real ground.
class CornersPanel extends StatelessWidget {
  const CornersPanel({super.key});

  Future<void> _pickHeading(BuildContext context, AppState s) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext c) => Scaffold(
          appBar: AppBar(title: Text(s.t('heading_exact'))),
          body: const CompassScreen(),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () {
              s.setScanHeading(AppState.compassDeg);
              Navigator.of(c).pop();
            },
            icon: const Icon(Icons.explore),
            label: Text(s.t('heading_take')),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(s.t('corners_title'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(s.t('corners_hint'),
            style: TextStyle(color: Pal.muted, fontSize: 11)),
        const SizedBox(height: 6),
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                '${s.t('heading_exact')}: ${s.scanHeading.toStringAsFixed(0)}°',
                style: TextStyle(color: Pal.amber, fontWeight: FontWeight.w700),
              ),
            ),
            FilledButton.tonalIcon(
              onPressed: () => _pickHeading(context, s),
              icon: const Icon(Icons.explore_outlined),
              label: Text(s.t('heading_take')),
            ),
          ],
        ),
        for (int i = 0; i < 4; i++)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              children: <Widget>[
                Icon(
                  s.cornerPts[i] != null
                      ? Icons.check_circle
                      : Icons.radio_button_unchecked,
                  size: 18,
                  color: s.cornerPts[i] != null ? Pal.good : Pal.muted,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    s.cornerPts[i] == null
                        ? s.t('corner_${i + 1}')
                        : '${s.t('corner_${i + 1}')}  ${s.cornerPts[i]![0].toStringAsFixed(6)}, ${s.cornerPts[i]![1].toStringAsFixed(6)}',
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
                TextButton(
                  onPressed: s.cornerBusy
                      ? null
                      : () async {
                          final ok = await s.recordCorner(i);
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: Text(ok
                                  ? s.t('corners_saved')
                                  : s.t('sat_no_gps'))));
                        },
                  child: Text(s.cornerBusy ? s.t('corners_wait') : s.t('corner_record')),
                ),
              ],
            ),
          ),
        if (s.cornersDone > 0)
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton(
              onPressed: s.clearCorners,
              child: Text(s.t('corner_clear')),
            ),
          ),
      ],
    );
  }
}
