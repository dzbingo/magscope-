import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';

/// One switch: "Corner measurement". When on, the app works out the heading
/// (phone compass) and the GPS position of the four corners of the scan
/// square by itself when a scan starts, so the image can be projected onto the
/// real ground.
class CornersPanel extends StatelessWidget {
  const CornersPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final done = s.cornersDone == 4;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(s.t('corners_title'),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(s.t('corners_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          value: s.autoCorners,
          onChanged: s.setAutoCorners,
        ),
        if (s.autoCorners) ...<Widget>[
          Row(
            children: <Widget>[
              Icon(
                done ? Icons.check_circle : Icons.radio_button_unchecked,
                size: 18,
                color: done ? Pal.good : Pal.muted,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  s.cornerBusy
                      ? s.t('corners_wait')
                      : s.cornerMsg.isNotEmpty
                          ? s.t(s.cornerMsg)
                          : done
                              ? '${s.t('heading_exact')}: ${s.scanHeading.toStringAsFixed(0)}°  ·  4/4'
                              : s.t('corners_auto_idle'),
                  style: TextStyle(
                      color: s.cornerMsg.isNotEmpty ? Pal.bad : Pal.text,
                      fontSize: 12),
                ),
              ),
              TextButton(
                onPressed: s.cornerBusy ? null : s.measureCorners,
                child: Text(s.t('corners_measure_now')),
              ),
            ],
          ),
          if (done)
            Text(
              '${s.cornerPts[0]![0].toStringAsFixed(6)}, ${s.cornerPts[0]![1].toStringAsFixed(6)}',
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 11),
            ),
        ],
      ],
    );
  }
}
