import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../dsp.dart';
import '../ger_xml.dart';
import 'export_sheet.dart';
import '../state.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';

class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key, this.onOpened});

  /// Called after a session is opened, so the shell can jump to the map tab.
  final VoidCallback? onOpened;

  Future<void> _import(BuildContext context, AppState s) async {
    if (await importFile(context, s) && onOpened != null) onOpened!();
  }

  /// Picks a GER3D XML file, saves it as a session and opens it.
  static Future<bool> importFile(BuildContext context, AppState s) async {
    String? text;
    String name = '';
    try {
      final res =
          await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      if (res == null || res.files.isEmpty) return false;
      final f = res.files.single;
      name = f.name.replaceAll(RegExp(r'\.[^.]*$'), '');
      if (f.bytes != null) {
        text = utf8.decode(f.bytes!, allowMalformed: true);
      } else if (f.path != null) {
        text = await File(f.path!).readAsString();
      }
    } catch (_) {}
    final sess = text == null ? null : GerXml.parse(text, name);
    if (!context.mounted) return false;
    if (sess == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(s.t('import_failed'))));
      return false;
    }
    await s.importSession(sess);
    if (!context.mounted) return false;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('imported'))));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilledButton.tonalIcon(
              onPressed: () => _import(context, s),
              icon: const Icon(Icons.file_open_outlined),
              label: Text(s.t('import_file')),
            ),
          ),
        ),
        Expanded(child: _body(context, s)),
      ],
    );
  }

  Widget _body(BuildContext context, AppState s) {
    if (s.sessions.isEmpty) {
      return Center(
        child: Text(s.t('files_empty'),
            style:  TextStyle(color: Pal.muted)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: s.sessions.length,
      separatorBuilder: (BuildContext c, int i) => const SizedBox(height: 10),
      itemBuilder: (BuildContext ctx, int i) {
        final sess = s.sessions[i];
        Future<void> open() async {
          await s.loadSession(sess);
          if (!ctx.mounted) return;
          ScaffoldMessenger.of(ctx)
              .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
          if (onOpened != null) onOpened!();
        }

        Future<void> rename() async {
          final ctrl = TextEditingController(text: sess.name);
          final name = await showDialog<String>(
            context: ctx,
            builder: (BuildContext dc) => AlertDialog(
              title: Text(s.t('rename')),
              content: TextField(
                controller: ctrl,
                autofocus: true,
                decoration: InputDecoration(labelText: s.t('session_name')),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(dc),
                  child: Text(s.t('cancel')),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dc, ctrl.text),
                  child: Text(s.t('ok')),
                ),
              ],
            ),
          );
          ctrl.dispose();
          if (name != null) await s.renameSession(sess, name);
        }

        Future<void> delete() async {
          final ok = await showDialog<bool>(
            context: ctx,
            builder: (BuildContext dc) => AlertDialog(
              title: Text(s.t('delete')),
              content: Text(sess.name),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(dc, false),
                  child: Text(s.t('cancel')),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dc, true),
                  child: Text(s.t('delete')),
                ),
              ],
            ),
          );
          if (ok == true) await s.deleteSession(sess);
        }

        Widget action(IconData icon, String label, Color c, VoidCallback f) =>
            Expanded(
              child: InkWell(
                onTap: f,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Icon(icon, size: 18, color: c),
                      const SizedBox(width: 6),
                      Text(label, style: TextStyle(color: c, fontSize: 13)),
                    ],
                  ),
                ),
              ),
            );

        return Container(
          decoration: BoxDecoration(
            color: Pal.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Pal.outline),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: <Widget>[
              InkWell(
                onTap: open,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 78,
                        height: 78,
                        child: RepaintBoundary(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: CustomPaint(
                              painter: ThumbPainter(
                                  cells: sess.cells,
                                  cols: sess.cols,
                                  rows: sess.rows),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(sess.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Text(
                              '${sess.cols}x${sess.rows}  |  ${stamp(sess.createdAt)}',
                              textDirection: TextDirection.ltr,
                              style: TextStyle(color: Pal.muted, fontSize: 12),
                            ),
                            if (sess.geo != null)
                              Text(sess.geo!.formatCoordinates(),
                                  textDirection: TextDirection.ltr,
                                  style: TextStyle(
                                      color: Pal.muted, fontSize: 11)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                color: Pal.bg.withAlpha(110),
                child: Row(
                  children: <Widget>[
                    action(Icons.edit_outlined, s.t('rename'), Pal.text, rename),
                    action(Icons.share_outlined, s.t('share'), Pal.text,
                        () => showExportSheet(ctx, s, sess)),
                    action(Icons.delete_outline, s.t('delete'), Pal.bad, delete),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Small static heat-map preview of a saved session.
class ThumbPainter extends HeatPainter {
  ThumbPainter({
    required List<double> cells,
    required int cols,
    required int rows,
  }) : super(
          cells: cells,
          cols: cols,
          rows: rows,
          lo: _lo(cells),
          hi: _hi(cells),
        );

  static double _lo(List<double> c) => _range(c)[0];
  static double _hi(List<double> c) => _range(c)[1];

  static List<double> _range(List<double> c) {
    final st = statsOf(c);
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < 1.0) {
      final mid = (hi + lo) / 2;
      lo = mid - 0.5;
      hi = mid + 0.5;
    }
    return <double>[lo, hi];
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) =>
      old is! ThumbPainter || !identical(old.cells, cells);
}
