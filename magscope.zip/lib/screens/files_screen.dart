import 'package:flutter/material.dart';

import '../state.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';

class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key, this.onOpened});

  /// Called after a session is opened, so the shell can jump to the map tab.
  final VoidCallback? onOpened;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (s.sessions.isEmpty) {
      return Center(
        child: Text(s.t('files_empty'),
            style: const TextStyle(color: Pal.muted)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: s.sessions.length,
      separatorBuilder: (BuildContext c, int i) => const SizedBox(height: 10),
      itemBuilder: (BuildContext ctx, int i) {
        final sess = s.sessions[i];
        return Panel(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          child: ListTile(
            leading: Icon(
              sess.source == 'ble' ? Icons.bluetooth : Icons.science_outlined,
              color: Pal.violet,
            ),
            title: Text(sess.name),
            subtitle: Text(
              '${stamp(sess.createdAt)}  |  ${sess.raw.length} ${s.t('samples')}  |  ${sess.cols} x ${sess.rows}',
              style: const TextStyle(color: Pal.muted, fontSize: 12),
            ),
            onTap: () async {
              await s.loadSession(sess);
              if (!ctx.mounted) return;
              ScaffoldMessenger.of(ctx)
                  .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
              if (onOpened != null) onOpened!();
            },
            trailing: PopupMenuButton<String>(
              onSelected: (String v) async {
                if (v == 'open') {
                  await s.loadSession(sess);
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx)
                      .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
                  if (onOpened != null) onOpened!();
                } else if (v == 'csv') {
                  final path = await SessionStore.exportCsv(sess);
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    SnackBar(content: Text('${s.t('exported_to')} $path')),
                  );
                } else if (v == 'del') {
                  await s.deleteSession(sess);
                }
              },
              itemBuilder: (BuildContext c) => <PopupMenuEntry<String>>[
                PopupMenuItem<String>(value: 'open', child: Text(s.t('open'))),
                PopupMenuItem<String>(
                    value: 'csv', child: Text(s.t('export_csv'))),
                PopupMenuItem<String>(
                    value: 'del', child: Text(s.t('delete'))),
              ],
            ),
          ),
        );
      },
    );
  }
}
