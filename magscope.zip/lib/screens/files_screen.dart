import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../dsp.dart';
import '../ger_xml.dart';
import '../imaging.dart';
import 'package:share_plus/share_plus.dart';
import 'export_sheet.dart';
import '../state.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';

class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key, this.onOpened});

  /// Called after a session is opened, so the shell can jump to the map tab.
  final VoidCallback? onOpened;

  Future<void> _import(BuildContext context, AppState s) async {
    if (await importFile(context, s) && onOpened != null) onOpened!();
  }

  /// Picks a GER3D XML file, saves it as a session and opens it.
  static Future<bool> importFile(BuildContext context, AppState s) async {
    String? text;
    String name = '';
    try {
      final res =
          await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      if (res == null || res.files.isEmpty) return false;
      final f = res.files.single;
      name = f.name.replaceAll(RegExp(r'\.[^.]*$'), '');
      if (f.bytes != null) {
        text = utf8.decode(f.bytes!, allowMalformed: true);
      } else if (f.path != null) {
        text = await File(f.path!).readAsString();
      }
    } catch (_) {}
    final sess = text == null ? null : GerXml.parse(text, name);
    if (!context.mounted) return false;
    if (sess == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(s.t('import_failed'))));
      return false;
    }
    await s.importSession(sess);
    if (!context.mounted) return false;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('imported'))));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilledButton.tonalIcon(
              onPressed: () => _import(context, s),
              icon: const Icon(Icons.file_open_outlined),
              label: Text(s.t('import_file')),
            ),
          ),
        ),
        Expanded(child: _body(context, s)),
      ],
    );
  }

  Widget _body(BuildContext context, AppState s) {
    if (s.sessions.isEmpty) {
      return Center(
        child: Text(s.t('files_empty'),
            style:  TextStyle(color: Pal.muted)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: s.sessions.length,
      separatorBuilder: (BuildContext c, int i) => const SizedBox(height: 10),
      itemBuilder: (BuildContext ctx, int i) {
        final sess = s.sessions[i];
        return Panel(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          child: ListTile(
            leading: SizedBox(
              width: 56,
              height: 56,
              child: RepaintBoundary(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: CustomPaint(
                    painter: ThumbPainter(
                        cells: sess.cells, cols: sess.cols, rows: sess.rows),
                  ),
                ),
              ),
            ),
            title: Text(sess.name),
            subtitle: Text(
              '${stamp(sess.createdAt)}  |  ${sess.raw.length} ${s.t('samples')}  |  ${sess.cols} x ${sess.rows}'
              '${sess.geo == null ? '' : '\n${sess.geo!.formatCoordinates()}'}',
              textDirection: TextDirection.ltr,
              style:  TextStyle(color: Pal.muted, fontSize: 12),
            ),
            onTap: () async {
              await s.loadSession(sess);
              if (!ctx.mounted) return;
              ScaffoldMessenger.of(ctx)
                  .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
              if (onOpened != null) onOpened!();
            },
            trailing: PopupMenuButton<String>(
              onSelected: (String v) async {
                if (v == 'open') {
                  await s.loadSession(sess);
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx)
                      .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
                  if (onOpened != null) onOpened!();
                } else if (v == 'csv') {
                  await showExportSheet(ctx, s, sess);
                } else if (v == 'rename') {
                  final ctrl = TextEditingController(text: sess.name);
                  final name = await showDialog<String>(
                    context: ctx,
                    builder: (BuildContext dc) => AlertDialog(
                      title: Text(s.t('rename')),
                      content: TextField(
                        controller: ctrl,
                        autofocus: true,
                        decoration:
                            InputDecoration(labelText: s.t('session_name')),
                      ),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pop(dc),
                          child: Text(s.t('cancel')),
                        ),
                        FilledButton(
                          onPressed: () => Navigator.pop(dc, ctrl.text),
                          child: Text(s.t('ok')),
                        ),
                      ],
                    ),
                  );
                  ctrl.dispose();
                  if (name != null) await s.renameSession(sess, name);
                } else if (v == 'png' || v == 'jpg') {
                  try {
                    final path = await Imaging.saveImage(sess, jpg: v == 'jpg');
                    await Share.shareXFiles(<XFile>[
                      XFile(path,
                          mimeType: v == 'jpg' ? 'image/jpeg' : 'image/png')
                    ]);
                  } catch (_) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(
                          SnackBar(content: Text(s.t('share_failed'))));
                    }
                  }
                } else if (v == 'del') {
                  await s.deleteSession(sess);
                }
              },
              itemBuilder: (BuildContext c) => <PopupMenuEntry<String>>[
                PopupMenuItem<String>(value: 'open', child: Text(s.t('open'))),
                PopupMenuItem<String>(
                    value: 'rename', child: Text(s.t('rename'))),
                PopupMenuItem<String>(
                    value: 'csv', child: Text(s.t('export'))),
                PopupMenuItem<String>(
                    value: 'png', child: Text(s.t('save_png'))),
                PopupMenuItem<String>(
                    value: 'jpg', child: Text(s.t('save_jpg'))),
                PopupMenuItem<String>(
                    value: 'del', child: Text(s.t('delete'))),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Small static heat-map preview of a saved session.
class ThumbPainter extends HeatPainter {
  ThumbPainter({
    required List<double> cells,
    required int cols,
    required int rows,
  }) : super(
          cells: cells,
          cols: cols,
          rows: rows,
          lo: _lo(cells),
          hi: _hi(cells),
        );

  static double _lo(List<double> c) => _range(c)[0];
  static double _hi(List<double> c) => _range(c)[1];

  static List<double> _range(List<double> c) {
    final st = statsOf(c);
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < 1.0) {
      final mid = (hi + lo) / 2;
      lo = mid - 0.5;
      hi = mid + 0.5;
    }
    return <double>[lo, hi];
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) =>
      old is! ThumbPainter || !identical(old.cells, cells);
}
