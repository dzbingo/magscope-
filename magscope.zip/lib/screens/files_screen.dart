import 'package:flutter/material.dart';

import '../dsp.dart';
import 'export_sheet.dart';
import '../state.dart';
import '../storage.dart';
import '../theme.dart';
import '../widgets.dart';

class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key, this.onOpened});

  /// Called after a session is opened, so the shell can jump to the map tab.
  final VoidCallback? onOpened;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (s.sessions.isEmpty) {
      return Center(
        child: Text(s.t('files_empty'),
            style:  TextStyle(color: Pal.muted)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: s.sessions.length,
      separatorBuilder: (BuildContext c, int i) => const SizedBox(height: 10),
      itemBuilder: (BuildContext ctx, int i) {
        final sess = s.sessions[i];
        return Panel(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          child: ListTile(
            leading: SizedBox(
              width: 56,
              height: 56,
              child: RepaintBoundary(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: CustomPaint(
                    painter: ThumbPainter(
                        cells: sess.cells, cols: sess.cols, rows: sess.rows),
                  ),
                ),
              ),
            ),
            title: Text(sess.name),
            subtitle: Text(
              '${stamp(sess.createdAt)}  |  ${sess.raw.length} ${s.t('samples')}  |  ${sess.cols} x ${sess.rows}',
              style:  TextStyle(color: Pal.muted, fontSize: 12),
            ),
            onTap: () async {
              await s.loadSession(sess);
              if (!ctx.mounted) return;
              ScaffoldMessenger.of(ctx)
                  .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
              if (onOpened != null) onOpened!();
            },
            trailing: PopupMenuButton<String>(
              onSelected: (String v) async {
                if (v == 'open') {
                  await s.loadSession(sess);
                  if (!ctx.mounted) return;
                  ScaffoldMessenger.of(ctx)
                      .showSnackBar(SnackBar(content: Text(s.t('loaded'))));
                  if (onOpened != null) onOpened!();
                } else if (v == 'csv') {
                  await showExportSheet(ctx, s, sess);
                } else if (v == 'del') {
                  await s.deleteSession(sess);
                }
              },
              itemBuilder: (BuildContext c) => <PopupMenuEntry<String>>[
                PopupMenuItem<String>(value: 'open', child: Text(s.t('open'))),
                PopupMenuItem<String>(
                    value: 'csv', child: Text(s.t('export'))),
                PopupMenuItem<String>(
                    value: 'del', child: Text(s.t('delete'))),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Small static heat-map preview of a saved session.
class ThumbPainter extends HeatPainter {
  ThumbPainter({
    required List<double> cells,
    required int cols,
    required int rows,
  }) : super(
          cells: cells,
          cols: cols,
          rows: rows,
          lo: _lo(cells),
          hi: _hi(cells),
        );

  static double _lo(List<double> c) => _range(c)[0];
  static double _hi(List<double> c) => _range(c)[1];

  static List<double> _range(List<double> c) {
    final st = statsOf(c);
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < 1.0) {
      final mid = (hi + lo) / 2;
      lo = mid - 0.5;
      hi = mid + 0.5;
    }
    return <double>[lo, hi];
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) =>
      old is! ThumbPainter || !identical(old.cells, cells);
}
