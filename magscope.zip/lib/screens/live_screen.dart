import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  double? _cursor;

  Future<void> _save(AppState s) async {
    final ctrl = TextEditingController(text: 'Scan_${stamp(DateTime.now())}');
    final name = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(s.t('session_name')),
        content: TextField(controller: ctrl, autofocus: true),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: Text(s.t('save')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (name == null || name.isEmpty) return;
    await s.saveCurrent(name);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  void _calibrate(AppState s) {
    s.calibrate();
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('calibrated'))));
  }

  Widget _mini(String label, String value, {Color? color}) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style: const TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          Num(
            value,
            style: TextStyle(
              color: color ?? Pal.text,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _legend(Color c, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(Icons.circle, size: 10, color: c),
        const SizedBox(width: 6),
        Text(text, style: const TextStyle(color: Pal.muted, fontSize: 12)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final filtered = s.filteredLive;
    final last = filtered.isEmpty ? double.nan : filtered.last;
    final threshold = s.threshold;
    final frac = (s.live.length < 20 || threshold <= 0)
        ? 0.0
        : s.dev / (threshold * 2);
    final alarmOn = s.alarm && s.scanning;
    final alarmColor = s.kind == 2 ? Pal.violet : Pal.bad;
    final gaugeColor =
        alarmOn ? alarmColor : (s.dev >= 0 ? Pal.amber : Pal.violet);
    final filled = s.filledCells;
    final progress = s.totalCells == 0 ? 0.0 : filled / s.totalCells;
    final refText = s.refValue.isNaN ? '--' : s.refValue.toStringAsFixed(2);
    final devText = s.live.length < 20
        ? '--'
        : '${s.dev >= 0 ? '+' : ''}${s.dev.toStringAsFixed(2)}';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          glow: alarmOn ? alarmColor : null,
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 200,
                child: Stack(
                  children: <Widget>[
                    Positioned.fill(
                      child: CustomPaint(
                        painter: GaugePainter(frac: frac, color: gaugeColor),
                      ),
                    ),
                    Align(
                      alignment: const Alignment(0, 0.2),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Num(
                            last.isNaN ? '--' : last.toStringAsFixed(2),
                            style: TextStyle(
                              fontSize: 50,
                              height: 1.0,
                              fontWeight: FontWeight.w800,
                              color: alarmOn ? alarmColor : Pal.text,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            alarmOn
                                ? s.t(s.kind == 1 ? 'kind_metal' : 'kind_void')
                                : s.t('unit'),
                            style: TextStyle(
                              color: alarmOn ? alarmColor : Pal.muted,
                              fontWeight:
                                  alarmOn ? FontWeight.w700 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: <Widget>[
                  _mini(s.t('reference'), refText),
                  _mini(s.t('deviation'), devText,
                      color: alarmOn ? alarmColor : null),
                  _mini(s.t('threshold'), s.threshold.toStringAsFixed(2)),
                  _mini(s.t('rate'), '${s.sampleRate.toStringAsFixed(0)} Hz'),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: (alarmOn ? alarmColor : Pal.muted).withAlpha(30),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: (alarmOn ? alarmColor : Pal.outline)
                          .withAlpha(alarmOn ? 150 : 255)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(
                      !alarmOn
                          ? Icons.remove_circle_outline
                          : (s.kind == 1 ? Icons.bolt : Icons.arrow_downward),
                      size: 18,
                      color: alarmOn ? alarmColor : Pal.muted,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      alarmOn
                          ? s.t(s.kind == 1 ? 'kind_metal' : 'kind_void')
                          : s.t('kind_none'),
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: alarmOn ? alarmColor : Pal.muted,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Text(s.t('kind_hint'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Pal.muted, fontSize: 10)),
              const SizedBox(height: 10),
              Row(
                children: <Widget>[
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed:
                          s.live.length >= 10 ? () => _calibrate(s) : null,
                      icon: const Icon(Icons.my_location),
                      label: Text(s.t('calibrate')),
                    ),
                  ),
                  if (s.baselineRef != null) ...<Widget>[
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: s.resetCalibration,
                      tooltip: s.t('reset_ref'),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 230,
                width: double.infinity,
                child: LayoutBuilder(
                  builder: (BuildContext ctx, BoxConstraints c) {
                    void setX(double dx) {
                      final w =
                          c.maxWidth - LinePainter.padL - LinePainter.padR;
                      if (w <= 0) return;
                      setState(() {
                        _cursor = ((dx - LinePainter.padL) / w)
                            .clamp(0.0, 1.0)
                            .toDouble();
                      });
                    }

                    void clear() => setState(() => _cursor = null);
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTapDown: (TapDownDetails d) => setX(d.localPosition.dx),
                      onTapUp: (TapUpDetails d) => clear(),
                      onTapCancel: clear,
                      onHorizontalDragUpdate: (DragUpdateDetails d) =>
                          setX(d.localPosition.dx),
                      onHorizontalDragEnd: (DragEndDetails d) => clear(),
                      onHorizontalDragCancel: clear,
                      child: CustomPaint(
                        painter: LinePainter(
                          raw: s.live,
                          filtered: filtered,
                          cursor: _cursor,
                          baseline: s.baselineRef,
                        ),
                        size: Size.infinite,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  _legend(Pal.muted, s.t('raw')),
                  const SizedBox(width: 20),
                  _legend(Pal.amber, s.t('filtered')),
                  if (s.baselineRef != null) ...<Widget>[
                    const SizedBox(width: 20),
                    _legend(Pal.violet, s.t('reference')),
                  ],
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(s.t('cell'),
                          style: const TextStyle(color: Pal.text)),
                      const SizedBox(width: 6),
                      Num('$filled / ${s.totalCells}',
                          style: const TextStyle(
                              color: Pal.text, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  Num('${s.cols} x ${s.rows}',
                      style: const TextStyle(color: Pal.muted, fontSize: 12)),
                ],
              ),
              const SizedBox(height: 10),
              LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                borderRadius: BorderRadius.circular(8),
                color: Pal.violet,
                backgroundColor: Pal.surface2,
              ),
            ],
          ),
        ),
        if (s.errorKey != null) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            glow: Pal.bad,
            child: Row(
              children: <Widget>[
                const Icon(Icons.error_outline, color: Pal.bad),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(s.t(s.errorKey!),
                      style: const TextStyle(color: Pal.bad)),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 16),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(54),
            backgroundColor: s.scanning ? Pal.bad : null,
            foregroundColor: s.scanning ? Colors.white : null,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          onPressed: s.conn == ConnState.connecting
              ? null
              : () => s.scanning ? s.stopScan() : s.startScan(),
          icon: Icon(s.scanning ? Icons.stop_rounded : Icons.play_arrow_rounded),
          label: Text(s.scanning ? s.t('stop') : s.t('start')),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: <Widget>[
            FilledButton.tonalIcon(
              onPressed: s.scanning ? s.nextCell : null,
              icon: const Icon(Icons.skip_next_rounded),
              label: Text(s.t('next_cell')),
            ),
            FilledButton.tonalIcon(
              onPressed: s.hasData ? () => _save(s) : null,
              icon: const Icon(Icons.save_outlined),
              label: Text(s.t('save')),
            ),
            FilledButton.tonalIcon(
              onPressed: s.scanning ? null : s.clearData,
              icon: const Icon(Icons.delete_sweep_outlined),
              label: Text(s.t('clear')),
            ),
          ],
        ),
      ],
    );
  }
}
