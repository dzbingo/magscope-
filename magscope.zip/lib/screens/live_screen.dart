import 'package:flutter/material.dart';

import '../state.dart';
import 'camera_screen.dart';
import '../theme.dart';
import '../widgets.dart';

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  double? _cursor;

  void _calibrate(AppState s) {
    s.calibrate();
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('calibrated'))));
  }

  Widget _mini(String label, String value, {Color? color}) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style:  TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          Num(
            value,
            style: TextStyle(
              color: color ?? Pal.text,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _legend(Color c, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(Icons.circle, size: 10, color: c),
        const SizedBox(width: 6),
        Text(text, style:  TextStyle(color: Pal.muted, fontSize: 12)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final filtered = s.filteredLive;
    final last = filtered.isEmpty ? double.nan : filtered.last;
    final threshold = s.threshold;
    final frac = (s.live.length < 20 || threshold <= 0)
        ? 0.0
        : s.dev / (threshold * 2);
    final alarmOn = s.alarm && s.conn == ConnState.connected;
    final alarmColor = s.kind == 2 ? Pal.violet : Pal.bad;
    final gaugeColor =
        alarmOn ? alarmColor : (s.dev >= 0 ? Pal.amber : Pal.violet);
    final refText = s.refValue.isNaN ? '--' : s.refValue.toStringAsFixed(2);
    final devText = s.live.length < 20
        ? '--'
        : '${s.dev >= 0 ? '+' : ''}${s.dev.toStringAsFixed(2)}';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          glow: alarmOn ? alarmColor : null,
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 200,
                child: Stack(
                  children: <Widget>[
                    Positioned.fill(
                      child: TweenAnimationBuilder<double>(
                        tween: Tween<double>(end: frac),
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOutCubic,
                        builder: (BuildContext c, double v, Widget? w) =>
                            CustomPaint(
                          painter: GaugePainter(frac: v, color: gaugeColor),
                        ),
                      ),
                    ),
                    Align(
                      alignment: const Alignment(0, 0.2),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Num(
                            last.isNaN ? '--' : last.toStringAsFixed(2),
                            style: TextStyle(
                              fontSize: 50,
                              height: 1.0,
                              fontWeight: FontWeight.w800,
                              color: alarmOn ? alarmColor : Pal.text,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            alarmOn
                                ? s.t(s.kind == 1 ? 'kind_metal' : 'kind_void')
                                : s.t('unit'),
                            style: TextStyle(
                              color: alarmOn ? alarmColor : Pal.muted,
                              fontWeight:
                                  alarmOn ? FontWeight.w700 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: <Widget>[
                  _mini(s.t('reference'), refText),
                  _mini(s.t('deviation'), devText,
                      color: alarmOn ? alarmColor : null),
                  _mini(s.t('threshold'), s.threshold.toStringAsFixed(2)),
                  _mini(s.t('rate'), '${s.sampleRate.toStringAsFixed(0)} Hz'),
                ],
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: (alarmOn ? alarmColor : Pal.muted).withAlpha(30),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: (alarmOn ? alarmColor : Pal.outline)
                          .withAlpha(alarmOn ? 150 : 255)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(
                      !alarmOn
                          ? Icons.remove_circle_outline
                          : (s.kind == 1 ? Icons.bolt : Icons.arrow_downward),
                      size: 18,
                      color: alarmOn ? alarmColor : Pal.muted,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      alarmOn
                          ? s.t(s.kind == 1 ? 'kind_metal' : 'kind_void')
                          : s.t('kind_none'),
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: alarmOn ? alarmColor : Pal.muted,
                      ),
                    ),
                  ],
                ),
              ),
              if (alarmOn && s.liveVerdict > 0) ...<Widget>[
                const SizedBox(height: 6),
                Text(s.t('live_verdict_${s.liveVerdict}'),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: s.liveVerdict == 2 ? Pal.good : Pal.amber,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
              ],
              const SizedBox(height: 6),
              Text(s.t('kind_hint'),
                  textAlign: TextAlign.center,
                  style:  TextStyle(color: Pal.muted, fontSize: 10)),
              const SizedBox(height: 10),
              Row(
                children: <Widget>[
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed:
                          s.live.length >= 10 ? () => _calibrate(s) : null,
                      icon: const Icon(Icons.my_location),
                      label: Text(s.t('calibrate')),
                    ),
                  ),
                  if (s.baselineRef != null) ...<Widget>[
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed: s.resetCalibration,
                      tooltip: s.t('reset_ref'),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 230,
                width: double.infinity,
                child: LayoutBuilder(
                  builder: (BuildContext ctx, BoxConstraints c) {
                    void setX(double dx) {
                      final w =
                          c.maxWidth - LinePainter.padL - LinePainter.padR;
                      if (w <= 0) return;
                      setState(() {
                        _cursor = ((dx - LinePainter.padL) / w)
                            .clamp(0.0, 1.0)
                            .toDouble();
                      });
                    }

                    void clear() => setState(() => _cursor = null);
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTapDown: (TapDownDetails d) => setX(d.localPosition.dx),
                      onTapUp: (TapUpDetails d) => clear(),
                      onTapCancel: clear,
                      onHorizontalDragUpdate: (DragUpdateDetails d) =>
                          setX(d.localPosition.dx),
                      onHorizontalDragEnd: (DragEndDetails d) => clear(),
                      onHorizontalDragCancel: clear,
                      child: CustomPaint(
                        painter: LinePainter(
                          raw: s.live,
                          filtered: filtered,
                          cursor: _cursor,
                          baseline: s.baselineRef,
                        ),
                        size: Size.infinite,
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  _legend(Pal.muted, s.t('raw')),
                  const SizedBox(width: 20),
                  _legend(Pal.amber, s.t('filtered')),
                  if (s.baselineRef != null) ...<Widget>[
                    const SizedBox(width: 20),
                    _legend(Pal.violet, s.t('reference')),
                  ],
                ],
              ),
            ],
          ),
        ),
        if (s.errorKey != null) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            glow: Pal.bad,
            child: Row(
              children: <Widget>[
                 Icon(Icons.error_outline, color: Pal.bad),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(s.t(s.errorKey!),
                          style: TextStyle(color: Pal.bad)),
                      if (s.errorDetail.isNotEmpty)
                        Text(s.errorDetail,
                            textDirection: TextDirection.ltr,
                            style: TextStyle(color: Pal.muted, fontSize: 10)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
        if (s.useBle && s.conn == ConnState.connected && s.live.isEmpty) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  s.packetCount == 0
                      ? s.t('connected_wait')
                      : s.t('no_readings_hint'),
                  style: TextStyle(color: Pal.amber),
                ),
                if (s.packetCount > 0)
                  Text('${s.t('packets')}: ${s.packetCount}   ${s.lastPacketHex}',
                      textDirection: TextDirection.ltr,
                      style: TextStyle(color: Pal.muted, fontSize: 11)),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        Text(s.t('live_hint'),
            textAlign: TextAlign.center,
            style: TextStyle(color: Pal.muted, fontSize: 11)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: <Widget>[
            FilledButton.tonalIcon(
              onPressed: s.conn == ConnState.connecting
                  ? null
                  : () => s.conn == ConnState.connected
                      ? s.disconnect()
                      : s.connect(),
              icon: Icon(s.conn == ConnState.connected
                  ? Icons.bluetooth_disabled
                  : Icons.bluetooth_connected),
              label: Text(s.conn == ConnState.connected
                  ? s.t('disconnect')
                  : s.t('connect')),
            ),
            FilledButton.tonalIcon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                    builder: (BuildContext c) => const CameraScanScreen()),
              ),
              icon: const Icon(Icons.photo_camera_outlined),
              label: Text(s.t('camera_view')),
            ),
          ],
        ),
      ],
    );
  }
}
