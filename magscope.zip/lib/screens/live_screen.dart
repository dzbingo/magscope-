import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class LiveScreen extends StatelessWidget {
  const LiveScreen({super.key});

  Future<void> _save(BuildContext context, AppState s) async {
    final ctrl = TextEditingController(text: 'Scan_${stamp(DateTime.now())}');
    final name = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(s.t('session_name')),
        content: TextField(controller: ctrl, autofocus: true),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: Text(s.t('save')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (name == null || name.isEmpty) return;
    await s.saveCurrent(name);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final filtered = s.filteredLive;
    final last = filtered.isEmpty ? double.nan : filtered.last;
    final progress = s.totalCells == 0 ? 0.0 : s.cellIdx / s.totalCells;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(s.t('reading'),
                        style: const TextStyle(color: Pal.muted, fontSize: 12)),
                    const SizedBox(height: 4),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: <Widget>[
                        Text(
                          last.isNaN ? '--' : last.toStringAsFixed(2),
                          style: const TextStyle(
                            fontSize: 44,
                            fontWeight: FontWeight.w700,
                            color: Pal.amber,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(s.t('unit'),
                            style: const TextStyle(color: Pal.muted)),
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    '${s.t('raw')}: ${s.lastValue.isNaN ? '--' : s.lastValue.toStringAsFixed(2)}',
                    style: const TextStyle(color: Pal.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    s.useBle ? s.t('ble') : s.t('simulator'),
                    style: const TextStyle(color: Pal.violet, fontSize: 12),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.fromLTRB(8, 12, 8, 10),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 220,
                width: double.infinity,
                child: CustomPaint(
                  painter: LinePainter(raw: s.live, filtered: filtered),
                  size: Size.infinite,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const Icon(Icons.circle, size: 10, color: Pal.muted),
                  const SizedBox(width: 6),
                  Text(s.t('raw'),
                      style: const TextStyle(color: Pal.muted, fontSize: 12)),
                  const SizedBox(width: 18),
                  const Icon(Icons.circle, size: 10, color: Pal.amber),
                  const SizedBox(width: 6),
                  Text(s.t('filtered'),
                      style: const TextStyle(color: Pal.muted, fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    '${s.t('cell')} ${s.cellIdx < s.totalCells ? s.cellIdx + 1 : s.totalCells} / ${s.totalCells}',
                    style: const TextStyle(color: Pal.text),
                  ),
                  Text('${s.cols} x ${s.rows}',
                      style: const TextStyle(color: Pal.muted, fontSize: 12)),
                ],
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                borderRadius: BorderRadius.circular(8),
                color: Pal.violet,
                backgroundColor: Pal.surface2,
              ),
            ],
          ),
        ),
        if (s.errorKey != null) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            child: Row(
              children: <Widget>[
                const Icon(Icons.error_outline, color: Pal.bad),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(s.t(s.errorKey!),
                      style: const TextStyle(color: Pal.bad)),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 16),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: <Widget>[
            FilledButton.icon(
              onPressed: s.conn == ConnState.connecting
                  ? null
                  : () => s.scanning ? s.stopScan() : s.startScan(),
              icon: Icon(s.scanning ? Icons.stop : Icons.play_arrow),
              label: Text(s.scanning ? s.t('stop') : s.t('start')),
            ),
            OutlinedButton.icon(
              onPressed: s.scanning ? s.nextCell : null,
              icon: const Icon(Icons.skip_next),
              label: Text(s.t('next_cell')),
            ),
            OutlinedButton.icon(
              onPressed: s.hasData ? () => _save(context, s) : null,
              icon: const Icon(Icons.save_outlined),
              label: Text(s.t('save')),
            ),
            OutlinedButton.icon(
              onPressed: s.scanning ? null : s.clearData,
              icon: const Icon(Icons.delete_sweep_outlined),
              label: Text(s.t('clear')),
            ),
          ],
        ),
      ],
    );
  }
}
