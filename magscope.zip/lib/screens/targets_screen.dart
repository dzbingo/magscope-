import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:share_plus/share_plus.dart';

import '../heading.dart';
import '../state.dart';
import '../targets.dart';
import '../theme.dart';
import '../widgets.dart';

/// Saved targets: notes, dig result, KML export and guidance to each one.
class TargetsScreen extends StatelessWidget {
  const TargetsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('targets_title')),
        actions: <Widget>[
          IconButton(
            tooltip: s.t('target_export'),
            icon: const Icon(Icons.ios_share),
            onPressed: s.targets.isEmpty
                ? null
                : () async {
                    final path = await TargetGeo.writeKml(s.targets);
                    await Share.shareXFiles(<XFile>[
                      XFile(path, mimeType: 'application/vnd.google-earth.kml+xml')
                    ]);
                  },
          ),
        ],
      ),
      body: s.targets.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(s.t('targets_empty'),
                    style: TextStyle(color: Pal.muted)),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: <Widget>[
                for (final t in s.targets.reversed) _card(context, s, t),
              ],
            ),
    );
  }

  Widget _card(BuildContext context, AppState s, FieldTarget t) {
    final verdictText = t.verdict == 1
        ? s.t('target_real')
        : (t.verdict == 2 ? s.t('target_fake') : s.t('target_unchecked'));
    final verdictColor =
        t.verdict == 1 ? Pal.good : (t.verdict == 2 ? Pal.bad : Pal.muted);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text('#${t.id}  ${t.kindKey.isEmpty ? '' : s.t(t.kindKey)}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                Text(verdictText,
                    style: TextStyle(color: verdictColor, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${t.lat.toStringAsFixed(6)}, ${t.lon.toStringAsFixed(6)}',
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 12),
            ),
            if (t.depthMin != null && t.depthMax != null)
              Text(
                '${s.t('tk_depth_range')}: ${t.depthMin!.toStringAsFixed(1)} - ${t.depthMax!.toStringAsFixed(1)} m',
                style: const TextStyle(fontSize: 12),
              ),
            if (t.note.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(t.note, style: TextStyle(color: Pal.amber)),
              ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: <Widget>[
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (BuildContext c) => TargetNavScreen(target: t)),
                  ),
                  icon: const Icon(Icons.navigation_outlined, size: 18),
                  label: Text(s.t('target_nav')),
                ),
                OutlinedButton(
                  onPressed: () => s.setTargetVerdict(t, 1),
                  child: Text(s.t('target_real')),
                ),
                OutlinedButton(
                  onPressed: () => s.setTargetVerdict(t, 2),
                  child: Text(s.t('target_fake')),
                ),
                TextButton(
                  onPressed: () async {
                    final c = TextEditingController(text: t.note);
                    final v = await showDialog<String>(
                      context: context,
                      builder: (BuildContext dc) => AlertDialog(
                        title: Text(s.t('target_note')),
                        content: TextField(controller: c, autofocus: true),
                        actions: <Widget>[
                          TextButton(
                              onPressed: () => Navigator.pop(dc),
                              child: Text(s.t('cancel'))),
                          FilledButton(
                              onPressed: () => Navigator.pop(dc, c.text),
                              child: Text(s.t('ok'))),
                        ],
                      ),
                    );
                    c.dispose();
                    if (v != null) s.setTargetNote(t, v);
                  },
                  child: Text(s.t('target_note')),
                ),
                TextButton(
                  onPressed: () => s.deleteTarget(t),
                  child: Text(s.t('delete'), style: TextStyle(color: Pal.bad)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Arrow + distance that guides the examiner back to a saved target.
class TargetNavScreen extends StatefulWidget {
  const TargetNavScreen({super.key, required this.target});
  final FieldTarget target;

  @override
  State<TargetNavScreen> createState() => _TargetNavScreenState();
}

class _TargetNavScreenState extends State<TargetNavScreen> {
  StreamSubscription<Position>? _pos;
  StreamSubscription<double>? _hdg;
  Position? _p;
  double _heading = 0;

  @override
  void initState() {
    super.initState();
    try {
      _pos = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          distanceFilter: 0,
        ),
      ).listen((Position p) {
        if (mounted) setState(() => _p = p);
      }, onError: (Object _) {});
    } catch (_) {}
    _hdg = HeadingService.stream().listen((double h) {
      if (mounted) setState(() => _heading = h);
    }, onError: (Object _) {});
  }

  @override
  void dispose() {
    _pos?.cancel();
    _hdg?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final t = widget.target;
    final p = _p;
    double? dist;
    double rel = 0;
    if (p != null) {
      dist = TargetGeo.distance(p.latitude, p.longitude, t.lat, t.lon);
      final b = TargetGeo.bearing(p.latitude, p.longitude, t.lat, t.lon);
      rel = (b - _heading) * math.pi / 180.0;
    }
    final arrived = dist != null && dist < math.max(1.0, (p?.accuracy ?? 0) * 0.5);
    return Scaffold(
      appBar: AppBar(title: Text('${s.t('target_nav')} #${t.id}')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (dist == null)
                  Text(s.t('target_gps_wait'), style: TextStyle(color: Pal.muted))
                else ...<Widget>[
                  Transform.rotate(
                    angle: rel,
                    child: Icon(
                      arrived ? Icons.check_circle : Icons.navigation,
                      size: 190,
                      color: arrived ? Pal.good : Pal.amber,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    dist >= 1000
                        ? '${(dist / 1000).toStringAsFixed(2)} km'
                        : '${dist.toStringAsFixed(1)} m',
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800),
                  ),
                  Text(arrived ? s.t('target_arrived') : s.t('target_follow'),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Pal.muted)),
                  const SizedBox(height: 6),
                  Text('±${p!.accuracy.toStringAsFixed(0)} m GPS',
                      textDirection: TextDirection.ltr,
                      style: TextStyle(color: Pal.muted, fontSize: 12)),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
