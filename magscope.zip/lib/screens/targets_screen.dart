import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:share_plus/share_plus.dart';

import '../heading.dart';
import '../state.dart';
import '../targets.dart';
import '../theme.dart';
import '../widgets.dart';

/// Saved targets: notes, dig result, KML export and guidance to each one.
class TargetsScreen extends StatelessWidget {
  const TargetsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('targets_title')),
        actions: <Widget>[
          IconButton(
            tooltip: s.t('target_export'),
            icon: const Icon(Icons.ios_share),
            onPressed: s.targets.isEmpty
                ? null
                : () async {
                    final path = await TargetGeo.writeKml(s.targets);
                    await Share.shareXFiles(<XFile>[
                      XFile(path, mimeType: 'application/vnd.google-earth.kml+xml')
                    ]);
                  },
          ),
        ],
      ),
      body: s.targets.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(s.t('targets_empty'),
                    style: TextStyle(color: Pal.muted)),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: <Widget>[
                for (final t in s.targets.reversed) _card(context, s, t),
              ],
            ),
    );
  }

  Widget _card(BuildContext context, AppState s, FieldTarget t) {
    final verdictText = t.verdict == 1
        ? s.t('target_real')
        : (t.verdict == 2 ? s.t('target_fake') : s.t('target_unchecked'));
    final verdictColor =
        t.verdict == 1 ? Pal.good : (t.verdict == 2 ? Pal.bad : Pal.muted);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text('#${t.id}  ${t.kindKey.isEmpty ? '' : s.t(t.kindKey)}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                Text(verdictText,
                    style: TextStyle(color: verdictColor, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '${t.lat.toStringAsFixed(6)}, ${t.lon.toStringAsFixed(6)}',
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 12),
            ),
            if (t.depthMin != null && t.depthMax != null)
              Text(
                '${s.t('tk_depth_range')}: ${t.depthMin!.toStringAsFixed(1)} - ${t.depthMax!.toStringAsFixed(1)} m',
                style: const TextStyle(fontSize: 12),
              ),
            if (t.walkFwd != null && t.walkRight != null && t.walkHeading != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  s.t('walk_guide')
                      .replaceAll('{f}', t.walkFwd!.toStringAsFixed(1))
                      .replaceAll('{h}', t.walkHeading!.toStringAsFixed(0))
                      .replaceAll('{r}', t.walkRight!.abs().toStringAsFixed(1))
                      .replaceAll(
                          '{d}', t.walkRight! >= 0 ? s.t('side_right') : s.t('side_left')),
                  style: TextStyle(color: Pal.muted, fontSize: 12),
                ),
              ),
            if (t.note.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(t.note, style: TextStyle(color: Pal.amber)),
              ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: <Widget>[
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (BuildContext c) => TargetNavScreen(target: t)),
                  ),
                  icon: const Icon(Icons.navigation_outlined, size: 18),
                  label: Text(s.t('target_nav')),
                ),
                OutlinedButton(
                  onPressed: () => s.setTargetVerdict(t, 1),
                  child: Text(s.t('target_real')),
                ),
                OutlinedButton(
                  onPressed: () => s.setTargetVerdict(t, 2),
                  child: Text(s.t('target_fake')),
                ),
                TextButton(
                  onPressed: () async {
                    final c = TextEditingController(text: t.note);
                    final v = await showDialog<String>(
                      context: context,
                      builder: (BuildContext dc) => AlertDialog(
                        title: Text(s.t('target_note')),
                        content: TextField(controller: c, autofocus: true),
                        actions: <Widget>[
                          TextButton(
                              onPressed: () => Navigator.pop(dc),
                              child: Text(s.t('cancel'))),
                          FilledButton(
                              onPressed: () => Navigator.pop(dc, c.text),
                              child: Text(s.t('ok'))),
                        ],
                      ),
                    );
                    c.dispose();
                    if (v != null) s.setTargetNote(t, v);
                  },
                  child: Text(s.t('target_note')),
                ),
                TextButton(
                  onPressed: () => s.deleteTarget(t),
                  child: Text(s.t('delete'), style: TextStyle(color: Pal.bad)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Arrow + distance that guides the examiner back to a saved target.
class TargetNavScreen extends StatefulWidget {
  const TargetNavScreen({super.key, required this.target});
  final FieldTarget target;

  @override
  State<TargetNavScreen> createState() => _TargetNavScreenState();
}

class _TargetNavScreenState extends State<TargetNavScreen> {
  StreamSubscription<Position>? _pos;
  StreamSubscription<double>? _hdg;
  final MapController _mc = MapController();
  Position? _p;
  double _heading = 0;
  bool _sat = true;
  bool _follow = true;
  bool _ready = false;
  bool _fitted = false;

  @override
  void initState() {
    super.initState();
    try {
      _pos = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          distanceFilter: 0,
        ),
      ).listen((Position p) {
        if (!mounted) return;
        setState(() => _p = p);
        _syncCamera();
      }, onError: (Object _) {});
    } catch (_) {}
    _hdg = HeadingService.stream().listen((double h) {
      if (mounted) setState(() => _heading = h);
    }, onError: (Object _) {});
  }

  /// First fix: show you and the target together; afterwards follow you.
  void _syncCamera() {
    final p = _p;
    if (p == null || !_ready) return;
    try {
      final me = LatLng(p.latitude, p.longitude);
      final tg = LatLng(widget.target.lat, widget.target.lon);
      if (!_fitted) {
        _fitted = true;
        _mc.fitCamera(CameraFit.coordinates(
          coordinates: <LatLng>[me, tg],
          padding: const EdgeInsets.all(70),
          maxZoom: 19,
        ));
      } else if (_follow) {
        _mc.move(me, _mc.camera.zoom);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _pos?.cancel();
    _hdg?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final t = widget.target;
    final p = _p;
    final tg = LatLng(t.lat, t.lon);
    double? dist;
    double rel = 0;
    if (p != null) {
      dist = TargetGeo.distance(p.latitude, p.longitude, t.lat, t.lon);
      final b = TargetGeo.bearing(p.latitude, p.longitude, t.lat, t.lon);
      rel = (b - _heading) * math.pi / 180.0;
    }
    final arrived = dist != null && dist < math.max(1.0, (p?.accuracy ?? 0) * 0.5);
    return Scaffold(
      appBar: AppBar(
          title: Text(t.id > 0
              ? '${s.t('target_nav')} #${t.id}'
              : (t.sessionName.isEmpty ? s.t('target_nav') : t.sessionName))),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Stack(
              children: <Widget>[
                FlutterMap(
                  mapController: _mc,
                  options: MapOptions(
                    initialCenter: tg,
                    initialZoom: 18,
                    maxZoom: 21,
                    onMapReady: () {
                      _ready = true;
                      _syncCamera();
                    },
                    onPositionChanged: (MapCamera c, bool byUser) {
                      if (byUser && _follow) setState(() => _follow = false);
                    },
                  ),
                  children: <Widget>[
                    TileLayer(
                      urlTemplate: _sat
                          ? 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
                          : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'com.sniperdz.magscope',
                      maxNativeZoom: _sat ? 17 : 19,
                      maxZoom: 21,
                    ),
                    if (p != null)
                      PolylineLayer(
                        polylines: <Polyline>[
                          Polyline(
                            points: <LatLng>[LatLng(p.latitude, p.longitude), tg],
                            strokeWidth: 3,
                            color: Colors.amber,
                          ),
                        ],
                      ),
                    if (p != null)
                      CircleLayer(
                        circles: <CircleMarker>[
                          CircleMarker(
                            point: LatLng(p.latitude, p.longitude),
                            radius: math.max(p.accuracy, 1.0),
                            useRadiusInMeter: true,
                            color: Colors.blue.withAlpha(40),
                            borderColor: Colors.blue.withAlpha(120),
                            borderStrokeWidth: 1,
                          ),
                        ],
                      ),
                    MarkerLayer(
                      markers: <Marker>[
                        Marker(
                          point: tg,
                          width: 44,
                          height: 44,
                          alignment: Alignment.topCenter,
                          child: const Icon(Icons.location_on,
                              color: Colors.redAccent, size: 44),
                        ),
                        if (p != null)
                          Marker(
                            point: LatLng(p.latitude, p.longitude),
                            width: 44,
                            height: 44,
                            child: Transform.rotate(
                              angle: _heading * math.pi / 180.0,
                              child: const Icon(Icons.navigation,
                                  color: Color(0xFF29B6F6), size: 40),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Column(
                    children: <Widget>[
                      FilledButton.tonalIcon(
                        onPressed: () => setState(() => _sat = !_sat),
                        icon: Icon(_sat ? Icons.map_outlined : Icons.satellite_alt),
                        label: Text(_sat ? 'MAP' : 'SAT'),
                      ),
                      const SizedBox(height: 6),
                      IconButton.filledTonal(
                        tooltip: s.t('target_follow_me'),
                        onPressed: () {
                          setState(() => _follow = true);
                          _syncCamera();
                        },
                        icon: Icon(_follow ? Icons.my_location : Icons.location_searching),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              child: dist == null
                  ? Text(s.t('target_gps_wait'), style: TextStyle(color: Pal.muted))
                  : Row(
                      children: <Widget>[
                        Transform.rotate(
                          angle: rel,
                          child: Icon(
                            arrived ? Icons.check_circle : Icons.navigation,
                            size: 64,
                            color: arrived ? Pal.good : Pal.amber,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                dist >= 1000
                                    ? '${(dist / 1000).toStringAsFixed(2)} km'
                                    : '${dist.toStringAsFixed(1)} m',
                                textDirection: TextDirection.ltr,
                                style: const TextStyle(
                                    fontSize: 32, fontWeight: FontWeight.w800),
                              ),
                              Text(
                                  arrived
                                      ? s.t('target_arrived')
                                      : s.t('target_follow'),
                                  style: TextStyle(color: Pal.muted, fontSize: 12)),
                              Text('±${p!.accuracy.toStringAsFixed(0)} m GPS',
                                  textDirection: TextDirection.ltr,
                                  style: TextStyle(color: Pal.muted, fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
