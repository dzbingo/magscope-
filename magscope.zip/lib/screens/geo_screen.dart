import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';

import '../geo.dart';
import '../geo_overlay.dart';
import '../imaging.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Lets the examiner pick the scan to project: the current one or a saved one.
Future<void> showGeoPicker(BuildContext context, AppState s) async {
  final list = <ScanSession>[
    if (s.hasData) s.snapshot('Scan_${stamp(DateTime.now())}'),
    ...s.sessions,
  ];
  if (list.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('no_data'))));
    return;
  }
  final pick = await showModalBottomSheet<ScanSession>(
    context: context,
    backgroundColor: Pal.surface,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (BuildContext c) => SafeArea(
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(c).size.height * 0.7),
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          children: <Widget>[
            Text(s.t('geo_overlay'),
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(s.t('geo_pick'),
                style: TextStyle(color: Pal.muted, fontSize: 12)),
            for (int i = 0; i < list.length; i++)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(i == 0 && s.hasData ? Icons.bolt : Icons.folder_open,
                    color: Pal.amber),
                title: Text(list[i].name, overflow: TextOverflow.ellipsis),
                subtitle: Text(
                    '${list[i].cols}x${list[i].rows}   ${list[i].geo == null ? s.t('geo_no_gps') : 'GPS'}',
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
                onTap: () => Navigator.pop(c, list[i]),
              ),
          ],
        ),
      ),
    ),
  );
  if (pick == null || !context.mounted) return;
  await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (BuildContext c) => GeoOverlayScreen(session: pick)));
}

/// The scan drawn on a real map, at its true place, size and direction.
class GeoOverlayScreen extends StatefulWidget {
  const GeoOverlayScreen({super.key, required this.session});
  final ScanSession session;

  @override
  State<GeoOverlayScreen> createState() => _GeoOverlayScreenState();
}

class _GeoOverlayScreenState extends State<GeoOverlayScreen> {
  ScanGeoLocation? _geo;
  double _heading = 0;
  double _opacity = 0.75;
  bool _sat = true;
  bool _busy = false;
  bool _loading = true;
  bool _inited = false;
  Uint8List? _png;
  final MapController _mc = MapController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_inited) return;
    _inited = true;
    final s = AppScope.of(context);
    _geo = widget.session.geo;
    _heading = _geo != null && _geo!.heading != 0 ? _geo!.heading : s.scanHeading;
    _start(s);
  }

  Future<void> _start(AppState s) async {
    final png = await Imaging.overlayPng(
        widget.session.cells, widget.session.cols, widget.session.rows,
        alpha: 235);
    ScanGeoLocation? g = _geo;
    g ??= await s.currentGeo();
    if (!mounted) return;
    setState(() {
      _png = png;
      _geo = g;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _mc.dispose();
    super.dispose();
  }

  ScanSession get _sess => _geo == null
      ? widget.session
      : widget.session.withGeo(_geo!.withHeading(_heading));

  Future<void> _earth(AppState s, {required bool share}) async {
    final g = _geo;
    if (g == null) return;
    setState(() => _busy = true);
    try {
      final f = GeoFrame(g, widget.session.cols, widget.session.rows,
          s.cellCm / 100.0, _heading);
      final path = await GeoOverlayExport.writeKmz(_sess, f,
          sensitivity: s.effSens, alpha: (_opacity * 255).round());
      bool opened = false;
      if (!share) {
        try {
          final r = await OpenFilex.open(path,
              type: 'application/vnd.google-earth.kmz');
          opened = r.type == ResultType.done;
        } catch (_) {}
      }
      if (!opened) {
        await Share.shareXFiles(<XFile>[
          XFile(path, mimeType: 'application/vnd.google-earth.kmz')
        ]);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(s.t('share_failed'))));
      }
    }
    if (mounted) setState(() => _busy = false);
  }

  LatLng _ll(GeoPt p) => LatLng(p.lat, p.lon);

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final g = _geo;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('geo_overlay'))),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : g == null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(s.t('kml_need_gps'),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Pal.muted)),
                    ),
                  )
                : _body(s, g),
      ),
    );
  }

  Widget _body(AppState s, ScanGeoLocation g) {
    final f = GeoFrame(g, widget.session.cols, widget.session.rows,
        s.cellCm / 100.0, _heading);
    final png = _png;
    return Column(
      children: <Widget>[
        Expanded(
          child: Stack(
            children: <Widget>[
              FlutterMap(
                mapController: _mc,
                options: MapOptions(
                  initialCenter: LatLng(g.latitude, g.longitude),
                  initialZoom: 19,
                  maxZoom: 22,
                ),
                children: <Widget>[
                  TileLayer(
                    urlTemplate: _sat
                        ? 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
                        : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.sniperdz.magscope',
                    maxNativeZoom: 19,
                    maxZoom: 22,
                  ),
                  if (png != null)
                    OverlayImageLayer(
                      overlayImages: <BaseOverlayImage>[
                        RotatedOverlayImage(
                          topLeftCorner: _ll(f.topLeft),
                          bottomLeftCorner: _ll(f.bottomLeft),
                          bottomRightCorner: _ll(f.bottomRight),
                          imageProvider: MemoryImage(png),
                          opacity: _opacity,
                        ),
                      ],
                    ),
                  MarkerLayer(
                    markers: <Marker>[
                      Marker(
                        point: LatLng(g.latitude, g.longitude),
                        width: 22,
                        height: 22,
                        child: const Icon(Icons.add, color: Colors.white, size: 22),
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                left: 6,
                bottom: 4,
                child: Container(
                  color: const Color(0x99000000),
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text(
                      _sat
                          ? 'Imagery: Esri, Maxar, Earthstar Geographics'
                          : '© OpenStreetMap contributors',
                      style: const TextStyle(color: Colors.white, fontSize: 9)),
                ),
              ),
            ],
          ),
        ),
        Container(
          color: Pal.surface,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Text(s.t('sat_opacity'),
                      style: TextStyle(color: Pal.muted, fontSize: 12)),
                  Expanded(
                    child: Slider(
                      value: _opacity,
                      min: 0.1,
                      max: 1,
                      onChanged: (double v) => setState(() => _opacity = v),
                    ),
                  ),
                  ChoiceChip(
                    label: Text(_sat ? s.t('geo_satellite') : s.t('geo_street')),
                    selected: _sat,
                    onSelected: (bool v) => setState(() => _sat = !_sat),
                  ),
                ],
              ),
              Row(
                children: <Widget>[
                  Text('${s.t('geo_heading')}: ${_heading.round()}°',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Expanded(
                    child: Slider(
                      value: _heading.clamp(0.0, 359.0).toDouble(),
                      min: 0,
                      max: 359,
                      onChanged: (double v) => setState(() => _heading = v),
                      onChangeEnd: s.setScanHeading,
                    ),
                  ),
                  IconButton(
                    tooltip: s.t('geo_from_compass'),
                    icon: Icon(Icons.explore, color: Pal.amber),
                    onPressed: () {
                      setState(() => _heading = AppState.compassDeg);
                      s.setScanHeading(AppState.compassDeg);
                    },
                  ),
                ],
              ),
              Text(s.t('geo_heading_hint'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _busy ? null : () => _earth(s, share: false),
                      icon: _busy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.public),
                      label: Text(s.t('geo_open_earth')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filledTonal(
                    tooltip: s.t('geo_share_kmz'),
                    onPressed: _busy ? null : () => _earth(s, share: true),
                    icon: const Icon(Icons.ios_share),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(s.t('geo_note'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ),
      ],
    );
  }
}
