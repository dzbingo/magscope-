import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import '../insight.dart';
import 'map_lab.dart';

class AnalysisScreen extends StatelessWidget {
  const AnalysisScreen({super.key});

  Widget _slider(
    String label,
    String valueText,
    double value,
    double min,
    double max,
    int? divisions,
    ValueChanged<double> onChanged,
  ) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(label,
                  style:  TextStyle(color: Pal.muted, fontSize: 13)),
            ),
            Text(valueText,
                style:  TextStyle(color: Pal.text, fontSize: 13)),
          ],
        ),
        Slider(
          value: value.clamp(min, max).toDouble(),
          min: min,
          max: max,
          divisions: divisions,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _stat(String label, double v) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style:  TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 4),
          Num(v.toStringAsFixed(2),
              style:  TextStyle(
                  color: Pal.text, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final f = s.filters;

    // Analyse at most the last 2000 samples to keep the screen responsive.
    final src = s.allRaw.length > 2000
        ? s.allRaw.sublist(s.allRaw.length - 2000)
        : s.allRaw;
    final fr = f.apply(src);
    final st = statsOf(fr);

    final peakIdx = <int>[];
    final centered = <double>[];
    if (fr.length > 10) {
      final med = medianOf(fr);
      for (final v in fr) {
        centered.add(v - med);
      }
      final mad = medianOf(centered.map((e) => e.abs()).toList()) * 1.4826;
      final thr = f.sensitivity * math.max(mad, 0.05);
      peakIdx.addAll(findPeaks(centered, thr, 10));
    }
    final cellHits = s.gridAnomalies;

    final children = <Widget>[];

    if (s.hasData) {
      children.add(Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SectionTitle(s.t('stats')),
            Row(
              children: <Widget>[
                _stat(s.t('min'), st.min),
                _stat(s.t('max'), st.max),
                _stat(s.t('mean'), st.mean),
                _stat(s.t('std'), st.std),
              ],
            ),
            const SizedBox(height: 8),
            Text('${s.t('samples')}: ${s.allRaw.length}',
                style:  TextStyle(color: Pal.muted, fontSize: 12)),
          ],
        ),
      ));
      children.add(const SizedBox(height: 12));
    } else {
      children.add(Panel(
        child: Text(s.t('no_data'),
            style:  TextStyle(color: Pal.muted)),
      ));
      children.add(const SizedBox(height: 12));
    }

    if (s.hasData) {
      final ins = InsightEngine.analyze(
        s.cells,
        s.cols,
        s.rows,
        sensitivity: s.filters.sensitivity,
        absThreshold: s.manualThr ? s.thrUT : null,
        cellM: s.cellCm / 100.0,
      );
      final viewNames = <String>[
        s.t('view_normal'),
        s.t('view_hipass'),
        s.t('view_gradient'),
        s.t('view_analytic'),
      ];
      children.add(Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SectionTitle(s.t('insight')),
            if (ins.kind == -1)
              Text(s.t('insight_low_data'),
                  style: TextStyle(color: Pal.muted))
            else if (ins.kind == 0)
              Text(s.t('insight_none'))
            else ...<Widget>[
              Text(
                s.t(ins.kind == 1 ? 'insight_metal' : 'insight_void'),
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: ins.kind == 1 ? Pal.amber : Pal.violet,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${s.t('cell')} (${ins.x + 1}, ${ins.y + 1})   '
                '${ins.deviation >= 0 ? '+' : ''}${ins.deviation.toStringAsFixed(2)}   '
                '${s.t('contrast')} ${ins.contrast.toStringAsFixed(1)}x'
                '${ins.depthM == null ? '' : '   ${s.t('depth')} ~${ins.depthM!.toStringAsFixed(2)} m'}',
                textDirection: TextDirection.ltr,
                style: TextStyle(color: Pal.muted, fontSize: 12),
              ),
              const SizedBox(height: 6),
              Text('${s.t('reliability')}: ${s.t('lvl_${ins.level}')}   '
                  '(${s.t('coverage')} ${(ins.coverage * 100).toStringAsFixed(0)}%)'),
              const SizedBox(height: 4),
              Text('${s.t('target_score')}: ${ins.score}/100    '
                  '${s.t('false_risk')}: ${s.t('risk_${ins.falseRisk}')}',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: ins.falseRisk == 0
                          ? Pal.good
                          : (ins.falseRisk == 1 ? Pal.amber : Pal.bad))),
              if (ins.dipole)
                Text(s.t('insight_dipole'),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
              if (ins.isolated)
                Text(s.t('insight_isolated'),
                    style: TextStyle(color: Pal.bad, fontSize: 12)),
              if (ins.widespread)
                Text(s.t('insight_widespread'),
                    style: TextStyle(color: Pal.amber, fontSize: 12)),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                        '${s.t('suggest_view')}: ${viewNames[ins.suggestView]}',
                        style: TextStyle(color: Pal.muted, fontSize: 12)),
                  ),
                  FilledButton.tonal(
                    onPressed: s.gridView == ins.suggestView
                        ? null
                        : () => s.setGridView(ins.suggestView),
                    child: Text(s.t('apply_view')),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 8),
            Text(s.t('insight_note'),
                style: TextStyle(color: Pal.muted, fontSize: 11)),
          ],
        ),
      ));
      children.add(const SizedBox(height: 12));
      children.add(const MapLab());
      children.add(const SizedBox(height: 12));
    }

    // ---- filters ---------------------------------------------------------
    children.add(Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('filters')),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('despike')),
            value: f.despike,
            onChanged: (bool v) => s.setFilters(f.copyWith(despike: v)),
          ),
          if (f.despike)
            _slider(
              s.t('strength'),
              f.despikeK.toStringAsFixed(1),
              f.despikeK,
              2,
              8,
              12,
              (double v) => s.setFilters(f.copyWith(despikeK: v)),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('median')),
            value: f.median,
            onChanged: (bool v) => s.setFilters(f.copyWith(median: v)),
          ),
          if (f.median)
            _slider(
              s.t('window'),
              '${f.medianWindow}',
              f.medianWindow.toDouble(),
              3,
              21,
              9,
              (double v) => s.setFilters(f.copyWith(medianWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('baseline')),
            value: f.baseline,
            onChanged: (bool v) => s.setFilters(f.copyWith(baseline: v)),
          ),
          if (f.baseline)
            _slider(
              s.t('window'),
              '${f.baselineWindow}',
              f.baselineWindow.toDouble(),
              20,
              400,
              19,
              (double v) =>
                  s.setFilters(f.copyWith(baselineWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('average')),
            value: f.average,
            onChanged: (bool v) => s.setFilters(f.copyWith(average: v)),
          ),
          if (f.average)
            _slider(
              s.t('window'),
              '${f.averageWindow}',
              f.averageWindow.toDouble(),
              2,
              30,
              14,
              (double v) =>
                  s.setFilters(f.copyWith(averageWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('ema')),
            value: f.ema,
            onChanged: (bool v) => s.setFilters(f.copyWith(ema: v)),
          ),
          if (f.ema)
            _slider(
              s.t('strength'),
              f.emaAlpha.toStringAsFixed(2),
              f.emaAlpha,
              0.05,
              1.0,
              19,
              (double v) => s.setFilters(f.copyWith(emaAlpha: v)),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('grid_smooth')),
            value: f.gridSmooth,
            onChanged: (bool v) => s.setFilters(f.copyWith(gridSmooth: v)),
          ),
          if (f.gridSmooth)
            _slider(
              s.t('passes'),
              '${f.gridPasses}',
              f.gridPasses.toDouble(),
              1,
              4,
              3,
              (double v) => s.setFilters(f.copyWith(gridPasses: v.round())),
            ),
        ],
      ),
    ));
    children.add(const SizedBox(height: 12));

    // ---- anomalies -------------------------------------------------------
    final anomalyRows = <Widget>[];
    for (final c in cellHits) {
      final de = estimateDepth(
          s.cells, s.cols, s.rows, c.x, c.y, s.cellCm / 100.0);
      anomalyRows.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: <Widget>[
            Icon(Icons.place,
                size: 16, color: c.deviation >= 0 ? Pal.amber : Pal.violet),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                  '${c.deviation >= 0 ? s.t('kind_metal') : s.t('kind_void')}  (${c.x + 1}, ${c.y + 1})'
                  '${de == null ? '' : '  ~${de.depthM.toStringAsFixed(2)} m'}'),
            ),
            Num(
              '${c.deviation >= 0 ? '+' : ''}${c.deviation.toStringAsFixed(2)} ${s.t('unit')}',
              style: TextStyle(
                  color: c.deviation >= 0 ? Pal.amber : Pal.violet),
            ),
          ],
        ),
      ));
    }
    final shownPeaks = peakIdx.length > 8 ? peakIdx.sublist(0, 8) : peakIdx;
    for (final i in shownPeaks) {
      anomalyRows.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: <Widget>[
             Icon(Icons.show_chart, size: 16, color: Pal.muted),
            const SizedBox(width: 8),
            Expanded(child: Text('${s.t('sample_no')} #$i')),
            Num(
              '${centered[i] >= 0 ? '+' : ''}${centered[i].toStringAsFixed(2)} ${s.t('unit')}',
              style:  TextStyle(color: Pal.muted),
            ),
          ],
        ),
      ));
    }

    children.add(Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('anomalies')),
          _slider(
            s.t('sensitivity'),
            f.sensitivity.toStringAsFixed(1),
            f.sensitivity,
            1.5,
            6,
            9,
            (double v) => s.setFilters(f.copyWith(sensitivity: v)),
          ),
          Text(s.t('sensitivity_hint'),
              style:  TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 10),
          if (anomalyRows.isEmpty)
            Text(s.t('none_found'),
                style:  TextStyle(color: Pal.muted))
          else
            ...anomalyRows,
          const SizedBox(height: 8),
          Text(s.t('depth_note'),
              style:  TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    ));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: children,
    );
  }
}
