import 'package:flutter/material.dart';

import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import '../confirm.dart';
import '../dsp.dart';
import '../imaging.dart';
import '../insight.dart';
import '../models.dart';
import '../state.dart';
import 'geo_screen.dart';
import '../theme.dart';
import '../widgets.dart';
import 'files_screen.dart';
import 'iso_view.dart';
import 'pro_tools.dart';

/// Opens the full-screen analysis window for the scan that is loaded now.
void showAnalysisViewer(BuildContext context) {
  Navigator.of(context).push<void>(
    MaterialPageRoute<void>(
      builder: (BuildContext c) => const AnalysisViewer(),
    ),
  );
}

Future<void> openAnalysisFile(BuildContext context, AppState s) async {
  final cur = s.hasData ? s.snapshot('Scan_${stamp(DateTime.now())}') : null;
  final pick = await showModalBottomSheet<Object>(
    context: context,
    backgroundColor: Pal.surface,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (BuildContext c) => SafeArea(
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(c).size.height * 0.7),
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          children: <Widget>[
            Text(s.t('open_file'),
                style: const TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w800)),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.file_open, color: Pal.amber),
              title: Text(s.t('import_file')),
              onTap: () => Navigator.pop(c, 'import'),
            ),
            if (cur != null)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.bolt, color: Pal.amber),
                title: Text(s.t('current_scan')),
                onTap: () => Navigator.pop(c, 'current'),
              ),
            if (s.sessions.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(s.t('saved_files'),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
              ),
            for (final e in s.sessions)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.folder_open, color: Pal.muted),
                title: Text(e.name, overflow: TextOverflow.ellipsis),
                subtitle: Text('${e.cols}x${e.rows}',
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
                onTap: () => Navigator.pop(c, e),
              ),
          ],
        ),
      ),
    ),
  );
  if (pick == null || !context.mounted) return;
  if (pick == 'import') {
    final ok = await FilesScreen.importFile(context, s);
    if (ok && context.mounted) showAnalysisViewer(context);
  } else if (pick == 'current') {
    showAnalysisViewer(context);
  } else if (pick is ScanSession) {
    await s.loadSession(pick);
    if (context.mounted) showAnalysisViewer(context);
  }
}


/// Analysis tab: an empty page with one "open file" button. The scan itself
/// is shown in [AnalysisViewer], full screen.
class AnalysisScreen extends StatelessWidget {
  const AnalysisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.insert_chart_outlined, size: 64, color: Pal.muted),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(minimumSize: const Size(220, 54)),
              onPressed: () => openAnalysisFile(context, s),
              icon: const Icon(Icons.folder_open),
              label: Text(s.t('open_file')),
            ),
            const SizedBox(height: 12),
            Text(s.t('open_file_hint'),
                textAlign: TextAlign.center,
                style: TextStyle(color: Pal.muted, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

/// Full-screen viewer: the picture takes all the room, the tools are a
/// vertical list of icons on the side and each opens a small sheet.
class AnalysisViewer extends StatefulWidget {
  const AnalysisViewer({super.key});

  @override
  State<AnalysisViewer> createState() => _AnalysisViewerState();
}

class _AnalysisViewerState extends State<AnalysisViewer> {
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  bool _menuOpen = true;
  bool _topOpen = true; // top toolbar shown; an arrow strip hides / shows it
  bool _full = false; // full-screen picture: no toolbar, no side menu
  int _mode = 0; // 0 = 2D, 1 = 3D, 2 = both on one screen
  double _lowShift = 0.0; // colour scale ends moved by the saturation buttons
  double _highShift = 0.0;
  final GlobalKey _picKey = GlobalKey();
  int _type = 0; // 0 all, 1 high, 2 low
  RangeValues _range = const RangeValues(0, 1);
  bool _land = false;
  PersistentBottomSheetController? _sheet;
  int _sheetIdx = -1;
  StateSetter? _sheetSet;
  final TransformationController _tc = TransformationController();

  @override
  void dispose() {
    _tc.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  /// Updates the picture and, when open, the small settings sheet.
  void _up(VoidCallback f) {
    setState(f);
    _sheetSet?.call(() {});
  }

  void _toggleLand() {
    setState(() => _land = !_land);
    SystemChrome.setPreferredOrientations(_land
        ? <DeviceOrientation>[
            DeviceOrientation.landscapeLeft,
            DeviceOrientation.landscapeRight
          ]
        : DeviceOrientation.values);
  }

  static const List<String> _menuKeys = <String>[
    'color_filter',
    'color_saturation',
    'depth_determination',
    'remove_false',
    'filters',
    'insight',
    'pro_tools',
  ];
  static const List<IconData> _menuIcons = <IconData>[
    Icons.filter_alt,
    Icons.palette,
    Icons.height,
    Icons.auto_fix_high,
    Icons.tune,
    Icons.psychology_alt,
    Icons.build_circle_outlined,
  ];

  Color _menuColor(int i) {
    switch (i) {
      case 0:
        return Pal.violet;
      case 1:
        return Pal.amber;
      case 2:
        return const Color(0xFF3AA0FF);
      case 3:
        return Pal.good;
      default:
        return Pal.text;
    }
  }

  Widget _panelFor(int idx, AppState s) {
    switch (idx) {
      case 0:
        return Column(
          children: <Widget>[
            _colorFilterPanel(s),
            const SizedBox(height: 8),
            _saturationPanel(s),
          ],
        );
      case 1:
        return _saturationPanel(s);
      case 2:
        return _depthPanel(s);
      case 3:
        return _falsePanel(s);
      case 4:
        return _filtersPanel(s);
      case 5:
        return _insightStatsPanel(s);
      default:
        return const ProTools();
    }
  }

  void _toggleMenu(int idx) {
    if (idx == 2) AppScope.of(context).setLabelMode(2); // depth shown on the picture
    final old = _sheet;
    if (old != null && _sheetIdx == idx) {
      old.close();
      return;
    }
    old?.close();
    final h = MediaQuery.of(context).size.height;
    final ctl = _key.currentState!.showBottomSheet(
      (BuildContext c) => StatefulBuilder(
        builder: (BuildContext c2, StateSetter setSt) {
          _sheetSet = setSt;
          final s = AppScope.of(c2);
          return Container(
            constraints: BoxConstraints(maxHeight: h * (_land ? 0.8 : 0.5)),
            decoration: BoxDecoration(
              color: Pal.surface.withAlpha(95),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
              border: Border.all(color: _menuColor(idx).withAlpha(160)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 6, 0),
                  child: Row(
                    children: <Widget>[
                      Icon(_menuIcons[idx], color: _menuColor(idx)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(s.t(_menuKeys[idx]),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15)),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => _sheet?.close(),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    children: <Widget>[PanelGlass(child: _panelFor(idx, s))],
                  ),
                ),
              ],
            ),
          );
        },
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
    );
    _sheet = ctl;
    _sheetIdx = idx;
    setState(() {});
    ctl.closed.then((_) {
      if (mounted && identical(_sheet, ctl)) {
        setState(() {
          _sheet = null;
          _sheetIdx = -1;
        });
        _sheetSet = null;
      }
    });
  }

  void _reset(AppState s) {
    _up(() {
      _type = 0;
      _range = const RangeValues(0, 1);
      _lowShift = 0.0;
      _highShift = 0.0;
      _mode = 0;
    });
    s.setGridView(0);
    s.setDestripe(false);
    s.setLabelMode(0);
    s.setFilters(const FilterConfig());
  }

  Widget _slider(
    String label,
    String valueText,
    double value,
    double min,
    double max,
    int? divisions,
    ValueChanged<double> onChanged,
  ) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(label,
                  style: TextStyle(color: Pal.muted, fontSize: 13)),
            ),
            Text(valueText, style: TextStyle(color: Pal.text, fontSize: 13)),
          ],
        ),
        Slider(
          value: value.clamp(min, max).toDouble(),
          min: min,
          max: max,
          divisions: divisions,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _stat(String label, double v) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style: TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 4),
          Num(v.toStringAsFixed(2),
              style: TextStyle(
                  color: Pal.text, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _topBtn(IconData icon, String label, VoidCallback onTap,
      {bool selected = false}) {
    return SizedBox(
      width: 74,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? Pal.amber.withAlpha(45) : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: selected ? Pal.amber : Colors.transparent, width: 1.4),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(icon, color: selected ? Pal.amber : Pal.text, size: 24),
              const SizedBox(height: 3),
              Text(label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 11,
                      color: selected ? Pal.amber : Pal.muted)),
            ],
          ),
        ),
      ),
    );
  }

  /// Saves exactly what is on the screen (the picture with its filters).
  Future<void> _saveShot(AppState s, bool jpg, String name) async {
    try {
      final b = _picKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (b == null) return;
      final im = await b.toImage(pixelRatio: 3.0);
      final path = await Imaging.saveCapture(im, name, jpg: jpg);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${s.t('exported_to')} $path')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(s.t('share_failed'))));
    }
  }

  Future<void> _askSave(AppState s) async {
    final ctrl = TextEditingController(
        text: 'MagVision_${DateTime.now().millisecondsSinceEpoch ~/ 1000}');
    bool jpg = true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext dc) => StatefulBuilder(
        builder: (BuildContext c, StateSetter set) => AlertDialog(
          title: Text(s.t('save_as_image')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: ctrl,
                decoration: InputDecoration(labelText: s.t('image_name')),
              ),
              const SizedBox(height: 12),
              SegmentedButton<bool>(
                showSelectedIcon: false,
                segments: const <ButtonSegment<bool>>[
                  ButtonSegment<bool>(value: true, label: Text('JPG')),
                  ButtonSegment<bool>(value: false, label: Text('PNG')),
                ],
                selected: <bool>{jpg},
                onSelectionChanged: (Set<bool> v) => set(() => jpg = v.first),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
                onPressed: () => Navigator.pop(dc, false),
                child: Text(s.t('cancel'))),
            FilledButton(
                onPressed: () => Navigator.pop(dc, true),
                child: Text(s.t('save'))),
          ],
        ),
      ),
    );
    final name = ctrl.text;
    ctrl.dispose();
    if (ok == true) await _saveShot(s, jpg, name);
  }

  Widget _saveRow(AppState s) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _askSave(s),
      child: Container(
        width: 64,
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        decoration: BoxDecoration(
          color: Pal.amber.withAlpha(24),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Pal.amber.withAlpha(110)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.image_outlined, color: Pal.amber, size: 24),
            const SizedBox(height: 3),
            Text(s.t('save_as_image'),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Pal.amber,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  Widget _sideAction(IconData icon, String label, VoidCallback onTap,
      {bool on = false}) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: 64,
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        decoration: BoxDecoration(
          color: on ? Pal.amber.withAlpha(40) : Pal.text.withAlpha(14),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: on ? Pal.amber : Pal.text.withAlpha(80)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, color: on ? Pal.amber : Pal.text, size: 24),
            const SizedBox(height: 3),
            Text(label,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: on ? Pal.amber : Pal.text,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  Widget _sideBtn(int idx) {
    final c = _menuColor(idx);
    final sel = _sheetIdx == idx;
    final s = AppScope.of(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _toggleMenu(idx),
      child: Container(
        width: 64,
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        decoration: BoxDecoration(
          color: c.withAlpha(sel ? 70 : 24),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: c.withAlpha(sel ? 255 : 100), width: sel ? 1.8 : 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(_menuIcons[idx], color: c, size: 24),
            const SizedBox(height: 3),
            Text(s.t(_menuKeys[idx]),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: c, fontSize: 9.5, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  // ---- panels --------------------------------------------------------------
  Widget _insightPanel(AppState s) {
    final ins = s.insight;
    final viewNames = <String>[
      s.t('view_normal'),
      s.t('view_hipass'),
      s.t('view_gradient'),
      s.t('view_analytic'),
    ];
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('insight')),
          if (s.gridGeo != null &&
              s.placeOf(s.gridGeo!.latitude, s.gridGeo!.longitude).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: <Widget>[
                  Icon(Icons.place, size: 16, color: Pal.amber),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                        '${s.t('place_label')}: ${s.placeOf(s.gridGeo!.latitude, s.gridGeo!.longitude)}',
                        style: const TextStyle(fontSize: 13)),
                  ),
                ],
              ),
            ),
          if (ins.kind == -1)
            Text(s.t('insight_low_data'),
                style: TextStyle(color: Pal.muted))
          else if (ins.kind == 0)
            Text(s.t('insight_none'))
          else ...<Widget>[
            Text(
              s.t(ins.kind == 1 ? 'insight_metal' : 'insight_void'),
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: ins.kind == 1 ? Pal.amber : Pal.violet,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${s.t('cell')} (${ins.x + 1}, ${ins.y + 1})   '
              '${ins.deviation >= 0 ? '+' : ''}${ins.deviation.toStringAsFixed(2)}   '
              '${s.t('contrast')} ${ins.contrast.toStringAsFixed(1)}x'
              '${(ins.kind == 1 ? ins.metalDepth : ins.voidDepth) == null ? '' : '   ${s.t('depth')} ${depthLabel((ins.kind == 1 ? ins.metalDepth : ins.voidDepth)!)}'}',
              textDirection: TextDirection.ltr,
              style: TextStyle(color: Pal.muted, fontSize: 12),
            ),
            if (ins.sizeClass >= 0)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                    s.t('size_${ins.kind == 1 ? 'metal' : 'void'}_${ins.sizeClass}'),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
              ),
            const SizedBox(height: 6),
            Text('${s.t('reliability')}: ${s.t('lvl_${ins.level}')}   '
                '(${s.t('coverage')} ${(ins.coverage * 100).toStringAsFixed(0)}%)'),
            const SizedBox(height: 4),
            Text('${s.t('target_score')}: ${ins.score}/100    '
                '${s.t('false_risk')}: ${s.t('risk_${ins.falseRisk}')}',
                style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: ins.falseRisk == 0
                        ? Pal.good
                        : (ins.falseRisk == 1 ? Pal.amber : Pal.bad))),
            Text(
                '${s.t('cand_metal')} ${ins.metalPct}%'
                '${ins.metalDepth == null ? '' : ' (${depthLabel(ins.metalDepth!)})'}'
                '   ·   ${s.t('cand_void')} ${ins.voidPct}%'
                '${ins.voidDepth == null ? '' : ' (${depthLabel(ins.voidDepth!)})'}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(s.t('cand_note'),
                style: TextStyle(color: Pal.muted, fontSize: 11)),
            if (ins.lowRes)
              Text(s.t('lowres_warn'),
                  style: TextStyle(color: Pal.amber, fontSize: 12)),
            if (ins.dipole)
              Text(s.t('insight_dipole'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
            if (ins.isolated)
              Text(s.t('insight_isolated'),
                  style: TextStyle(color: Pal.bad, fontSize: 12)),
            if (ins.belowLearned)
              Text(s.t('insight_learned_low'),
                  style: TextStyle(color: Pal.bad, fontSize: 12)),
            if (ins.widespread)
              Text(s.t('insight_widespread'),
                  style: TextStyle(color: Pal.amber, fontSize: 12)),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                      '${s.t('suggest_view')}: ${viewNames[ins.suggestView]}',
                      style: TextStyle(color: Pal.muted, fontSize: 12)),
                ),
                FilledButton.tonal(
                  onPressed: s.gridView == ins.suggestView
                      ? null
                      : () => s.setGridView(ins.suggestView),
                  child: Text(s.t('apply_view')),
                ),
              ],
            ),
          ],
          const SizedBox(height: 8),
          Text(s.t('insight_note'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    );
  }

  /// Title with a small "?" that explains in one line when to use the filter.
  Widget _titleHelp(AppState s, String key) {
    return Row(
      children: <Widget>[
        Expanded(child: Text(s.t(key))),
        IconButton(
          visualDensity: VisualDensity.compact,
          iconSize: 18,
          icon: Icon(Icons.help_outline, color: Pal.muted),
          onPressed: () => showDialog<void>(
            context: context,
            builder: (BuildContext dc) => AlertDialog(
              title: Text(s.t(key)),
              content: Text(s.t('help_$key')),
              actions: <Widget>[
                TextButton(
                    onPressed: () => Navigator.pop(dc), child: Text(s.t('ok'))),
              ],
            ),
          ),
        ),
      ],
    );
  }

  List<Widget> _filterTiles(AppState s) {
    final f = s.filters;
    return <Widget>[
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'despike'),
            value: f.despike,
            onChanged: (bool v) => s.setFilters(f.copyWith(despike: v)),
          ),
          if (f.despike)
            _slider(
              s.t('strength'),
              f.despikeK.toStringAsFixed(1),
              f.despikeK,
              2,
              8,
              12,
              (double v) => s.setFilters(f.copyWith(despikeK: v)),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'median'),
            value: f.median,
            onChanged: (bool v) => s.setFilters(f.copyWith(median: v)),
          ),
          if (f.median)
            _slider(
              s.t('window'),
              '${f.medianWindow}',
              f.medianWindow.toDouble(),
              3,
              21,
              9,
              (double v) => s.setFilters(f.copyWith(medianWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'baseline'),
            value: f.baseline,
            onChanged: (bool v) => s.setFilters(f.copyWith(baseline: v)),
          ),
          if (f.baseline)
            _slider(
              s.t('window'),
              '${f.baselineWindow}',
              f.baselineWindow.toDouble(),
              20,
              400,
              19,
              (double v) =>
                  s.setFilters(f.copyWith(baselineWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'average'),
            value: f.average,
            onChanged: (bool v) => s.setFilters(f.copyWith(average: v)),
          ),
          if (f.average)
            _slider(
              s.t('window'),
              '${f.averageWindow}',
              f.averageWindow.toDouble(),
              2,
              30,
              14,
              (double v) =>
                  s.setFilters(f.copyWith(averageWindow: v.round())),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'ema'),
            value: f.ema,
            onChanged: (bool v) => s.setFilters(f.copyWith(ema: v)),
          ),
          if (f.ema)
            _slider(
              s.t('strength'),
              f.emaAlpha.toStringAsFixed(2),
              f.emaAlpha,
              0.05,
              1.0,
              19,
              (double v) => s.setFilters(f.copyWith(emaAlpha: v)),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: _titleHelp(s, 'grid_smooth'),
            value: f.gridSmooth,
            onChanged: (bool v) => s.setFilters(f.copyWith(gridSmooth: v)),
          ),
          if (f.gridSmooth)
            _slider(
              s.t('passes'),
              '${f.gridPasses}',
              f.gridPasses.toDouble(),
              1,
              4,
              3,
              (double v) => s.setFilters(f.copyWith(gridPasses: v.round())),
            ),
    ];
  }

  Widget _statsPanel(AppState s) {
    final st = statsOf(s.displayCells);
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('stats')),
          Row(
            children: <Widget>[
              _stat(s.t('min'), st.min),
              _stat(s.t('max'), st.max),
              _stat(s.t('mean'), st.mean),
              _stat(s.t('std'), st.std),
            ],
          ),
        ],
      ),
    );
  }

  Widget _colorFilterPanel(AppState s) {
    // grid-view ids: 0 normal, 1 high-pass, 2 gradient, 3 analytic, 5 laplacian, 4 difference
    final viewIds = <int>[0, 1, 2, 3, 5, if (s.compareRef != null) 4];
    const viewKeys = <int, String>{
      0: 'view_normal',
      1: 'view_hipass',
      2: 'view_gradient',
      3: 'view_analytic',
      4: 'view_diff',
      5: 'view_laplacian',
    };
    final cov = s.coverageMap();
    final nMissing = cov.where((int e) => e == 3).length;
    final nPartial = cov.where((int e) => e == 1).length;
    final nUnstable = cov.where((int e) => e == 2).length;
    final st = statsOf(s.displayCells);
    final span = (st.max - st.min) <= 1e-9 ? 1.0 : (st.max - st.min);
    final rLo = st.min + span * _range.start;
    final rHi = st.min + span * _range.end;
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('color_filter')),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: <Widget>[
              for (final i in viewIds)
                ChoiceChip(
                  label: Text(s.t(viewKeys[i]!)),
                  selected: s.gridView == i,
                  onSelected: (bool _) => s.setGridView(i),
                ),
            ],
          ),
          Text(s.t('view_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          if (s.gridView == 5)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(s.t('view_laplacian_hint'),
                  style: TextStyle(color: Pal.amber, fontSize: 11)),
            ),
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            value: s.showCoverage,
            onChanged: s.setShowCoverage,
            title: Text(s.t('cov_layer')),
            subtitle: Text(
                s.showCoverage
                    ? '${s.t('cov_missing')}: $nMissing   ${s.t('cov_partial')}: $nPartial   ${s.t('cov_unstable')}: $nUnstable'
                    : s.t('cov_hint'),
                style: TextStyle(color: Pal.muted, fontSize: 11)),
          ),
          const Divider(),
          Wrap(
            spacing: 8,
            children: <Widget>[
              ChoiceChip(
                label: Text(s.t('show_all')),
                selected: _type == 0,
                onSelected: (bool _) => _up(() => _type = 0),
              ),
              ChoiceChip(
                label: Text(s.t('show_metal')),
                selected: _type == 1,
                onSelected: (bool _) => _up(() => _type = 1),
              ),
              ChoiceChip(
                label: Text(s.t('show_void')),
                selected: _type == 2,
                onSelected: (bool _) => _up(() => _type = 2),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(s.t('value_range'),
              style: TextStyle(color: Pal.muted, fontSize: 12)),
          RangeSlider(
            values: _range,
            min: 0,
            max: 1,
            onChanged: (RangeValues v) => _up(() => _range = v),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Num(rLo.toStringAsFixed(2),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
              Num(rHi.toStringAsFixed(2),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _saturationPanel(AppState s) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('color_saturation')),
          Row(
            children: <Widget>[
              Text(s.t('palette'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
              const Spacer(),
              for (int i = 0; i < kPalettes.length; i++)
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: 8),
                  child: GestureDetector(
                    onTap: () => s.setPalette(i),
                    child: Container(
                      width: 40,
                      height: 26,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        gradient: LinearGradient(colors: kPalettes[i]),
                        border: Border.all(
                          color: s.palette == i ? Pal.text : Pal.outline,
                          width: s.palette == i ? 2 : 1,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              for (final b in <List<Object>>[
                <Object>[true, -1.0, const Color(0xFF6CB8FF)],
                <Object>[true, 1.0, const Color(0xFF2196F3)],
                <Object>[false, -1.0, const Color(0xFFE57373)],
                <Object>[false, 1.0, const Color(0xFFF44336)],
              ])
                Expanded(
                  child: Center(
                    child: Tooltip(
                      message: s.t(b[0] == true
                          ? (b[1] == 1.0 ? 'sat_low_up' : 'sat_low_down')
                          : (b[1] == 1.0 ? 'sat_high_up' : 'sat_high_down')),
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                            backgroundColor: b[2] as Color,
                            shape: const CircleBorder(),
                            minimumSize: const Size(52, 52),
                            maximumSize: const Size(52, 52),
                            padding: EdgeInsets.zero),
                        onPressed: () => _up(() {
                          final d = (b[1] as double) * 0.04;
                          if (b[0] == true) {
                            _lowShift = (_lowShift + d).clamp(-1.0, 1.0).toDouble();
                          } else {
                            _highShift = (_highShift + d).clamp(-1.0, 1.0).toDouble();
                          }
                        }),
                        child: Icon(
                            (b[1] as double) > 0
                                ? Icons.arrow_upward
                                : Icons.arrow_downward,
                            color: Colors.white),
                      ),
                    ),
                  ),
                ),
              IconButton(
                tooltip: s.t('reset'),
                icon: const Icon(Icons.restart_alt),
                onPressed: () => _up(() {
                  _lowShift = 0.0;
                  _highShift = 0.0;
                }),
              ),
            ],
          ),
          Text(s.t('sat_btn_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 4),
          const SatelliteControls(),
        ],
      ),
    );
  }

  Future<void> _startConfirm(AppState s, CellAnomaly c, double? depth) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext d) => AlertDialog(
        title: Text(s.t('confirm_btn')),
        content: Text(s.t('confirm_explain')),
        actions: <Widget>[
          TextButton(
              onPressed: () => Navigator.pop(d, false),
              child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(d, true),
              child: Text(s.t('ok'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final now = DateTime.now();
    await s.saveCurrent(
        'Scan_${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}-${now.minute.toString().padLeft(2, '0')}');
    s.startConfirm(ConfirmTarget(
      x: c.x,
      y: c.y,
      metal: c.deviation >= 0,
      depthM: depth,
      cols: s.cols,
      rows: s.rows,
      cellCm: s.cellCm,
      firstPerp: s.perpScan,
    ));
    s.clearData();
    s.setPerpScan(!s.perpScan);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('confirm_ready'))));
  }

  Widget _confirmCard(AppState s) {
    final t = s.confirmTarget;
    if (t == null) return const SizedBox.shrink();
    final ready = s.hasData && !s.scanning && s.filledCells >= s.cols * s.rows * 0.8;
    String title;
    String body;
    Color col = Pal.muted;
    if (!ready) {
      title = s.t('confirm_waiting');
      body = s.t('confirm_waiting_hint');
    } else {
      final r = judgeConfirmation(
        first: t,
        second: depthTargets(s),
        depthOf: (CellAnomaly h) => estimateDepth(
                s.residualGrid, s.cols, s.rows, h.x, h.y, s.cellCm / 100.0,
                isResidual: true)
            ?.depthM,
        cols: s.cols,
        rows: s.rows,
        cellCm: s.cellCm,
        secondPerp: s.perpScan,
      );
      switch (r.verdict) {
        case ConfirmVerdict.confirmed:
          title = s.t('confirm_yes');
          col = Pal.good;
          final ratio = r.depthRatio;
          final depthTxt = ratio == null
              ? ''
              : (ratio > 0.55 && ratio < 1.8
                  ? s.t('confirm_depth_ok')
                  : s.t('confirm_depth_diff'));
          body = '${s.t('confirm_dist')}: ${r.distM!.toStringAsFixed(2)} ${s.t('meter')}. $depthTxt';
          break;
        case ConfirmVerdict.notConfirmed:
          title = s.t('confirm_no');
          col = Pal.amber;
          body = s.t('confirm_no_hint');
          break;
        case ConfirmVerdict.conflict:
          title = s.t('confirm_conflict');
          col = Pal.bad;
          body = s.t('confirm_conflict_hint');
          break;
        case ConfirmVerdict.differentGrid:
          title = s.t('confirm_grid');
          col = Pal.bad;
          body = s.t('confirm_grid_hint');
          break;
        case ConfirmVerdict.sameDirection:
          title = s.t('confirm_same_dir');
          col = Pal.bad;
          body = s.t('confirm_same_dir_hint');
          break;
      }
    }
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(children: <Widget>[
            Icon(Icons.verified_outlined, color: col),
            const SizedBox(width: 8),
            Expanded(
                child: Text(title,
                    style: TextStyle(
                        color: col, fontWeight: FontWeight.w800, fontSize: 15))),
            TextButton(onPressed: s.endConfirm, child: Text(s.t('confirm_end'))),
          ]),
          Text(
              '${t.metal ? s.t('kind_metal') : s.t('kind_void')}  (${t.x + 1}, ${t.y + 1})'
              '${t.depthM == null ? '' : '  ~${t.depthM!.toStringAsFixed(2)} ${s.t('meter')}'}',
              style: TextStyle(color: Pal.muted, fontSize: 12)),
          const SizedBox(height: 4),
          Text(body, style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 4),
          Text(s.t('confirm_limit'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _depthPanel(AppState s) {
    final cellHits = depthTargets(s);
    final anomalyRows = <Widget>[];
    for (final c in cellHits) {
      final de = estimateDepth(
          s.residualGrid, s.cols, s.rows, c.x, c.y, s.cellCm / 100.0,
          isResidual: true);
      anomalyRows.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: <Widget>[
            Icon(Icons.place,
                size: 16, color: c.deviation >= 0 ? Pal.amber : Pal.violet),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                  '${c.deviation >= 0 ? s.t('kind_metal') : s.t('kind_void')}  (${c.x + 1}, ${c.y + 1})'
                  '${de == null ? '' : '  ${depthLabel(de)}'}'),
            ),
            Num(
              '${c.deviation >= 0 ? '+' : ''}${c.deviation.toStringAsFixed(2)}',
              style: TextStyle(
                  color: c.deviation >= 0 ? Pal.amber : Pal.violet),
            ),
            IconButton(
              tooltip: s.t('confirm_btn'),
              visualDensity: VisualDensity.compact,
              icon: Icon(Icons.verified_outlined, size: 20, color: Pal.violet),
              onPressed: () => _startConfirm(s, c, de?.depthM),
            ),
            IconButton(
              tooltip: s.t('mark_found'),
              visualDensity: VisualDensity.compact,
              icon: Icon(Icons.check_circle_outline, size: 20, color: Pal.good),
              onPressed: () {
                s.markTarget(s.contrastOf(c.deviation), true);
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(s.t('mark_saved'))));
              },
            ),
            IconButton(
              tooltip: s.t('mark_fake'),
              visualDensity: VisualDensity.compact,
              icon: Icon(Icons.cancel_outlined, size: 20, color: Pal.bad),
              onPressed: () {
                s.markTarget(s.contrastOf(c.deviation), false);
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(s.t('mark_saved'))));
              },
            ),
          ],
        ),
      ));
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (s.confirmTarget != null) ...<Widget>[
          _confirmCard(s),
          const SizedBox(height: 8),
        ],
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('depth_determination')),
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: <ButtonSegment<int>>[
                  ButtonSegment<int>(value: 0, label: Text(s.t('prio_void'))),
                  ButtonSegment<int>(value: 1, label: Text(s.t('prio_metal'))),
                  ButtonSegment<int>(value: 2, label: Text(s.t('prio_equal'))),
                ],
                selected: <int>{s.priority},
                onSelectionChanged: (Set<int> v) => s.setPriority(v.first),
              ),
              const SizedBox(height: 6),
              const SoilAndStep(showStep: false),
              const Divider(),
              Text(s.t('anomalies'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              if (anomalyRows.isEmpty)
                Text(s.t('none_found'), style: TextStyle(color: Pal.muted))
              else
                ...anomalyRows,
              const SizedBox(height: 8),
              Text(s.t('depth_note'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _falsePanel(AppState s) {
    final f = s.filters;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SectionTitle(s.t('remove_false')),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                title: Text(s.t('destripe')),
                subtitle: Text(s.t('destripe_hint'),
                    style: TextStyle(color: Pal.muted, fontSize: 11)),
                value: s.destripe,
                onChanged: s.setDestripe,
              ),
              _slider(
                s.t('sensitivity'),
                f.sensitivity.toStringAsFixed(1),
                f.sensitivity,
                1.5,
                6,
                9,
                (double v) => s.setFilters(f.copyWith(sensitivity: v)),
              ),
              Text(s.t('sensitivity_hint'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _filtersPanel(AppState s) => Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SectionTitle(s.t('filters')),
            Text(s.t('filters_live_only'),
                style: TextStyle(color: Pal.muted, fontSize: 11)),
            const SizedBox(height: 6),
            ..._filterTiles(s),
          ],
        ),
      );

  Widget _insightStatsPanel(AppState s) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _insightPanel(s),
          const SizedBox(height: 12),
          _statsPanel(s),
        ],
      );

  Widget _picture(AppState s, List<double> masked, double lo, double hi) {
    if (_mode == 2) {
      return Column(
        children: <Widget>[
          Expanded(child: _pictureOf(0, s, masked, lo, hi)),
          Expanded(child: _pictureOf(1, s, masked, lo, hi)),
        ],
      );
    }
    return _pictureOf(_mode, s, masked, lo, hi);
  }

  Widget _pictureOf(
      int mode, AppState s, List<double> masked, double lo, double hi) {
    if (mode == 0) {
      return LayoutBuilder(
        builder: (BuildContext c, BoxConstraints box) {
          final ar = s.cols / s.rows;
          double w = box.maxWidth;
          double h = w / ar;
          if (h > box.maxHeight) {
            h = box.maxHeight;
            w = h * ar;
          }
          return Center(
            child: GestureDetector(
              onDoubleTap: () => _tc.value = Matrix4.identity(),
              child: InteractiveViewer(
                transformationController: _tc,
                minScale: 1.0,
                maxScale: 8.0,
                child: SizedBox(
                  width: w,
                  height: h,
                  child: withSatBackdrop(
                    s,
                    CustomPaint(
                      painter: HeatPainter(
                        cells: masked,
                        cols: s.cols,
                        rows: s.rows,
                        lo: lo,
                        hi: hi,
                        labels: cellLabelsFor(s, masked),
                        coverage: s.showCoverage ? s.coverageMap() : null,
                      ),
                      size: Size.infinite,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    }
    return Iso3DView(
      cells: masked,
      lo: lo,
      hi: hi,
      cutLo: _lowShift > 0 ? lo : null,
      height: null,
      showPins: s.labelMode == 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final cells = s.displayCells;
    final st = statsOf(cells);
    final valid = cells.where((e) => !e.isNaN).toList();
    final med = valid.isEmpty ? 0.0 : medianOf(valid);
    final span = (st.max - st.min) <= 1e-9 ? 1.0 : (st.max - st.min);
    final rLo = st.min + span * _range.start;
    final rHi = st.min + span * _range.end;
    final masked = List<double>.from(cells);
    for (int i = 0; i < masked.length; i++) {
      final v = masked[i];
      if (v.isNaN) continue;
      final out = v < rLo - 1e-9 ||
          v > rHi + 1e-9 ||
          (_type == 1 && v < med) ||
          (_type == 2 && v > med);
      if (out) masked[i] = double.nan;
    }
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }
    if (_lowShift != 0.0 || _highShift != 0.0) {
      // The saturation buttons move the two ends of the colour scale, but the
      // scale can never collapse: at least 8% of it always stays, so the
      // strongest values keep their colour instead of the whole picture
      // turning one flat colour.
      final bs = hi - lo;
      lo += _lowShift * bs;
      hi += _highShift * bs;
      if (hi - lo < 0.08 * bs) {
        if (_lowShift > 0 && _highShift <= 0) {
          lo = hi - 0.08 * bs;
        } else {
          hi = lo + 0.08 * bs;
        }
      }
    }

    final modeNames = <String>[
      s.t('view_2d'),
      s.t('view_3d'),
      s.t('view_split')
    ];
    final modeIcons = <IconData>[
      Icons.grid_on,
      Icons.view_in_ar,
      Icons.vertical_split
    ];

    return Scaffold(
      key: _key,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            if (!_full && _topOpen)
            Container(
              color: Pal.surface,
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
              child: Row(
                children: <Widget>[
                  IconButton(
                    tooltip: s.t('close'),
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => Navigator.of(context).maybePop(),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: <Widget>[
                          for (int i = 0; i < 3; i++)
                            _topBtn(modeIcons[i], modeNames[i],
                                () => _up(() => _mode = i),
                                selected: _mode == i),
                          _topBtn(Icons.grid_view, s.t('values_grid'),
                              () => s.setLabelMode((s.labelMode + 1) % 3),
                              selected: s.labelMode != 0),
                          _topBtn(Icons.height, s.t('depth_determination'),
                              () => _toggleMenu(2),
                              selected: _sheetIdx == 2),
                          _topBtn(Icons.refresh, s.t('reset'), () => _reset(s)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (!_full)
              GestureDetector(
                onTap: () => _up(() => _topOpen = !_topOpen),
                child: Container(
                  height: 16,
                  width: double.infinity,
                  alignment: Alignment.center,
                  color: Pal.surface.withAlpha(120),
                  child: Icon(
                    _topOpen
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    size: 20,
                    color: Pal.amber,
                  ),
                ),
              ),
            Expanded(
              child: Row(
                children: <Widget>[
                  if (_menuOpen && !_full)
                    Container(
                      color: Pal.surface,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: SingleChildScrollView(
                        child: Column(
                          children: <Widget>[
                            _sideAction(Icons.fullscreen, s.t('fullscreen'), () {
                              _sheet?.close();
                              _up(() => _full = true);
                            }),
                            _sideAction(Icons.screen_rotation, s.t('landscape'),
                                _toggleLand,
                                on: _land),
                            _saveRow(s),
                            for (int i = 0; i < _menuKeys.length; i++)
                              if (i != 1 && i != 2) _sideBtn(i),
                            _sideAction(Icons.public, s.t('geo_overlay'),
                                () => showGeoPicker(context, s)),
                            _sideAction(
                                Icons.blur_on,
                                s.t(const <String>[
                                  'interp_smooth',
                                  'interp_xsmooth',
                                  'interp_blocks'
                                ][s.interp]),
                                () => s.setInterp((s.interp + 1) % 3)),
                          ],
                        ),
                      ),
                    ),
                  if (!_full)
                  GestureDetector(
                    onTap: () {
                      if (_menuOpen) _sheet?.close();
                      _up(() => _menuOpen = !_menuOpen);
                    },
                    child: Container(
                      width: 16,
                      alignment: Alignment.center,
                      color: Pal.surface.withAlpha(120),
                      child: Icon(
                        _menuOpen
                            ? Icons.chevron_left_rounded
                            : Icons.chevron_right_rounded,
                        size: 20,
                        color: Pal.amber,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Expanded(
                          child: Stack(
                            children: <Widget>[
                              Positioned.fill(
                                child: RepaintBoundary(
                                  key: _picKey,
                                  child: ColoredBox(
                                    color: Pal.bg,
                                    child: _picture(s, masked, lo, hi),
                                  ),
                                ),
                              ),
                              if (_full)
                                Positioned(
                                  top: 6,
                                  right: 6,
                                  child: IconButton.filledTonal(
                                    tooltip: s.t('close'),
                                    visualDensity: VisualDensity.compact,
                                    icon: const Icon(Icons.fullscreen_exit),
                                    onPressed: () => _up(() => _full = false),
                                  ),
                                ),
                              if (_mode != 0)
                                Positioned(
                                  bottom: 4,
                                  left: 4,
                                  child: IconButton.filledTonal(
                                    tooltip: s.t('show_ground'),
                                    visualDensity: VisualDensity.compact,
                                    iconSize: 18,
                                    icon: Icon(s.groundHidden
                                        ? Icons.layers_outlined
                                        : Icons.layers_clear_outlined),
                                    onPressed: () =>
                                        s.setGroundHidden(!s.groundHidden),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 2, 12, 6),
                          child: HeatLegend(lo: lo, hi: hi),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
