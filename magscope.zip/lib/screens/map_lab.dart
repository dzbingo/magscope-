import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'iso_view.dart';

/// Map processing: choose the view (normal / high-pass / gradient), remove
/// row stripes, filter by colour range, and look at the result in 2D or 3D.
class MapLab extends StatefulWidget {
  const MapLab({super.key});

  @override
  State<MapLab> createState() => _MapLabState();
}

class _MapLabState extends State<MapLab> {
  int _mode = 1; // 0 = 2D, 1 = 3D, 2 = solid columns
  int _type = 0; // 0 all, 1 high, 2 low
  RangeValues _range = const RangeValues(0, 1);
  final TransformationController _tc = TransformationController();

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Widget _chips(AppState s) {
    final labels = <String>[
      s.t('view_normal'),
      s.t('view_hipass'),
      s.t('view_gradient'),
      s.t('view_analytic'),
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: <Widget>[
        for (int i = 0; i < labels.length; i++)
          ChoiceChip(
            label: Text(labels[i]),
            selected: s.gridView == i,
            onSelected: (bool _) => s.setGridView(i),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final cells = s.displayCells;
    final st = statsOf(cells);
    final valid = cells.where((e) => !e.isNaN).toList();
    final med = valid.isEmpty ? 0.0 : medianOf(valid);

    // colour filter: keep only values inside the chosen range / side
    final span = (st.max - st.min) <= 1e-9 ? 1.0 : (st.max - st.min);
    final rLo = st.min + span * _range.start;
    final rHi = st.min + span * _range.end;
    final masked = List<double>.from(cells);
    for (int i = 0; i < masked.length; i++) {
      final v = masked[i];
      if (v.isNaN) continue;
      final out = v < rLo - 1e-9 ||
          v > rHi + 1e-9 ||
          (_type == 1 && v < med) ||
          (_type == 2 && v > med);
      if (out) masked[i] = double.nan;
    }

    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }

    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('map_lab')),
          _chips(s),
          const SizedBox(height: 4),
          Text(s.t('view_hint'),
              style:  TextStyle(color: Pal.muted, fontSize: 11)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: Text(s.t('destripe')),
            subtitle: Text(s.t('destripe_hint'),
                style:  TextStyle(color: Pal.muted, fontSize: 11)),
            value: s.destripe,
            onChanged: s.setDestripe,
          ),
           Divider(color: Pal.outline),
          Text(s.t('color_filter'),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: <Widget>[
              ChoiceChip(
                label: Text(s.t('show_all')),
                selected: _type == 0,
                onSelected: (bool _) => setState(() => _type = 0),
              ),
              ChoiceChip(
                label: Text(s.t('show_metal')),
                selected: _type == 1,
                onSelected: (bool _) => setState(() => _type = 1),
              ),
              ChoiceChip(
                label: Text(s.t('show_void')),
                selected: _type == 2,
                onSelected: (bool _) => setState(() => _type = 2),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(s.t('value_range'),
              style:  TextStyle(color: Pal.muted, fontSize: 12)),
          RangeSlider(
            values: _range,
            min: 0,
            max: 1,
            onChanged: (RangeValues v) => setState(() => _range = v),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Num(rLo.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
              Num(rHi.toStringAsFixed(2),
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: <ButtonSegment<int>>[
              ButtonSegment<int>(
                  value: 0,
                  label: Text(s.t('view_2d')),
                  icon: const Icon(Icons.grid_on)),
              ButtonSegment<int>(
                  value: 1,
                  label: Text(s.t('view_3d')),
                  icon: const Icon(Icons.view_in_ar)),
              ButtonSegment<int>(
                  value: 2,
                  label: Text(s.t('view_solid')),
                  icon: const Icon(Icons.view_module)),
            ],
            selected: <int>{_mode},
            onSelectionChanged: (Set<int> v) =>
                setState(() => _mode = v.first),
          ),
          const SizedBox(height: 10),
          if (_mode == 0)
            GestureDetector(
              onDoubleTap: () => _tc.value = Matrix4.identity(),
              child: InteractiveViewer(
                transformationController: _tc,
                minScale: 1.0,
                maxScale: 8.0,
                child: AspectRatio(
                  aspectRatio: s.cols / s.rows,
                  child: withSatBackdrop(
                    s,
                    CustomPaint(
                      painter: HeatPainter(
                        cells: masked,
                        cols: s.cols,
                        rows: s.rows,
                        lo: lo,
                        hi: hi,
                      ),
                      size: Size.infinite,
                    ),
                  ),
                ),
              ),
            )
          else
            Iso3DView(
              cells: masked,
              lo: lo,
              hi: hi,
              height: 320,
              solid: _mode == 2,
            ),
          const SizedBox(height: 10),
          const SatelliteControls(),
          const SizedBox(height: 6),
          HeatLegend(lo: lo, hi: hi),
        ],
      ),
    );
  }
}
