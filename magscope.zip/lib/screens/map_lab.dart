import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Map processing: choose the view (normal / high-pass / gradient), remove
/// row stripes, filter by colour range, and look at the result in 2D or 3D.
class MapLab extends StatefulWidget {
  const MapLab({super.key});

  @override
  State<MapLab> createState() => _MapLabState();
}

class _MapLabState extends State<MapLab> {
  int _mode = 1; // 0 = 2D, 1 = 3D
  int _type = 0; // 0 all, 1 high, 2 low
  RangeValues _range = const RangeValues(0, 1);
  double _angle = 0.6;
  double _tilt = 0.5;
  double _zoom = 1.0;
  double _baseZoom = 1.0;
  final TransformationController _tc = TransformationController();

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Widget _chips(AppState s) {
    final labels = <String>[
      s.t('view_normal'),
      s.t('view_hipass'),
      s.t('view_gradient'),
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: <Widget>[
        for (int i = 0; i < labels.length; i++)
          ChoiceChip(
            label: Text(labels[i]),
            selected: s.gridView == i,
            onSelected: (bool _) => s.setGridView(i),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final cells = s.displayCells;
    final st = statsOf(cells);
    final valid = cells.where((e) => !e.isNaN).toList();
    final med = valid.isEmpty ? 0.0 : medianOf(valid);

    // colour filter: keep only values inside the chosen range / side
    final span = (st.max - st.min) <= 1e-9 ? 1.0 : (st.max - st.min);
    final rLo = st.min + span * _range.start;
    final rHi = st.min + span * _range.end;
    final masked = List<double>.from(cells);
    for (int i = 0; i < masked.length; i++) {
      final v = masked[i];
      if (v.isNaN) continue;
      final out = v < rLo - 1e-9 ||
          v > rHi + 1e-9 ||
          (_type == 1 && v < med) ||
          (_type == 2 && v > med);
      if (out) masked[i] = double.nan;
    }

    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }

    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SectionTitle(s.t('map_lab')),
          _chips(s),
          const SizedBox(height: 4),
          Text(s.t('view_hint'),
              style: const TextStyle(color: Pal.muted, fontSize: 11)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: Text(s.t('destripe')),
            subtitle: Text(s.t('destripe_hint'),
                style: const TextStyle(color: Pal.muted, fontSize: 11)),
            value: s.destripe,
            onChanged: s.setDestripe,
          ),
          const Divider(color: Pal.outline),
          Text(s.t('color_filter'),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: <Widget>[
              ChoiceChip(
                label: Text(s.t('show_all')),
                selected: _type == 0,
                onSelected: (bool _) => setState(() => _type = 0),
              ),
              ChoiceChip(
                label: Text(s.t('show_metal')),
                selected: _type == 1,
                onSelected: (bool _) => setState(() => _type = 1),
              ),
              ChoiceChip(
                label: Text(s.t('show_void')),
                selected: _type == 2,
                onSelected: (bool _) => setState(() => _type = 2),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(s.t('value_range'),
              style: const TextStyle(color: Pal.muted, fontSize: 12)),
          RangeSlider(
            values: _range,
            min: 0,
            max: 1,
            onChanged: (RangeValues v) => setState(() => _range = v),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Num(rLo.toStringAsFixed(2),
                  style: const TextStyle(color: Pal.muted, fontSize: 11)),
              Num(rHi.toStringAsFixed(2),
                  style: const TextStyle(color: Pal.muted, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: <ButtonSegment<int>>[
              ButtonSegment<int>(
                  value: 0,
                  label: Text(s.t('view_2d')),
                  icon: const Icon(Icons.grid_on)),
              ButtonSegment<int>(
                  value: 1,
                  label: Text(s.t('view_3d')),
                  icon: const Icon(Icons.view_in_ar)),
            ],
            selected: <int>{_mode},
            onSelectionChanged: (Set<int> v) =>
                setState(() => _mode = v.first),
          ),
          const SizedBox(height: 10),
          if (_mode == 0)
            GestureDetector(
              onDoubleTap: () => _tc.value = Matrix4.identity(),
              child: InteractiveViewer(
                transformationController: _tc,
                minScale: 1.0,
                maxScale: 8.0,
                child: AspectRatio(
                  aspectRatio: s.cols / s.rows,
                  child: CustomPaint(
                    painter: HeatPainter(
                      cells: masked,
                      cols: s.cols,
                      rows: s.rows,
                      lo: lo,
                      hi: hi,
                    ),
                    size: Size.infinite,
                  ),
                ),
              ),
            )
          else
            SizedBox(
              height: 320,
              width: double.infinity,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onDoubleTap: () => setState(() => _zoom = 1.0),
                onScaleStart: (ScaleStartDetails d) => _baseZoom = _zoom,
                onScaleUpdate: (ScaleUpdateDetails d) {
                  setState(() {
                    _zoom = (_baseZoom * d.scale).clamp(0.6, 4.0).toDouble();
                    _angle += d.focalPointDelta.dx * 0.012;
                    _tilt = (_tilt + d.focalPointDelta.dy * 0.003)
                        .clamp(0.22, 0.9)
                        .toDouble();
                  });
                },
                child: ClipRect(
                  child: Transform.scale(
                    scale: _zoom,
                    child: CustomPaint(
                      painter: IsoPainter(
                        cells: masked,
                        cols: s.cols,
                        rows: s.rows,
                        lo: lo,
                        hi: hi,
                        angle: _angle,
                        heightScale: 1.0,
                        tilt: _tilt,
                      ),
                      size: Size.infinite,
                    ),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 6),
          HeatLegend(lo: lo, hi: hi),
          const SizedBox(height: 4),
          Text(s.t('zoom_hint'),
              style: const TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    );
  }
}
