import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../exporters.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';

/// Bottom sheet listing export formats. Tap a row to share the file (the
/// Android share sheet includes Bluetooth); the download icon only saves it.
Future<void> showExportSheet(
    BuildContext context, AppState s, ScanSession sess) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: Pal.surface,
    showDragHandle: true,
    builder: (BuildContext ctx) {
      // KML needs a GPS position: use the saved one or read it now.
      Future<ScanSession?> prepared(ExportFormat f) async {
        if (f != ExportFormat.kml || sess.geo != null) return sess;
        final g = await s.currentGeo();
        if (g == null) {
          if (ctx.mounted) {
            ScaffoldMessenger.of(ctx).showSnackBar(
                SnackBar(content: Text(s.t('kml_need_gps'))));
          }
          return null;
        }
        return sess.withGeo(g);
      }

      Future<void> save(ExportFormat f) async {
        final ps = await prepared(f);
        if (ps == null) return;
        final path = await Exporter.write(ps, f, s.cellCm / 100.0);
        if (!ctx.mounted) return;
        ScaffoldMessenger.of(ctx).showSnackBar(
          SnackBar(content: Text('${s.t('exported_to')} $path')),
        );
      }

      Future<void> share(ExportFormat f) async {
        try {
          final ps = await prepared(f);
          if (ps == null) return;
          final path = await Exporter.write(ps, f, s.cellCm / 100.0);
          await Share.shareXFiles(<XFile>[XFile(path)]);
        } catch (_) {
          if (!ctx.mounted) return;
          ScaffoldMessenger.of(ctx)
              .showSnackBar(SnackBar(content: Text(s.t('share_failed'))));
        }
      }

      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(s.t('export'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(s.t('export_hint'),
                  style:  TextStyle(color: Pal.muted, fontSize: 12)),
              Text(s.t('kml_hint'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
              const SizedBox(height: 8),
              for (final f in ExportFormat.values)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading:  Icon(Icons.share, color: Pal.amber),
                  title: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(f.title),
                  ),
                  subtitle: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(f.note,
                        style:
                             TextStyle(color: Pal.muted, fontSize: 12)),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.download),
                    onPressed: () => save(f),
                  ),
                  onTap: () => share(f),
                ),
            ],
          ),
        ),
      );
    },
  );
}
