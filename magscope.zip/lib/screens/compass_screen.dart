import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Compass using the phone's own magnetometer (not the external device).
/// The heading is tilt-compensated with the accelerometer when available;
/// it is a MAGNETIC heading (not corrected for local declination).
class CompassScreen extends StatefulWidget {
  const CompassScreen({super.key});

  @override
  State<CompassScreen> createState() => _CompassScreenState();
}

class _CompassScreenState extends State<CompassScreen> {
  StreamSubscription<MagnetometerEvent>? _sub;
  Timer? _timeout;
  StreamSubscription<AccelerometerEvent>? _accSub;
  StreamSubscription<Position>? _gpsSub;
  double _heading = 0;
  double _strength = double.nan;
  bool _noSensor = false;
  List<double>? _acc; // latest accelerometer reading (gravity included)
  String _gpsMsg = '';
  Position? _pos;

  @override
  void initState() {
    super.initState();
    try {
      _accSub = accelerometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen((AccelerometerEvent a) => _acc = <double>[a.x, a.y, a.z],
          onError: (Object _) {});
    } catch (_) {}
    try {
      _sub = magnetometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen(
        (MagnetometerEvent e) {
          _timeout?.cancel();
          // azimuth in radians, clockwise from magnetic north
          double az;
          final a = _acc;
          final g = a == null
              ? 0.0
              : math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
          if (a != null && g > 1.0) {
            // tilt compensation (same maths as Android's getRotationMatrix)
            var hx = e.y * a[2] - e.z * a[1];
            var hy = e.z * a[0] - e.x * a[2];
            var hz = e.x * a[1] - e.y * a[0];
            final nh = math.sqrt(hx * hx + hy * hy + hz * hz);
            if (nh < 1e-6) return;
            hx /= nh;
            hy /= nh;
            hz /= nh;
            final ax = a[0] / g;
            final ay = a[1] / g;
            final az2 = a[2] / g;
            final my = az2 * hx - ax * hz;
            az = math.atan2(hy, my);
          } else {
            // phone flat: azimuth of the top edge, clockwise from north
            az = math.atan2(-e.x, e.y);
          }
          // low-pass the angle on the circle to avoid jitter
          final prev = -_heading;
          var d = az - prev;
          while (d > math.pi) {
            d -= 2 * math.pi;
          }
          while (d < -math.pi) {
            d += 2 * math.pi;
          }
          final smooth = prev + d * 0.2;
          AppState.compassDeg = ((smooth * 180 / math.pi) % 360 + 360) % 360;
          if (!mounted) return;
          setState(() {
            _heading = -smooth;
            _strength = math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
            _noSensor = false;
          });
        },
        onError: (Object _) {
          if (mounted) setState(() => _noSensor = true);
        },
        cancelOnError: false,
      );
    } catch (_) {
      _noSensor = true;
    }
    _startGps();
    _timeout = Timer(const Duration(seconds: 3), () {
      if (mounted && _strength.isNaN) setState(() => _noSensor = true);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _accSub?.cancel();
    _gpsSub?.cancel();
    _timeout?.cancel();
    super.dispose();
  }

  /// GPS is read automatically (no switch): permission is asked on start.
  Future<void> _startGps() async {
    try {
      final st = await Permission.locationWhenInUse.request();
      if (!st.isGranted || !await Geolocator.isLocationServiceEnabled()) {
        if (mounted) setState(() => _gpsMsg = 'sat_no_gps');
        return;
      }
      _gpsSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          distanceFilter: 1,
        ),
      ).listen((Position p) {
        if (mounted) setState(() => _pos = p);
      }, onError: (Object _) {
        if (mounted) setState(() => _gpsMsg = 'sat_no_gps');
      });
    } catch (_) {
      if (mounted) setState(() => _gpsMsg = 'sat_no_gps');
    }
  }

  /// Compass point (8 wind rose) name for a bearing in degrees.
  String _point(AppState s, double deg) {
    final i = ((deg + 22.5) ~/ 45) % 8;
    return s.t('pt8_$i');
  }

  /// Quadrant form, e.g. "North 30° West".
  String _quadrant(AppState s, double deg) {
    String ns;
    String ew;
    double a;
    if (deg < 90) {
      ns = 'card_n';
      ew = 'card_e';
      a = deg;
    } else if (deg < 180) {
      ns = 'card_s';
      ew = 'card_e';
      a = 180 - deg;
    } else if (deg < 270) {
      ns = 'card_s';
      ew = 'card_w';
      a = deg - 180;
    } else {
      ns = 'card_n';
      ew = 'card_w';
      a = 360 - deg;
    }
    if (a < 0.5) return s.t(ns);
    if ((90 - a).abs() < 0.5) return s.t(ew);
    return '${s.t(ns)} ${a.toStringAsFixed(0)}° ${s.t(ew)}';
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (_noSensor) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(s.t('no_sensor'),
              textAlign: TextAlign.center,
              style:  TextStyle(color: Pal.muted)),
        ),
      );
    }
    var deg = (-_heading * 180 / math.pi) % 360;
    if (deg < 0) deg += 360;
    final side = MediaQuery.of(context).size.width - 24;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: <Widget>[
        Panel(
          padding: const EdgeInsets.fromLTRB(6, 14, 6, 14),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: side.clamp(280.0, 560.0).toDouble(),
                child: CustomPaint(
                  painter: _DialPainter(
                    heading: _heading,
                    n: s.t('dir_n'),
                    e: s.t('dir_e'),
                    sth: s.t('dir_s'),
                    w: s.t('dir_w'),
                    deg: '${deg.toStringAsFixed(1)}°',
                    point: _point(s, deg),
                  ),
                  size: Size.infinite,
                ),
              ),
              const SizedBox(height: 8),
              Text(_quadrant(s, deg),
                  style: TextStyle(color: Pal.muted, fontSize: 13)),
              const SizedBox(height: 4),
              Num(
                _strength.isNaN
                    ? '--'
                    : '${s.t('field_strength')}  ${_strength.toStringAsFixed(1)} ${s.t('unit_ut')}',
                style: TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w700, color: Pal.amber),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Icon(Icons.my_location, size: 18, color: Pal.amber),
                  const SizedBox(width: 6),
                  Text(s.t('gps_title'),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 6),
              if (_pos != null) ...<Widget>[
                SelectableText(
                  '${_pos!.latitude.toStringAsFixed(6)}, ${_pos!.longitude.toStringAsFixed(6)}',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '${s.t('altitude')} ${_pos!.altitude.toStringAsFixed(0)} m   '
                  '±${_pos!.accuracy.toStringAsFixed(0)} m',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Pal.muted, fontSize: 12),
                ),
              ] else
                Text(_gpsMsg.isEmpty ? s.t('gps_waiting') : s.t(_gpsMsg),
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Text(s.t('compass_hint'),
            textAlign: TextAlign.center,
            style: TextStyle(color: Pal.muted, fontSize: 12)),
      ],
    );
  }
}

class _DialPainter extends CustomPainter {
  _DialPainter({
    required this.heading,
    required this.n,
    required this.e,
    required this.sth,
    required this.w,
    required this.deg,
    required this.point,
  });

  final double heading;
  final String n;
  final String e;
  final String sth;
  final String w;
  final String deg;
  final String point;

  void _text(Canvas canvas, String t, Offset at, Color color, double size,
      {FontWeight weight = FontWeight.w700}) {
    final tp = TextPainter(
      text: TextSpan(
        text: t,
        style: TextStyle(color: color, fontSize: size, fontWeight: weight),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, at - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = math.min(size.width, size.height) / 2 - 6;

    // glow + gold bezel
    canvas.drawCircle(
      c,
      r + 2,
      Paint()
        ..color = Pal.amber.withAlpha(70)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = SweepGradient(
          colors: <Color>[
            Pal.amber,
            Pal.amber.withAlpha(90),
            Pal.text.withAlpha(200),
            Pal.amber.withAlpha(90),
            Pal.amber,
          ],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    final face = r - 9;
    canvas.drawCircle(
      c,
      face,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[
            Pal.surface,
            Pal.bg,
          ],
        ).createShader(Rect.fromCircle(center: c, radius: face)),
    );

    // rotating scale
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(heading); // heading = -azimuth: the dial turns against the phone
    for (int i = 0; i < 72; i++) {
      final a = i * math.pi / 36;
      final major = i % 6 == 0; // every 30 degrees
      final mid = i % 2 == 0; // every 10 degrees
      final len = major ? 18.0 : (mid ? 11.0 : 6.0);
      canvas.drawLine(
        Offset(math.sin(a) * (face - 4), -math.cos(a) * (face - 4)),
        Offset(math.sin(a) * (face - 4 - len), -math.cos(a) * (face - 4 - len)),
        Paint()
          ..strokeWidth = major ? 3 : (mid ? 1.8 : 1.0)
          ..color = major ? Pal.amber : Pal.muted,
      );
    }
    final nr = face - 40; // numbers
    for (int d = 30; d < 360; d += 30) {
      if (d % 90 == 0) continue;
      final a = d * math.pi / 180;
      canvas.save();
      canvas.translate(math.sin(a) * nr, -math.cos(a) * nr);
      canvas.rotate(a);
      _text(canvas, '$d', Offset.zero, Pal.muted, 12);
      canvas.restore();
    }
    final lr = face - 44;
    void card(String t, double deg, Color col) {
      final a = deg * math.pi / 180;
      canvas.save();
      canvas.translate(math.sin(a) * lr, -math.cos(a) * lr);
      canvas.rotate(a);
      _text(canvas, t, Offset.zero, col, deg == 0 ? 26 : 20);
      canvas.restore();
    }

    card(n, 0, Pal.bad);
    card(e, 90, Pal.text);
    card(sth, 180, Pal.text);
    card(w, 270, Pal.text);
    // north arrow on the dial
    canvas.drawPath(
      Path()
        ..moveTo(0, -(face * 0.62))
        ..lineTo(10, -(face * 0.45))
        ..lineTo(-10, -(face * 0.45))
        ..close(),
      Paint()..color = Pal.bad,
    );
    canvas.restore();

    // inner ring and centre read-out
    canvas.drawCircle(
      c,
      face * 0.38,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = Pal.outline,
    );
    _text(canvas, deg, c.translate(0, -6), Pal.text, face * 0.2,
        weight: FontWeight.w800);
    _text(canvas, point, c.translate(0, face * 0.15), Pal.amber, face * 0.095);

    // fixed marker at the top = where the phone points
    canvas.drawPath(
      Path()
        ..moveTo(c.dx, c.dy - r + 2)
        ..lineTo(c.dx + 11, c.dy - r - 9)
        ..lineTo(c.dx - 11, c.dy - r - 9)
        ..close(),
      Paint()..color = Pal.amber,
    );
    canvas.drawLine(
      Offset(c.dx, c.dy - face * 0.38),
      Offset(c.dx, c.dy - face + 8),
      Paint()
        ..strokeWidth = 2.5
        ..color = Pal.amber.withAlpha(170),
    );
  }

  @override
  bool shouldRepaint(covariant _DialPainter old) =>
      old.heading != heading || old.deg != deg;
}
