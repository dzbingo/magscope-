import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Compass using the phone's own magnetometer (not the external device).
/// The heading is only approximate: it assumes the phone is held flat.
class CompassScreen extends StatefulWidget {
  const CompassScreen({super.key});

  @override
  State<CompassScreen> createState() => _CompassScreenState();
}

class _CompassScreenState extends State<CompassScreen> {
  StreamSubscription<MagnetometerEvent>? _sub;
  Timer? _timeout;
  double _heading = 0;
  double _strength = double.nan;
  bool _noSensor = false;

  @override
  void initState() {
    super.initState();
    try {
      _sub = magnetometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen(
        (MagnetometerEvent e) {
          _timeout?.cancel();
          var h = math.atan2(e.y, e.x) - math.pi / 2;
          // low-pass the angle on the circle to avoid jitter
          final prev = _heading;
          var d = h - prev;
          while (d > math.pi) {
            d -= 2 * math.pi;
          }
          while (d < -math.pi) {
            d += 2 * math.pi;
          }
          h = prev + d * 0.2;
          if (!mounted) return;
          setState(() {
            _heading = h;
            _strength = math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
            _noSensor = false;
          });
        },
        onError: (Object _) {
          if (mounted) setState(() => _noSensor = true);
        },
        cancelOnError: false,
      );
    } catch (_) {
      _noSensor = true;
    }
    _timeout = Timer(const Duration(seconds: 3), () {
      if (mounted && _strength.isNaN) setState(() => _noSensor = true);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _timeout?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (_noSensor) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(s.t('no_sensor'),
              textAlign: TextAlign.center,
              style:  TextStyle(color: Pal.muted)),
        ),
      );
    }
    var deg = (-_heading * 180 / math.pi) % 360;
    if (deg < 0) deg += 360;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 300,
                child: CustomPaint(
                  painter: _DialPainter(
                    heading: _heading,
                    n: s.t('dir_n'),
                    e: s.t('dir_e'),
                    sth: s.t('dir_s'),
                    w: s.t('dir_w'),
                  ),
                  size: Size.infinite,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(s.t('heading'),
                            style:  TextStyle(
                                color: Pal.muted, fontSize: 11)),
                        const SizedBox(height: 3),
                        Num('${deg.toStringAsFixed(0)}°',
                            style: const TextStyle(
                                fontSize: 22, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(s.t('field_strength'),
                            style:  TextStyle(
                                color: Pal.muted, fontSize: 11)),
                        const SizedBox(height: 3),
                        Num(
                          _strength.isNaN
                              ? '--'
                              : '${_strength.toStringAsFixed(1)} ${s.t('unit')}',
                          style:  TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              color: Pal.amber),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Text(s.t('compass_hint'),
            textAlign: TextAlign.center,
            style:  TextStyle(color: Pal.muted, fontSize: 12)),
      ],
    );
  }
}

class _DialPainter extends CustomPainter {
  _DialPainter({
    required this.heading,
    required this.n,
    required this.e,
    required this.sth,
    required this.w,
  });

  final double heading;
  final String n;
  final String e;
  final String sth;
  final String w;

  void _text(Canvas canvas, String t, Offset at, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(
        text: t,
        style: TextStyle(
            color: color, fontSize: size, fontWeight: FontWeight.w700),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, at - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = math.min(size.width, size.height) / 2 - 8;
    canvas.drawCircle(c, r, Paint()..color = Pal.bg);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Pal.outline,
    );
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(-heading);
    for (int i = 0; i < 72; i++) {
      final a = i * math.pi / 36;
      final major = i % 9 == 0;
      final len = major ? 14.0 : (i % 3 == 0 ? 9.0 : 5.0);
      canvas.drawLine(
        Offset(math.sin(a) * (r - 4), -math.cos(a) * (r - 4)),
        Offset(math.sin(a) * (r - 4 - len), -math.cos(a) * (r - 4 - len)),
        Paint()
          ..strokeWidth = major ? 2.5 : 1.2
          ..color = major ? Pal.text : Pal.muted,
      );
    }
    final lr = r - 34;
    _text(canvas, n, Offset(0, -lr), Pal.bad, 18);
    _text(canvas, e, Offset(lr, 0), Pal.text, 15);
    _text(canvas, sth, Offset(0, lr), Pal.text, 15);
    _text(canvas, w, Offset(-lr, 0), Pal.text, 15);
    canvas.restore();

    // fixed needle pointing up (phone's top edge)
    final needle = Path()
      ..moveTo(c.dx, c.dy - r * 0.45)
      ..lineTo(c.dx + 9, c.dy)
      ..lineTo(c.dx - 9, c.dy)
      ..close();
    canvas.drawPath(needle, Paint()..color = Pal.amber);
    canvas.drawCircle(c, 5, Paint()..color = Pal.text);
    canvas.drawPath(
      Path()
        ..moveTo(c.dx, c.dy - r - 2)
        ..lineTo(c.dx + 7, c.dy - r + 10)
        ..lineTo(c.dx - 7, c.dy - r + 10)
        ..close(),
      Paint()..color = Pal.amber,
    );
  }

  @override
  bool shouldRepaint(covariant _DialPainter old) => old.heading != heading;
}
