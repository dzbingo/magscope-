import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Compass using the phone's own magnetometer (not the external device).
/// The heading is tilt-compensated with the accelerometer when available;
/// it is a MAGNETIC heading (not corrected for local declination).
class CompassScreen extends StatefulWidget {
  const CompassScreen({super.key});

  @override
  State<CompassScreen> createState() => _CompassScreenState();
}

class _CompassScreenState extends State<CompassScreen> {
  StreamSubscription<MagnetometerEvent>? _sub;
  Timer? _timeout;
  StreamSubscription<AccelerometerEvent>? _accSub;
  StreamSubscription<Position>? _gpsSub;
  double _heading = 0;
  double _strength = double.nan;
  bool _noSensor = false;
  List<double>? _acc; // latest accelerometer reading (gravity included)
  bool _gps = false;
  String _gpsMsg = '';
  Position? _pos;

  @override
  void initState() {
    super.initState();
    try {
      _accSub = accelerometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen((AccelerometerEvent a) => _acc = <double>[a.x, a.y, a.z],
          onError: (Object _) {});
    } catch (_) {}
    try {
      _sub = magnetometerEventStream(
        samplingPeriod: const Duration(milliseconds: 60),
      ).listen(
        (MagnetometerEvent e) {
          _timeout?.cancel();
          // azimuth in radians, clockwise from magnetic north
          double az;
          final a = _acc;
          final g = a == null
              ? 0.0
              : math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
          if (a != null && g > 1.0) {
            // tilt compensation (same maths as Android's getRotationMatrix)
            var hx = e.y * a[2] - e.z * a[1];
            var hy = e.z * a[0] - e.x * a[2];
            var hz = e.x * a[1] - e.y * a[0];
            final nh = math.sqrt(hx * hx + hy * hy + hz * hz);
            if (nh < 1e-6) return;
            hx /= nh;
            hy /= nh;
            hz /= nh;
            final ax = a[0] / g;
            final ay = a[1] / g;
            final az2 = a[2] / g;
            final my = az2 * hx - ax * hz;
            az = math.atan2(hy, my);
          } else {
            // phone flat: azimuth of the top edge, clockwise from north
            az = math.atan2(-e.x, e.y);
          }
          // low-pass the angle on the circle to avoid jitter
          final prev = -_heading;
          var d = az - prev;
          while (d > math.pi) {
            d -= 2 * math.pi;
          }
          while (d < -math.pi) {
            d += 2 * math.pi;
          }
          final smooth = prev + d * 0.2;
          if (!mounted) return;
          setState(() {
            _heading = -smooth;
            _strength = math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
            _noSensor = false;
          });
        },
        onError: (Object _) {
          if (mounted) setState(() => _noSensor = true);
        },
        cancelOnError: false,
      );
    } catch (_) {
      _noSensor = true;
    }
    _timeout = Timer(const Duration(seconds: 3), () {
      if (mounted && _strength.isNaN) setState(() => _noSensor = true);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _accSub?.cancel();
    _gpsSub?.cancel();
    _timeout?.cancel();
    super.dispose();
  }

  Future<void> _setGps(bool on, AppState s) async {
    if (!on) {
      await _gpsSub?.cancel();
      _gpsSub = null;
      setState(() {
        _gps = false;
        _pos = null;
        _gpsMsg = '';
      });
      return;
    }
    setState(() {
      _gps = true;
      _gpsMsg = s.t('gps_waiting');
    });
    try {
      final st = await Permission.locationWhenInUse.request();
      if (!st.isGranted || !await Geolocator.isLocationServiceEnabled()) {
        if (mounted) {
          setState(() {
            _gps = false;
            _gpsMsg = s.t('sat_no_gps');
          });
        }
        return;
      }
      _gpsSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best,
          distanceFilter: 1,
        ),
      ).listen((Position p) {
        if (mounted) setState(() => _pos = p);
      }, onError: (Object _) {
        if (mounted) setState(() => _gpsMsg = s.t('sat_no_gps'));
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _gps = false;
          _gpsMsg = s.t('sat_no_gps');
        });
      }
    }
  }

  /// Compass point (8 wind rose) name for a bearing in degrees.
  String _point(AppState s, double deg) {
    final i = ((deg + 22.5) ~/ 45) % 8;
    return s.t('pt8_$i');
  }

  /// Quadrant form, e.g. "North 30° West".
  String _quadrant(AppState s, double deg) {
    String ns;
    String ew;
    double a;
    if (deg < 90) {
      ns = 'card_n';
      ew = 'card_e';
      a = deg;
    } else if (deg < 180) {
      ns = 'card_s';
      ew = 'card_e';
      a = 180 - deg;
    } else if (deg < 270) {
      ns = 'card_s';
      ew = 'card_w';
      a = deg - 180;
    } else {
      ns = 'card_n';
      ew = 'card_w';
      a = 360 - deg;
    }
    if (a < 0.5) return s.t(ns);
    if ((90 - a).abs() < 0.5) return s.t(ew);
    return '${s.t(ns)} ${a.toStringAsFixed(0)}° ${s.t(ew)}';
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (_noSensor) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(s.t('no_sensor'),
              textAlign: TextAlign.center,
              style:  TextStyle(color: Pal.muted)),
        ),
      );
    }
    var deg = (-_heading * 180 / math.pi) % 360;
    if (deg < 0) deg += 360;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Panel(
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 300,
                child: CustomPaint(
                  painter: _DialPainter(
                    heading: _heading,
                    n: s.t('dir_n'),
                    e: s.t('dir_e'),
                    sth: s.t('dir_s'),
                    w: s.t('dir_w'),
                  ),
                  size: Size.infinite,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(s.t('heading'),
                            style:  TextStyle(
                                color: Pal.muted, fontSize: 11)),
                        const SizedBox(height: 3),
                        Num('${deg.toStringAsFixed(1)}°',
                            style: const TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 2),
                        Text(_point(s, deg),
                            style: TextStyle(
                                color: Pal.amber,
                                fontSize: 16,
                                fontWeight: FontWeight.w700)),
                        Text(_quadrant(s, deg),
                            style: TextStyle(color: Pal.muted, fontSize: 12)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(s.t('field_strength'),
                            style:  TextStyle(
                                color: Pal.muted, fontSize: 11)),
                        const SizedBox(height: 3),
                        Num(
                          _strength.isNaN
                              ? '--'
                              : '${_strength.toStringAsFixed(1)} ${s.t('unit')}',
                          style:  TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              color: Pal.amber),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                title: Text(s.t('compass_gps')),
                value: _gps,
                onChanged: (bool v) => _setGps(v, s),
              ),
              if (_gps && _pos != null) ...<Widget>[
                SelectableText(
                  '${_pos!.latitude.toStringAsFixed(6)}, ${_pos!.longitude.toStringAsFixed(6)}',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '${s.t('altitude')} ${_pos!.altitude.toStringAsFixed(0)} m   '
                  '±${_pos!.accuracy.toStringAsFixed(0)} m',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Pal.muted, fontSize: 12),
                ),
              ] else if (_gps || _gpsMsg.isNotEmpty)
                Text(_gpsMsg,
                    style: TextStyle(color: Pal.muted, fontSize: 12)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Text(s.t('compass_hint'),
            textAlign: TextAlign.center,
            style:  TextStyle(color: Pal.muted, fontSize: 12)),
      ],
    );
  }
}

class _DialPainter extends CustomPainter {
  _DialPainter({
    required this.heading,
    required this.n,
    required this.e,
    required this.sth,
    required this.w,
  });

  final double heading;
  final String n;
  final String e;
  final String sth;
  final String w;

  void _text(Canvas canvas, String t, Offset at, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(
        text: t,
        style: TextStyle(
            color: color, fontSize: size, fontWeight: FontWeight.w700),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, at - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = math.min(size.width, size.height) / 2 - 8;
    canvas.drawCircle(c, r, Paint()..color = Pal.bg);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Pal.outline,
    );
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(heading); // heading = -azimuth: the dial turns against the phone
    for (int i = 0; i < 72; i++) {
      final a = i * math.pi / 36;
      final major = i % 9 == 0;
      final len = major ? 14.0 : (i % 3 == 0 ? 9.0 : 5.0);
      canvas.drawLine(
        Offset(math.sin(a) * (r - 4), -math.cos(a) * (r - 4)),
        Offset(math.sin(a) * (r - 4 - len), -math.cos(a) * (r - 4 - len)),
        Paint()
          ..strokeWidth = major ? 2.5 : 1.2
          ..color = major ? Pal.text : Pal.muted,
      );
    }
    final lr = r - 34;
    _text(canvas, n, Offset(0, -lr), Pal.bad, 18);
    _text(canvas, e, Offset(lr, 0), Pal.text, 15);
    _text(canvas, sth, Offset(0, lr), Pal.text, 15);
    _text(canvas, w, Offset(-lr, 0), Pal.text, 15);
    canvas.restore();

    // fixed needle pointing up (phone's top edge)
    final needle = Path()
      ..moveTo(c.dx, c.dy - r * 0.45)
      ..lineTo(c.dx + 9, c.dy)
      ..lineTo(c.dx - 9, c.dy)
      ..close();
    canvas.drawPath(needle, Paint()..color = Pal.amber);
    canvas.drawCircle(c, 5, Paint()..color = Pal.text);
    canvas.drawPath(
      Path()
        ..moveTo(c.dx, c.dy - r - 2)
        ..lineTo(c.dx + 7, c.dy - r + 10)
        ..lineTo(c.dx - 7, c.dy - r + 10)
        ..close(),
      Paint()..color = Pal.amber,
    );
  }

  @override
  bool shouldRepaint(covariant _DialPainter old) => old.heading != heading;
}
