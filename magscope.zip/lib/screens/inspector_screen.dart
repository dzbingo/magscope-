import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Connects to the selected BLE device, lists its services/characteristics
/// and shows live packets (hex, text and number guesses) so the right data
/// characteristic and packet format can be picked.
class InspectorScreen extends StatefulWidget {
  const InspectorScreen({super.key, required this.deviceId});

  final String deviceId;

  @override
  State<InspectorScreen> createState() => _InspectorScreenState();
}

class _Live {
  List<int> last = <int>[];
  int count = 0;
  StreamSubscription<List<int>>? sub;
}

class _InspectorScreenState extends State<InspectorScreen> {
  late final BluetoothDevice _dev = BluetoothDevice.fromId(widget.deviceId);
  List<BluetoothService> _services = <BluetoothService>[];
  final Map<String, _Live> _live = <String, _Live>{};
  bool _busy = false;
  bool _connected = false;
  String _error = '';
  bool _empty = false;

  @override
  void dispose() {
    for (final l in _live.values) {
      l.sub?.cancel();
    }
    _dev.disconnect().catchError((Object _) {});
    super.dispose();
  }

  Future<void> _connect() async {
    setState(() {
      _busy = true;
      _error = '';
      _empty = false;
    });
    try {
      await _dev.connect(timeout: const Duration(seconds: 15));
      final sv = await _dev.discoverServices();
      if (!mounted) return;
      setState(() {
        _services = sv;
        _connected = true;
        _empty = sv.isEmpty;
      });
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
    if (mounted) setState(() => _busy = false);
  }

  String _key(BluetoothCharacteristic c) =>
      '${c.serviceUuid}/${c.uuid}';

  Future<void> _toggle(BluetoothCharacteristic c) async {
    final k = _key(c);
    final cur = _live[k];
    if (cur != null) {
      await cur.sub?.cancel();
      try {
        await c.setNotifyValue(false);
      } catch (_) {}
      setState(() => _live.remove(k));
      return;
    }
    final l = _Live();
    try {
      await c.setNotifyValue(true);
      l.sub = c.onValueReceived.listen((List<int> d) {
        l.last = d;
        l.count++;
        if (mounted) setState(() {});
      });
      setState(() => _live[k] = l);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  String _hex(List<int> d) =>
      d.map((int b) => b.toRadixString(16).padLeft(2, '0')).join(' ');

  String _guess(List<int> d) {
    if (d.isEmpty) return '';
    final parts = <String>[];
    final txt = utf8.decode(d, allowMalformed: true).trim();
    if (txt.isNotEmpty &&
        txt.runes.every((int r) => r == 10 || r == 13 || (r >= 32 && r < 127))) {
      parts.add('text: $txt');
    }
    final bd = ByteData.sublistView(Uint8List.fromList(d));
    if (d.length >= 2) {
      final v = <String>[];
      for (int i = 0; i + 2 <= d.length && i < 12; i += 2) {
        v.add('${bd.getInt16(i, Endian.little)}');
      }
      parts.add('int16: ${v.join(', ')}');
    }
    if (d.length >= 4) {
      final v = <String>[];
      for (int i = 0; i + 4 <= d.length && i < 12; i += 4) {
        v.add(bd.getFloat32(i, Endian.little).toStringAsFixed(3));
      }
      parts.add('float32: ${v.join(', ')}');
    }
    return parts.join('\n');
  }

  String _props(BluetoothCharacteristic c) {
    final p = c.properties;
    return <String>[
      if (p.read) 'read',
      if (p.write || p.writeWithoutResponse) 'write',
      if (p.notify) 'notify',
      if (p.indicate) 'indicate',
    ].join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final children = <Widget>[
      Text(s.t('inspect_hint'),
          style: TextStyle(color: Pal.muted, fontSize: 12)),
      const SizedBox(height: 8),
      Text(widget.deviceId,
          textDirection: TextDirection.ltr,
          style: TextStyle(color: Pal.muted, fontSize: 11)),
      const SizedBox(height: 10),
      FilledButton.icon(
        onPressed: _busy ? null : _connect,
        icon: const Icon(Icons.bluetooth_connected),
        label: Text(_busy ? s.t('connecting') : s.t('inspect_connect')),
      ),
    ];
    if (_error.isNotEmpty) {
      children.add(const SizedBox(height: 10));
      children.add(Panel(
        glow: Pal.bad,
        child: Text(_error,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: Pal.bad, fontSize: 12)),
      ));
    }
    if (_connected && _empty) {
      children.add(const SizedBox(height: 10));
      children.add(Text(s.t('inspect_none'),
          style: TextStyle(color: Pal.amber)));
    }
    for (final sv in _services) {
      children.add(const SizedBox(height: 12));
      children.add(Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Service ${sv.uuid}',
                textDirection: TextDirection.ltr,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 12)),
            for (final c in sv.characteristics) ...<Widget>[
              const Divider(height: 18),
              Text('${c.uuid}',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 2),
              Text(_props(c),
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
              if (c.properties.notify || c.properties.indicate)
                Row(
                  children: <Widget>[
                    TextButton(
                      onPressed: () => _toggle(c),
                      child: Text(_live.containsKey(_key(c))
                          ? s.t('stop')
                          : s.t('start')),
                    ),
                    TextButton(
                      onPressed: () {
                        s.setBleConfig(
                          service: '${sv.uuid}',
                          characteristic: '${c.uuid}',
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(s.t('char_set'))));
                      },
                      child: Text(s.t('use_char')),
                    ),
                    const Spacer(),
                    if (_live[_key(c)] != null)
                      Text('${s.t('packets')}: ${_live[_key(c)]!.count}',
                          style: TextStyle(color: Pal.amber, fontSize: 11)),
                  ],
                ),
              if (_live[_key(c)] != null &&
                  _live[_key(c)]!.last.isNotEmpty) ...<Widget>[
                Text('${s.t('last_packet')}: ${_hex(_live[_key(c)]!.last)}',
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(fontSize: 11)),
                const SizedBox(height: 2),
                Text(_guess(_live[_key(c)]!.last),
                    textDirection: TextDirection.ltr,
                    style: TextStyle(color: Pal.muted, fontSize: 11)),
              ],
            ],
          ],
        ),
      ));
    }
    return Scaffold(
      appBar: AppBar(title: Text(s.t('inspector'))),
      body: ListView(padding: const EdgeInsets.all(16), children: children),
    );
  }
}
