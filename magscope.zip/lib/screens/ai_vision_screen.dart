import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';

import '../ai_vision.dart';
import '../insight.dart';
import '../quality.dart';
import '../target_analysis.dart';
import '../soil.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'corners_panel.dart';
import 'num_stepper.dart';
import 'scan_window.dart';
import 'targets_screen.dart';
import '../storage.dart';

/// AI Vision scan: the examiner only sets the grid (size, step, start side)
/// and the conditions. A soil photo (or a manual soil choice) lets the "AI
/// manager" set every filter and correction by itself. The manager is a set of
/// rules based on soil magnetic susceptibility, not a trained neural network.
class AiVisionScreen extends StatefulWidget {
  const AiVisionScreen({super.key});

  @override
  State<AiVisionScreen> createState() => _AiVisionScreenState();
}

class _AiVisionScreenState extends State<AiVisionScreen> {
  bool _night = false;
  bool _humid = false;
  String? _photo;
  SoilGuess? _guess;
  int _soilIdx = 0;
  bool _busy = false;
  bool _verdictGiven = false;
  int _pkgCount = 0;

  @override
  void initState() {
    super.initState();
    _countPackages();
  }

  Future<Directory> _baseDir() async {
    Directory? ext;
    try {
      ext = await AppFolders.root();
    } catch (_) {}
    return ext ?? await getApplicationDocumentsDirectory();
  }

  Future<void> _countPackages() async {
    final n = AiVision.packages(await _baseDir()).length;
    if (mounted) setState(() => _pkgCount = n);
  }

  Future<void> _useImage(String path) async {
    setState(() {
      _busy = true;
      _photo = path;
    });
    try {
      final g = await AiVision.guessSoil(await File(path).readAsBytes());
      if (!mounted) return;
      setState(() {
        _guess = g;
        _soilIdx = g.soilIdx;
      });
    } catch (_) {}
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _capture() async {
    final path = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(builder: (_) => const _SoilCapture()),
    );
    if (path != null) await _useImage(path);
  }

  Future<void> _gallery() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.image);
      final p = r?.files.single.path;
      if (p != null) await _useImage(p);
    } catch (_) {}
  }

  Future<void> _start(AppState s) async {
    if (s.scanning) return;
    if (s.hasData) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (BuildContext c) => AlertDialog(
          content: Text(s.t('ai_new_scan_confirm')),
          actions: <Widget>[
            TextButton(
                onPressed: () => Navigator.pop(c, false),
                child: Text(s.t('cancel'))),
            FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: Text(s.t('ok'))),
          ],
        ),
      );
      if (ok != true || !mounted) return;
      s.clearData();
    }
    final plan =
        AiVision.plan(soilIdx: _soilIdx, humid: _humid, night: _night);
    s.setSoil(plan.soilIdx);
    s.setFilters(plan.filters);
    s.setDestripe(plan.destripe);
    s.setGridView(plan.gridView);
    if (s.calSigma != null) {
      // the threshold comes from the noise that was really measured
      s.setThrUT((s.calSigma! * s.effSens).clamp(0.1, 20.0).toDouble());
      s.setManualThr(true);
    } else {
      s.setManualThr(false);
    }
    setState(() => _verdictGiven = false);
    await s.startScan();
    if (!s.scanning || !mounted) return;
    final r = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        fullscreenDialog: true,
        builder: (BuildContext c) => const ScanWindow(),
      ),
    );
    if (r == 'save' && mounted) await _save(s);
    if (mounted) setState(() {});
  }

  Future<void> _save(AppState s) async {
    final name = 'AI_${stamp(DateTime.now())}';
    await s.saveCurrent(name);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  Future<void> _verdict(AppState s, Insight ins, bool found, [TargetInfo? info]) async {
    s.markTarget(ins.contrast, found);
    if (info != null) s.markFeat(info.features, found);
    try {
      await AiVision.savePackage(
        cols: s.cols,
        rows: s.rows,
        cellCm: s.cellCm,
        cells: s.cells,
        soilIdx: _soilIdx,
        guess: _guess,
        humid: _humid,
        night: _night,
        contrast: ins.contrast,
        score: ins.score,
        found: found,
      );
    } catch (_) {}
    if (!mounted) return;
    setState(() => _verdictGiven = true);
    _countPackages();
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('ai_pkg_saved'))));
  }

  Future<void> _sharePackages() async {
    final files = AiVision.packages(await _baseDir());
    if (files.isEmpty) return;
    await Share.shareXFiles(<XFile>[
      for (final f in files.take(50)) XFile(f.path, mimeType: 'application/json')
    ]);
  }

  Widget _head(String text, Color c) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: TextStyle(color: c, fontWeight: FontWeight.w800)),
      );

  Widget _plan(AppState s) {
    final plan =
        AiVision.plan(soilIdx: _soilIdx, humid: _humid, night: _night);
    final f = plan.filters;
    final soil = kSoils[_soilIdx];
    String yn(bool v) => v ? s.t('ai_on') : s.t('ai_off');
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _head(s.t('ai_plan'), Pal.good),
          Text('${s.t('soil_title')}: ${s.t(soil.key)}'),
          Text('${s.t('ai_sens')}: ${(f.sensitivity * soil.kFactor).toStringAsFixed(1)}'),
          Text('${s.t('ai_median')}: ${f.medianWindow}'),
          Text('${s.t('ai_baseline')}: ${yn(f.baseline)}'),
          Text('${s.t('destripe')}: ${yn(plan.destripe)}'),
          Text('${s.t('ai_passes')}: ${f.gridPasses}'),
          const SizedBox(height: 6),
          for (final r in plan.reasons)
            Text('• ${s.t(r)}',
                style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _calPanel(AppState s) {
    final connected = s.conn == ConnState.connected;
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _head(s.t('cal_title'), Pal.violet),
          Text(s.t('cal_hint'), style: TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 6),
          if (s.calibrating) ...<Widget>[
            LinearProgressIndicator(value: 1 - s.calLeft / 10.0),
            const SizedBox(height: 4),
            Text('${s.t('cal_running')}  ${s.calLeft}',
                style: TextStyle(color: Pal.amber)),
          ] else ...<Widget>[
            Text(
              s.calSigma == null
                  ? s.t('cal_none')
                  : '${s.t('cal_done')}: ${s.calSigma!.toStringAsFixed(3)}',
              style: TextStyle(
                  color: s.calSigma == null ? Pal.muted : Pal.good, fontSize: 12),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: (!connected || s.scanning)
                        ? null
                        : () async {
                            final ok = await s.calibrateNoise();
                            if (!mounted || ok) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(s.t('cal_failed'))));
                          },
                    icon: const Icon(Icons.tune),
                    label: Text(s.t('cal_start')),
                  ),
                ),
                if (s.calSigma != null)
                  TextButton(
                      onPressed: s.clearCalibration,
                      child: Text(s.t('cal_reset'))),
              ],
            ),
            if (!connected)
              Text(s.t('cal_connect'),
                  style: TextStyle(color: Pal.amber, fontSize: 11)),
          ],
        ],
      ),
    );
  }

  Widget _qualityCard(AppState s, ScanQuality q) {
    final c = q.score >= 75 ? Pal.good : (q.score >= 50 ? Pal.amber : Pal.bad);
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withAlpha(140)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                  child: Text(s.t('quality_title'),
                      style: const TextStyle(fontWeight: FontWeight.w700))),
              Text('${q.score}%',
                  style: TextStyle(
                      color: c, fontWeight: FontWeight.w800, fontSize: 18)),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
              value: q.score / 100.0, color: c, minHeight: 6),
          const SizedBox(height: 6),
          if (q.issues.isEmpty)
            Text(s.t('q_ok'), style: TextStyle(color: Pal.muted, fontSize: 12))
          else
            for (final k in q.issues)
              Text('• ${s.t(k)}',
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _targetCard(AppState s, TargetInfo i) {
    final r = i.depthRange;
    final model = s.localModel;
    final cnt = LocalModel.counts(s.featRecs);
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Pal.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(s.t('tk_title'),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(s.t(i.kindKey), style: TextStyle(color: Pal.amber)),
          const SizedBox(height: 4),
          Text('${s.t('tk_width')}: ~${i.widthM.toStringAsFixed(1)} m   '
              '${s.t('tk_peaks')}: ${i.peaks}   '
              '${s.t('tk_symmetry')}: ${(i.symmetry * 100).round()}%',
              style: const TextStyle(fontSize: 12)),
          if (r != null)
            Text('${s.t('tk_depth_range')}: ${r.$1.toStringAsFixed(1)} - ${r.$2.toStringAsFixed(1)} m',
                style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          if (model != null) ...<Widget>[
            Text('${s.t('tk_model_prob')}: ${(model.probability(i.features) * 100).round()}%',
                style: TextStyle(color: Pal.good, fontWeight: FontWeight.w700)),
            Text('${s.t('tk_model_acc')}: ${(model.accuracy * 100).round()}%  (n=${model.samples})',
                style: TextStyle(color: Pal.muted, fontSize: 11)),
          ] else
            Text(
                '${s.t('tk_model_need')} ${s.featRecs.length} (${cnt.$1}/${cnt.$2}) ${s.t('tk_model_need2')}',
                style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _result(AppState s) {
    final ins = InsightEngine.analyze(
      s.cells,
      s.cols,
      s.rows,
      sensitivity: s.effSens,
      cellM: s.cellCm / 100.0,
      learnedContrast: s.learnedContrast,
      widespreadFrac: 0.12 * s.soil.widespread / 0.25,
      calSigma: s.calSigma,
    );
    final noise = math.max(InsightEngine.noiseOf(s.cells), s.calSigma ?? 0.0);
    final TargetInfo? info = ins.kind > 0
        ? TargetAnalysis.analyze(
            s.cells, s.cols, s.rows, ins.x, ins.y, s.cellCm / 100.0, noise)
        : null;
    final q = ScanQuality.of(
        cells: s.cells,
        cols: s.cols,
        rows: s.rows,
        raw: s.allRaw,
        calSigma: s.calSigma);
    final String msg;
    if (ins.kind == -1) {
      msg = s.t('insight_low_data');
    } else if (ins.kind == 0) {
      msg = s.t('insight_none');
    } else {
      msg = s.t(ins.kind == 1 ? 'insight_metal' : 'insight_void');
    }
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _head(s.t('ai_verdict'), Pal.amber),
          Text(msg),
          const SizedBox(height: 8),
          _qualityCard(s, q),
          if (ins.kind > 0) ...<Widget>[
            const SizedBox(height: 6),
            Text('${s.t('target_score')}: ${ins.score}/100   '
                '${s.t('false_risk')}: ${s.t('risk_${ins.falseRisk}')}'),
            if (ins.depthM != null)
              Text('${s.t('depth')}: ~${ins.depthM!.toStringAsFixed(2)} m'),
            if (ins.isolated)
              Text(s.t('insight_isolated'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            if (ins.widespread)
              Text(s.t('insight_widespread'),
                  style: TextStyle(color: Pal.muted, fontSize: 11)),
            if (info != null) ...<Widget>[
              const SizedBox(height: 10),
              _targetCard(s, info),
              const SizedBox(height: 6),
              FilledButton.tonalIcon(
                onPressed: () async {
                  final t = await s.saveTargetAt(ins.x, ins.y, info);
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(
                          t == null ? s.t('target_no_geo') : s.t('target_saved'))));
                },
                icon: const Icon(Icons.pin_drop_outlined),
                label: Text(s.t('target_save')),
              ),
            ],
            const SizedBox(height: 10),
            _head(s.t('ai_feedback'), Pal.violet),
            if (_verdictGiven)
              Text(s.t('ai_pkg_saved'), style: TextStyle(color: Pal.good))
            else
              Row(
                children: <Widget>[
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: Pal.good,
                          foregroundColor: Colors.black),
                      onPressed: () => _verdict(s, ins, true, info),
                      icon: const Icon(Icons.check_circle),
                      label: Text(s.t('ai_found')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                          backgroundColor: Pal.bad,
                          foregroundColor: Colors.white),
                      onPressed: () => _verdict(s, ins, false, info),
                      icon: const Icon(Icons.cancel),
                      label: Text(s.t('ai_fake')),
                    ),
                  ),
                ],
              ),
          ],
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: <Widget>[
              FilledButton.tonalIcon(
                onPressed: () => _save(s),
                icon: const Icon(Icons.save_outlined),
                label: Text(s.t('save')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final canShow = s.hasData && !s.scanning;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('ai_vision'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            Panel(
              child: Text(s.t('ai_intro'),
                  style: TextStyle(color: Pal.muted, fontSize: 12)),
            ),
            const SizedBox(height: 12),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _head(s.t('ai_step1'), Pal.amber),
                  NumStepper(
                    label: s.t('columns'),
                    value: s.cols,
                    min: 2,
                    max: 48,
                    enabled: !s.scanning,
                    onChanged: (int v) => s.setGrid(v, s.rows),
                  ),
                  NumStepper(
                    label: s.t('rows'),
                    value: s.rows,
                    min: 2,
                    max: 48,
                    enabled: !s.scanning,
                    onChanged: (int v) => s.setGrid(s.cols, v),
                  ),
                  Text(s.t('step_size')),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Slider(
                          value: s.cellCm.clamp(30.0, 50.0).toDouble(),
                          min: 30,
                          max: 50,
                          divisions: 4,
                          label: '${s.cellCm.round()}',
                          onChanged: s.scanning ? null : s.setCellCm,
                        ),
                      ),
                      Num('${s.cellCm.round()} cm',
                          style: TextStyle(
                              color: Pal.amber, fontWeight: FontWeight.w800)),
                    ],
                  ),
                  SegmentedButton<bool>(
                    segments: <ButtonSegment<bool>>[
                      ButtonSegment<bool>(
                          value: false, label: Text(s.t('dir_ltr'))),
                      ButtonSegment<bool>(
                          value: true, label: Text(s.t('dir_rtl'))),
                    ],
                    selected: <bool>{s.rtl},
                    onSelectionChanged:
                        s.scanning ? null : (Set<bool> v) => s.setRtl(v.first),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Panel(child: CornersPanel()),
            const SizedBox(height: 12),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _head(s.t('ai_step2'), Pal.violet),
                  SegmentedButton<bool>(
                    segments: <ButtonSegment<bool>>[
                      ButtonSegment<bool>(
                          value: false,
                          icon: const Icon(Icons.wb_sunny_outlined),
                          label: Text(s.t('ai_day'))),
                      ButtonSegment<bool>(
                          value: true,
                          icon: const Icon(Icons.nightlight_outlined),
                          label: Text(s.t('ai_night'))),
                    ],
                    selected: <bool>{_night},
                    onSelectionChanged: (Set<bool> v) =>
                        setState(() => _night = v.first),
                  ),
                  const SizedBox(height: 8),
                  SegmentedButton<bool>(
                    segments: <ButtonSegment<bool>>[
                      ButtonSegment<bool>(
                          value: false,
                          icon: const Icon(Icons.landscape_outlined),
                          label: Text(s.t('ai_dry'))),
                      ButtonSegment<bool>(
                          value: true,
                          icon: const Icon(Icons.water_drop_outlined),
                          label: Text(s.t('ai_humid'))),
                    ],
                    selected: <bool>{_humid},
                    onSelectionChanged: (Set<bool> v) =>
                        setState(() => _humid = v.first),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _head(s.t('ai_step3'), Pal.good),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: _busy ? null : _capture,
                          icon: const Icon(Icons.photo_camera),
                          label: Text(s.t('ai_take_photo')),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filledTonal(
                        tooltip: s.t('ai_from_gallery'),
                        onPressed: _busy ? null : _gallery,
                        icon: const Icon(Icons.photo_library_outlined),
                      ),
                    ],
                  ),
                  if (_busy)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: LinearProgressIndicator(),
                    ),
                  if (_photo != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(File(_photo!),
                            height: 130, width: double.infinity, fit: BoxFit.cover),
                      ),
                    ),
                  if (_guess != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        '${s.t('ai_guess')}: ${s.t(kSoils[_guess!.soilIdx].key)}  '
                        '(${(_guess!.confidence * 100).round()}%)',
                        style: TextStyle(color: Pal.amber),
                      ),
                    ),
                  const SizedBox(height: 8),
                  Text(s.t('soil_title'),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  DropdownButton<int>(
                    isExpanded: true,
                    value: _soilIdx,
                    items: <DropdownMenuItem<int>>[
                      for (int i = 0; i < kSoils.length; i++)
                        DropdownMenuItem<int>(
                            value: i, child: Text(s.t(kSoils[i].key))),
                    ],
                    onChanged: (int? v) {
                      if (v != null) setState(() => _soilIdx = v);
                    },
                  ),
                  Text(_night ? s.t('ai_night_hint') : s.t('ai_photo_hint'),
                      style: TextStyle(color: Pal.muted, fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _calPanel(s),
            const SizedBox(height: 12),
            _plan(s),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
              onPressed: s.scanning ? null : () => _start(s),
              icon: const Icon(Icons.auto_awesome),
              label: Text(s.t('ai_start')),
            ),
            if (s.conn != ConnState.connected)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(s.t('ai_connect_first'),
                    style: TextStyle(color: Pal.amber, fontSize: 11)),
              ),
            if (canShow) ...<Widget>[
              const SizedBox(height: 12),
              _result(s),
            ],
            const SizedBox(height: 12),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _head(s.t('ai_learning'), Pal.violet),
                  Text('${s.t('ai_pkg_count')}: $_pkgCount',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(
                    s.learnedContrast == null
                        ? s.t('learn_need')
                        : '${s.t('learn_threshold')}: ${s.learnedContrast!.toStringAsFixed(1)}x',
                    style: TextStyle(color: Pal.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(s.t('ai_learning_note'),
                      style: TextStyle(color: Pal.muted, fontSize: 11)),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: TextButton.icon(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                            builder: (BuildContext c) => const TargetsScreen()),
                      ),
                      icon: const Icon(Icons.pin_drop_outlined, size: 18),
                      label: Text('${s.t('targets_open')} (${s.targets.length})'),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: TextButton.icon(
                      onPressed: _pkgCount == 0 ? null : _sharePackages,
                      icon: const Icon(Icons.ios_share, size: 18),
                      label: Text(s.t('ai_share_pkgs')),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Minimal camera page that returns the path of one ground photo.
class _SoilCapture extends StatefulWidget {
  const _SoilCapture();

  @override
  State<_SoilCapture> createState() => _SoilCaptureState();
}

class _SoilCaptureState extends State<_SoilCapture> {
  CameraController? _cam;
  String? _error;
  bool _taking = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final st = await Permission.camera.request();
      if (!st.isGranted) {
        if (mounted) setState(() => _error = 'camera_denied');
        return;
      }
      final cams = await availableCameras();
      if (cams.isEmpty) {
        if (mounted) setState(() => _error = 'camera_unavailable');
        return;
      }
      final back = cams.firstWhere(
        (CameraDescription c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cams.first,
      );
      final ctrl = CameraController(back, ResolutionPreset.medium,
          enableAudio: false);
      await ctrl.initialize();
      if (!mounted) {
        await ctrl.dispose();
        return;
      }
      setState(() => _cam = ctrl);
    } catch (_) {
      if (mounted) setState(() => _error = 'camera_unavailable');
    }
  }

  @override
  void dispose() {
    _cam?.dispose();
    super.dispose();
  }

  Future<void> _shot() async {
    final c = _cam;
    if (c == null || _taking) return;
    setState(() => _taking = true);
    try {
      final f = await c.takePicture();
      if (mounted) Navigator.of(context).pop(f.path);
    } catch (_) {
      if (mounted) setState(() => _taking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final c = _cam;
    return Scaffold(
      appBar: AppBar(title: Text(s.t('ai_take_photo'))),
      body: _error != null
          ? Center(child: Text(s.t(_error!)))
          : c == null
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: <Widget>[
                    Expanded(child: Center(child: CameraPreview(c))),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(s.t('ai_photo_hint'),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Pal.muted, fontSize: 12)),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: FloatingActionButton.large(
                        onPressed: _taking ? null : _shot,
                        child: const Icon(Icons.camera_alt),
                      ),
                    ),
                  ],
                ),
    );
  }
}
