import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme.dart';

/// Integer field with - / + buttons. The value is committed when the user
/// presses done or leaves the field, not on every keystroke.
class NumStepper extends StatefulWidget {
  const NumStepper({
    super.key,
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.enabled = true,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final bool enabled;
  final ValueChanged<int> onChanged;

  @override
  State<NumStepper> createState() => _NumStepperState();
}

class _NumStepperState extends State<NumStepper> {
  late final TextEditingController _c =
      TextEditingController(text: '${widget.value}');
  final FocusNode _f = FocusNode();

  @override
  void initState() {
    super.initState();
    _f.addListener(() {
      if (!_f.hasFocus) _commit();
    });
  }

  @override
  void didUpdateWidget(NumStepper old) {
    super.didUpdateWidget(old);
    if (!_f.hasFocus && _c.text != '${widget.value}') {
      _c.text = '${widget.value}';
    }
  }

  @override
  void dispose() {
    _c.dispose();
    _f.dispose();
    super.dispose();
  }

  void _commit() {
    final v = int.tryParse(_c.text.trim());
    final n = (v ?? widget.value).clamp(widget.min, widget.max).toInt();
    _c.text = '$n';
    if (n != widget.value) widget.onChanged(n);
  }

  void _step(int d) {
    final n = (widget.value + d).clamp(widget.min, widget.max).toInt();
    if (n != widget.value) widget.onChanged(n);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(widget.label,
                style: const TextStyle(color: Pal.muted)),
          ),
          IconButton(
            onPressed: widget.enabled ? () => _step(-1) : null,
            icon: const Icon(Icons.remove_circle_outline),
          ),
          SizedBox(
            width: 64,
            child: TextField(
              controller: _c,
              focusNode: _f,
              enabled: widget.enabled,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              textDirection: TextDirection.ltr,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
              ],
              decoration: const InputDecoration(
                isDense: true,
                contentPadding:
                    EdgeInsets.symmetric(vertical: 8, horizontal: 4),
              ),
              onSubmitted: (String _) => _commit(),
            ),
          ),
          IconButton(
            onPressed: widget.enabled ? () => _step(1) : null,
            icon: const Icon(Icons.add_circle_outline),
          ),
        ],
      ),
    );
  }
}
