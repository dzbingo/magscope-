import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../state.dart';
import '../theme.dart';
import '../dsp.dart';
import '../widgets.dart';

/// Live camera view with the detector readout drawn on top (a simple
/// "augmented" HUD): reading, metal/void verdict, signal trace and a small
/// map of the cells measured so far.
class CameraScanScreen extends StatefulWidget {
  const CameraScanScreen({super.key});

  @override
  State<CameraScanScreen> createState() => _CameraScanScreenState();
}

class _CameraScanScreenState extends State<CameraScanScreen> {
  CameraController? _cam;
  String? _error; // l10n key
  bool _torch = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final st = await Permission.camera.request();
      if (!st.isGranted) {
        if (mounted) setState(() => _error = 'camera_denied');
        return;
      }
      final cams = await availableCameras();
      if (cams.isEmpty) {
        if (mounted) setState(() => _error = 'camera_unavailable');
        return;
      }
      final back = cams.firstWhere(
        (CameraDescription c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cams.first,
      );
      final ctrl = CameraController(back, ResolutionPreset.high,
          enableAudio: false);
      await ctrl.initialize();
      if (!mounted) {
        await ctrl.dispose();
        return;
      }
      setState(() => _cam = ctrl);
    } catch (_) {
      if (mounted) setState(() => _error = 'camera_unavailable');
    }
  }

  @override
  void dispose() {
    _cam?.dispose();
    super.dispose();
  }

  Future<void> _toggleTorch() async {
    final c = _cam;
    if (c == null) return;
    try {
      _torch = !_torch;
      await c.setFlashMode(_torch ? FlashMode.torch : FlashMode.off);
      if (mounted) setState(() {});
    } catch (_) {
      _torch = false;
    }
  }

  Widget _glass(Widget child) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(150),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withAlpha(40)),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final cam = _cam;
    final filtered = s.filteredLive;
    final last = filtered.isEmpty ? double.nan : filtered.last;
    final alarmOn = s.alarm && s.conn == ConnState.connected;
    final accent = alarmOn ? (s.kind == 2 ? Pal.violet : Pal.bad) : Pal.amber;
    final devText = s.live.length < 20
        ? '--'
        : '${s.dev >= 0 ? '+' : ''}${s.dev.toStringAsFixed(2)}';

    Widget preview;
    if (_error != null) {
      preview = Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(s.t(_error!),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70)),
        ),
      );
    } else if (cam == null || !cam.value.isInitialized) {
      preview = const Center(child: CircularProgressIndicator());
    } else {
      preview = ClipRect(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: cam.value.previewSize?.height ?? 1,
            height: cam.value.previewSize?.width ?? 1,
            child: CameraPreview(cam),
          ),
        ),
      );
    }

    final cells = s.displayCells;
    final st = statsOf(cells);
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          preview,
          // alarm frame
          IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: alarmOn ? accent : Colors.transparent,
                  width: 6,
                ),
              ),
            ),
          ),
          // reticle
          IgnorePointer(
            child: CustomPaint(painter: _ReticlePainter(color: accent)),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      IconButton.filledTonal(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back),
                      ),
                      const Spacer(),
                      if (s.hasData)
                        SizedBox(
                          width: 96,
                          height: 96 * s.rows / s.cols > 140
                              ? 140
                              : 96 * s.rows / s.cols,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              color: Colors.black.withAlpha(150),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(4),
                              child: CustomPaint(
                                painter: HeatPainter(
                                  cells: cells,
                                  cols: s.cols,
                                  rows: s.rows,
                                  lo: lo,
                                  hi: hi,
                                  cursorX: s.cursor == null ? -1 : s.cursor![0],
                                  cursorY: s.cursor == null ? -1 : s.cursor![1],
                                ),
                              ),
                            ),
                          ),
                        ),
                      const SizedBox(width: 8),
                      IconButton.filledTonal(
                        tooltip: s.t('torch'),
                        onPressed: _toggleTorch,
                        icon: Icon(_torch ? Icons.flash_on : Icons.flash_off),
                      ),
                    ],
                  ),
                  const Spacer(),
                  _glass(
                    Column(
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Num(
                                    last.isNaN ? '--' : last.toStringAsFixed(2),
                                    style: TextStyle(
                                      color: accent,
                                      fontSize: 38,
                                      height: 1.0,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(s.t('unit'),
                                      style: const TextStyle(
                                          color: Colors.white70)),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: <Widget>[
                                Text(
                                  alarmOn
                                      ? s.t(s.kind == 1
                                          ? 'kind_metal'
                                          : 'kind_void')
                                      : s.t('kind_none'),
                                  style: TextStyle(
                                    color: alarmOn ? accent : Colors.white70,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Num(
                                  '${s.t('deviation')} $devText   '
                                  '${s.t('threshold')} ${s.threshold.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      color: Colors.white70, fontSize: 12),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          height: 70,
                          width: double.infinity,
                          child: CustomPaint(
                            painter: LinePainter(
                              raw: s.live,
                              filtered: filtered,
                              cursor: null,
                              baseline: s.baselineRef,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(50),
                          ),
                          onPressed: s.conn == ConnState.connecting
                              ? null
                              : () => s.conn == ConnState.connected
                                  ? s.disconnect()
                                  : s.connect(),
                          icon: Icon(s.conn == ConnState.connected
                              ? Icons.bluetooth_disabled
                              : Icons.bluetooth_connected),
                          label: Text(s.conn == ConnState.connected
                              ? s.t('disconnect')
                              : s.t('connect')),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filledTonal(
                        tooltip: s.t('calibrate'),
                        onPressed: s.live.length >= 10 ? s.calibrate : null,
                        icon: const Icon(Icons.my_location),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReticlePainter extends CustomPainter {
  _ReticlePainter({required this.color});
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide * 0.16;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..color = color;
    canvas.drawCircle(c, r, p);
    for (int i = 0; i < 4; i++) {
      final dir = <Offset>[
        const Offset(1, 0),
        const Offset(0, 1),
        const Offset(-1, 0),
        const Offset(0, -1),
      ][i];
      canvas.drawLine(c + dir * (r * 0.5), c + dir * (r * 1.5), p);
    }
    canvas.drawCircle(c, 3, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _ReticlePainter old) => old.color != color;
}
