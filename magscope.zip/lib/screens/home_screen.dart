import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Start screen: connection status on top, then a grid of big tiles.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onGo});

  /// Called with the page index the shell should open.
  final void Function(int index) onGo;

  Widget _status(AppState s) {
    final Color color;
    switch (s.conn) {
      case ConnState.connected:
        color = Pal.good;
        break;
      case ConnState.connecting:
        color = Pal.amber;
        break;
      case ConnState.error:
        color = Pal.bad;
        break;
      case ConnState.idle:
        color = Pal.muted;
        break;
    }
    final sub = s.useBle
        ? (s.deviceName.isEmpty ? s.t('no_selected') : s.deviceName)
        : s.t('status_sim');
    return Panel(
      glow: s.conn == ConnState.error ? Pal.bad : null,
      child: Row(
        children: <Widget>[
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: color.withAlpha(35),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withAlpha(140)),
            ),
            child: Icon(
              s.useBle ? Icons.bluetooth : Icons.science_outlined,
              color: color,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  s.useBle ? s.t('status_ble') : s.t('simulator'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 15),
                ),
                const SizedBox(height: 2),
                Text(sub,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Pal.muted, fontSize: 12)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: color.withAlpha(35),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withAlpha(140)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(Icons.circle, size: 9, color: color),
                const SizedBox(width: 6),
                Text(s.t(s.conn.name),
                    style: TextStyle(
                        color: color,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final tiles = <_TileData>[
      _TileData('home_live', 1, _Art.wave, Pal.amber),
      _TileData('home_map', 2, _Art.heat, Pal.violet),
      _TileData('home_analysis', 3, _Art.filter, Pal.good),
      _TileData('home_files', 4, _Art.folder, Pal.amber),
      _TileData('home_compass', 6, _Art.compass, Pal.violet),
      _TileData('home_settings', 5, _Art.gear, Pal.muted),
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        _status(s),
        const SizedBox(height: 14),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          childAspectRatio: 0.95,
          children: <Widget>[
            for (final t in tiles)
              _Tile(
                data: t,
                label: s.t(t.key),
                onTap: () => onGo(t.page),
              ),
          ],
        ),
      ],
    );
  }
}

enum _Art { wave, heat, filter, folder, compass, gear }

class _TileData {
  const _TileData(this.key, this.page, this.art, this.color);
  final String key;
  final int page;
  final _Art art;
  final Color color;
}

class _Tile extends StatelessWidget {
  const _Tile({required this.data, required this.label, required this.onTap});

  final _TileData data;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = data.color;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[Pal.surface2, Pal.surface],
          ),
          border: Border.all(color: c.withAlpha(70)),
          boxShadow: <BoxShadow>[
            BoxShadow(color: c.withAlpha(30), blurRadius: 18),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              width: 92,
              height: 92,
              child: CustomPaint(
                painter: _ArtPainter(data.art, c),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                label,
                textAlign: TextAlign.center,
                maxLines: 2,
                style:
                    const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Original tile artwork: a glowing ring with a small drawing inside.
class _ArtPainter extends CustomPainter {
  _ArtPainter(this.art, this.color);

  final _Art art;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 4;
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..color = color.withAlpha(60)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawCircle(c, r, Paint()..color = Pal.bg.withAlpha(200));
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..shader = SweepGradient(
          colors: <Color>[color, color.withAlpha(60), color],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
    canvas.save();
    canvas.translate(c.dx, c.dy);
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = color;
    switch (art) {
      case _Art.wave:
        final p = Path()..moveTo(-28, 0);
        const pts = <List<double>>[
          <double>[-20, 2],
          <double>[-14, -6],
          <double>[-8, 10],
          <double>[-2, -22],
          <double>[4, 18],
          <double>[10, -8],
          <double>[16, 4],
          <double>[28, 0],
        ];
        for (final q in pts) {
          p.lineTo(q[0], q[1]);
        }
        canvas.drawPath(p, stroke);
        break;
      case _Art.heat:
        for (int y = -2; y <= 2; y++) {
          for (int x = -2; x <= 2; x++) {
            final d = math.sqrt((x * x + y * y).toDouble());
            final v = (1 - d / 3).clamp(0.0, 1.0).toDouble();
            canvas.drawRRect(
              RRect.fromRectAndRadius(
                Rect.fromCenter(
                    center: Offset(x * 11.0, y * 11.0), width: 10, height: 10),
                const Radius.circular(3),
              ),
              Paint()..color = heatColor(v),
            );
          }
        }
        break;
      case _Art.filter:
        final p = Path()
          ..moveTo(-24, -20)
          ..lineTo(24, -20)
          ..lineTo(5, 2)
          ..lineTo(5, 22)
          ..lineTo(-5, 16)
          ..lineTo(-5, 2)
          ..close();
        canvas.drawPath(p, stroke);
        break;
      case _Art.folder:
        final p = Path()
          ..moveTo(-26, 18)
          ..lineTo(-26, -16)
          ..lineTo(-8, -16)
          ..lineTo(-2, -9)
          ..lineTo(26, -9)
          ..lineTo(26, 18)
          ..close();
        canvas.drawPath(p, stroke);
        canvas.drawCircle(const Offset(0, 5), 5, Paint()..color = color);
        break;
      case _Art.compass:
        canvas.drawCircle(Offset.zero, 26, stroke..strokeWidth = 2);
        final needleN = Path()
          ..moveTo(0, -22)
          ..lineTo(7, 0)
          ..lineTo(-7, 0)
          ..close();
        canvas.drawPath(needleN, Paint()..color = Pal.bad);
        final needleS = Path()
          ..moveTo(0, 22)
          ..lineTo(7, 0)
          ..lineTo(-7, 0)
          ..close();
        canvas.drawPath(needleS, Paint()..color = Pal.text);
        break;
      case _Art.gear:
        stroke.strokeWidth = 3;
        canvas.drawCircle(Offset.zero, 11, stroke);
        for (int i = 0; i < 8; i++) {
          final a = i * math.pi / 4;
          canvas.drawLine(
            Offset(math.cos(a) * 17, math.sin(a) * 17),
            Offset(math.cos(a) * 25, math.sin(a) * 25),
            stroke..strokeWidth = 5,
          );
        }
        break;
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ArtPainter old) =>
      old.art != art || old.color != color;
}
