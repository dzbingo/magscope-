import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Full-screen scan window: a big 2D map of the chosen grid that fills in
/// while the scan runs. Opened by the "start scan" button.
class ScanWindow extends StatelessWidget {
  const ScanWindow({super.key});

  Future<void> _confirmClose(BuildContext context, AppState s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(s.t('stop_3d')),
        content: Text(s.t('scan_stop_confirm')),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: Text(s.t('ok')),
          ),
        ],
      ),
    );
    if (ok == true) {
      s.stopScan();
      if (context.mounted) Navigator.of(context).pop();
    }
  }

  Widget _info(String label, Widget value) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style: TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          value,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    final total = s.totalCells;
    final filled = s.filledCells;
    final done = !s.scanning && s.cellIdx >= total && total > 0;
    final cells = s.cells;
    final valid = cells.where((e) => !e.isNaN).toList();

    double lo = 0;
    double hi = 1;
    double med = 0;
    if (valid.isNotEmpty) {
      final st = statsOf(valid);
      lo = st.min;
      hi = st.max;
      med = medianOf(valid);
      if (hi - lo < s.minSpan) {
        final mid = (hi + lo) / 2;
        lo = mid - s.minSpan / 2;
        hi = mid + s.minSpan / 2;
      }
    }
    final cur = s.cursor;
    final last = s.lastValue;
    final dv = last.isNaN || valid.isEmpty ? 0.0 : last - med;

    return PopScope(
      canPop: !s.scanning,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) _confirmClose(context, s);
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(s.t('scan_window')),
          actions: <Widget>[
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 6),
              child: Center(
                child: Num('$filled / $total',
                    style: TextStyle(
                        color: Pal.amber, fontWeight: FontWeight.w800)),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                if (s.scanning) {
                  _confirmClose(context, s);
                } else {
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Row(
                  children: <Widget>[
                    _info(
                      s.t('cell'),
                      Num(
                        cur == null
                            ? '--'
                            : '${cur[0] + 1}, ${cur[1] + 1}',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                    ),
                    _info(
                      s.t('reading'),
                      Num(
                        last.isNaN ? '--' : last.toStringAsFixed(2),
                        style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: Pal.amber),
                      ),
                    ),
                    _info(
                      s.t('deviation'),
                      Num(
                        last.isNaN
                            ? '--'
                            : '${dv >= 0 ? '+' : ''}${dv.toStringAsFixed(2)}',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: dv >= 0 ? Pal.amber : Pal.violet),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: LinearProgressIndicator(
                  value: total == 0 ? 0 : filled / total,
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(8),
                  color: Pal.violet,
                  backgroundColor: Pal.surface2,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Center(
                    child: AspectRatio(
                      aspectRatio: s.cols / s.rows,
                      child: CustomPaint(
                        painter: HeatPainter(
                          cells: cells,
                          cols: s.cols,
                          rows: s.rows,
                          lo: lo,
                          hi: hi,
                          cursorX: cur == null ? -1 : cur[0],
                          cursorY: cur == null ? -1 : cur[1],
                        ),
                        size: Size.infinite,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    if (done)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(s.t('scan_done'),
                            style: TextStyle(
                                color: Pal.good,
                                fontWeight: FontWeight.w800,
                                fontSize: 15)),
                      )
                    else
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          s.scanning ? s.t('scan_press_hint') : s.t('scan_paused'),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Pal.amber, fontSize: 12),
                        ),
                      ),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      alignment: WrapAlignment.center,
                      children: <Widget>[
                        FilledButton.tonalIcon(
                          onPressed: s.cellIdx > 0 ? s.prevCell : null,
                          icon: const Icon(Icons.skip_previous_rounded),
                          label: Text(s.t('prev_cell')),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: s.scanning ? s.nextCell : null,
                          icon: const Icon(Icons.skip_next_rounded),
                          label: Text(s.t('next_cell')),
                        ),
                        FilledButton.tonalIcon(
                          onPressed: s.scanning ? s.addReference : null,
                          icon: const Icon(Icons.my_location),
                          label: Text(
                              '${s.t('ref_reading')} (${s.driftRefs.length})'),
                        ),
                        FilterChip(
                          avatar: const Icon(Icons.volume_up, size: 18),
                          label: Text(s.t('tone')),
                          selected: s.toneOn,
                          onSelected: (bool v) => s.setToneOn(v),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    if (done)
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: FilledButton.icon(
                              style: FilledButton.styleFrom(
                                  minimumSize: const Size.fromHeight(52)),
                              onPressed: () => Navigator.of(context).pop('save'),
                              icon: const Icon(Icons.save_outlined),
                              label: Text(s.t('save')),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: FilledButton.styleFrom(
                                  minimumSize: const Size.fromHeight(52)),
                              onPressed: () => Navigator.of(context).pop(),
                              icon: const Icon(Icons.view_in_ar),
                              label: Text(s.t('view_results')),
                            ),
                          ),
                        ],
                      )
                    else if (s.scanning)
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          minimumSize: const Size.fromHeight(54),
                          backgroundColor: Pal.bad,
                          foregroundColor: Colors.white,
                        ),
                        onPressed: s.stopScan,
                        icon: const Icon(Icons.stop_rounded),
                        label: Text(s.t('stop_3d')),
                      )
                    else
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: FilledButton.icon(
                              style: FilledButton.styleFrom(
                                  minimumSize: const Size.fromHeight(52)),
                              onPressed: s.startScan,
                              icon: const Icon(Icons.play_arrow_rounded),
                              label: Text(s.t('resume_scan')),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: FilledButton.styleFrom(
                                  minimumSize: const Size.fromHeight(52)),
                              onPressed: () => Navigator.of(context).pop(),
                              icon: const Icon(Icons.close),
                              label: Text(s.t('close')),
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
