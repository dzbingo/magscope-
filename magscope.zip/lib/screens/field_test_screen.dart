import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

const List<String> kFtMetals = <String>[
  'iron', 'cast', 'stainless', 'copper', 'brass', 'alu', 'lead', 'magnet', 'other'
];
const List<String> kFtShapes = <String>[
  'bar', 'plate', 'sphere', 'tube', 'dumbbell', 'other'
];
const List<String> kFtOrient = <String>['ns', 'ew', 'vert', 'unk'];
const List<String> kFtMagnetic = <String>['yes', 'weak', 'no'];

/// Stored as plain JSON maps, independent from the scans.
class FieldTestStore {
  static const String _k = 'fieldtests';

  static Future<List<Map<String, dynamic>>> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_k);
      if (raw == null) return <Map<String, dynamic>>[];
      return (jsonDecode(raw) as List<dynamic>)
          .map((dynamic e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  static Future<void> save(List<Map<String, dynamic>> l) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_k, jsonEncode(l));
    } catch (_) {}
  }
}

double? _num(String t) => double.tryParse(t.trim().replaceAll(',', '.'));

/// List of real-metal tests with every detail of the target and the readings.
class FieldTestScreen extends StatefulWidget {
  const FieldTestScreen({super.key});

  @override
  State<FieldTestScreen> createState() => _FieldTestScreenState();
}

class _FieldTestScreenState extends State<FieldTestScreen> {
  List<Map<String, dynamic>> _items = <Map<String, dynamic>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await FieldTestStore.load();
    if (!mounted) return;
    setState(() {
      _items = l;
      _loaded = true;
    });
  }

  Future<void> _edit(Map<String, dynamic>? cur) async {
    final r = await Navigator.of(context).push<Map<String, dynamic>>(
      MaterialPageRoute<Map<String, dynamic>>(
        builder: (BuildContext c) => FieldTestForm(initial: cur),
      ),
    );
    if (r == null) return;
    final i = _items.indexWhere((Map<String, dynamic> e) => e['id'] == r['id']);
    setState(() {
      if (i >= 0) {
        _items[i] = r;
      } else {
        _items.insert(0, r);
      }
    });
    await FieldTestStore.save(_items);
  }

  Future<void> _share(Map<String, dynamic> it) async {
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/MagVisionPro_test_${it['id']}.json');
      await f.writeAsString(const JsonEncoder.withIndent('  ').convert(it));
      await Share.shareXFiles(<XFile>[XFile(f.path, mimeType: 'application/json')]);
    } catch (_) {}
  }

  Future<void> _delete(Map<String, dynamic> it) async {
    final s = AppScope.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        content: Text(s.t('ft_del_q')),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(s.t('cancel'))),
          TextButton(onPressed: () => Navigator.pop(c, true), child: Text(s.t('ft_delete'))),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _items.removeWhere((Map<String, dynamic> e) => e['id'] == it['id']));
    await FieldTestStore.save(_items);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('ft_title'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(null),
        icon: const Icon(Icons.add),
        label: Text(s.t('ft_new')),
      ),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? Center(child: Text(s.t('ft_empty'), style: TextStyle(color: Pal.muted)))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                  children: <Widget>[
                    for (final it in _items)
                      Panel(
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text('${it['name'] ?? ''}'),
                          subtitle: Text(
                            '${s.t('ft_m_${it['metal'] ?? 'other'}')}  ·  '
                            '${(it['reads'] as List<dynamic>? ?? <dynamic>[]).length} '
                            '${s.t('ft_readings_n')}  ·  ${'${it['date'] ?? ''}'.split('T').first}',
                            style: TextStyle(color: Pal.muted, fontSize: 12),
                          ),
                          onTap: () => _edit(it),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              IconButton(
                                tooltip: s.t('ft_share'),
                                icon: const Icon(Icons.ios_share),
                                onPressed: () => _share(it),
                              ),
                              IconButton(
                                tooltip: s.t('ft_delete'),
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () => _delete(it),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}

class _Row {
  _Row(String d, String v)
      : dist = TextEditingController(text: d),
        val = TextEditingController(text: v);
  final TextEditingController dist;
  final TextEditingController val;
  void dispose() {
    dist.dispose();
    val.dispose();
  }
}

class FieldTestForm extends StatefulWidget {
  const FieldTestForm({super.key, this.initial});
  final Map<String, dynamic>? initial;

  @override
  State<FieldTestForm> createState() => _FieldTestFormState();
}

class _FieldTestFormState extends State<FieldTestForm> {
  final Map<String, TextEditingController> _c = <String, TextEditingController>{};
  final List<_Row> _rows = <_Row>[];
  String _metal = 'iron';
  String _shape = 'bar';
  String _orient = 'unk';
  String _magnetic = 'yes';
  bool _rust = false;
  late final String _id;
  late final String _date;

  static const List<String> _textKeys = <String>[
    'name', 'len', 'wid', 'hei', 'weight', 'sensorH', 'burial', 'ground',
    'device', 'gain', 'notes', 'baseBefore', 'baseAfter'
  ];

  @override
  void initState() {
    super.initState();
    final m = widget.initial;
    _id = (m?['id'] as String?) ?? DateTime.now().millisecondsSinceEpoch.toString();
    _date = (m?['date'] as String?) ?? DateTime.now().toIso8601String();
    for (final k in _textKeys) {
      _c[k] = TextEditingController(text: m == null ? '' : '${m[k] ?? ''}');
    }
    if (m != null) {
      _metal = '${m['metal'] ?? 'iron'}';
      _shape = '${m['shape'] ?? 'bar'}';
      _orient = '${m['orient'] ?? 'unk'}';
      _magnetic = '${m['magnetic'] ?? 'yes'}';
      _rust = m['rust'] == true;
      for (final r in (m['reads'] as List<dynamic>? ?? <dynamic>[])) {
        final e = r as Map;
        _rows.add(_Row('${e['d'] ?? ''}', '${e['v'] ?? ''}'));
      }
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (widget.initial == null && (_c['ground']!.text.isEmpty) && (_c['device']!.text.isEmpty)) {
      final s = AppScope.of(context);
      _c['ground']!.text = s.t(s.soil.key);
      _c['device']!.text = s.deviceName;
    }
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    for (final r in _rows) {
      r.dispose();
    }
    super.dispose();
  }

  Widget _field(AppState s, String key, String label, {bool number = true, int lines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: _c[key],
        maxLines: lines,
        keyboardType: number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  Widget _drop(AppState s, String label, String value, List<String> keys,
      String prefix, ValueChanged<String> on) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DropdownButtonFormField<String>(
        value: value,
        isExpanded: true,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        items: <DropdownMenuItem<String>>[
          for (final k in keys)
            DropdownMenuItem<String>(value: k, child: Text(s.t('$prefix$k'))),
        ],
        onChanged: (String? v) {
          if (v != null) setState(() => on(v));
        },
      ),
    );
  }

  void _fill90() {
    setState(() {
      for (final r in _rows) {
        r.dispose();
      }
      _rows
        ..clear()
        ..addAll(<int>[90, 70, 50, 30, 20, 10, 5, 0].map((int d) => _Row('$d', '')));
    });
  }

  void _takeLive(_Row r) {
    final s = AppScope.of(context);
    final v = s.lastValue;
    if (v.isNaN || v.isInfinite) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ft_no_live'))));
      return;
    }
    setState(() => r.val.text = v.toStringAsFixed(v == v.roundToDouble() ? 0 : 1));
  }

  void _save() {
    final s = AppScope.of(context);
    final name = _c['name']!.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('ft_need_name'))));
      return;
    }
    final out = <String, dynamic>{
      'id': _id,
      'date': _date,
      'metal': _metal,
      'shape': _shape,
      'orient': _orient,
      'magnetic': _magnetic,
      'rust': _rust,
      'reads': <Map<String, dynamic>>[
        for (final r in _rows)
          if (_num(r.dist.text) != null && _num(r.val.text) != null)
            <String, dynamic>{'d': _num(r.dist.text), 'v': _num(r.val.text)},
      ],
    };
    const numeric = <String>[
      'len', 'wid', 'hei', 'weight', 'sensorH', 'burial', 'baseBefore', 'baseAfter'
    ];
    for (final k in _textKeys) {
      final t = _c[k]!.text.trim();
      out[k] = numeric.contains(k) ? (_num(t) ?? (t.isEmpty ? null : t)) : t;
    }
    Navigator.of(context).pop(out);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('ft_title')),
        actions: <Widget>[
          TextButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check),
            label: Text(s.t('ft_save')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          _field(s, 'name', s.t('ft_name'), number: false),
          SectionTitle(s.t('ft_sec_target')),
          _drop(s, s.t('ft_metal'), _metal, kFtMetals, 'ft_m_', (String v) => _metal = v),
          if (_metal == 'magnet')
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(s.t('ft_magnet_warn'),
                  style: TextStyle(color: Pal.amber, fontSize: 12)),
            ),
          _drop(s, s.t('ft_shape'), _shape, kFtShapes, 'ft_s_', (String v) => _shape = v),
          _field(s, 'len', s.t('ft_len')),
          _field(s, 'wid', s.t('ft_wid')),
          _field(s, 'hei', s.t('ft_hei')),
          _field(s, 'weight', s.t('ft_weight')),
          DropdownButtonFormField<String>(
            value: _magnetic,
            isExpanded: true,
            decoration: InputDecoration(
                labelText: s.t('ft_magnetic'), border: const OutlineInputBorder()),
            items: <DropdownMenuItem<String>>[
              for (final k in kFtMagnetic)
                DropdownMenuItem<String>(value: k, child: Text(s.t('ft_$k'))),
            ],
            onChanged: (String? v) {
              if (v != null) setState(() => _magnetic = v);
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('ft_rust')),
            value: _rust,
            onChanged: (bool v) => setState(() => _rust = v),
          ),
          const SizedBox(height: 8),
          SectionTitle(s.t('ft_sec_setup')),
          _field(s, 'sensorH', s.t('ft_sensor_h')),
          _field(s, 'burial', s.t('ft_burial')),
          _drop(s, s.t('ft_orient'), _orient, kFtOrient, 'ft_o_', (String v) => _orient = v),
          _field(s, 'ground', s.t('ft_ground'), number: false),
          _field(s, 'device', s.t('ft_device'), number: false),
          _field(s, 'gain', s.t('ft_gain'), number: false),
          const SizedBox(height: 8),
          SectionTitle(s.t('ft_sec_base')),
          Row(
            children: <Widget>[
              Expanded(child: _field(s, 'baseBefore', s.t('ft_base_before'))),
              const SizedBox(width: 10),
              Expanded(child: _field(s, 'baseAfter', s.t('ft_base_after'))),
            ],
          ),
          SectionTitle(s.t('ft_sec_reads')),
          for (int i = 0; i < _rows.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      controller: _rows[i].dist,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                          labelText: s.t('ft_dist'), border: const OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _rows[i].val,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                          labelText: s.t('ft_read'), border: const OutlineInputBorder()),
                    ),
                  ),
                  IconButton(
                    tooltip: s.t('ft_take'),
                    icon: const Icon(Icons.sensors),
                    onPressed: () => _takeLive(_rows[i]),
                  ),
                  IconButton(
                    tooltip: s.t('ft_delete'),
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _rows.removeAt(i).dispose()),
                  ),
                ],
              ),
            ),
          Wrap(
            spacing: 8,
            children: <Widget>[
              OutlinedButton.icon(
                onPressed: () => setState(() => _rows.add(_Row('', ''))),
                icon: const Icon(Icons.add),
                label: Text(s.t('ft_add_row')),
              ),
              OutlinedButton.icon(
                onPressed: _fill90,
                icon: const Icon(Icons.format_list_numbered),
                label: Text(s.t('ft_fill90')),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _field(s, 'notes', s.t('ft_notes'), number: false, lines: 3),
          const SizedBox(height: 60),
        ],
      ),
    );
  }
}
