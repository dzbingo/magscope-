import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'export_sheet.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  int _mode = 0;
  double _angle = 0.6;
  double _tilt = 0.5;
  double _height = 1.0;
  List<int>? _sel;
  final TransformationController _tc = TransformationController();
  double _zoom = 1.0;
  double _baseZoom = 1.0;

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Widget _chip(String label, String value) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style: const TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          Num(value,
              style: const TextStyle(
                  color: Pal.text, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.hasData) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            s.t('no_data'),
            textAlign: TextAlign.center,
            style: const TextStyle(color: Pal.muted),
          ),
        ),
      );
    }

    final cells = s.displayCells;
    final st = statsOf(cells);
    // Keep a minimum colour span so that plain sensor noise is not blown up
    // into a rainbow: only real changes should reach the hot colours.
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }
    final cur = s.cursor;
    final anomalies = s.gridAnomalies;

    final sel = (_sel != null && _sel![0] < s.cols && _sel![1] < s.rows)
        ? _sel
        : null;

    Widget selInfo;
    if (sel != null) {
      final v = cells[sel[1] * s.cols + sel[0]];
      final valid = cells.where((e) => !e.isNaN).toList();
      final med = valid.isEmpty ? 0.0 : medianOf(valid);
      final d = v - med;
      selInfo = Row(
        children: <Widget>[
          const Icon(Icons.place, size: 18, color: Pal.good),
          const SizedBox(width: 8),
          Text('${s.t('cell')} (${sel[0] + 1}, ${sel[1] + 1})'),
          const Spacer(),
          if (v.isNaN)
            Text(s.t('none_found'), style: const TextStyle(color: Pal.muted))
          else ...<Widget>[
            Num('${v.toStringAsFixed(2)} ${s.t('unit')}',
                style: const TextStyle(
                    color: Pal.text, fontWeight: FontWeight.w700)),
            const SizedBox(width: 10),
            Num('${d >= 0 ? '+' : ''}${d.toStringAsFixed(2)}',
                style: TextStyle(color: d >= 0 ? Pal.amber : Pal.violet)),
          ],
        ],
      );
    } else {
      selInfo = Text(
        _mode == 0 ? s.t('tap_cell') : s.t('drag_hint'),
        style: const TextStyle(color: Pal.muted, fontSize: 12),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        SegmentedButton<int>(
          segments: <ButtonSegment<int>>[
            ButtonSegment<int>(
              value: 0,
              label: Text(s.t('view_2d')),
              icon: const Icon(Icons.grid_on),
            ),
            ButtonSegment<int>(
              value: 1,
              label: Text(s.t('view_3d')),
              icon: const Icon(Icons.view_in_ar),
            ),
          ],
          selected: <int>{_mode},
          onSelectionChanged: (Set<int> v) => setState(() => _mode = v.first),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: TextButton.icon(
            onPressed: () => showExportSheet(
                context, s, s.snapshot('Scan_${stamp(DateTime.now())}')),
            icon: const Icon(Icons.ios_share, size: 18),
            label: Text(s.t('export')),
          ),
        ),
        Panel(
          padding: const EdgeInsets.all(10),
          child: _mode == 0
              ? GestureDetector(
                  onDoubleTap: () => _tc.value = Matrix4.identity(),
                  child: InteractiveViewer(
                    transformationController: _tc,
                    minScale: 1.0,
                    maxScale: 8.0,
                    child: AspectRatio(
                  aspectRatio: s.cols / s.rows,
                  child: LayoutBuilder(
                    builder: (BuildContext ctx, BoxConstraints c) {
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: (TapDownDetails d) {
                          final cw = c.maxWidth / s.cols;
                          final ch = c.maxHeight / s.rows;
                          final x = (d.localPosition.dx / cw).floor();
                          final y = (d.localPosition.dy / ch).floor();
                          if (x >= 0 && y >= 0 && x < s.cols && y < s.rows) {
                            setState(() => _sel = <int>[x, y]);
                          }
                        },
                        child: CustomPaint(
                          painter: HeatPainter(
                            cells: cells,
                            cols: s.cols,
                            rows: s.rows,
                            lo: lo,
                            hi: hi,
                            cursorX: cur == null ? -1 : cur[0],
                            cursorY: cur == null ? -1 : cur[1],
                            selX: sel == null ? -1 : sel[0],
                            selY: sel == null ? -1 : sel[1],
                            anomalies: anomalies,
                          ),
                          size: Size.infinite,
                        ),
                      );
                    },
                  ),
                ),
                  ),
                )
              : SizedBox(
                  height: 360,
                  width: double.infinity,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onDoubleTap: () => setState(() => _zoom = 1.0),
                    onScaleStart: (ScaleStartDetails d) => _baseZoom = _zoom,
                    onScaleUpdate: (ScaleUpdateDetails d) {
                      setState(() {
                        _zoom = (_baseZoom * d.scale).clamp(0.6, 4.0).toDouble();
                        _angle += d.focalPointDelta.dx * 0.012;
                        _tilt = (_tilt + d.focalPointDelta.dy * 0.003)
                            .clamp(0.22, 0.9)
                            .toDouble();
                      });
                    },
                    child: ClipRect(
                      child: Transform.scale(
                        scale: _zoom,
                        child: CustomPaint(
                      painter: IsoPainter(
                        cells: cells,
                        cols: s.cols,
                        rows: s.rows,
                        lo: lo,
                        hi: hi,
                        angle: _angle,
                        heightScale: _height,
                        tilt: _tilt,
                      ),
                      size: Size.infinite,
                    ),
                      ),
                    ),
                  ),
                ),
        ),
        const SizedBox(height: 4),
        Text(s.t('zoom_hint'),
            textAlign: TextAlign.center,
            style: const TextStyle(color: Pal.muted, fontSize: 11)),
        const SizedBox(height: 12),
        HeatLegend(lo: lo, hi: hi),
        Row(
          children: <Widget>[
            Text(s.t('palette'),
                style: const TextStyle(color: Pal.muted, fontSize: 12)),
            const Spacer(),
            for (int i = 0; i < kPalettes.length; i++)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Tooltip(
                  message: s.t('pal_$i'),
                  child: GestureDetector(
                    onTap: () => s.setPalette(i),
                    child: Container(
                      width: 34,
                      height: 22,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        gradient: LinearGradient(colors: kPalettes[i]),
                        border: Border.all(
                          color: s.palette == i ? Pal.text : Pal.outline,
                          width: s.palette == i ? 2 : 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
        Row(
          children: <Widget>[
            Text(s.t('color_range'),
                style: const TextStyle(color: Pal.muted, fontSize: 12)),
            Expanded(
              child: Slider(
                value: s.minSpan.clamp(0.5, 10.0).toDouble(),
                min: 0.5,
                max: 10.0,
                onChanged: s.setMinSpan,
              ),
            ),
            SizedBox(
              width: 58,
              child: Num('${s.minSpan.toStringAsFixed(1)} ${s.t('unit')}',
                  style: const TextStyle(color: Pal.muted, fontSize: 11)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  _chip(s.t('min'), st.min.toStringAsFixed(2)),
                  _chip(s.t('max'), st.max.toStringAsFixed(2)),
                  _chip(s.t('mean'), st.mean.toStringAsFixed(2)),
                  _chip(s.t('anomalies'), '${anomalies.length}'),
                ],
              ),
              const SizedBox(height: 12),
              selInfo,
            ],
          ),
        ),
        if (_mode == 1) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 80,
                      child: Text(s.t('rotation'),
                          style: const TextStyle(color: Pal.muted)),
                    ),
                    Expanded(
                      child: Slider(
                        value: (_angle % 6.283).clamp(0.0, 6.283).toDouble(),
                        min: 0,
                        max: 6.283,
                        onChanged: (double v) => setState(() => _angle = v),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 80,
                      child: Text(s.t('height'),
                          style: const TextStyle(color: Pal.muted)),
                    ),
                    Expanded(
                      child: Slider(
                        value: _height,
                        min: 0.2,
                        max: 2.0,
                        onChanged: (double v) => setState(() => _height = v),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
