import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'camera_screen.dart';
import 'corners_panel.dart';
import 'geo_screen.dart';
import 'iso_view.dart';
import 'num_stepper.dart';
import 'scan_window.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  int _mode = 1; // 0 = 2D, 1 = 3D, 2 = solid columns
  List<int>? _sel;
  final TransformationController _tc = TransformationController();

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Widget _chip(String label, String value) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style:  TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          Num(value,
              style:  TextStyle(
                  color: Pal.text, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Future<void> _save(AppState s) async {
    final ctrl = TextEditingController(text: 'Scan_${stamp(DateTime.now())}');
    final name = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(s.t('session_name')),
        content: TextField(controller: ctrl, autofocus: true),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: Text(s.t('save')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (name == null || name.isEmpty) return;
    await s.saveCurrent(name);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  /// Saves the finished scan by itself and tells the user.
  Future<void> _autoSave(AppState s) async {
    if (!s.hasData) return;
    await s.saveCurrent('Scan_${stamp(DateTime.now())}');
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  /// Starts the scan and opens the full-screen scan window.
  Future<void> _begin(AppState s) async {
    await s.startScan();
    if (!s.scanning || !mounted) return;
    await _openWindow(s);
  }

  Future<void> _openWindow(AppState s) async {
    final r = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        fullscreenDialog: true,
        builder: (BuildContext c) => const ScanWindow(),
      ),
    );
    if (r == 'save' && mounted) await _autoSave(s);
  }

  /// Everything needed to prepare and run a 3D scan, in one place.
  Widget _scanPanel(AppState s) {
    final filled = s.filledCells;
    final progress = s.totalCells == 0 ? 0.0 : filled / s.totalCells;
    final connected = s.conn == ConnState.connected;
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: SectionTitle(s.t('scan_setup'))),
              Num('$filled / ${s.totalCells}',
                  style: TextStyle(
                      color: Pal.text, fontWeight: FontWeight.w700)),
            ],
          ),
          NumStepper(
            label: s.t('columns'),
            value: s.cols,
            min: 2,
            max: 48,
            enabled: !s.scanning,
            onChanged: (int v) => s.setGrid(v, s.rows),
          ),
          NumStepper(
            label: s.t('rows'),
            value: s.rows,
            min: 2,
            max: 48,
            enabled: !s.scanning,
            onChanged: (int v) => s.setGrid(s.cols, v),
          ),
          NumStepper(
            label: s.t('spc_label'),
            value: s.samplesPerCell,
            min: 1,
            max: 200,
            onChanged: s.setSamplesPerCell,
          ),
          SoilAndStep(stepEnabled: !s.scanning, showSoil: false),
          NumStepper(
            label: s.t('ignore_below'),
            value: s.ignoreBelow,
            min: 0,
            max: 255,
            onChanged: s.setIgnoreBelow,
          ),
          Text(s.t('ignore_below_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            title: Text(s.t('thr_manual')),
            subtitle: Text(s.t('thr_manual_hint'),
                style: TextStyle(color: Pal.muted, fontSize: 11)),
            value: s.manualThr,
            onChanged: s.setManualThr,
          ),
          if (s.manualThr)
            Row(
              children: <Widget>[
                SizedBox(
                  width: 110,
                  child: Text(s.t('thr_value'),
                      style: TextStyle(color: Pal.muted)),
                ),
                Expanded(
                  child: Slider(
                    value: s.thrUT.clamp(0.1, 20.0).toDouble(),
                    min: 0.1,
                    max: 20,
                    onChanged: s.setThrUT,
                  ),
                ),
                SizedBox(
                  width: 56,
                  child: Num(s.thrUT.toStringAsFixed(1)),
                ),
              ],
            ),
          const Divider(),
          const CornersPanel(),
          const Divider(),
          const SizedBox(height: 6),
          Text(s.t('path_hint'),
              style: TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 6),
          SegmentedButton<bool>(
            segments: <ButtonSegment<bool>>[
              ButtonSegment<bool>(value: false, label: Text(s.t('dir_ltr'))),
              ButtonSegment<bool>(value: true, label: Text(s.t('dir_rtl'))),
            ],
            selected: <bool>{s.rtl},
            onSelectionChanged:
                s.scanning ? null : (Set<bool> v) => s.setRtl(v.first),
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            borderRadius: BorderRadius.circular(8),
            color: Pal.violet,
            backgroundColor: Pal.surface2,
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              backgroundColor: s.scanning ? Pal.bad : null,
              foregroundColor: s.scanning ? Colors.white : null,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              textStyle:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            onPressed: s.conn == ConnState.connecting
                ? null
                : () => s.scanning ? s.stopScan() : _begin(s),
            icon: Icon(
                s.scanning ? Icons.stop_rounded : Icons.play_arrow_rounded),
            label: Text(s.scanning ? s.t('stop_3d') : s.t('start_3d')),
          ),
          if (!s.scanning) ...<Widget>[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                    builder: (BuildContext c) => const CameraScanScreen()),
              ),
              icon: const Icon(Icons.photo_camera_outlined, size: 18),
              label: Text(s.t('camera_scan')),
            ),
          ],
          const SizedBox(height: 8),
          Text(
            s.scanning
                ? s.t('scan_press_hint')
                : (connected ? s.t('connected') : s.t(s.conn.name)),
            style: TextStyle(
                color: s.scanning ? Pal.amber : Pal.muted, fontSize: 11),
          ),
          if (s.errorKey != null && !connected) ...<Widget>[
            const SizedBox(height: 6),
            Text(s.t(s.errorKey!),
                style: TextStyle(color: Pal.bad, fontSize: 12)),
            if (s.errorDetail.isNotEmpty)
              SelectableText(s.errorDetail,
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Pal.muted, fontSize: 10)),
          ],
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: FilledButton.tonal(
                  onPressed: s.cellIdx > 0 ? s.prevCell : null,
                  child: Text(s.t('prev_cell'), maxLines: 1),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: FilledButton.tonal(
                  onPressed: s.scanning ? null : s.clearData,
                  child: Text(s.t('clear'), maxLines: 1),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: FilledButton.tonal(
                  onPressed: s.scanning ? s.nextCell : null,
                  child: Text(s.t('next_cell'), maxLines: 1),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              if (s.scanning)
                FilledButton.tonalIcon(
                  onPressed: () => _openWindow(s),
                  icon: const Icon(Icons.open_in_full),
                  label: Text(s.t('scan_window')),
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.hasData) {
      return ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          _scanPanel(s),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              s.t('no_data'),
              textAlign: TextAlign.center,
              style: TextStyle(color: Pal.muted),
            ),
          ),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        _scanPanel(s),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            s.t('scan_only_hint'),
            textAlign: TextAlign.center,
            style: TextStyle(color: Pal.muted, fontSize: 12),
          ),
        ),
      ],
    );
  }
}
