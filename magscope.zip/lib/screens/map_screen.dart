import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'camera_screen.dart';
import 'export_sheet.dart';
import 'iso_view.dart';
import 'num_stepper.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  int _mode = 1; // 0 = 2D, 1 = 3D, 2 = solid columns
  List<int>? _sel;
  final TransformationController _tc = TransformationController();

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  Widget _chip(String label, String value) {
    return Expanded(
      child: Column(
        children: <Widget>[
          Text(label, style:  TextStyle(color: Pal.muted, fontSize: 11)),
          const SizedBox(height: 3),
          Num(value,
              style:  TextStyle(
                  color: Pal.text, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Future<void> _save(AppState s) async {
    final ctrl = TextEditingController(text: 'Scan_${stamp(DateTime.now())}');
    final name = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(s.t('session_name')),
        content: TextField(controller: ctrl, autofocus: true),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: Text(s.t('save')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (name == null || name.isEmpty) return;
    await s.saveCurrent(name);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('saved'))));
  }

  Future<void> _jump(AppState s) async {
    final ctrl = TextEditingController(text: '${s.cellIdx + 1}');
    final txt = await showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text('${s.t('go_cell')} (1 - ${s.totalCells})'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          textDirection: TextDirection.ltr,
          decoration: InputDecoration(labelText: s.t('cell_number')),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(s.t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
            child: Text(s.t('ok')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    final n = int.tryParse(txt ?? '');
    if (n != null) s.jumpToCell(n);
  }

  /// Everything needed to prepare and run a 3D scan, in one place.
  Widget _scanPanel(AppState s) {
    final filled = s.filledCells;
    final progress = s.totalCells == 0 ? 0.0 : filled / s.totalCells;
    final connected = s.conn == ConnState.connected;
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: SectionTitle(s.t('scan_setup'))),
              Num('$filled / ${s.totalCells}',
                  style: TextStyle(
                      color: Pal.text, fontWeight: FontWeight.w700)),
            ],
          ),
          NumStepper(
            label: s.t('columns'),
            value: s.cols,
            min: 2,
            max: 48,
            enabled: !s.scanning,
            onChanged: (int v) => s.setGrid(v, s.rows),
          ),
          NumStepper(
            label: s.t('rows'),
            value: s.rows,
            min: 2,
            max: 48,
            enabled: !s.scanning,
            onChanged: (int v) => s.setGrid(s.cols, v),
          ),
          NumStepper(
            label: s.t('spc_label'),
            value: s.samplesPerCell,
            min: 1,
            max: 200,
            onChanged: s.setSamplesPerCell,
          ),
          const SizedBox(height: 6),
          SegmentedButton<bool>(
            segments: <ButtonSegment<bool>>[
              ButtonSegment<bool>(
                  value: true, label: Text(s.t('path_zigzag'))),
              ButtonSegment<bool>(
                  value: false, label: Text(s.t('path_parallel'))),
            ],
            selected: <bool>{s.zigzag},
            onSelectionChanged:
                s.scanning ? null : (Set<bool> v) => s.setZigzag(v.first),
          ),
          const SizedBox(height: 8),
          SegmentedButton<bool>(
            segments: <ButtonSegment<bool>>[
              ButtonSegment<bool>(value: false, label: Text(s.t('dir_ltr'))),
              ButtonSegment<bool>(value: true, label: Text(s.t('dir_rtl'))),
            ],
            selected: <bool>{s.rtl},
            onSelectionChanged:
                s.scanning ? null : (Set<bool> v) => s.setRtl(v.first),
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            borderRadius: BorderRadius.circular(8),
            color: Pal.violet,
            backgroundColor: Pal.surface2,
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              backgroundColor: s.scanning ? Pal.bad : null,
              foregroundColor: s.scanning ? Colors.white : null,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              textStyle:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            onPressed: s.conn == ConnState.connecting
                ? null
                : () => s.scanning ? s.stopScan() : s.startScan(),
            icon: Icon(
                s.scanning ? Icons.stop_rounded : Icons.play_arrow_rounded),
            label: Text(s.scanning ? s.t('stop_3d') : s.t('start_3d')),
          ),
          const SizedBox(height: 8),
          Text(
            s.scanning
                ? s.t('scan_press_hint')
                : (connected ? s.t('connected') : s.t(s.conn.name)),
            style: TextStyle(
                color: s.scanning ? Pal.amber : Pal.muted, fontSize: 11),
          ),
          if (s.errorKey != null && !connected) ...<Widget>[
            const SizedBox(height: 6),
            Text(s.t(s.errorKey!),
                style: TextStyle(color: Pal.bad, fontSize: 12)),
            if (s.errorDetail.isNotEmpty)
              SelectableText(s.errorDetail,
                  textDirection: TextDirection.ltr,
                  style: TextStyle(color: Pal.muted, fontSize: 10)),
          ],
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              FilledButton.tonalIcon(
                onPressed: s.cellIdx > 0 ? s.prevCell : null,
                icon: const Icon(Icons.skip_previous_rounded),
                label: Text(s.t('prev_cell')),
              ),
              FilledButton.tonalIcon(
                onPressed: () => _jump(s),
                icon: const Icon(Icons.pin_drop_outlined),
                label: Text(s.t('go_cell')),
              ),
              FilledButton.tonalIcon(
                onPressed: s.scanning ? s.nextCell : null,
                icon: const Icon(Icons.skip_next_rounded),
                label: Text(s.t('next_cell')),
              ),
              FilledButton.tonalIcon(
                onPressed: s.hasData ? () => _save(s) : null,
                icon: const Icon(Icons.save_outlined),
                label: Text(s.t('save')),
              ),
              FilledButton.tonalIcon(
                onPressed: s.scanning ? null : s.clearData,
                icon: const Icon(Icons.delete_sweep_outlined),
                label: Text(s.t('clear')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.hasData) {
      return ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          _scanPanel(s),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              s.t('no_data'),
              textAlign: TextAlign.center,
              style: TextStyle(color: Pal.muted),
            ),
          ),
        ],
      );
    }

    final cells = s.displayCells;
    final st = statsOf(cells);
    // Keep a minimum colour span so that plain sensor noise is not blown up
    // into a rainbow: only real changes should reach the hot colours.
    double lo = st.min;
    double hi = st.max;
    if (hi - lo < s.minSpan) {
      final mid = (hi + lo) / 2;
      lo = mid - s.minSpan / 2;
      hi = mid + s.minSpan / 2;
    }
    final cur = s.cursor;
    final anomalies = s.gridAnomalies;

    final sel = (_sel != null && _sel![0] < s.cols && _sel![1] < s.rows)
        ? _sel
        : null;

    Widget selInfo;
    if (sel != null) {
      final v = cells[sel[1] * s.cols + sel[0]];
      final valid = cells.where((e) => !e.isNaN).toList();
      final med = valid.isEmpty ? 0.0 : medianOf(valid);
      final d = v - med;
      selInfo = Row(
        children: <Widget>[
           Icon(Icons.place, size: 18, color: Pal.good),
          const SizedBox(width: 8),
          Text('${s.t('cell')} (${sel[0] + 1}, ${sel[1] + 1})'),
          const Spacer(),
          if (v.isNaN)
            Text(s.t('none_found'), style:  TextStyle(color: Pal.muted))
          else ...<Widget>[
            Num('${v.toStringAsFixed(2)} ${s.t('unit')}',
                style:  TextStyle(
                    color: Pal.text, fontWeight: FontWeight.w700)),
            const SizedBox(width: 10),
            Num('${d >= 0 ? '+' : ''}${d.toStringAsFixed(2)}',
                style: TextStyle(color: d >= 0 ? Pal.amber : Pal.violet)),
          ],
        ],
      );
    } else {
      selInfo = Text(
        _mode == 0 ? s.t('tap_cell') : s.t('drag_hint'),
        style:  TextStyle(color: Pal.muted, fontSize: 12),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        _scanPanel(s),
        const SizedBox(height: 12),
        SegmentedButton<int>(
          segments: <ButtonSegment<int>>[
            ButtonSegment<int>(
              value: 0,
              label: Text(s.t('view_2d')),
              icon: const Icon(Icons.grid_on),
            ),
            ButtonSegment<int>(
              value: 1,
              label: Text(s.t('view_3d')),
              icon: const Icon(Icons.view_in_ar),
            ),
            ButtonSegment<int>(
              value: 2,
              label: Text(s.t('view_solid')),
              icon: const Icon(Icons.view_module),
            ),
          ],
          selected: <int>{_mode},
          onSelectionChanged: (Set<int> v) => setState(() => _mode = v.first),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerEnd,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                      builder: (BuildContext c) => const CameraScanScreen()),
                ),
                icon: const Icon(Icons.photo_camera_outlined, size: 18),
                label: Text(s.t('camera_view')),
              ),
              TextButton.icon(
            onPressed: () => showExportSheet(
                context, s, s.snapshot('Scan_${stamp(DateTime.now())}')),
            icon: const Icon(Icons.ios_share, size: 18),
            label: Text(s.t('export')),
          ),
            ],
          ),
        ),
        Panel(
          padding: const EdgeInsets.all(10),
          child: _mode == 0
              ? GestureDetector(
                  onDoubleTap: () => _tc.value = Matrix4.identity(),
                  child: InteractiveViewer(
                    transformationController: _tc,
                    minScale: 1.0,
                    maxScale: 8.0,
                    child: AspectRatio(
                  aspectRatio: s.cols / s.rows,
                  child: LayoutBuilder(
                    builder: (BuildContext ctx, BoxConstraints c) {
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: (TapDownDetails d) {
                          final cw = c.maxWidth / s.cols;
                          final ch = c.maxHeight / s.rows;
                          final x = (d.localPosition.dx / cw).floor();
                          final y = (d.localPosition.dy / ch).floor();
                          if (x >= 0 && y >= 0 && x < s.cols && y < s.rows) {
                            setState(() => _sel = <int>[x, y]);
                          }
                        },
                        child: withSatBackdrop(
                          s,
                          CustomPaint(
                            painter: HeatPainter(
                              cells: cells,
                              cols: s.cols,
                              rows: s.rows,
                              lo: lo,
                              hi: hi,
                              cursorX: cur == null ? -1 : cur[0],
                              cursorY: cur == null ? -1 : cur[1],
                              selX: sel == null ? -1 : sel[0],
                              selY: sel == null ? -1 : sel[1],
                              anomalies: anomalies,
                            ),
                            size: Size.infinite,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                  ),
                )
              : Iso3DView(
                  cells: cells,
                  lo: lo,
                  hi: hi,
                  height: 360,
                  solid: _mode == 2,
                ),
        ),
        if (_mode == 0) ...<Widget>[
          const SizedBox(height: 4),
          Text(s.t('zoom_hint'),
              textAlign: TextAlign.center,
              style: TextStyle(color: Pal.muted, fontSize: 11)),
        ],
        const SizedBox(height: 12),
        const Panel(child: SatelliteControls()),
        const SizedBox(height: 12),
        HeatLegend(lo: lo, hi: hi),
        Row(
          children: <Widget>[
            Text(s.t('palette'),
                style:  TextStyle(color: Pal.muted, fontSize: 12)),
            const Spacer(),
            for (int i = 0; i < kPalettes.length; i++)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Tooltip(
                  message: s.t('pal_$i'),
                  child: GestureDetector(
                    onTap: () => s.setPalette(i),
                    child: Container(
                      width: 34,
                      height: 22,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        gradient: LinearGradient(colors: kPalettes[i]),
                        border: Border.all(
                          color: s.palette == i ? Pal.text : Pal.outline,
                          width: s.palette == i ? 2 : 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
        Row(
          children: <Widget>[
            Text(s.t('color_range'),
                style:  TextStyle(color: Pal.muted, fontSize: 12)),
            Expanded(
              child: Slider(
                value: s.minSpan.clamp(0.5, 10.0).toDouble(),
                min: 0.5,
                max: 10.0,
                onChanged: s.setMinSpan,
              ),
            ),
            SizedBox(
              width: 58,
              child: Num('${s.minSpan.toStringAsFixed(1)} ${s.t('unit')}',
                  style:  TextStyle(color: Pal.muted, fontSize: 11)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  _chip(s.t('min'), st.min.toStringAsFixed(2)),
                  _chip(s.t('max'), st.max.toStringAsFixed(2)),
                  _chip(s.t('mean'), st.mean.toStringAsFixed(2)),
                  _chip(s.t('anomalies'), '${anomalies.length}'),
                ],
              ),
              const SizedBox(height: 12),
              selInfo,
            ],
          ),
        ),
      ],
    );
  }
}
