import 'package:flutter/material.dart';

import '../dsp.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  int _mode = 0;
  double _angle = 0.6;
  double _height = 1.0;

  @override
  Widget build(BuildContext context) {
    final s = AppScope.of(context);
    if (!s.hasData) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            s.t('no_data'),
            textAlign: TextAlign.center,
            style: const TextStyle(color: Pal.muted),
          ),
        ),
      );
    }

    final cells = s.displayCells;
    final st = statsOf(cells);
    final lo = st.min;
    final hi = (st.max - st.min) < 0.1 ? st.min + 0.1 : st.max;
    final cur = s.cursor;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        SegmentedButton<int>(
          segments: <ButtonSegment<int>>[
            ButtonSegment<int>(
              value: 0,
              label: Text(s.t('view_2d')),
              icon: const Icon(Icons.grid_on),
            ),
            ButtonSegment<int>(
              value: 1,
              label: Text(s.t('view_3d')),
              icon: const Icon(Icons.view_in_ar),
            ),
          ],
          selected: <int>{_mode},
          onSelectionChanged: (Set<int> v) => setState(() => _mode = v.first),
        ),
        const SizedBox(height: 12),
        Panel(
          padding: const EdgeInsets.all(10),
          child: _mode == 0
              ? AspectRatio(
                  aspectRatio: s.cols / s.rows,
                  child: CustomPaint(
                    painter: HeatPainter(
                      cells: cells,
                      cols: s.cols,
                      rows: s.rows,
                      lo: lo,
                      hi: hi,
                      cursorX: cur == null ? -1 : cur[0],
                      cursorY: cur == null ? -1 : cur[1],
                    ),
                    size: Size.infinite,
                  ),
                )
              : SizedBox(
                  height: 340,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: IsoPainter(
                      cells: cells,
                      cols: s.cols,
                      rows: s.rows,
                      lo: lo,
                      hi: hi,
                      angle: _angle,
                      heightScale: _height,
                    ),
                    size: Size.infinite,
                  ),
                ),
        ),
        const SizedBox(height: 12),
        HeatLegend(lo: lo, hi: hi),
        if (_mode == 1) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 80,
                      child: Text(s.t('rotation'),
                          style: const TextStyle(color: Pal.muted)),
                    ),
                    Expanded(
                      child: Slider(
                        value: _angle,
                        min: 0,
                        max: 6.283,
                        onChanged: (double v) => setState(() => _angle = v),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 80,
                      child: Text(s.t('height'),
                          style: const TextStyle(color: Pal.muted)),
                    ),
                    Expanded(
                      child: Slider(
                        value: _height,
                        min: 0.2,
                        max: 2.0,
                        onChanged: (double v) => setState(() => _height = v),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
