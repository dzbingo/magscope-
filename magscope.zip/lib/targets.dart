import 'dart:io';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';

import 'storage.dart';

/// A spot found by a scan that the examiner wants to come back to.
class FieldTarget {
  FieldTarget({
    required this.id,
    required this.lat,
    required this.lon,
    required this.createdAt,
    this.note = '',
    this.verdict = 0,
    this.contrast = 0,
    this.depthMin,
    this.depthMax,
    this.kindKey = '',
    this.sessionName = '',
  });

  final int id;
  final double lat;
  final double lon;
  final DateTime createdAt;
  String note;

  /// 0 = not checked yet, 1 = dug: real, 2 = dug: false.
  int verdict;
  final double contrast;
  final double? depthMin;
  final double? depthMax;
  final String kindKey;
  final String sessionName;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'lat': lat,
        'lon': lon,
        't': createdAt.millisecondsSinceEpoch,
        'note': note,
        'v': verdict,
        'c': contrast,
        if (depthMin != null) 'dmin': depthMin,
        if (depthMax != null) 'dmax': depthMax,
        'k': kindKey,
        's': sessionName,
      };

  static FieldTarget fromJson(Map<String, dynamic> j) => FieldTarget(
        id: (j['id'] as num).toInt(),
        lat: (j['lat'] as num).toDouble(),
        lon: (j['lon'] as num).toDouble(),
        createdAt:
            DateTime.fromMillisecondsSinceEpoch((j['t'] as num).toInt()),
        note: (j['note'] ?? '').toString(),
        verdict: (j['v'] as num?)?.toInt() ?? 0,
        contrast: (j['c'] as num?)?.toDouble() ?? 0,
        depthMin: (j['dmin'] as num?)?.toDouble(),
        depthMax: (j['dmax'] as num?)?.toDouble(),
        kindKey: (j['k'] ?? '').toString(),
        sessionName: (j['s'] ?? '').toString(),
      );
}

class TargetGeo {
  /// Distance in metres between two GPS points (haversine).
  static double distance(double lat1, double lon1, double lat2, double lon2) {
    const r = 6371000.0;
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dp = (lat2 - lat1) * math.pi / 180;
    final dl = (lon2 - lon1) * math.pi / 180;
    final a = math.sin(dp / 2) * math.sin(dp / 2) +
        math.cos(p1) * math.cos(p2) * math.sin(dl / 2) * math.sin(dl / 2);
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  /// Initial bearing in degrees (0..360, clockwise from north).
  static double bearing(double lat1, double lon1, double lat2, double lon2) {
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dl = (lon2 - lon1) * math.pi / 180;
    final y = math.sin(dl) * math.cos(p2);
    final x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl);
    return ((math.atan2(y, x) * 180 / math.pi) % 360 + 360) % 360;
  }

  static String _esc(String v) => v
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  /// Writes the targets as a KML file (Google Earth / Maps) and returns its path.
  static Future<String> writeKml(List<FieldTarget> list) async {
    final b = StringBuffer()
      ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
      ..writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document>')
      ..writeln('<name>MagVision Pro targets</name>');
    for (final t in list) {
      final v = t.verdict == 1 ? 'real' : (t.verdict == 2 ? 'false' : 'unchecked');
      final depth = (t.depthMin != null && t.depthMax != null)
          ? 'depth ${t.depthMin!.toStringAsFixed(1)}-${t.depthMax!.toStringAsFixed(1)} m; '
          : '';
      b.writeln('<Placemark><name>Target ${t.id} ($v)</name>'
          '<description>${_esc('$depth${t.note}')}</description>'
          '<Point><coordinates>${t.lon.toStringAsFixed(7)},${t.lat.toStringAsFixed(7)},0</coordinates></Point>'
          '</Placemark>');
    }
    b.writeln('</Document></kml>');
    Directory? d;
    try {
      d = await AppFolders.root();
    } catch (_) {}
    d ??= await getApplicationDocumentsDirectory();
    final path = '${d.path}/targets_${DateTime.now().millisecondsSinceEpoch}.kml';
    await File(path).writeAsString(b.toString());
    return path;
  }
}
